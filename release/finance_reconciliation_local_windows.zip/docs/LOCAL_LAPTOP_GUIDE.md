# Run the synthetic finance demo on a Windows laptop

## Recommended: local web app

1. Install an organization-approved Python 3.11 or newer and make its `py` launcher or `python` command available. Python 3.13 is the version used for this project's local checks.
2. On the hosted demo's **My Home** page, select **Download Windows bundle**. Copy the ZIP to a writable folder on the laptop and extract **all** files. The archive contains the compiled UI; Node.js and Git are not required to run it.
3. Run these standalone scripts in order from the extracted folder:
   - `01_Check_Prerequisites.cmd` confirms Python and the compiled UI files.
   - `02_Install_Local_Runtime.cmd` creates `.venv` and installs the small web runtime from `requirements-local.txt`. This first setup needs an approved Python package index.
   - `03_Run_Local_Demo.cmd` starts the local server. Keep this window open.
   - In a **second window**, run `04_Verify_Local_Demo.cmd`. It confirms the page, health endpoint, 12 periods, six decisions and three routes.
4. The browser opens at `http://127.0.0.1:8876/`. If it does not open automatically, enter that address in a browser on the same laptop. Press **Ctrl+C** in the Step 03 window to stop it.

`Start Finance Demo.cmd` remains a one-click alternative. It combines setup and start, so the numbered scripts are optional when you want a quick demo.

The FastAPI mode stores synthetic cases in `poc_state.sqlite3` beside the extracted app. It binds only to `127.0.0.1`, so another device cannot browse it over the network. The app does not need a SAP, AWS, Google, Databricks or model account.

In the **Execution simulator**, open **Detailed report for <period>** for the full reconciliation report (accounts, reconciling items, aging, controls, AI review, audit trail, CSV/JSON/print), and use **Scenario lab** to simulate a late replication, a stale load, an unreplicated posting or a clean close. Choose **Restore the seeded baseline** to reset. These changes affect only the local synthetic data.

The interface is a SAP Fiori-style shell with three spaces: **Finance apps** (tiles for Close & reconcile, Cash & treasury and Accruals), **Agents** (Ask the agents, Agent catalog, Technical options) and **Architecture & operations** (tiles for the architecture views, including Live run, Complete architecture, MCP hosting and Agent hosting).

To use a different port, open a terminal in the extracted folder and run `py -3 local_demo.py --port 8899`. If the corporate laptop does not allow local Python or package installation, ask IT for an approved Python runtime and access to the approved package index; no production credentials should be added to this demo.

## Optional: local Streamlit mode

Run `py -3 local_demo.py --mode streamlit --port 8502` from the extracted folder, or use `run_streamlit.ps1` where PowerShell scripts are allowed. This mode installs the larger `requirements.txt` set on first use. Open `http://127.0.0.1:8502/`. This is also local; it does not use Streamlit Community Cloud. Streamlit cases live only for the browser session, while the recommended FastAPI mode keeps its SQLite demo cases locally.

The `run_poc.ps1` PowerShell script is an alternative to the double-click launcher. Neither mode requires Node.js at runtime. Node.js is only needed to rebuild the UI after editing frontend source.
