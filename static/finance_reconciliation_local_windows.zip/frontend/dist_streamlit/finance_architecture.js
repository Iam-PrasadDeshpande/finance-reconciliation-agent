// \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || (e((t = { exports: {} }).exports, t, t.exports), e = null), t.exports), s = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, c = (n, r, o) => (o = n == null ? {} : e(i(n)), s(r || !n || !n.__esModule || !a.call(n, "default") ? t(o, "default", {
	value: n,
	enumerable: !0
}) : o, n)), l = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element"), n = Symbol.for("react.portal"), r = Symbol.for("react.fragment"), i = Symbol.for("react.strict_mode"), a = Symbol.for("react.profiler"), o = Symbol.for("react.consumer"), s = Symbol.for("react.context"), c = Symbol.for("react.forward_ref"), l = Symbol.for("react.suspense"), u = Symbol.for("react.memo"), d = Symbol.for("react.lazy"), f = Symbol.for("react.activity"), p = Symbol.for("react.view_transition"), m = Symbol.iterator;
	function h(e) {
		return typeof e != "object" || !e ? null : (e = m && e[m] || e["@@iterator"], typeof e == "function" ? e : null);
	}
	var g = {
		isMounted: function() {
			return !1;
		},
		enqueueForceUpdate: function() {},
		enqueueReplaceState: function() {},
		enqueueSetState: function() {}
	}, _ = Object.assign, v = {};
	function y(e, t, n) {
		this.props = e, this.context = t, this.refs = v, this.updater = n || g;
	}
	y.prototype.isReactComponent = {}, y.prototype.setState = function(e, t) {
		if (typeof e != "object" && typeof e != "function" && e != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
		this.updater.enqueueSetState(this, e, t, "setState");
	}, y.prototype.forceUpdate = function(e) {
		this.updater.enqueueForceUpdate(this, e, "forceUpdate");
	};
	function b() {}
	b.prototype = y.prototype;
	function x(e, t, n) {
		this.props = e, this.context = t, this.refs = v, this.updater = n || g;
	}
	var S = x.prototype = new b();
	S.constructor = x, _(S, y.prototype), S.isPureReactComponent = !0;
	var C = Array.isArray;
	function w() {}
	var T = {
		H: null,
		A: null,
		T: null,
		S: null
	}, E = Object.prototype.hasOwnProperty;
	function D(e, n, r) {
		var i = r.ref;
		return {
			$$typeof: t,
			type: e,
			key: n,
			ref: i === void 0 ? null : i,
			props: r
		};
	}
	function O(e, t) {
		return D(e.type, t, e.props);
	}
	function k(e) {
		return typeof e == "object" && !!e && e.$$typeof === t;
	}
	function ee(e) {
		var t = {
			"=": "=0",
			":": "=2"
		};
		return "$" + e.replace(/[=:]/g, function(e) {
			return t[e];
		});
	}
	var te = /\/+/g;
	function ne(e, t) {
		return typeof e == "object" && e && e.key != null ? ee("" + e.key) : t.toString(36);
	}
	function re(e) {
		switch (e.status) {
			case "fulfilled": return e.value;
			case "rejected": throw e.reason;
			default: switch (typeof e.status == "string" ? e.then(w, w) : (e.status = "pending", e.then(function(t) {
				e.status === "pending" && (e.status = "fulfilled", e.value = t);
			}, function(t) {
				e.status === "pending" && (e.status = "rejected", e.reason = t);
			})), e.status) {
				case "fulfilled": return e.value;
				case "rejected": throw e.reason;
			}
		}
		throw e;
	}
	function ie(e, r, i, a, o) {
		var s = typeof e;
		(s === "undefined" || s === "boolean") && (e = null);
		var c = !1;
		if (e === null) c = !0;
		else switch (s) {
			case "bigint":
			case "string":
			case "number":
				c = !0;
				break;
			case "object": switch (e.$$typeof) {
				case t:
				case n:
					c = !0;
					break;
				case d: return c = e._init, ie(c(e._payload), r, i, a, o);
			}
		}
		if (c) return o = o(e), c = a === "" ? "." + ne(e, 0) : a, C(o) ? (i = "", c != null && (i = c.replace(te, "$&/") + "/"), ie(o, r, i, "", function(e) {
			return e;
		})) : o != null && (k(o) && (o = O(o, i + (o.key == null || e && e.key === o.key ? "" : ("" + o.key).replace(te, "$&/") + "/") + c)), r.push(o)), 1;
		c = 0;
		var l = a === "" ? "." : a + ":";
		if (C(e)) for (var u = 0; u < e.length; u++) a = e[u], s = l + ne(a, u), c += ie(a, r, i, s, o);
		else if (u = h(e), typeof u == "function") for (e = u.call(e), u = 0; !(a = e.next()).done;) a = a.value, s = l + ne(a, u++), c += ie(a, r, i, s, o);
		else if (s === "object") {
			if (typeof e.then == "function") return ie(re(e), r, i, a, o);
			throw r = String(e), Error("Objects are not valid as a React child (found: " + (r === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : r) + "). If you meant to render a collection of children, use an array instead.");
		}
		return c;
	}
	function A(e, t, n) {
		if (e == null) return e;
		var r = [], i = 0;
		return ie(e, r, "", "", function(e) {
			return t.call(n, e, i++);
		}), r;
	}
	function ae(e) {
		if (e._status === -1) {
			var t = e._result, n = t();
			n.then(function(t) {
				(e._status === 0 || e._status === -1) && (e._status = 1, e._result = t, n.status === void 0 && (n.status = "fulfilled", n.value = t));
			}, function(t) {
				(e._status === 0 || e._status === -1) && (e._status = 2, e._result = t, n.status === void 0 && (n.status = "rejected", n.reason = t));
			}), e._status === -1 && (e._status = 0, e._result = n);
		}
		if (e._status === 1) return e._result.default;
		throw e._result;
	}
	var oe = typeof reportError == "function" ? reportError : function(e) {
		if (typeof window == "object" && typeof window.ErrorEvent == "function") {
			var t = new window.ErrorEvent("error", {
				bubbles: !0,
				cancelable: !0,
				message: typeof e == "object" && e && typeof e.message == "string" ? String(e.message) : String(e),
				error: e
			});
			if (!window.dispatchEvent(t)) return;
		} else if (typeof process == "object" && typeof process.emit == "function") {
			process.emit("uncaughtException", e);
			return;
		}
		console.error(e);
	};
	function se(e) {
		var t = T.T, n = {};
		n.types = t === null ? null : t.types, T.T = n;
		try {
			var r = e(), i = T.S;
			i !== null && i(n, r), typeof r == "object" && r && typeof r.then == "function" && r.then(w, oe);
		} catch (e) {
			oe(e);
		} finally {
			t !== null && n.types !== null && (t.types = n.types), T.T = t;
		}
	}
	function ce(e) {
		var t = T.T;
		if (t !== null) {
			var n = t.types;
			n === null ? t.types = [e] : n.indexOf(e) === -1 && n.push(e);
		} else se(ce.bind(null, e));
	}
	var j = {
		map: A,
		forEach: function(e, t, n) {
			A(e, function() {
				t.apply(this, arguments);
			}, n);
		},
		count: function(e) {
			var t = 0;
			return A(e, function() {
				t++;
			}), t;
		},
		toArray: function(e) {
			return A(e, function(e) {
				return e;
			}) || [];
		},
		only: function(e) {
			if (!k(e)) throw Error("React.Children.only expected to receive a single React element child.");
			return e;
		}
	};
	e.Activity = f, e.Children = j, e.Component = y, e.Fragment = r, e.Profiler = a, e.PureComponent = x, e.StrictMode = i, e.Suspense = l, e.ViewTransition = p, e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = T, e.__COMPILER_RUNTIME = {
		__proto__: null,
		c: function(e) {
			return T.H.useMemoCache(e);
		}
	}, e.addTransitionType = ce, e.cache = function(e) {
		return function() {
			return e.apply(null, arguments);
		};
	}, e.cacheSignal = function() {
		return null;
	}, e.cloneElement = function(e, t, n) {
		if (e == null) throw Error("The argument must be a React element, but you passed " + e + ".");
		var r = _({}, e.props), i = e.key;
		if (t != null) for (a in t.key !== void 0 && (i = "" + t.key), t) !E.call(t, a) || a === "key" || a === "__self" || a === "__source" || a === "ref" && t.ref === void 0 || (r[a] = t[a]);
		var a = arguments.length - 2;
		if (a === 1) r.children = n;
		else if (1 < a) {
			for (var o = Array(a), s = 0; s < a; s++) o[s] = arguments[s + 2];
			r.children = o;
		}
		return D(e.type, i, r);
	}, e.createContext = function(e) {
		return e = {
			$$typeof: s,
			_currentValue: e,
			_currentValue2: e,
			_threadCount: 0,
			Provider: null,
			Consumer: null
		}, e.Provider = e, e.Consumer = {
			$$typeof: o,
			_context: e
		}, e;
	}, e.createElement = function(e, t, n) {
		var r, i = {}, a = null;
		if (t != null) for (r in t.key !== void 0 && (a = "" + t.key), t) E.call(t, r) && r !== "key" && r !== "__self" && r !== "__source" && (i[r] = t[r]);
		var o = arguments.length - 2;
		if (o === 1) i.children = n;
		else if (1 < o) {
			for (var s = Array(o), c = 0; c < o; c++) s[c] = arguments[c + 2];
			i.children = s;
		}
		if (e && e.defaultProps) for (r in o = e.defaultProps, o) i[r] === void 0 && (i[r] = o[r]);
		return D(e, a, i);
	}, e.createRef = function() {
		return { current: null };
	}, e.forwardRef = function(e) {
		return {
			$$typeof: c,
			render: e
		};
	}, e.isValidElement = k, e.lazy = function(e) {
		return {
			$$typeof: d,
			_payload: {
				_status: -1,
				_result: e
			},
			_init: ae
		};
	}, e.memo = function(e, t) {
		return {
			$$typeof: u,
			type: e,
			compare: t === void 0 ? null : t
		};
	}, e.startTransition = se, e.unstable_useCacheRefresh = function() {
		return T.H.useCacheRefresh();
	}, e.use = function(e) {
		return T.H.use(e);
	}, e.useActionState = function(e, t, n) {
		return T.H.useActionState(e, t, n);
	}, e.useCallback = function(e, t) {
		return T.H.useCallback(e, t);
	}, e.useContext = function(e) {
		return T.H.useContext(e);
	}, e.useDebugValue = function() {}, e.useDeferredValue = function(e, t) {
		return T.H.useDeferredValue(e, t);
	}, e.useEffect = function(e, t) {
		return T.H.useEffect(e, t);
	}, e.useEffectEvent = function(e) {
		return T.H.useEffectEvent(e);
	}, e.useId = function() {
		return T.H.useId();
	}, e.useImperativeHandle = function(e, t, n) {
		return T.H.useImperativeHandle(e, t, n);
	}, e.useInsertionEffect = function(e, t) {
		return T.H.useInsertionEffect(e, t);
	}, e.useLayoutEffect = function(e, t) {
		return T.H.useLayoutEffect(e, t);
	}, e.useMemo = function(e, t) {
		return T.H.useMemo(e, t);
	}, e.useOptimistic = function(e, t) {
		return T.H.useOptimistic(e, t);
	}, e.useReducer = function(e, t, n) {
		return T.H.useReducer(e, t, n);
	}, e.useRef = function(e) {
		return T.H.useRef(e);
	}, e.useState = function(e) {
		return T.H.useState(e);
	}, e.useSyncExternalStore = function(e, t, n) {
		return T.H.useSyncExternalStore(e, t, n);
	}, e.useTransition = function() {
		return T.H.useTransition();
	}, e.version = "19.3.1";
})), u = /* @__PURE__ */ o(((e, t) => {
	t.exports = l();
})), d = /* @__PURE__ */ o(((e) => {
	function t(e, t) {
		var n = e.length;
		e.push(t);
		a: for (; 0 < n;) {
			var r = n - 1 >>> 1, a = e[r];
			if (0 < i(a, t)) e[r] = t, e[n] = a, n = r;
			else break a;
		}
	}
	function n(e) {
		return e.length === 0 ? null : e[0];
	}
	function r(e) {
		if (e.length === 0) return null;
		var t = e[0], n = e.pop();
		if (n !== t) {
			e[0] = n;
			a: for (var r = 0, a = e.length, o = a >>> 1; r < o;) {
				var s = 2 * (r + 1) - 1, c = e[s], l = s + 1, u = e[l];
				if (0 > i(c, n)) l < a && 0 > i(u, c) ? (e[r] = u, e[l] = n, r = l) : (e[r] = c, e[s] = n, r = s);
				else if (l < a && 0 > i(u, n)) e[r] = u, e[l] = n, r = l;
				else break a;
			}
		}
		return t;
	}
	function i(e, t) {
		var n = e.sortIndex - t.sortIndex;
		return n === 0 ? e.id - t.id : n;
	}
	if (e.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
		var a = performance;
		e.unstable_now = function() {
			return a.now();
		};
	} else {
		var o = Date, s = o.now();
		e.unstable_now = function() {
			return o.now() - s;
		};
	}
	var c = [], l = [], u = 1, d = null, f = 3, p = !1, m = !1, h = !1, g = !1, _ = typeof setTimeout == "function" ? setTimeout : null, v = typeof clearTimeout == "function" ? clearTimeout : null, y = typeof setImmediate < "u" ? setImmediate : null;
	function b(e) {
		for (var i = n(l); i !== null;) {
			if (i.callback === null) r(l);
			else if (i.startTime <= e) r(l), i.sortIndex = i.expirationTime, t(c, i);
			else break;
			i = n(l);
		}
	}
	function x(e) {
		if (h = !1, b(e), !m) {
			if (n(c) !== null) m = !0, S || (S = !0, O());
			else {
				var t = n(l);
				t !== null && te(x, t.startTime - e);
			}
		}
	}
	var S = !1, C = -1, w = 5, T = -1;
	function E() {
		return g ? !0 : !(e.unstable_now() - T < w);
	}
	function D() {
		if (g = !1, S) {
			var t = e.unstable_now();
			T = t;
			var i = !0;
			try {
				a: {
					m = !1, h && (h = !1, v(C), C = -1), p = !0;
					var a = f;
					try {
						b: {
							for (b(t), d = n(c); d !== null && !(d.expirationTime > t && E());) {
								var o = d.callback;
								if (typeof o == "function") {
									d.callback = null, f = d.priorityLevel;
									var s = o(d.expirationTime <= t);
									if (t = e.unstable_now(), typeof s == "function") {
										d.callback = s, b(t), i = !0;
										break b;
									}
									d === n(c) && r(c), b(t);
								} else r(c);
								d = n(c);
							}
							if (d !== null) i = !0;
							else {
								var u = n(l);
								u !== null && te(x, u.startTime - t), i = !1;
							}
						}
						break a;
					} finally {
						d = null, f = a, p = !1;
					}
					i = void 0;
				}
			} finally {
				i ? O() : S = !1;
			}
		}
	}
	var O;
	if (typeof y == "function") O = function() {
		y(D);
	};
	else if (typeof MessageChannel < "u") {
		var k = new MessageChannel(), ee = k.port2;
		k.port1.onmessage = D, O = function() {
			ee.postMessage(null);
		};
	} else O = function() {
		_(D, 0);
	};
	function te(t, n) {
		C = _(function() {
			t(e.unstable_now());
		}, n);
	}
	e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(e) {
		e.callback = null;
	}, e.unstable_forceFrameRate = function(e) {
		0 > e || 125 < e ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : w = 0 < e ? Math.floor(1e3 / e) : 5;
	}, e.unstable_getCurrentPriorityLevel = function() {
		return f;
	}, e.unstable_next = function(e) {
		switch (f) {
			case 1:
			case 2:
			case 3:
				var t = 3;
				break;
			default: t = f;
		}
		var n = f;
		f = t;
		try {
			return e();
		} finally {
			f = n;
		}
	}, e.unstable_requestPaint = function() {
		g = !0;
	}, e.unstable_runWithPriority = function(e, t) {
		switch (e) {
			case 1:
			case 2:
			case 3:
			case 4:
			case 5: break;
			default: e = 3;
		}
		var n = f;
		f = e;
		try {
			return t();
		} finally {
			f = n;
		}
	}, e.unstable_scheduleCallback = function(r, i, a) {
		var o = e.unstable_now();
		switch (typeof a == "object" && a ? (a = a.delay, a = typeof a == "number" && 0 < a ? o + a : o) : a = o, r) {
			case 1:
				var s = -1;
				break;
			case 2:
				s = 250;
				break;
			case 5:
				s = 1073741823;
				break;
			case 4:
				s = 1e4;
				break;
			default: s = 5e3;
		}
		return s = a + s, r = {
			id: u++,
			callback: i,
			priorityLevel: r,
			startTime: a,
			expirationTime: s,
			sortIndex: -1
		}, a > o ? (r.sortIndex = a, t(l, r), n(c) === null && r === n(l) && (h ? (v(C), C = -1) : h = !0, te(x, a - o))) : (r.sortIndex = s, t(c, r), m || p || (m = !0, S || (S = !0, O()))), r;
	}, e.unstable_shouldYield = E, e.unstable_wrapCallback = function(e) {
		var t = f;
		return function() {
			var n = f;
			f = t;
			try {
				return e.apply(this, arguments);
			} finally {
				f = n;
			}
		};
	};
})), f = /* @__PURE__ */ o(((e, t) => {
	t.exports = d();
})), p = /* @__PURE__ */ o(((e) => {
	var t = u();
	function n(e) {
		var t = "https://react.dev/errors/" + e;
		if (1 < arguments.length) {
			t += "?args[]=" + encodeURIComponent(arguments[1]);
			for (var n = 2; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
		}
		return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
	}
	function r() {}
	var i = {
		d: {
			f: r,
			r: function() {
				throw Error(n(522));
			},
			D: r,
			C: r,
			L: r,
			m: r,
			X: r,
			S: r,
			M: r
		},
		p: 0,
		findDOMNode: null
	}, a = Symbol.for("react.portal"), o = Symbol.for("react.recoverable"), s = Symbol.for("react.optimistic_key");
	function c(e, t, n) {
		var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
		return {
			$$typeof: a,
			key: r == null ? null : r === s ? s : "" + r,
			children: e,
			containerInfo: t,
			implementation: n
		};
	}
	var l = t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
	function d(e, t) {
		if (e === "font") return "";
		if (typeof t == "string") return t === "use-credentials" ? t : "";
	}
	e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = i, e.browser = function(e) {
		return {
			$$typeof: o,
			_reason: e
		};
	}, e.createPortal = function(e, t) {
		var r = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
		if (!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11) throw Error(n(299));
		return c(e, t, null, r);
	}, e.flushSync = function(e) {
		var t = l.T, n = i.p;
		try {
			if (l.T = null, i.p = 2, e) return e();
		} finally {
			l.T = t, i.p = n, i.d.f();
		}
	}, e.preconnect = function(e, t) {
		typeof e == "string" && (t ? (t = t.crossOrigin, t = typeof t == "string" ? t === "use-credentials" ? t : "" : void 0) : t = null, i.d.C(e, t));
	}, e.prefetchDNS = function(e) {
		typeof e == "string" && i.d.D(e);
	}, e.preinit = function(e, t) {
		if (typeof e == "string" && t && typeof t.as == "string") {
			var n = t.as, r = d(n, t.crossOrigin), a = typeof t.integrity == "string" ? t.integrity : void 0, o = typeof t.fetchPriority == "string" ? t.fetchPriority : void 0;
			n === "style" ? i.d.S(e, typeof t.precedence == "string" ? t.precedence : void 0, {
				crossOrigin: r,
				integrity: a,
				fetchPriority: o
			}) : n === "script" && i.d.X(e, {
				crossOrigin: r,
				integrity: a,
				fetchPriority: o,
				nonce: typeof t.nonce == "string" ? t.nonce : void 0
			});
		}
	}, e.preinitModule = function(e, t) {
		if (typeof e == "string") {
			if (typeof t == "object" && t) {
				if (t.as == null || t.as === "script") {
					var n = d(t.as, t.crossOrigin);
					i.d.M(e, {
						crossOrigin: n,
						integrity: typeof t.integrity == "string" ? t.integrity : void 0,
						nonce: typeof t.nonce == "string" ? t.nonce : void 0,
						fetchPriority: typeof t.fetchPriority == "string" ? t.fetchPriority : void 0
					});
				}
			} else t ?? i.d.M(e);
		}
	}, e.preload = function(e, t) {
		if (typeof e == "string" && typeof t == "object" && t && typeof t.as == "string") {
			var n = t.as, r = d(n, t.crossOrigin);
			i.d.L(e, n, {
				crossOrigin: r,
				integrity: typeof t.integrity == "string" ? t.integrity : void 0,
				nonce: typeof t.nonce == "string" ? t.nonce : void 0,
				type: typeof t.type == "string" ? t.type : void 0,
				fetchPriority: typeof t.fetchPriority == "string" ? t.fetchPriority : void 0,
				referrerPolicy: typeof t.referrerPolicy == "string" ? t.referrerPolicy : void 0,
				imageSrcSet: typeof t.imageSrcSet == "string" ? t.imageSrcSet : void 0,
				imageSizes: typeof t.imageSizes == "string" ? t.imageSizes : void 0,
				media: typeof t.media == "string" ? t.media : void 0
			});
		}
	}, e.preloadModule = function(e, t) {
		if (typeof e == "string") {
			if (t) {
				var n = d(t.as, t.crossOrigin);
				i.d.m(e, {
					as: typeof t.as == "string" && t.as !== "script" ? t.as : void 0,
					crossOrigin: n,
					integrity: typeof t.integrity == "string" ? t.integrity : void 0,
					nonce: typeof t.nonce == "string" ? t.nonce : void 0,
					fetchPriority: typeof t.fetchPriority == "string" ? t.fetchPriority : void 0
				});
			} else i.d.m(e);
		}
	}, e.requestFormReset = function(e) {
		i.d.r(e);
	}, e.unstable_batchedUpdates = function(e, t) {
		return e(t);
	}, e.useFormState = function(e, t, n) {
		return l.H.useFormState(e, t, n);
	}, e.useFormStatus = function() {
		return l.H.useHostTransitionStatus();
	}, e.version = "19.3.1";
})), m = /* @__PURE__ */ o(((e, t) => {
	function n() {
		if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE == "function") try {
			__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n);
		} catch (e) {
			console.error(e);
		}
	}
	n(), t.exports = p();
})), h = /* @__PURE__ */ o(((e) => {
	var t = f(), n = u(), r = m();
	function i(e) {
		var t = "https://react.dev/errors/" + e;
		if (1 < arguments.length) {
			t += "?args[]=" + encodeURIComponent(arguments[1]);
			for (var n = 2; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
		}
		return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
	}
	function a(e) {
		return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11);
	}
	function o(e) {
		for (var t = e, n = t; n && !n.alternate;) t = n, t.flags & 4098 && (e = t.return), n = t.return;
		for (; t.return;) t = t.return;
		return t.tag === 3 ? e : null;
	}
	function s(e) {
		if (e.tag === 13) {
			var t = e.memoizedState;
			if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated;
		}
		return null;
	}
	function c(e) {
		if (e.tag === 31) {
			var t = e.memoizedState;
			if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated;
		}
		return null;
	}
	function l(e) {
		if (o(e) !== e) throw Error(i(188));
	}
	function d(e) {
		var t = e.alternate;
		if (!t) {
			if (t = o(e), t === null) throw Error(i(188));
			return t === e ? e : null;
		}
		for (var n = e, r = t;;) {
			var a = n.return;
			if (a === null) break;
			var s = a.alternate;
			if (s === null) {
				if (r = a.return, r !== null) {
					n = r;
					continue;
				}
				break;
			}
			if (a.child === s.child) {
				for (s = a.child; s;) {
					if (s === n) return l(a), e;
					if (s === r) return l(a), t;
					s = s.sibling;
				}
				throw Error(i(188));
			}
			if (n.return !== r.return) n = a, r = s;
			else {
				for (var c = !1, u = a.child; u;) {
					if (u === n) {
						c = !0, n = a, r = s;
						break;
					}
					if (u === r) {
						c = !0, r = a, n = s;
						break;
					}
					u = u.sibling;
				}
				if (!c) {
					for (u = s.child; u;) {
						if (u === n) {
							c = !0, n = s, r = a;
							break;
						}
						if (u === r) {
							c = !0, r = s, n = a;
							break;
						}
						u = u.sibling;
					}
					if (!c) throw Error(i(189));
				}
			}
			if (n.alternate !== r) throw Error(i(190));
		}
		if (n.tag !== 3) throw Error(i(188));
		return n.stateNode.current === n ? e : t;
	}
	function p(e) {
		var t = e.tag;
		if (t === 5 || t === 26 || t === 27 || t === 6) return e;
		for (e = e.child; e !== null;) {
			if (t = p(e), t !== null) return t;
			e = e.sibling;
		}
		return null;
	}
	function h(e, t, n, r, i, a) {
		for (; e !== null;) {
			if ((e.tag === 5 || e.tag === 27 || e.tag === 6) && n(e, r, i, a) || (e.tag !== 22 || e.memoizedState === null) && (t || e.tag !== 5 && e.tag !== 27) && h(e.child, t, n, r, i, a)) return !0;
			e = e.sibling;
		}
		return !1;
	}
	function g(e) {
		for (e = e.return; e !== null;) {
			if (e.tag === 3 || e.tag === 5 || e.tag === 27) return e;
			e = e.return;
		}
		return null;
	}
	function _(e) {
		var t = !1;
		for (e = e.return; e !== null && (e.tag === 4 && (t = !0), e.tag !== 3 && e.tag !== 5 && e.tag !== 27);) e = e.return;
		return t;
	}
	function v(e) {
		var t = [null, null], n = g(e);
		return n === null || y(t, e, n.child, { foundSelf: !1 }), t;
	}
	function y(e, t, n, r) {
		for (; n !== null;) {
			if (n === t) r.foundSelf = !0;
			else if (n.tag === 5 || n.tag === 27 || n.tag === 6) {
				if (r.foundSelf) return e[1] = n, !0;
				e[0] = n;
			} else if ((n.tag !== 22 || n.memoizedState === null) && y(e, t, n.child, r)) return !0;
			n = n.sibling;
		}
		return !1;
	}
	function b(e) {
		switch (e.tag) {
			case 5:
			case 27:
			case 6: return e.stateNode;
			case 3: return e.stateNode.containerInfo;
			default: throw Error(i(559));
		}
	}
	var x = null, S = null;
	function C(e, t, n) {
		return e === n || e === t && (x = e, !0);
	}
	function w(e, t, n) {
		return e === n ? (S = e, !1) : e === t && (S !== null && (x = e), !0);
	}
	function T(e) {
		if (e === null) return null;
		do
			e = e === null ? null : e.return;
		while (e && e.tag !== 5 && e.tag !== 27 && e.tag !== 3);
		return e || null;
	}
	function E(e, t, n) {
		for (var r = 0, i = e; i; i = n(i)) r++;
		i = 0;
		for (var a = t; a; a = n(a)) i++;
		for (; 0 < r - i;) e = n(e), r--;
		for (; 0 < i - r;) t = n(t), i--;
		for (; r--;) {
			if (e === t || t !== null && e === t.alternate) return e;
			e = n(e), t = n(t);
		}
		return null;
	}
	var D = Object.assign, O = Symbol.for("react.element"), k = Symbol.for("react.transitional.element"), ee = Symbol.for("react.portal"), te = Symbol.for("react.fragment"), ne = Symbol.for("react.strict_mode"), re = Symbol.for("react.profiler"), ie = Symbol.for("react.consumer"), A = Symbol.for("react.context"), ae = Symbol.for("react.forward_ref"), oe = Symbol.for("react.suspense"), se = Symbol.for("react.suspense_list"), ce = Symbol.for("react.memo"), j = Symbol.for("react.lazy"), le = Symbol.for("react.activity"), ue = Symbol.for("react.legacy_hidden"), de = Symbol.for("react.memo_cache_sentinel"), fe = Symbol.for("react.view_transition"), pe = Symbol.for("react.recoverable"), me = Symbol.iterator;
	function he(e) {
		return typeof e != "object" || !e ? null : (e = me && e[me] || e["@@iterator"], typeof e == "function" ? e : null);
	}
	var ge = Symbol.for("react.client.reference");
	function _e(e) {
		if (e == null) return null;
		if (typeof e == "function") return e.$$typeof === ge ? null : e.displayName || e.name || null;
		if (typeof e == "string") return e;
		switch (e) {
			case te: return "Fragment";
			case re: return "Profiler";
			case ne: return "StrictMode";
			case oe: return "Suspense";
			case se: return "SuspenseList";
			case le: return "Activity";
			case fe: return "ViewTransition";
		}
		if (typeof e == "object") switch (e.$$typeof) {
			case ee: return "Portal";
			case A: return e.displayName || "Context";
			case ie: return (e._context.displayName || "Context") + ".Consumer";
			case ae:
				var t = e.render;
				return e = e.displayName, e ||= (e = t.displayName || t.name || "", e === "" ? "ForwardRef" : "ForwardRef(" + e + ")"), e;
			case ce: return t = e.displayName || null, t === null ? _e(e.type) || "Memo" : t;
			case j:
				t = e._payload, e = e._init;
				try {
					return _e(e(t));
				} catch {}
		}
		return null;
	}
	var ve = Array.isArray, M = n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, N = r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, ye = {
		pending: !1,
		data: null,
		method: null,
		action: null
	}, be = [], P = -1;
	function xe(e) {
		return { current: e };
	}
	function Se(e) {
		0 > P || (e.current = be[P], be[P] = null, P--);
	}
	function F(e, t) {
		P++, be[P] = e.current, e.current = t;
	}
	var Ce = xe(null), we = xe(null), Te = xe(null), Ee = xe(null);
	function De(e, t) {
		switch (F(Te, t), F(we, e), F(Ce, null), t.nodeType) {
			case 9:
			case 11:
				e = (e = t.documentElement) && (e = e.namespaceURI) ? up(e) : 0;
				break;
			default: if (e = t.tagName, t = t.namespaceURI) t = up(t), e = dp(t, e);
			else switch (e) {
				case "svg":
					e = 1;
					break;
				case "math":
					e = 2;
					break;
				default: e = 0;
			}
		}
		Se(Ce), F(Ce, e);
	}
	function Oe() {
		Se(Ce), Se(we), Se(Te);
	}
	function ke(e) {
		var t = e.memoizedState;
		t !== null && (sh._currentValue = t.memoizedState, F(Ee, e)), t = Ce.current;
		var n = dp(t, e.type);
		t !== n && (F(we, e), F(Ce, n));
	}
	function Ae(e) {
		we.current === e && (Se(Ce), Se(we)), Ee.current === e && (Se(Ee), sh._currentValue = ye);
	}
	var je, Me;
	function Ne(e) {
		if (je === void 0) try {
			throw Error();
		} catch (e) {
			var t = e.stack.trim().match(/\n( *(at )?)/);
			je = t && t[1] || "", Me = -1 < e.stack.indexOf("\n    at") ? " (<anonymous>)" : -1 < e.stack.indexOf("@") ? "@unknown:0:0" : "";
		}
		return "\n" + je + e + Me;
	}
	var I = !1;
	function Pe(e, t) {
		if (!e || I) return "";
		I = !0;
		var n = Error.prepareStackTrace;
		Error.prepareStackTrace = void 0;
		try {
			var r = { DetermineComponentFrameRoot: function() {
				try {
					if (t) {
						var n = function() {
							throw Error();
						};
						if (Object.defineProperty(n.prototype, "props", { set: function() {
							throw Error();
						} }), typeof Reflect == "object" && Reflect.construct) {
							try {
								Reflect.construct(n, []);
							} catch (e) {
								var r = e;
							}
							Reflect.construct(e, [], n);
						} else {
							try {
								n.call();
							} catch (e) {
								r = e;
							}
							n = !1;
							try {
								var i = Object.getOwnPropertyDescriptor(e.prototype, "props");
								Object.defineProperty(e.prototype, "props", {
									configurable: !0,
									set: function() {
										throw Error();
									}
								}), n = !0, new e();
							} finally {
								n && (i === void 0 ? delete e.prototype.props : Object.defineProperty(e.prototype, "props", i));
							}
						}
					} else {
						try {
							throw Error();
						} catch (e) {
							r = e;
						}
						(n = e()) && typeof n.catch == "function" && n.catch(function() {});
					}
				} catch (e) {
					if (e && r && typeof e.stack == "string") return [e.stack, r.stack];
				}
				return [null, null];
			} };
			r.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
			var i = Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot, "name");
			i && i.configurable && Object.defineProperty(r.DetermineComponentFrameRoot, "name", { value: "DetermineComponentFrameRoot" });
			var a = r.DetermineComponentFrameRoot(), o = a[0], s = a[1];
			if (o && s) {
				var c = o.split("\n"), l = s.split("\n");
				for (i = r = 0; r < c.length && !c[r].includes("DetermineComponentFrameRoot");) r++;
				for (; i < l.length && !l[i].includes("DetermineComponentFrameRoot");) i++;
				if (r === c.length || i === l.length) for (r = c.length - 1, i = l.length - 1; 1 <= r && 0 <= i && c[r] !== l[i];) i--;
				for (; 1 <= r && 0 <= i; r--, i--) if (c[r] !== l[i]) {
					if (r !== 1 || i !== 1) do
						if (r--, i--, 0 > i || c[r] !== l[i]) {
							var u = "\n" + c[r].replace(" at new ", " at ");
							return e.displayName && u.includes("<anonymous>") && (u = u.replace("<anonymous>", e.displayName)), u;
						}
					while (1 <= r && 0 <= i);
					break;
				}
			}
		} finally {
			I = !1, Error.prepareStackTrace = n;
		}
		return (n = e ? e.displayName || e.name : "") ? Ne(n) : "";
	}
	function Fe(e, t) {
		switch (e.tag) {
			case 26:
			case 27:
			case 5: return Ne(e.type);
			case 16: return Ne("Lazy");
			case 13: return e.child !== t && t !== null ? Ne("Suspense Fallback") : Ne("Suspense");
			case 19: return Ne("SuspenseList");
			case 0:
			case 15: return Pe(e.type, !1);
			case 11: return Pe(e.type.render, !1);
			case 1: return Pe(e.type, !0);
			case 31: return Ne("Activity");
			case 30: return Ne("ViewTransition");
			default: return "";
		}
	}
	function Ie(e) {
		try {
			var t = "", n = null;
			do
				t += Fe(e, n), n = e, e = e.return;
			while (e);
			return t;
		} catch (e) {
			return "\nError generating stack: " + e.message + "\n" + e.stack;
		}
	}
	var Le = Object.prototype.hasOwnProperty, Re = t.unstable_scheduleCallback, ze = t.unstable_cancelCallback, Be = t.unstable_shouldYield, Ve = t.unstable_requestPaint, He = t.unstable_now, Ue = t.unstable_getCurrentPriorityLevel, We = t.unstable_ImmediatePriority, Ge = t.unstable_UserBlockingPriority, Ke = t.unstable_NormalPriority, qe = t.unstable_LowPriority, Je = t.unstable_IdlePriority, Ye = t.log, Xe = t.unstable_setDisableYieldValue, Ze = null, Qe = null;
	function $e(e) {
		if (typeof Ye == "function" && Xe(e), Qe && typeof Qe.setStrictMode == "function") try {
			Qe.setStrictMode(Ze, e);
		} catch {}
	}
	var L = Math.clz32 ? Math.clz32 : R, et = Math.log, tt = Math.LN2;
	function R(e) {
		return e >>>= 0, e === 0 ? 32 : 31 - (et(e) / tt | 0) | 0;
	}
	var nt = 256, z = 262144, rt = 4194304;
	function it(e) {
		var t = e & 42;
		if (t !== 0) return t;
		switch (e & -e) {
			case 1: return 1;
			case 2: return 2;
			case 4: return 4;
			case 8: return 8;
			case 16: return 16;
			case 32: return 32;
			case 64: return 64;
			case 128: return 128;
			case 256:
			case 512:
			case 1024:
			case 2048:
			case 4096:
			case 8192:
			case 16384:
			case 32768:
			case 65536:
			case 131072: return e & -e;
			case 262144:
			case 524288:
			case 1048576:
			case 2097152: return e & 3932160;
			case 4194304:
			case 8388608:
			case 16777216:
			case 33554432: return e & 62914560;
			case 67108864: return 67108864;
			case 134217728: return 134217728;
			case 268435456: return 268435456;
			case 536870912: return 536870912;
			case 1073741824: return 0;
			default: return e;
		}
	}
	function at(e, t, n) {
		var r = e.pendingLanes;
		if (r === 0) return 0;
		var i = 0, a = e.suspendedLanes, o = e.pingedLanes;
		e = e.warmLanes;
		var s = r & 134217727;
		return s === 0 ? (s = r & ~a, s === 0 ? o === 0 ? n || (n = r & ~e, n !== 0 && (i = it(n))) : i = it(o) : i = it(s)) : (r = s & ~a, r === 0 ? (o &= s, o === 0 ? n || (n = s & ~e, n !== 0 && (i = it(n))) : i = it(o)) : i = it(r)), i === 0 ? 0 : t !== 0 && t !== i && (t & a) === 0 && (a = i & -i, n = t & -t, a >= n || a === 32 && n & 4194048) ? t : i;
	}
	function ot(e, t) {
		return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0;
	}
	function st(e, t) {
		t & 8 && (t |= t & 32);
		var n = e.entangledLanes;
		if (n !== 0) for (e = e.entanglements, n &= t; 0 < n;) {
			var r = 31 - L(n), i = 1 << r;
			t |= e[r], n &= ~i;
		}
		return t;
	}
	function ct(e, t) {
		switch (e) {
			case 1:
			case 2:
			case 4:
			case 8:
			case 64: return t + 250;
			case 16:
			case 32:
			case 128:
			case 256:
			case 512:
			case 1024:
			case 2048:
			case 4096:
			case 8192:
			case 16384:
			case 32768:
			case 65536:
			case 131072:
			case 262144:
			case 524288:
			case 1048576:
			case 2097152: return t + 5e3;
			case 4194304:
			case 8388608:
			case 16777216:
			case 33554432: return -1;
			case 67108864:
			case 134217728:
			case 268435456:
			case 536870912:
			case 1073741824: return -1;
			default: return -1;
		}
	}
	function lt() {
		var e = rt;
		return rt <<= 1, !(rt & 62914560) && (rt = 4194304), e;
	}
	function ut(e) {
		for (var t = [], n = 0; 31 > n; n++) t.push(e);
		return t;
	}
	function dt(e, t) {
		e.pendingLanes |= t, t !== 268435456 && (e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0);
	}
	function ft(e, t, n, r, i, a) {
		var o = e.pendingLanes;
		e.pendingLanes = n, e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0, e.expiredLanes &= n, e.entangledLanes &= n, e.errorRecoveryDisabledLanes &= n, e.shellSuspendCounter = 0;
		var s = e.entanglements, c = e.expirationTimes, l = e.hiddenUpdates;
		for (n = o & ~n; 0 < n;) {
			var u = 31 - L(n), d = 1 << u;
			s[u] = 0, c[u] = -1;
			var f = l[u];
			if (f !== null) for (l[u] = null, u = 0; u < f.length; u++) {
				var p = f[u];
				p !== null && (p.lane &= -536870913);
			}
			n &= ~d;
		}
		r !== 0 && pt(e, r, 0), a !== 0 && i === 0 && e.tag !== 0 && (e.suspendedLanes |= a & ~(o & ~t));
	}
	function pt(e, t, n) {
		e.pendingLanes |= t, e.suspendedLanes &= ~t;
		var r = 31 - L(t);
		e.entangledLanes |= t, e.entanglements[r] = e.entanglements[r] | 1073741824 | n & 261930;
	}
	function mt(e, t) {
		var n = e.entangledLanes |= t;
		for (e = e.entanglements; n;) {
			var r = 31 - L(n), i = 1 << r;
			i & t | e[r] & t && (e[r] |= t), n &= ~i;
		}
	}
	function ht(e, t) {
		var n = t & -t;
		return n = n & 42 ? 1 : gt(n), (n & (e.suspendedLanes | t)) === 0 ? n : 0;
	}
	function gt(e) {
		switch (e) {
			case 2:
				e = 1;
				break;
			case 8:
				e = 4;
				break;
			case 32:
				e = 16;
				break;
			case 256:
			case 512:
			case 1024:
			case 2048:
			case 4096:
			case 8192:
			case 16384:
			case 32768:
			case 65536:
			case 131072:
			case 262144:
			case 524288:
			case 1048576:
			case 2097152:
			case 4194304:
			case 8388608:
			case 16777216:
			case 33554432:
				e = 128;
				break;
			case 268435456:
				e = 134217728;
				break;
			default: e = 0;
		}
		return e;
	}
	function _t(e) {
		return e &= -e, 2 < e ? 8 < e ? e & 134217727 ? 32 : 268435456 : 8 : 2;
	}
	function vt() {
		var e = N.p;
		return e === 0 ? (e = window.event, e === void 0 ? 32 : Ch(e.type)) : e;
	}
	function yt(e, t) {
		var n = N.p;
		try {
			return N.p = e, t();
		} finally {
			N.p = n;
		}
	}
	var bt = Math.random().toString(36).slice(2), B = "__reactFiber$" + bt, xt = "__reactProps$" + bt, St = "__reactContainer$" + bt, Ct = "__reactEvents$" + bt, wt = "__reactListeners$" + bt, Tt = "__reactHandles$" + bt, Et = "__reactResources$" + bt, Dt = "__reactMarker$" + bt, Ot = "__reactLoad$" + bt;
	function kt(e) {
		delete e[B], delete e[xt], delete e[wt], delete e[Tt];
	}
	function At(e) {
		var t;
		if (t = e[B]) return t;
		for (var n = e.parentNode; n;) {
			if (t = n[St] || n[B]) {
				if (n = t.alternate, t.child !== null || n !== null && n.child !== null) for (e = fm(e); e !== null;) {
					if (n = e[B]) return n;
					e = fm(e);
				}
				return t;
			}
			e = n, n = e.parentNode;
		}
		return null;
	}
	function jt(e) {
		if (e = e[B] || e[St]) {
			var t = e.tag;
			if (t === 5 || t === 6 || t === 13 || t === 31 || t === 26 || t === 27 || t === 3) return e;
		}
		return null;
	}
	function Mt(e) {
		var t = e.tag;
		if (t === 5 || t === 26 || t === 27 || t === 6) return e.stateNode;
		throw Error(i(33));
	}
	function Nt(e) {
		var t = e[Et];
		return t ||= e[Et] = {
			hoistableStyles: /* @__PURE__ */ new Map(),
			hoistableScripts: /* @__PURE__ */ new Map()
		}, t;
	}
	function V(e) {
		e[Dt] = !0;
	}
	function Pt(e) {
		e[Ot] = void 0;
	}
	var Ft = /* @__PURE__ */ new Set(), It = {};
	function Lt(e, t) {
		Rt(e, t), Rt(e + "Capture", t);
	}
	function Rt(e, t) {
		for (It[e] = t, e = 0; e < t.length; e++) Ft.add(t[e]);
	}
	var zt = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"), Bt = {}, Vt = {};
	function Ht(e) {
		return Le.call(Vt, e) ? !0 : Le.call(Bt, e) ? !1 : zt.test(e) ? Vt[e] = !0 : (Bt[e] = !0, !1);
	}
	var H = !1;
	function Ut() {
		var e = H;
		return H = !1, e;
	}
	function Wt(e, t, n) {
		if (Ht(t)) {
			if (n === null) e.removeAttribute(t);
			else {
				switch (typeof n) {
					case "undefined":
					case "function":
					case "symbol":
						e.removeAttribute(t);
						return;
					case "boolean":
						var r = t.toLowerCase().slice(0, 5);
						if (r !== "data-" && r !== "aria-") {
							e.removeAttribute(t);
							return;
						}
				}
				e.setAttribute(t, n);
			}
		}
	}
	function Gt(e, t, n) {
		if (n === null) e.removeAttribute(t);
		else {
			switch (typeof n) {
				case "undefined":
				case "function":
				case "symbol":
				case "boolean":
					e.removeAttribute(t);
					return;
			}
			e.setAttribute(t, n);
		}
	}
	function Kt(e, t, n, r) {
		if (r === null) e.removeAttribute(n);
		else {
			switch (typeof r) {
				case "undefined":
				case "function":
				case "symbol":
				case "boolean":
					e.removeAttribute(n);
					return;
			}
			e.setAttributeNS(t, n, r);
		}
	}
	function qt(e) {
		switch (typeof e) {
			case "bigint":
			case "boolean":
			case "number":
			case "string":
			case "undefined": return e;
			case "object": return e;
			default: return "";
		}
	}
	function Jt(e) {
		var t = e.type;
		return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
	}
	function Yt(e, t, n) {
		var r = Object.getOwnPropertyDescriptor(e.constructor.prototype, t);
		if (!e.hasOwnProperty(t) && r !== void 0 && typeof r.get == "function" && typeof r.set == "function") {
			var i = r.get, a = r.set;
			return Object.defineProperty(e, t, {
				configurable: !0,
				get: function() {
					return i.call(this);
				},
				set: function(e) {
					n = "" + e, a.call(this, e);
				}
			}), Object.defineProperty(e, t, { enumerable: r.enumerable }), {
				getValue: function() {
					return n;
				},
				setValue: function(e) {
					n = "" + e;
				},
				stopTracking: function() {
					e._valueTracker = null, delete e[t];
				}
			};
		}
	}
	function Xt(e) {
		if (!e._valueTracker) {
			var t = Jt(e) ? "checked" : "value";
			e._valueTracker = Yt(e, t, "" + e[t]);
		}
	}
	function Zt(e) {
		if (!e) return !1;
		var t = e._valueTracker;
		if (!t) return !0;
		var n = t.getValue(), r = "";
		return e && (r = Jt(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n && (t.setValue(e), !0);
	}
	var Qt = /[\n"\\]/g;
	function $t(e) {
		return e.replace(Qt, function(e) {
			return "\\" + e.charCodeAt(0).toString(16) + " ";
		});
	}
	function en(e, t, n, r, i, a, o, s) {
		e.name = "", o != null && typeof o != "function" && typeof o != "symbol" && typeof o != "boolean" ? e.type = o : e.removeAttribute("type"), t == null ? o !== "submit" && o !== "reset" || e.removeAttribute("value") : o === "number" ? (t === 0 && e.value === "" || e.value != t) && (e.value = "" + qt(t)) : e.value !== "" + qt(t) && (e.value = "" + qt(t)), t == null ? n == null ? r != null && e.removeAttribute("value") : nn(e, qt(n)) : o === "number" && e.value == t ? nn(e, qt(e.value)) : nn(e, qt(t)), i == null && a != null && (e.defaultChecked = !!a), i != null && (e.checked = i && typeof i != "function" && typeof i != "symbol"), s != null && typeof s != "function" && typeof s != "symbol" && typeof s != "boolean" ? e.name = "" + qt(s) : e.removeAttribute("name");
	}
	function tn(e, t, n, r, i, a, o, s) {
		if (a != null && typeof a != "function" && typeof a != "symbol" && typeof a != "boolean" && (e.type = a), t != null || n != null) {
			if (!(a !== "submit" && a !== "reset" || t != null)) {
				Xt(e);
				return;
			}
			n = n == null ? "" : "" + qt(n), t = t == null ? n : "" + qt(t), s || t === e.value || (e.value = t), e.defaultValue = t;
		}
		r ??= i, r = typeof r != "function" && typeof r != "symbol" && !!r, e.checked = s ? e.checked : !!r, e.defaultChecked = !!r, o != null && typeof o != "function" && typeof o != "symbol" && typeof o != "boolean" && (e.name = o), Xt(e);
	}
	function nn(e, t) {
		e.defaultValue !== "" + t && (e.defaultValue = "" + t);
	}
	function rn(e, t, n, r) {
		if (e = e.options, t) {
			t = {};
			for (var i = 0; i < n.length; i++) t["$" + n[i]] = !0;
			for (n = 0; n < e.length; n++) i = t.hasOwnProperty("$" + e[n].value), e[n].selected !== i && (e[n].selected = i), i && r && (e[n].defaultSelected = !0);
		} else {
			for (n = "" + qt(n), t = null, i = 0; i < e.length; i++) {
				if (e[i].value === n) {
					e[i].selected = !0, r && (e[i].defaultSelected = !0);
					return;
				}
				t !== null || e[i].disabled || (t = e[i]);
			}
			t !== null && (t.selected = !0);
		}
	}
	function an(e, t, n) {
		t != null && (t = "" + qt(t), t !== e.value && (e.value = t), n == null) ? e.defaultValue !== t && (e.defaultValue = t) : e.defaultValue = n == null ? "" : "" + qt(n);
	}
	function on(e, t, n, r) {
		if (t == null) {
			if (r != null) {
				if (n != null) throw Error(i(92));
				if (ve(r)) {
					if (1 < r.length) throw Error(i(93));
					r = r[0];
				}
				n = r;
			}
			n ??= "", t = n;
		}
		n = qt(t), e.defaultValue = n, r = e.textContent, r === n && r !== "" && r !== null && (e.value = r), Xt(e);
	}
	function sn(e, t) {
		if (t) {
			var n = e.firstChild;
			if (n && n === e.lastChild && n.nodeType === 3) {
				n.nodeValue = t;
				return;
			}
		}
		e.textContent = t;
	}
	var cn = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));
	function ln(e, t, n) {
		var r = t.indexOf("--") === 0;
		n == null || typeof n == "boolean" || n === "" ? r ? e.setProperty(t, "") : t === "float" ? e.cssFloat = "" : e[t] = "" : r ? e.setProperty(t, n) : typeof n != "number" || n === 0 || cn.has(t) ? t === "float" ? e.cssFloat = n : e[t] = ("" + n).trim() : e[t] = n + "px";
	}
	function un(e, t, n) {
		if (t != null && typeof t != "object") throw Error(i(62));
		if (e = e.style, n != null) {
			for (var r in n) !n.hasOwnProperty(r) || t != null && t.hasOwnProperty(r) || (r.indexOf("--") === 0 ? e.setProperty(r, "") : r === "float" ? e.cssFloat = "" : e[r] = "", H = !0);
			for (var a in t) r = t[a], t.hasOwnProperty(a) && n[a] !== r && (ln(e, a, r), H = !0);
		} else for (var o in t) t.hasOwnProperty(o) && ln(e, o, t[o]);
	}
	function dn(e) {
		if (e.indexOf("-") === -1) return !1;
		switch (e) {
			case "annotation-xml":
			case "color-profile":
			case "font-face":
			case "font-face-src":
			case "font-face-uri":
			case "font-face-format":
			case "font-face-name":
			case "missing-glyph": return !1;
			default: return !0;
		}
	}
	var fn = /* @__PURE__ */ new Map([
		["acceptCharset", "accept-charset"],
		["htmlFor", "for"],
		["httpEquiv", "http-equiv"],
		["crossOrigin", "crossorigin"],
		["accentHeight", "accent-height"],
		["alignmentBaseline", "alignment-baseline"],
		["arabicForm", "arabic-form"],
		["baselineShift", "baseline-shift"],
		["capHeight", "cap-height"],
		["clipPath", "clip-path"],
		["clipRule", "clip-rule"],
		["colorInterpolation", "color-interpolation"],
		["colorInterpolationFilters", "color-interpolation-filters"],
		["colorProfile", "color-profile"],
		["colorRendering", "color-rendering"],
		["dominantBaseline", "dominant-baseline"],
		["enableBackground", "enable-background"],
		["fillOpacity", "fill-opacity"],
		["fillRule", "fill-rule"],
		["floodColor", "flood-color"],
		["floodOpacity", "flood-opacity"],
		["fontFamily", "font-family"],
		["fontSize", "font-size"],
		["fontSizeAdjust", "font-size-adjust"],
		["fontStretch", "font-stretch"],
		["fontStyle", "font-style"],
		["fontVariant", "font-variant"],
		["fontWeight", "font-weight"],
		["glyphName", "glyph-name"],
		["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
		["glyphOrientationVertical", "glyph-orientation-vertical"],
		["horizAdvX", "horiz-adv-x"],
		["horizOriginX", "horiz-origin-x"],
		["imageRendering", "image-rendering"],
		["letterSpacing", "letter-spacing"],
		["lightingColor", "lighting-color"],
		["markerEnd", "marker-end"],
		["markerMid", "marker-mid"],
		["markerStart", "marker-start"],
		["maskType", "mask-type"],
		["overlinePosition", "overline-position"],
		["overlineThickness", "overline-thickness"],
		["paintOrder", "paint-order"],
		["panose-1", "panose-1"],
		["pointerEvents", "pointer-events"],
		["renderingIntent", "rendering-intent"],
		["shapeRendering", "shape-rendering"],
		["stopColor", "stop-color"],
		["stopOpacity", "stop-opacity"],
		["strikethroughPosition", "strikethrough-position"],
		["strikethroughThickness", "strikethrough-thickness"],
		["strokeDasharray", "stroke-dasharray"],
		["strokeDashoffset", "stroke-dashoffset"],
		["strokeLinecap", "stroke-linecap"],
		["strokeLinejoin", "stroke-linejoin"],
		["strokeMiterlimit", "stroke-miterlimit"],
		["strokeOpacity", "stroke-opacity"],
		["strokeWidth", "stroke-width"],
		["textAnchor", "text-anchor"],
		["textDecoration", "text-decoration"],
		["textRendering", "text-rendering"],
		["transformOrigin", "transform-origin"],
		["underlinePosition", "underline-position"],
		["underlineThickness", "underline-thickness"],
		["unicodeBidi", "unicode-bidi"],
		["unicodeRange", "unicode-range"],
		["unitsPerEm", "units-per-em"],
		["vAlphabetic", "v-alphabetic"],
		["vHanging", "v-hanging"],
		["vIdeographic", "v-ideographic"],
		["vMathematical", "v-mathematical"],
		["vectorEffect", "vector-effect"],
		["vertAdvY", "vert-adv-y"],
		["vertOriginX", "vert-origin-x"],
		["vertOriginY", "vert-origin-y"],
		["wordSpacing", "word-spacing"],
		["writingMode", "writing-mode"],
		["xmlnsXlink", "xmlns:xlink"],
		["xHeight", "x-height"]
	]), pn = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
	function mn(e) {
		return pn.test("" + e) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : e;
	}
	function hn() {}
	var gn = null;
	function _n(e) {
		return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e;
	}
	var vn = null, yn = null;
	function bn(e) {
		var t = jt(e);
		if (t && (e = t.stateNode)) {
			var n = e[xt] || null;
			a: switch (e = t.stateNode, t.type) {
				case "input":
					if (en(e, n.value, n.defaultValue, n.defaultValue, n.checked, n.defaultChecked, n.type, n.name), t = n.name, n.type === "radio" && t != null) {
						for (n = e; n.parentNode;) n = n.parentNode;
						for (n = n.querySelectorAll("input[name=\"" + $t("" + t) + "\"][type=\"radio\"]"), t = 0; t < n.length; t++) {
							var r = n[t];
							if (r !== e && r.form === e.form) {
								var a = r[xt] || null;
								if (!a) throw Error(i(90));
								en(r, a.value, a.defaultValue, a.defaultValue, a.checked, a.defaultChecked, a.type, a.name);
							}
						}
						for (t = 0; t < n.length; t++) r = n[t], r.form === e.form && Zt(r);
					}
					break a;
				case "textarea":
					an(e, n.value, n.defaultValue);
					break a;
				case "select": t = n.value, t != null && rn(e, !!n.multiple, t, !1);
			}
		}
	}
	var xn = !1;
	function Sn(e, t, n) {
		if (xn) return e(t, n);
		xn = !0;
		try {
			return e(t);
		} finally {
			if (xn = !1, (vn !== null || yn !== null) && (zd(), vn && (t = vn, e = yn, yn = vn = null, bn(t), e))) for (t = 0; t < e.length; t++) bn(e[t]);
		}
	}
	function Cn(e, t) {
		var n = e.stateNode;
		if (n === null) return null;
		var r = n[xt] || null;
		if (r === null) return null;
		n = r[t];
		a: switch (t) {
			case "onClick":
			case "onClickCapture":
			case "onDoubleClick":
			case "onDoubleClickCapture":
			case "onMouseDown":
			case "onMouseDownCapture":
			case "onMouseMove":
			case "onMouseMoveCapture":
			case "onMouseUp":
			case "onMouseUpCapture":
			case "onMouseEnter":
				(r = !r.disabled) || (e = e.type, r = e !== "button" && e !== "input" && e !== "select" && e !== "textarea"), e = !r;
				break a;
			default: e = !1;
		}
		if (e) return null;
		if (n && typeof n != "function") throw Error(i(231, t, typeof n));
		return n;
	}
	var wn = typeof window < "u" && window.document !== void 0 && window.document.createElement !== void 0, Tn = !1;
	if (wn) try {
		var En = {};
		Object.defineProperty(En, "passive", { get: function() {
			Tn = !0;
		} }), window.addEventListener("test", En, En), window.removeEventListener("test", En, En);
	} catch {
		Tn = !1;
	}
	var Dn = null, On = null, kn = null;
	function An() {
		if (kn) return kn;
		var e, t = On, n = t.length, r, i = "value" in Dn ? Dn.value : Dn.textContent, a = i.length;
		for (e = 0; e < n && t[e] === i[e]; e++);
		var o = n - e;
		for (r = 1; r <= o && t[n - r] === i[a - r]; r++);
		return kn = i.slice(e, 1 < r ? 1 - r : void 0);
	}
	function jn(e) {
		var t = e.keyCode;
		return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0;
	}
	function Mn() {
		return !0;
	}
	function Nn() {
		return !1;
	}
	function Pn(e) {
		function t(t, n, r, i, a) {
			for (var o in this._reactName = t, this._targetInst = r, this.type = n, this.nativeEvent = i, this.target = a, this.currentTarget = null, e) e.hasOwnProperty(o) && (t = e[o], this[o] = t ? t(i) : i[o]);
			return this.isDefaultPrevented = (i.defaultPrevented == null ? !1 === i.returnValue : i.defaultPrevented) ? Mn : Nn, this.isPropagationStopped = Nn, this;
		}
		return D(t.prototype, {
			preventDefault: function() {
				this.defaultPrevented = !0;
				var e = this.nativeEvent;
				e && (e.preventDefault ? e.preventDefault() : typeof e.returnValue != "unknown" && (e.returnValue = !1), this.isDefaultPrevented = Mn);
			},
			stopPropagation: function() {
				var e = this.nativeEvent;
				e && (e.stopPropagation ? e.stopPropagation() : typeof e.cancelBubble != "unknown" && (e.cancelBubble = !0), this.isPropagationStopped = Mn);
			},
			persist: function() {},
			isPersistent: Mn
		}), t;
	}
	var Fn = {
		eventPhase: 0,
		bubbles: 0,
		cancelable: 0,
		timeStamp: function(e) {
			return e.timeStamp || Date.now();
		},
		defaultPrevented: 0,
		isTrusted: 0
	}, In = Pn(Fn), Ln = D({}, Fn, {
		view: 0,
		detail: 0
	}), Rn = Pn(Ln), zn, Bn, Vn, Hn = D({}, Ln, {
		screenX: 0,
		screenY: 0,
		clientX: 0,
		clientY: 0,
		pageX: 0,
		pageY: 0,
		ctrlKey: 0,
		shiftKey: 0,
		altKey: 0,
		metaKey: 0,
		getModifierState: $n,
		button: 0,
		buttons: 0,
		relatedTarget: function(e) {
			return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget;
		},
		movementX: function(e) {
			return "movementX" in e ? e.movementX : (e !== Vn && (Vn && e.type === "mousemove" ? (zn = e.screenX - Vn.screenX, Bn = e.screenY - Vn.screenY) : Bn = zn = 0, Vn = e), zn);
		},
		movementY: function(e) {
			return "movementY" in e ? e.movementY : Bn;
		}
	}), Un = Pn(Hn), Wn = Pn(D({}, Hn, { dataTransfer: 0 })), Gn = Pn(D({}, Ln, { relatedTarget: 0 })), Kn = Pn(D({}, Fn, {
		animationName: 0,
		elapsedTime: 0,
		pseudoElement: 0
	})), qn = Pn(D({}, Fn, { clipboardData: function(e) {
		return "clipboardData" in e ? e.clipboardData : window.clipboardData;
	} })), Jn = Pn(D({}, Fn, { data: 0 })), Yn = {
		Esc: "Escape",
		Spacebar: " ",
		Left: "ArrowLeft",
		Up: "ArrowUp",
		Right: "ArrowRight",
		Down: "ArrowDown",
		Del: "Delete",
		Win: "OS",
		Menu: "ContextMenu",
		Apps: "ContextMenu",
		Scroll: "ScrollLock",
		MozPrintableKey: "Unidentified"
	}, Xn = {
		8: "Backspace",
		9: "Tab",
		12: "Clear",
		13: "Enter",
		16: "Shift",
		17: "Control",
		18: "Alt",
		19: "Pause",
		20: "CapsLock",
		27: "Escape",
		32: " ",
		33: "PageUp",
		34: "PageDown",
		35: "End",
		36: "Home",
		37: "ArrowLeft",
		38: "ArrowUp",
		39: "ArrowRight",
		40: "ArrowDown",
		45: "Insert",
		46: "Delete",
		112: "F1",
		113: "F2",
		114: "F3",
		115: "F4",
		116: "F5",
		117: "F6",
		118: "F7",
		119: "F8",
		120: "F9",
		121: "F10",
		122: "F11",
		123: "F12",
		144: "NumLock",
		145: "ScrollLock",
		224: "Meta"
	}, Zn = {
		Alt: "altKey",
		Control: "ctrlKey",
		Meta: "metaKey",
		Shift: "shiftKey"
	};
	function Qn(e) {
		var t = this.nativeEvent;
		return t.getModifierState ? t.getModifierState(e) : (e = Zn[e]) ? !!t[e] : !1;
	}
	function $n() {
		return Qn;
	}
	var er = Pn(D({}, Ln, {
		key: function(e) {
			if (e.key) {
				var t = Yn[e.key] || e.key;
				if (t !== "Unidentified") return t;
			}
			return e.type === "keypress" ? (e = jn(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? Xn[e.keyCode] || "Unidentified" : "";
		},
		code: 0,
		location: 0,
		ctrlKey: 0,
		shiftKey: 0,
		altKey: 0,
		metaKey: 0,
		repeat: 0,
		locale: 0,
		getModifierState: $n,
		charCode: function(e) {
			return e.type === "keypress" ? jn(e) : 0;
		},
		keyCode: function(e) {
			return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
		},
		which: function(e) {
			return e.type === "keypress" ? jn(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
		}
	})), tr = Pn(D({}, Hn, {
		pointerId: 0,
		width: 0,
		height: 0,
		pressure: 0,
		tangentialPressure: 0,
		tiltX: 0,
		tiltY: 0,
		twist: 0,
		pointerType: 0,
		isPrimary: 0
	})), nr = Pn(D({}, Fn, { submitter: 0 })), rr = Pn(D({}, Ln, {
		touches: 0,
		targetTouches: 0,
		changedTouches: 0,
		altKey: 0,
		metaKey: 0,
		ctrlKey: 0,
		shiftKey: 0,
		getModifierState: $n
	})), ir = Pn(D({}, Fn, {
		propertyName: 0,
		elapsedTime: 0,
		pseudoElement: 0
	})), ar = Pn(D({}, Hn, {
		deltaX: function(e) {
			return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
		},
		deltaY: function(e) {
			return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0;
		},
		deltaZ: 0,
		deltaMode: 0
	})), or = Pn(D({}, Fn, {
		newState: 0,
		oldState: 0,
		source: 0
	})), sr = [
		9,
		13,
		27,
		32
	], cr = wn && "CompositionEvent" in window, U = null;
	wn && "documentMode" in document && (U = document.documentMode);
	var lr = wn && "TextEvent" in window && !U, ur = wn && (!cr || U && 8 < U && 11 >= U), dr = " ", fr = !1;
	function pr(e, t) {
		switch (e) {
			case "keyup": return sr.indexOf(t.keyCode) !== -1;
			case "keydown": return t.keyCode !== 229;
			case "keypress":
			case "mousedown":
			case "focusout": return !0;
			default: return !1;
		}
	}
	function mr(e) {
		return e = e.detail, typeof e == "object" && "data" in e ? e.data : null;
	}
	var hr = !1;
	function gr(e, t) {
		switch (e) {
			case "compositionend": return mr(t);
			case "keypress": return t.which === 32 ? (fr = !0, dr) : null;
			case "textInput": return e = t.data, e === dr && fr ? null : e;
			default: return null;
		}
	}
	function _r(e, t) {
		if (hr) return e === "compositionend" || !cr && pr(e, t) ? (e = An(), kn = On = Dn = null, hr = !1, e) : null;
		switch (e) {
			case "paste": return null;
			case "keypress":
				if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
					if (t.char && 1 < t.char.length) return t.char;
					if (t.which) return String.fromCharCode(t.which);
				}
				return null;
			case "compositionend": return ur && t.locale !== "ko" ? null : t.data;
			default: return null;
		}
	}
	var vr = {
		color: !0,
		date: !0,
		datetime: !0,
		"datetime-local": !0,
		email: !0,
		month: !0,
		number: !0,
		password: !0,
		range: !0,
		search: !0,
		tel: !0,
		text: !0,
		time: !0,
		url: !0,
		week: !0
	};
	function yr(e) {
		var t = e && e.nodeName && e.nodeName.toLowerCase();
		return t === "input" ? !!vr[e.type] : t === "textarea";
	}
	function br(e, t, n, r) {
		vn ? yn ? yn.push(r) : yn = [r] : vn = r, t = Jf(t, "onChange"), 0 < t.length && (n = new In("onChange", "change", null, n, r), e.push({
			event: n,
			listeners: t
		}));
	}
	var xr = null, Sr = null;
	function Cr(e) {
		Vf(e, 0);
	}
	function wr(e) {
		if (Zt(Mt(e))) return e;
	}
	function Tr(e, t) {
		if (e === "change") return t;
	}
	var Er = !1;
	if (wn) {
		var Dr;
		if (wn) {
			var Or = "oninput" in document;
			if (!Or) {
				var kr = document.createElement("div");
				kr.setAttribute("oninput", "return;"), Or = typeof kr.oninput == "function";
			}
			Dr = Or;
		} else Dr = !1;
		Er = Dr && (!document.documentMode || 9 < document.documentMode);
	}
	function Ar() {
		xr && (xr.detachEvent("onpropertychange", jr), Sr = xr = null);
	}
	function jr(e) {
		if (e.propertyName === "value" && wr(Sr)) {
			var t = [];
			br(t, Sr, e, _n(e)), Sn(Cr, t);
		}
	}
	function Mr(e, t, n) {
		e === "focusin" ? (Ar(), xr = t, Sr = n, xr.attachEvent("onpropertychange", jr)) : e === "focusout" && Ar();
	}
	function Nr(e) {
		if (e === "selectionchange" || e === "keyup" || e === "keydown") return wr(Sr);
	}
	function Pr(e, t) {
		if (e === "click") return wr(t);
	}
	function Fr(e, t) {
		if (e === "input" || e === "change") return wr(t);
	}
	function Ir(e, t) {
		return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t;
	}
	var Lr = typeof Object.is == "function" ? Object.is : Ir;
	function Rr(e, t) {
		if (Lr(e, t)) return !0;
		if (typeof e != "object" || !e || typeof t != "object" || !t) return !1;
		var n = Object.keys(e), r = Object.keys(t);
		if (n.length !== r.length) return !1;
		for (r = 0; r < n.length; r++) {
			var i = n[r];
			if (!Le.call(t, i) || !Lr(e[i], t[i])) return !1;
		}
		return !0;
	}
	function zr(e) {
		if (e ||= typeof document < "u" ? document : void 0, e === void 0) return null;
		try {
			return e.activeElement || e.body;
		} catch {
			return e.body;
		}
	}
	function Br(e) {
		for (; e && e.firstChild;) e = e.firstChild;
		return e;
	}
	function Vr(e, t) {
		var n = Br(e);
		e = 0;
		for (var r; n;) {
			if (n.nodeType === 3) {
				if (r = e + n.textContent.length, e <= t && r >= t) return {
					node: n,
					offset: t - e
				};
				e = r;
			}
			a: {
				for (; n;) {
					if (n.nextSibling) {
						n = n.nextSibling;
						break a;
					}
					n = n.parentNode;
				}
				n = void 0;
			}
			n = Br(n);
		}
	}
	function Hr(e, t) {
		return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? Hr(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1;
	}
	function Ur(e) {
		e = e != null && e.ownerDocument != null && e.ownerDocument.defaultView != null ? e.ownerDocument.defaultView : window;
		for (var t = zr(e.document); t instanceof e.HTMLIFrameElement;) {
			try {
				var n = typeof t.contentWindow.location.href == "string";
			} catch {
				n = !1;
			}
			if (n) e = t.contentWindow;
			else break;
			t = zr(e.document);
		}
		return t;
	}
	function Wr(e) {
		var t = e && e.nodeName && e.nodeName.toLowerCase();
		return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true");
	}
	var Gr = wn && "documentMode" in document && 11 >= document.documentMode, Kr = null, qr = null, Jr = null, Yr = !1;
	function Xr(e, t, n) {
		var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
		Yr || Kr == null || Kr !== zr(r) || (r = Kr, "selectionStart" in r && Wr(r) ? r = {
			start: r.selectionStart,
			end: r.selectionEnd
		} : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
			anchorNode: r.anchorNode,
			anchorOffset: r.anchorOffset,
			focusNode: r.focusNode,
			focusOffset: r.focusOffset
		}), Jr && Rr(Jr, r) || (Jr = r, r = Jf(qr, "onSelect"), 0 < r.length && (t = new In("onSelect", "select", null, t, n), e.push({
			event: t,
			listeners: r
		}), t.target = Kr)));
	}
	function Zr(e, t) {
		var n = {};
		return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n;
	}
	var Qr = {
		animationend: Zr("Animation", "AnimationEnd"),
		animationiteration: Zr("Animation", "AnimationIteration"),
		animationstart: Zr("Animation", "AnimationStart"),
		transitionrun: Zr("Transition", "TransitionRun"),
		transitionstart: Zr("Transition", "TransitionStart"),
		transitioncancel: Zr("Transition", "TransitionCancel"),
		transitionend: Zr("Transition", "TransitionEnd")
	}, $r = {}, ei = {};
	wn && (ei = document.createElement("div").style, "AnimationEvent" in window || (delete Qr.animationend.animation, delete Qr.animationiteration.animation, delete Qr.animationstart.animation), "TransitionEvent" in window || delete Qr.transitionend.transition);
	function ti(e) {
		if ($r[e]) return $r[e];
		if (!Qr[e]) return e;
		var t = Qr[e], n;
		for (n in t) if (t.hasOwnProperty(n) && n in ei) return $r[e] = t[n];
		return e;
	}
	var ni = ti("animationend"), ri = ti("animationiteration"), ii = ti("animationstart"), ai = ti("transitionrun"), oi = ti("transitionstart"), si = ti("transitioncancel"), ci = ti("transitionend"), li = /* @__PURE__ */ new Map(), ui = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
	ui.push("scrollEnd");
	function di(e, t) {
		li.set(e, t), Lt(t, [e]);
	}
	var fi = 0;
	function pi(e, t) {
		if (e.name != null && e.name !== "auto") return e.name;
		if (t.autoName !== null) return t.autoName;
		e = bd.identifierPrefix;
		var n = fi++;
		return e = "_" + e + "t_" + n.toString(32) + "_", t.autoName = e;
	}
	function mi(e) {
		if (e == null || typeof e == "string") return e;
		var t = null, n = Od;
		if (n !== null) for (var r = 0; r < n.length; r++) {
			var i = e[n[r]];
			if (i != null) {
				if (i === "none") return "none";
				t = t == null ? i : t + (" " + i);
			}
		}
		return t ?? e.default;
	}
	function hi(e, t) {
		return e = mi(e), t = mi(t), t == null ? e === "auto" ? null : e : t === "auto" ? null : t;
	}
	var gi = typeof reportError == "function" ? reportError : function(e) {
		if (typeof window == "object" && typeof window.ErrorEvent == "function") {
			var t = new window.ErrorEvent("error", {
				bubbles: !0,
				cancelable: !0,
				message: typeof e == "object" && e && typeof e.message == "string" ? String(e.message) : String(e),
				error: e
			});
			if (!window.dispatchEvent(t)) return;
		} else if (typeof process == "object" && typeof process.emit == "function") {
			process.emit("uncaughtException", e);
			return;
		}
		console.error(e);
	}, _i = [], vi = 0, yi = 0;
	function bi() {
		for (var e = vi, t = yi = vi = 0; t < e;) {
			var n = _i[t];
			_i[t++] = null;
			var r = _i[t];
			_i[t++] = null;
			var i = _i[t];
			_i[t++] = null;
			var a = _i[t];
			if (_i[t++] = null, r !== null && i !== null) {
				var o = r.pending;
				o === null ? i.next = i : (i.next = o.next, o.next = i), r.pending = i;
			}
			a !== 0 && wi(n, i, a);
		}
	}
	function xi(e, t, n, r) {
		_i[vi++] = e, _i[vi++] = t, _i[vi++] = n, _i[vi++] = r, yi |= r, e.lanes |= r, e = e.alternate, e !== null && (e.lanes |= r);
	}
	function Si(e, t, n, r) {
		return xi(e, t, n, r), Ti(e);
	}
	function Ci(e, t) {
		return xi(e, null, null, t), Ti(e);
	}
	function wi(e, t, n) {
		e.lanes |= n;
		var r = e.alternate;
		r !== null && (r.lanes |= n);
		for (var i = !1, a = e.return; a !== null;) a.childLanes |= n, r = a.alternate, r !== null && (r.childLanes |= n), a.tag === 22 && (e = a.stateNode, e === null || e._visibility & 1 || (i = !0)), e = a, a = a.return;
		return e.tag === 3 ? (a = e.stateNode, i && t !== null && (i = 31 - L(n), e = a.hiddenUpdates, r = e[i], r === null ? e[i] = [t] : r.push(t), t.lane = n | 536870912), a) : null;
	}
	function Ti(e) {
		if (50 < kd) throw kd = 0, Ad = null, Error(i(185));
		for (var t = e.return; t !== null;) e = t, t = e.return;
		return e.tag === 3 ? e.stateNode : null;
	}
	var Ei = {};
	function Di(e, t, n, r) {
		this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
	}
	function Oi(e, t, n, r) {
		return new Di(e, t, n, r);
	}
	function ki(e) {
		return e = e.prototype, !(!e || !e.isReactComponent);
	}
	function Ai(e, t) {
		var n = e.alternate;
		return n === null ? (n = Oi(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 1206910976, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
			lanes: t.lanes,
			firstContext: t.firstContext
		}, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n.refCleanup = e.refCleanup, n;
	}
	function ji(e, t) {
		e.flags &= 1206910978;
		var n = e.alternate;
		return n === null ? (e.childLanes = 0, e.lanes = t, e.child = null, e.subtreeFlags = 0, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null) : (e.childLanes = n.childLanes, e.lanes = n.lanes, e.child = n.child, e.subtreeFlags = 0, e.deletions = null, e.memoizedProps = n.memoizedProps, e.memoizedState = n.memoizedState, e.updateQueue = n.updateQueue, e.type = n.type, t = n.dependencies, e.dependencies = t === null ? null : {
			lanes: t.lanes,
			firstContext: t.firstContext
		}), e;
	}
	function Mi(e, t, n, r, a, o) {
		var s = 0;
		if (r = e, typeof r == "function") ki(r) && (s = 1);
		else if (typeof r == "string") s = qm(e, n, Ce.current) ? 26 : e === "html" || e === "head" || e === "body" ? 27 : 5;
		else a: switch (r) {
			case le: return e = Oi(31, n, t, a), e.elementType = le, e.lanes = o, e;
			case te: return Ni(n.children, a, o, t);
			case ne:
				s = 8, a |= 24;
				break;
			case re: return e = Oi(12, n, t, a | 2), e.elementType = re, e.lanes = o, e;
			case oe: return e = Oi(13, n, t, a), e.elementType = oe, e.lanes = o, e;
			case se: return e = Oi(19, n, t, a), e.elementType = se, e.lanes = o, e;
			case ue:
			case fe: return e = a | 32, e = Oi(30, n, t, e), e.elementType = fe, e.lanes = o, e.stateNode = {
				autoName: null,
				paired: null,
				clones: null,
				ref: null
			}, e;
			default:
				if (typeof r == "object" && r) switch (r.$$typeof) {
					case A:
						s = 10;
						break a;
					case ie:
						s = 9;
						break a;
					case ae:
						s = 11;
						break a;
					case ce:
						s = 14;
						break a;
					case j:
						s = 16, r = null;
						break a;
				}
				s = 29, n = Error(i(130, e === null ? "null" : typeof e, "")), r = null;
		}
		return t = Oi(s, n, t, a), t.elementType = e, t.type = r, t.lanes = o, t;
	}
	function Ni(e, t, n, r) {
		return e = Oi(7, e, r, t), e.lanes = n, e;
	}
	function Pi(e, t, n) {
		return e = Oi(6, e, null, t), e.lanes = n, e;
	}
	function Fi(e) {
		var t = Oi(18, null, null, 0);
		return t.stateNode = e, t;
	}
	function Ii(e, t, n) {
		return t = Oi(4, e.children === null ? [] : e.children, e.key, t), t.lanes = n, t.stateNode = {
			containerInfo: e.containerInfo,
			pendingChildren: null,
			implementation: e.implementation
		}, t;
	}
	var Li = /* @__PURE__ */ new WeakMap();
	function Ri(e, t) {
		if (typeof e == "object" && e) {
			var n = Li.get(e);
			return n === void 0 ? (t = {
				value: e,
				source: t,
				stack: Ie(t)
			}, Li.set(e, t), t) : n;
		}
		return {
			value: e,
			source: t,
			stack: Ie(t)
		};
	}
	var zi = [], Bi = 0, Vi = null, Hi = 0, Ui = [], Wi = 0, Gi = null, Ki = 1, qi = "";
	function Ji(e, t) {
		zi[Bi++] = Hi, zi[Bi++] = Vi, Vi = e, Hi = t;
	}
	function Yi(e, t, n) {
		Ui[Wi++] = Ki, Ui[Wi++] = qi, Ui[Wi++] = Gi, Gi = e;
		var r = Ki;
		e = qi;
		var i = 32 - L(r) - 1;
		r &= ~(1 << i), n += 1;
		var a = 32 - L(t) + i;
		if (30 < a) {
			var o = i - i % 5;
			a = (r & (1 << o) - 1).toString(32), r >>= o, i -= o, Ki = 1 << 32 - L(t) + i | n << i | r, qi = a + e;
		} else Ki = 1 << a | n << i | r, qi = e;
	}
	function Xi(e) {
		e.return !== null && (Ji(e, 1), Yi(e, 1, 0));
	}
	function Zi(e) {
		for (; e === Vi;) Vi = zi[--Bi], zi[Bi] = null, Hi = zi[--Bi], zi[Bi] = null;
		for (; e === Gi;) Gi = Ui[--Wi], Ui[Wi] = null, qi = Ui[--Wi], Ui[Wi] = null, Ki = Ui[--Wi], Ui[Wi] = null;
	}
	function Qi(e, t) {
		Ui[Wi++] = Ki, Ui[Wi++] = qi, Ui[Wi++] = Gi, Ki = t.id, qi = t.overflow, Gi = e;
	}
	var $i = null, ea = null, W = !1, ta = null, na = !1, ra = Error(i(519));
	function ia(e) {
		throw ua(Ri(Error(i(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML", "")), e)), ra;
	}
	function aa(e) {
		var t = e.stateNode, n = e.type, r = e.memoizedProps;
		switch (t[B] = e, t[xt] = r, n) {
			case "dialog":
				Q("cancel", t), Q("close", t);
				break;
			case "iframe":
			case "object":
			case "embed":
				Q("load", t);
				break;
			case "video":
			case "audio":
				for (n = 0; n < zf.length; n++) Q(zf[n], t);
				break;
			case "source":
				Q("error", t);
				break;
			case "img":
			case "image":
			case "link":
				Q("error", t), Q("load", t);
				break;
			case "details":
				Q("toggle", t);
				break;
			case "input":
				Q("invalid", t), tn(t, r.value, r.defaultValue, r.checked, r.defaultChecked, r.type, r.name, !0);
				break;
			case "select":
				Q("invalid", t);
				break;
			case "textarea": Q("invalid", t), on(t, r.value, r.defaultValue, r.children);
		}
		n = r.children, typeof n != "string" && typeof n != "number" && typeof n != "bigint" || t.textContent === "" + n || !0 === r.suppressHydrationWarning || ep(t.textContent, n) ? (r.popover != null && (Q("beforetoggle", t), Q("toggle", t)), r.onScroll != null && Q("scroll", t), r.onScrollEnd != null && Q("scrollend", t), r.onClick != null && (t.onclick = hn), t = !0) : t = !1, t || ia(e, !0);
	}
	function oa(e) {
		for ($i = e.return; $i;) switch ($i.tag) {
			case 5:
			case 31:
			case 13:
				na = !1;
				return;
			case 27:
			case 3:
				na = !0;
				return;
			default: $i = $i.return;
		}
	}
	function sa(e) {
		if (e !== $i) return !1;
		if (!W) return oa(e), W = !0, !1;
		var t = e.tag, n;
		if ((n = t !== 3 && t !== 27) && ((n = t === 5) && (n = e.type, n = n === "form" || n === "button" || pp(e.type, e.memoizedProps)), n = !n), n && ea && ia(e), oa(e), t === 13) {
			if (e = e.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(i(317));
			ea = dm(e);
		} else if (t === 31) {
			if (e = e.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(i(317));
			ea = dm(e);
		} else t === 27 ? (t = ea, Sp(e.type) ? (e = um, um = null, ea = e) : ea = t) : ea = $i ? lm(e.stateNode.nextSibling) : null;
		return !0;
	}
	function ca() {
		ea = $i = null, W = !1;
	}
	function la() {
		var e = ta;
		return e !== null && (fd === null ? fd = e : fd.push.apply(fd, e), ta = null), e;
	}
	function ua(e) {
		ta === null ? ta = [e] : ta.push(e);
	}
	var da = xe(null), fa = null, pa = null;
	function ma(e, t, n) {
		F(da, t._currentValue), t._currentValue = n;
	}
	function ha(e) {
		e._currentValue = da.current, Se(da);
	}
	function ga(e, t, n) {
		for (; e !== null;) {
			var r = e.alternate;
			if ((e.childLanes & t) === t ? r !== null && (r.childLanes & t) !== t && (r.childLanes |= t) : (e.childLanes |= t, r !== null && (r.childLanes |= t)), e === n) break;
			e = e.return;
		}
	}
	function _a(e, t, n, r) {
		var a = e.child;
		for (a !== null && (a.return = e); a !== null;) {
			var o = a.dependencies;
			if (o !== null) {
				var s = a.child;
				o = o.firstContext;
				a: for (; o !== null;) {
					var c = o;
					o = a;
					for (var l = 0; l < t.length; l++) if (c.context === t[l]) {
						o.lanes |= n, c = o.alternate, c !== null && (c.lanes |= n), ga(o.return, n, e), r || (s = null);
						break a;
					}
					o = c.next;
				}
			} else if (a.tag === 18) {
				if (s = a.return, s === null) throw Error(i(341));
				s.lanes |= n, o = s.alternate, o !== null && (o.lanes |= n), ga(s, n, e), s = null;
			} else a.tag === 13 && a.memoizedState !== null && a.memoizedState.dehydrated === null ? (a.lanes |= n, s = a.alternate, s !== null && (s.lanes |= n), ga(a.return, n, e), s = a.child, s = s === null ? null : s.sibling) : s = a.child;
			if (s !== null) s.return = a;
			else for (s = a; s !== null;) {
				if (s === e) {
					s = null;
					break;
				}
				if (a = s.sibling, a !== null) {
					a.return = s.return, s = a;
					break;
				}
				s = s.return;
			}
			a = s;
		}
	}
	function va(e, t, n, r) {
		e = null;
		for (var a = t, o = !1; a !== null;) {
			if (!o) {
				if (a.flags & 524288) o = !0;
				else if (a.flags & 262144) break;
			}
			if (a.tag === 10) {
				var s = a.alternate;
				if (s === null) throw Error(i(387));
				if (s = s.memoizedProps, s !== null) {
					var c = a.type;
					Lr(a.pendingProps.value, s.value) || (e === null ? e = [c] : e.push(c));
				}
			} else if (a === Ee.current) {
				if (s = a.alternate, s === null) throw Error(i(387));
				s.memoizedState.memoizedState !== a.memoizedState.memoizedState && (e === null ? e = [sh] : e.push(sh));
			}
			a = a.return;
		}
		return e !== null && _a(t, e, n, r), t.flags |= 262144, e !== null;
	}
	function ya(e) {
		for (e = e.firstContext; e !== null;) {
			if (!Lr(e.context._currentValue, e.memoizedValue)) return !0;
			e = e.next;
		}
		return !1;
	}
	function ba(e) {
		fa = e, pa = null, e = e.dependencies, e !== null && (e.firstContext = null);
	}
	function xa(e) {
		return Ca(fa, e);
	}
	function Sa(e, t) {
		return fa === null && ba(e), Ca(e, t);
	}
	function Ca(e, t) {
		var n = t._currentValue;
		if (t = {
			context: t,
			memoizedValue: n,
			next: null
		}, pa === null) {
			if (e === null) throw Error(i(308));
			pa = t, e.dependencies = {
				lanes: 0,
				firstContext: t
			}, e.flags |= 524288;
		} else pa = pa.next = t;
		return n;
	}
	var wa = typeof AbortController < "u" ? AbortController : function() {
		var e = [], t = this.signal = {
			aborted: !1,
			addEventListener: function(t, n) {
				e.push(n);
			}
		};
		this.abort = function() {
			t.aborted = !0, e.forEach(function(e) {
				return e();
			});
		};
	}, Ta = t.unstable_scheduleCallback, Ea = t.unstable_NormalPriority, Da = {
		$$typeof: A,
		Consumer: null,
		Provider: null,
		_currentValue: null,
		_currentValue2: null,
		_threadCount: 0
	};
	function Oa() {
		return {
			controller: new wa(),
			data: /* @__PURE__ */ new Map(),
			refCount: 0
		};
	}
	function ka(e) {
		e.refCount--, e.refCount === 0 && Ta(Ea, function() {
			e.controller.abort();
		});
	}
	function Aa(e, t) {
		if (e.pendingLanes & 4194048) {
			var n = e.transitionTypes;
			for (n === null && (n = e.transitionTypes = []), e = 0; e < t.length; e++) {
				var r = t[e];
				n.indexOf(r) === -1 && n.push(r);
			}
		}
	}
	var ja = null;
	function Ma(e) {
		var t = e.transitionTypes;
		return e.transitionTypes = null, t;
	}
	var Na = null, Pa = 0, Fa = 0, Ia = null;
	function La(e, t) {
		if (Na === null) {
			var n = Na = [];
			Pa = 0, Fa = Pf(), Ia = {
				status: "pending",
				value: void 0,
				then: function(e) {
					n.push(e);
				}
			};
		}
		return Pa++, t.then(Ra, Ra), t;
	}
	function Ra() {
		if (--Pa === 0 && (ja = null, Na !== null)) {
			Ia !== null && (Ia.status = "fulfilled");
			var e = Na;
			Na = null, Fa = 0, Ia = null;
			for (var t = 0; t < e.length; t++) (0, e[t])();
		}
	}
	function za(e, t) {
		var n = [], r = {
			status: "pending",
			value: null,
			reason: null,
			then: function(e) {
				n.push(e);
			}
		};
		return e.then(function() {
			r.status = "fulfilled", r.value = t;
			for (var e = 0; e < n.length; e++) (0, n[e])(t);
		}, function(e) {
			for (r.status = "rejected", r.reason = e, e = 0; e < n.length; e++) (0, n[e])(void 0);
		}), r;
	}
	var Ba = M.S;
	M.S = function(e, t) {
		if (hd = He(), typeof t == "object" && t && typeof t.then == "function" && La(e, t), ja !== null) for (var n = bf; n !== null;) Aa(n, ja), n = n.next;
		if (n = e.types, n !== null) {
			for (var r = bf; r !== null;) Aa(r, n), r = r.next;
			if (Fa !== 0) {
				r = ja, r === null && (r = ja = []);
				for (var i = 0; i < n.length; i++) {
					var a = n[i];
					r.indexOf(a) === -1 && r.push(a);
				}
			}
		}
		Ba !== null && Ba(e, t);
	};
	var Va = xe(null);
	function Ha() {
		var e = Va.current;
		return e === null ? $u.pooledCache : e;
	}
	function Ua(e, t) {
		t === null ? F(Va, Va.current) : F(Va, t.pool);
	}
	function Wa() {
		var e = Ha();
		return e === null ? null : {
			parent: Da._currentValue,
			pool: e
		};
	}
	var Ga = Error(i(460)), Ka = Error(i(474)), qa = Error(i(542)), Ja = { then: function() {} };
	function Ya(e) {
		return e = e.status, e === "fulfilled" || e === "rejected";
	}
	function Xa(e, t, n) {
		switch (n = e[n], n === void 0 ? e.push(t) : n !== t && (t.then(hn, hn), t = n), t.status) {
			case "fulfilled": return t.value;
			case "rejected": throw e = t.reason, eo(e), e === void 0 && !("reason" in t) ? Error(i(600)) : e;
			default:
				if (typeof t.status == "string") t.then(hn, hn);
				else {
					if (e = $u, e !== null && 100 < e.shellSuspendCounter) throw Error(i(482));
					e = t, e.status = "pending", e.then(function(e) {
						if (t.status === "pending") {
							var n = t;
							n.status = "fulfilled", n.value = e;
						}
					}, function(e) {
						if (t.status === "pending") {
							var n = t;
							n.status = "rejected", n.reason = e;
						}
					});
				}
				switch (t.status) {
					case "fulfilled": return t.value;
					case "rejected": throw e = t.reason, eo(e), e;
				}
				throw Qa = t, Ga;
		}
	}
	function Za(e) {
		try {
			var t = e._init;
			return t(e._payload);
		} catch (e) {
			throw typeof e == "object" && e && typeof e.then == "function" ? (Qa = e, Ga) : e;
		}
	}
	var Qa = null;
	function $a() {
		if (Qa === null) throw Error(i(459));
		var e = Qa;
		return Qa = null, e;
	}
	function eo(e) {
		if (e === Ga || e === qa) throw Error(i(483));
	}
	var to = null, no = 0;
	function ro(e) {
		var t = no;
		return no += 1, to === null && (to = []), Xa(to, e, t);
	}
	function io(e, t) {
		t = t.props.ref, e.ref = t === void 0 ? null : t;
	}
	function ao(e, t) {
		throw t.$$typeof === O ? Error(i(525)) : (e = Object.prototype.toString.call(t), Error(i(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e)));
	}
	function oo(e) {
		function t(t, n) {
			if (e) {
				var r = t.deletions;
				r === null ? (t.deletions = [n], t.flags |= 16) : r.push(n);
			}
		}
		function n(n, r) {
			if (!e) return null;
			for (; r !== null;) t(n, r), r = r.sibling;
			return null;
		}
		function r(e) {
			for (var t = /* @__PURE__ */ new Map(); e !== null;) e.key === null ? t.set(e.index, e) : t.set(e.key, e), e = e.sibling;
			return t;
		}
		function a(e, t) {
			return e = Ai(e, t), e.index = 0, e.sibling = null, e;
		}
		function o(t, n, r) {
			return t.index = r, e ? (r = t.alternate, r === null ? (t.flags |= 134217730, n) : (r = r.index, r < n ? (t.flags |= 2, n) : r)) : (t.flags |= 1048576, n);
		}
		function s(t) {
			return e && t.alternate === null && (t.flags |= 134217730), t;
		}
		function c(e, t, n, r) {
			return t === null || t.tag !== 6 ? (t = Pi(n, e.mode, r), t.return = e, t) : (t = a(t, n), t.return = e, t);
		}
		function l(e, t, n, r) {
			var i = n.type;
			return i === te ? (e = d(e, t, n.props.children, r, n.key), io(e, n), e) : t !== null && (t.elementType === i || typeof i == "object" && i && i.$$typeof === j && Za(i) === t.type) ? (t = a(t, n.props), io(t, n), t.return = e, t) : (t = Mi(n.type, n.key, n.props, null, e.mode, r), io(t, n), t.return = e, t);
		}
		function u(e, t, n, r) {
			return t === null || t.tag !== 4 || t.stateNode.containerInfo !== n.containerInfo || t.stateNode.implementation !== n.implementation ? (t = Ii(n, e.mode, r), t.return = e, t) : (t = a(t, n.children || []), t.return = e, t);
		}
		function d(e, t, n, r, i) {
			return t === null || t.tag !== 7 ? (t = Ni(n, e.mode, r, i), t.return = e, t) : (t = a(t, n), t.return = e, t);
		}
		function f(e, t, n) {
			if (typeof t == "string" && t !== "" || typeof t == "number" || typeof t == "bigint") return t = Pi("" + t, e.mode, n), t.return = e, t;
			if (typeof t == "object" && t) {
				switch (t.$$typeof) {
					case k: return n = Mi(t.type, t.key, t.props, null, e.mode, n), io(n, t), n.return = e, n;
					case ee: return t = Ii(t, e.mode, n), t.return = e, t;
					case j: return t = Za(t), f(e, t, n);
				}
				if (ve(t) || he(t)) return t = Ni(t, e.mode, n, null), t.return = e, t;
				if (typeof t.then == "function") return f(e, ro(t), n);
				if (t.$$typeof === A) return f(e, Sa(e, t), n);
				ao(e, t);
			}
			return null;
		}
		function p(e, t, n, r) {
			var i = t === null ? null : t.key;
			if (typeof n == "string" && n !== "" || typeof n == "number" || typeof n == "bigint") return i === null ? c(e, t, "" + n, r) : null;
			if (typeof n == "object" && n) {
				switch (n.$$typeof) {
					case k: return n.key === i ? l(e, t, n, r) : null;
					case ee: return n.key === i ? u(e, t, n, r) : null;
					case j: return n = Za(n), p(e, t, n, r);
				}
				if (ve(n) || he(n)) return i === null ? d(e, t, n, r, null) : null;
				if (typeof n.then == "function") return p(e, t, ro(n), r);
				if (n.$$typeof === A) return p(e, t, Sa(e, n), r);
				ao(e, n);
			}
			return null;
		}
		function m(e, t, n, r, i) {
			if (typeof r == "string" && r !== "" || typeof r == "number" || typeof r == "bigint") return e = e.get(n) || null, c(t, e, "" + r, i);
			if (typeof r == "object" && r) {
				switch (r.$$typeof) {
					case k: return e = e.get(r.key === null ? n : r.key) || null, l(t, e, r, i);
					case ee: return e = e.get(r.key === null ? n : r.key) || null, u(t, e, r, i);
					case j: return r = Za(r), m(e, t, n, r, i);
				}
				if (ve(r) || he(r)) return e = e.get(n) || null, d(t, e, r, i, null);
				if (typeof r.then == "function") return m(e, t, n, ro(r), i);
				if (r.$$typeof === A) return m(e, t, n, Sa(t, r), i);
				ao(t, r);
			}
			return null;
		}
		function h(i, a, s, c) {
			for (var l = null, u = null, d = a, h = a = 0, g = null; d !== null && h < s.length; h++) {
				d.index > h ? (g = d, d = null) : g = d.sibling;
				var _ = p(i, d, s[h], c);
				if (_ === null) {
					d === null && (d = g);
					break;
				}
				e && d && _.alternate === null && t(i, d), a = o(_, a, h), u === null ? l = _ : u.sibling = _, u = _, d = g;
			}
			if (h === s.length) return n(i, d), W && Ji(i, h), l;
			if (d === null) {
				for (; h < s.length; h++) d = f(i, s[h], c), d !== null && (a = o(d, a, h), u === null ? l = d : u.sibling = d, u = d);
				return W && Ji(i, h), l;
			}
			for (d = r(d); h < s.length; h++) g = m(d, i, h, s[h], c), g !== null && (e && (_ = g.alternate, _ !== null && d.delete(_.key === null ? h : _.key)), a = o(g, a, h), u === null ? l = g : u.sibling = g, u = g);
			return e && d.forEach(function(e) {
				return t(i, e);
			}), W && Ji(i, h), l;
		}
		function g(a, s, c, l) {
			if (c == null) throw Error(i(151));
			for (var u = null, d = null, h = s, g = s = 0, _ = null, v = c.next(); h !== null && !v.done; g++, v = c.next()) {
				h.index > g ? (_ = h, h = null) : _ = h.sibling;
				var y = p(a, h, v.value, l);
				if (y === null) {
					h === null && (h = _);
					break;
				}
				e && h && y.alternate === null && t(a, h), s = o(y, s, g), d === null ? u = y : d.sibling = y, d = y, h = _;
			}
			if (v.done) return n(a, h), W && Ji(a, g), u;
			if (h === null) {
				for (; !v.done; g++, v = c.next()) v = f(a, v.value, l), v !== null && (s = o(v, s, g), d === null ? u = v : d.sibling = v, d = v);
				return W && Ji(a, g), u;
			}
			for (h = r(h); !v.done; g++, v = c.next()) v = m(h, a, g, v.value, l), v !== null && (e && (_ = v.alternate, _ !== null && h.delete(_.key === null ? g : _.key)), s = o(v, s, g), d === null ? u = v : d.sibling = v, d = v);
			return e && h.forEach(function(e) {
				return t(a, e);
			}), W && Ji(a, g), u;
		}
		function _(e, r, o, c) {
			if (typeof o == "object" && o && o.type === te && o.key === null && o.props.ref === void 0 && (o = o.props.children), typeof o == "object" && o) {
				switch (o.$$typeof) {
					case k:
						a: {
							for (var l = o.key; r !== null;) {
								if (r.key === l) {
									if (l = o.type, l === te) {
										if (r.tag === 7) {
											n(e, r.sibling), c = a(r, o.props.children), io(c, o), c.return = e, e = c;
											break a;
										}
									} else if (r.elementType === l || typeof l == "object" && l && l.$$typeof === j && Za(l) === r.type) {
										n(e, r.sibling), c = a(r, o.props), io(c, o), c.return = e, e = c;
										break a;
									}
									n(e, r);
									break;
								}
								t(e, r), r = r.sibling;
							}
							o.type === te ? (c = Ni(o.props.children, e.mode, c, o.key), io(c, o), c.return = e, e = c) : (c = Mi(o.type, o.key, o.props, null, e.mode, c), io(c, o), c.return = e, e = c);
						}
						return s(e);
					case ee:
						a: {
							for (l = o.key; r !== null;) {
								if (r.key === l) {
									if (r.tag === 4 && r.stateNode.containerInfo === o.containerInfo && r.stateNode.implementation === o.implementation) {
										n(e, r.sibling), c = a(r, o.children || []), c.return = e, e = c;
										break a;
									}
									n(e, r);
									break;
								}
								t(e, r), r = r.sibling;
							}
							c = Ii(o, e.mode, c), c.return = e, e = c;
						}
						return s(e);
					case j: return o = Za(o), _(e, r, o, c);
				}
				if (ve(o)) return h(e, r, o, c);
				if (he(o)) {
					if (l = he(o), typeof l != "function") throw Error(i(150));
					return o = l.call(o), g(e, r, o, c);
				}
				if (typeof o.then == "function") return _(e, r, ro(o), c);
				if (o.$$typeof === A) return _(e, r, Sa(e, o), c);
				ao(e, o);
			}
			return typeof o == "string" && o !== "" || typeof o == "number" || typeof o == "bigint" ? (o = "" + o, r !== null && r.tag === 6 ? (n(e, r.sibling), c = a(r, o), c.return = e, e = c) : (n(e, r), c = Pi(o, e.mode, c), c.return = e, e = c), s(e)) : n(e, r);
		}
		return function(e, t, n, r) {
			try {
				no = 0;
				var i = _(e, t, n, r);
				return to = null, i;
			} catch (t) {
				if (t === Ga || t === qa) throw t;
				var a = Oi(29, t, null, e.mode);
				return a.lanes = r, a.return = e, a;
			}
		};
	}
	var so = oo(!0), co = oo(!1), lo = !1;
	function uo(e) {
		e.updateQueue = {
			baseState: e.memoizedState,
			firstBaseUpdate: null,
			lastBaseUpdate: null,
			shared: {
				pending: null,
				lanes: 0,
				hiddenCallbacks: null
			},
			callbacks: null
		};
	}
	function fo(e, t) {
		e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
			baseState: e.baseState,
			firstBaseUpdate: e.firstBaseUpdate,
			lastBaseUpdate: e.lastBaseUpdate,
			shared: e.shared,
			callbacks: null
		});
	}
	function po(e) {
		return {
			lane: e,
			tag: 0,
			payload: null,
			callback: null,
			next: null
		};
	}
	function mo(e, t, n) {
		var r = e.updateQueue;
		if (r === null) return null;
		if (r = r.shared, q & 2) {
			var i = r.pending;
			return i === null ? t.next = t : (t.next = i.next, i.next = t), r.pending = t, t = Ti(e), wi(e, null, n), t;
		}
		return xi(e, r, t, n), Ti(e);
	}
	function ho(e, t, n) {
		if (t = t.updateQueue, t !== null && (t = t.shared, n & 4194048)) {
			var r = t.lanes;
			r &= e.pendingLanes, n |= r, t.lanes = n, mt(e, n);
		}
	}
	function go(e, t) {
		var n = e.updateQueue, r = e.alternate;
		if (r !== null && (r = r.updateQueue, n === r)) {
			var i = null, a = null;
			if (n = n.firstBaseUpdate, n !== null) {
				do {
					var o = {
						lane: n.lane,
						tag: n.tag,
						payload: n.payload,
						callback: null,
						next: null
					};
					a === null ? i = a = o : a = a.next = o, n = n.next;
				} while (n !== null);
				a === null ? i = a = t : a = a.next = t;
			} else i = a = t;
			n = {
				baseState: r.baseState,
				firstBaseUpdate: i,
				lastBaseUpdate: a,
				shared: r.shared,
				callbacks: r.callbacks
			}, e.updateQueue = n;
		} else e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t;
	}
	var _o = !1;
	function vo() {
		if (_o) {
			var e = Ia;
			if (e !== null) throw e;
		}
	}
	function yo(e, t, n, r) {
		_o = !1;
		var i = e.updateQueue;
		lo = !1;
		var a = i.firstBaseUpdate, o = i.lastBaseUpdate, s = i.shared.pending;
		if (s !== null) {
			i.shared.pending = null;
			var c = s, l = c.next;
			c.next = null, o === null ? a = l : o.next = l, o = c;
			var u = e.alternate;
			u !== null && (u = u.updateQueue, s = u.lastBaseUpdate, s !== o && (s === null ? u.firstBaseUpdate = l : s.next = l, u.lastBaseUpdate = c));
		}
		if (a !== null) {
			var d = i.baseState;
			o = 0, u = l = c = null, s = a;
			do {
				var f = s.lane & -536870913, p = f !== s.lane;
				if (p ? (Y & f) === f : (r & f) === f) {
					f !== 0 && f === Fa && (_o = !0), u !== null && (u = u.next = {
						lane: 0,
						tag: s.tag,
						payload: s.payload,
						callback: null,
						next: null
					});
					a: {
						var m = e, h = s;
						f = t;
						var g = n;
						switch (h.tag) {
							case 1:
								if (m = h.payload, typeof m == "function") {
									d = m.call(g, d, f);
									break a;
								}
								d = m;
								break a;
							case 3: m.flags = m.flags & -65537 | 128;
							case 0:
								if (m = h.payload, f = typeof m == "function" ? m.call(g, d, f) : m, f == null) break a;
								d = D({}, d, f);
								break a;
							case 2: lo = !0;
						}
					}
					f = s.callback, f !== null && (e.flags |= 64, p && (e.flags |= 8192), p = i.callbacks, p === null ? i.callbacks = [f] : p.push(f));
				} else p = {
					lane: f,
					tag: s.tag,
					payload: s.payload,
					callback: s.callback,
					next: null
				}, u === null ? (l = u = p, c = d) : u = u.next = p, o |= f;
				if (s = s.next, s === null) {
					if (s = i.shared.pending, s === null) break;
					p = s, s = p.next, p.next = null, i.lastBaseUpdate = p, i.shared.pending = null;
				}
			} while (1);
			u === null && (c = d), i.baseState = c, i.firstBaseUpdate = l, i.lastBaseUpdate = u, a === null && (i.shared.lanes = 0), od |= o, e.lanes = o, e.memoizedState = d;
		}
	}
	function bo(e, t) {
		if (typeof e != "function") throw Error(i(191, e));
		e.call(t);
	}
	function xo(e, t) {
		var n = e.callbacks;
		if (n !== null) for (e.callbacks = null, e = 0; e < n.length; e++) bo(n[e], t);
	}
	var So = xe(null), Co = xe(0);
	function wo(e, t) {
		e = id, F(Co, e), F(So, t), id = e | t.baseLanes;
	}
	function To() {
		F(Co, id), F(So, So.current);
	}
	function Eo() {
		id = Co.current, Se(So), Se(Co);
	}
	var Do = xe(null), Oo = null;
	function ko(e) {
		var t = e.alternate;
		F(Po, Po.current & 1), F(Do, e), Oo === null && (t === null || So.current !== null || t.memoizedState !== null) && (Oo = e);
	}
	function Ao(e) {
		F(Po, Po.current), F(Do, e), Oo === null && (Oo = e);
	}
	function jo(e) {
		e.tag === 22 ? (F(Po, Po.current), F(Do, e), Oo === null && (Oo = e)) : Mo();
	}
	function Mo() {
		F(Po, Po.current), F(Do, Do.current);
	}
	function No(e) {
		Se(Do), Oo === e && (Oo = null), Se(Po);
	}
	var Po = xe(0);
	function Fo(e, t) {
		F(Do, Do.current), F(Po, t);
	}
	function Io(e) {
		Se(Po), Se(Do), Oo === e && (Oo = null);
	}
	function Lo(e) {
		for (var t = e; t !== null;) {
			if (t.tag === 13) {
				var n = t.memoizedState;
				if (n !== null && (n = n.dehydrated, n === null || om(n) || sm(n))) return t;
			} else if (t.tag === 19 && t.memoizedProps.revealOrder !== "independent") {
				if (t.flags & 128) return t;
			} else if (t.child !== null) {
				t.child.return = t, t = t.child;
				continue;
			}
			if (t === e) break;
			for (; t.sibling === null;) {
				if (t.return === null || t.return === e) return null;
				t = t.return;
			}
			t.sibling.return = t.return, t = t.sibling;
		}
		return null;
	}
	var Ro = 0, G = null, zo = null, Bo = null, Vo = !1, Ho = !1, Uo = !1, Wo = 0, Go = 0, Ko = null, qo = 0;
	function Jo() {
		throw Error(i(321));
	}
	function Yo(e, t) {
		if (t === null) return !1;
		for (var n = 0; n < t.length && n < e.length; n++) if (!Lr(e[n], t[n])) return !1;
		return !0;
	}
	function Xo(e, t, n, r, i, a) {
		return Ro = a, G = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, M.H = e === null || e.memoizedState === null ? pc : mc, Uo = !1, a = n(r, i), Uo = !1, Ho && (a = Qo(t, n, r, i)), Zo(e), a;
	}
	function Zo(e) {
		M.H = fc;
		var t = zo !== null && zo.next !== null;
		if (Ro = 0, Bo = zo = G = null, Vo = !1, Go = 0, Ko = null, t) throw Error(i(300));
		e === null || jc || (e = e.dependencies, e !== null && ya(e) && (jc = !0));
	}
	function Qo(e, t, n, r) {
		G = e;
		var a = 0;
		do {
			if (Ho && (Ko = null), Go = 0, Ho = !1, 25 <= a) throw Error(i(301));
			if (a += 1, Bo = zo = null, e.updateQueue != null) {
				var o = e.updateQueue;
				o.lastEffect = null, o.events = null, o.stores = null, o.memoCache != null && (o.memoCache.index = 0);
			}
			M.H = hc, o = t(n, r);
		} while (Ho);
		return o;
	}
	function $o() {
		var e = M.H, t = e.useState()[0];
		return t = typeof t.then == "function" ? os(t) : t, e = e.useState()[0], (zo === null ? null : zo.memoizedState) !== e && (G.flags |= 1024), t;
	}
	function es() {
		var e = Wo !== 0;
		return Wo = 0, e;
	}
	function ts(e, t, n) {
		t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~n;
	}
	function ns(e) {
		if (Vo) {
			for (e = e.memoizedState; e !== null;) {
				var t = e.queue;
				t !== null && (t.pending = null), e = e.next;
			}
			Vo = !1;
		}
		Ro = 0, Bo = zo = G = null, Ho = !1, Go = Wo = 0, Ko = null;
	}
	function rs() {
		var e = {
			memoizedState: null,
			baseState: null,
			baseQueue: null,
			queue: null,
			next: null
		};
		return Bo === null ? G.memoizedState = Bo = e : Bo = Bo.next = e, Bo;
	}
	function is() {
		if (zo === null) {
			var e = G.alternate;
			e = e === null ? null : e.memoizedState;
		} else e = zo.next;
		var t = Bo === null ? G.memoizedState : Bo.next;
		if (t !== null) Bo = t, zo = e;
		else {
			if (e === null) throw G.alternate === null ? Error(i(467)) : Error(i(310));
			zo = e, e = {
				memoizedState: zo.memoizedState,
				baseState: zo.baseState,
				baseQueue: zo.baseQueue,
				queue: zo.queue,
				next: null
			}, Bo === null ? G.memoizedState = Bo = e : Bo = Bo.next = e;
		}
		return Bo;
	}
	function as() {
		return {
			lastEffect: null,
			events: null,
			stores: null,
			memoCache: null
		};
	}
	function os(e) {
		var t = Go;
		return Go += 1, Ko === null && (Ko = []), e = Xa(Ko, e, t), t = G, (Bo === null ? t.memoizedState : Bo.next) === null && (t = t.alternate, M.H = t === null || t.memoizedState === null ? pc : mc), e;
	}
	function ss(e) {
		if (typeof e == "object" && e) {
			if (typeof e.then == "function") return os(e);
			if (e.$$typeof === pe) return;
			if (e.$$typeof === A) return xa(e);
		}
		throw Error(i(438, String(e)));
	}
	function cs(e) {
		var t = null, n = G.updateQueue;
		if (n !== null && (t = n.memoCache), t == null) {
			var r = G.alternate;
			r !== null && (r = r.updateQueue, r !== null && (r = r.memoCache, r != null && (t = {
				data: r.data.map(function(e) {
					return e.slice();
				}),
				index: 0
			})));
		}
		if (t ??= {
			data: [],
			index: 0
		}, n === null && (n = as(), G.updateQueue = n), n.memoCache = t, n = t.data[t.index], n === void 0) for (n = t.data[t.index] = Array(e), r = 0; r < e; r++) n[r] = de;
		return t.index++, n;
	}
	function ls(e, t) {
		return typeof t == "function" ? t(e) : t;
	}
	function us(e) {
		return ds(is(), zo, e);
	}
	function ds(e, t, n) {
		var r = e.queue;
		if (r === null) throw Error(i(311));
		r.lastRenderedReducer = n;
		var a = e.baseQueue, o = r.pending;
		if (o !== null) {
			if (a !== null) {
				var s = a.next;
				a.next = o.next, o.next = s;
			}
			t.baseQueue = a = o, r.pending = null;
		}
		if (o = e.baseState, a === null) e.memoizedState = o;
		else {
			t = a.next;
			var c = s = null, l = null, u = t, d = !1;
			do {
				var f = u.lane & -536870913;
				if (f === u.lane ? (Ro & f) === f : (Y & f) === f) {
					var p = u.revertLane;
					if (p === 0) l !== null && (l = l.next = {
						lane: 0,
						revertLane: 0,
						gesture: null,
						action: u.action,
						hasEagerState: u.hasEagerState,
						eagerState: u.eagerState,
						next: null
					}), f === Fa && (d = !0);
					else if ((Ro & p) === p) {
						u = u.next, p === Fa && (d = !0);
						continue;
					} else f = {
						lane: 0,
						revertLane: u.revertLane,
						gesture: null,
						action: u.action,
						hasEagerState: u.hasEagerState,
						eagerState: u.eagerState,
						next: null
					}, l === null ? (c = l = f, s = o) : l = l.next = f, G.lanes |= p, od |= p;
					f = u.action, Uo && n(o, f), o = u.hasEagerState ? u.eagerState : n(o, f);
				} else p = {
					lane: f,
					revertLane: u.revertLane,
					gesture: u.gesture,
					action: u.action,
					hasEagerState: u.hasEagerState,
					eagerState: u.eagerState,
					next: null
				}, l === null ? (c = l = p, s = o) : l = l.next = p, G.lanes |= f, od |= f;
				u = u.next;
			} while (u !== null && u !== t);
			if (l === null ? s = o : l.next = c, !Lr(o, e.memoizedState) && (jc = !0, d && (n = Ia, n !== null))) throw n;
			e.memoizedState = o, e.baseState = s, e.baseQueue = l, r.lastRenderedState = o;
		}
		return a === null && (r.lanes = 0), [e.memoizedState, r.dispatch];
	}
	function fs(e) {
		var t = is(), n = t.queue;
		if (n === null) throw Error(i(311));
		n.lastRenderedReducer = e;
		var r = n.dispatch, a = n.pending, o = t.memoizedState;
		if (a !== null) {
			n.pending = null;
			var s = a = a.next;
			do
				o = e(o, s.action), s = s.next;
			while (s !== a);
			Lr(o, t.memoizedState) || (jc = !0), t.memoizedState = o, t.baseQueue === null && (t.baseState = o), n.lastRenderedState = o;
		}
		return [o, r];
	}
	function ps(e, t, n) {
		var r = G, a = is(), o = W;
		if (o) {
			if (n === void 0) throw Error(i(407));
			n = n();
		} else n = t();
		var s = !Lr((zo || a).memoizedState, n);
		if (s && (a.memoizedState = n, jc = !0), a = a.queue, Rs(gs.bind(null, r, a, e), [e]), e = a.getSnapshot !== t || s || Bo !== null && !!(Bo.memoizedState.tag & 1), Ns(e ? 9 : 8, { destroy: void 0 }, hs.bind(null, r, a, n, t), null), e) {
			if (r.flags |= 2048, $u === null) throw Error(i(349));
			o || Ro & 127 || ms(r, t, n);
		}
		return n;
	}
	function ms(e, t, n) {
		e.flags |= 16384, e = {
			getSnapshot: t,
			value: n
		}, t = G.updateQueue, t === null ? (t = as(), G.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e));
	}
	function hs(e, t, n, r) {
		t.value = n, t.getSnapshot = r, _s(t) && vs(e);
	}
	function gs(e, t, n) {
		return n(function() {
			_s(t) && vs(e);
		});
	}
	function _s(e) {
		var t = e.getSnapshot;
		e = e.value;
		try {
			var n = t();
			return !Lr(e, n);
		} catch {
			return !0;
		}
	}
	function vs(e) {
		var t = Ci(e, 2);
		t !== null && Pd(t, e, 2);
	}
	function ys(e) {
		var t = rs();
		if (typeof e == "function") {
			var n = e;
			if (e = n(), Uo) {
				$e(!0);
				try {
					n();
				} finally {
					$e(!1);
				}
			}
		}
		return t.memoizedState = t.baseState = e, t.queue = {
			pending: null,
			lanes: 0,
			dispatch: null,
			lastRenderedReducer: ls,
			lastRenderedState: e
		}, t;
	}
	function bs(e, t, n, r) {
		return e.baseState = n, ds(e, zo, typeof r == "function" ? r : ls);
	}
	function xs(e, t, n, r, a) {
		if (lc(e)) throw Error(i(485));
		if (e = t.action, e !== null) {
			var o = {
				payload: a,
				action: e,
				next: null,
				isTransition: !0,
				status: "pending",
				value: null,
				reason: null,
				listeners: [],
				then: function(e) {
					o.listeners.push(e);
				}
			};
			M.T === null ? o.isTransition = !1 : n(!0), r(o), n = t.pending, n === null ? (o.next = t.pending = o, Ss(t, o)) : (o.next = n.next, t.pending = n.next = o);
		}
	}
	function Ss(e, t) {
		var n = t.action, r = t.payload, i = e.state;
		if (t.isTransition) {
			var a = M.T, o = {};
			o.types = a === null ? null : a.types, M.T = o;
			try {
				var s = n(i, r), c = M.S;
				c !== null && c(o, s), Cs(e, t, s);
			} catch (n) {
				Ts(e, t, n);
			} finally {
				a !== null && o.types !== null && (a.types = o.types), M.T = a;
			}
		} else try {
			a = n(i, r), Cs(e, t, a);
		} catch (n) {
			Ts(e, t, n);
		}
	}
	function Cs(e, t, n) {
		typeof n == "object" && n && typeof n.then == "function" ? n.then(function(n) {
			ws(e, t, n);
		}, function(n) {
			return Ts(e, t, n);
		}) : ws(e, t, n);
	}
	function ws(e, t, n) {
		t.status = "fulfilled", t.value = n, Es(t), e.state = n, t = e.pending, t !== null && (n = t.next, n === t ? e.pending = null : (n = n.next, t.next = n, Ss(e, n)));
	}
	function Ts(e, t, n) {
		var r = e.pending;
		if (e.pending = null, r !== null) {
			r = r.next;
			do
				t.status = "rejected", t.reason = n, Es(t), t = t.next;
			while (t !== r);
		}
		e.action = null;
	}
	function Es(e) {
		e = e.listeners;
		for (var t = 0; t < e.length; t++) (0, e[t])();
	}
	function Ds(e, t) {
		return t;
	}
	function Os(e, t) {
		if (W) {
			var n = $u.formState;
			if (n !== null) {
				a: {
					var r = G;
					if (W) {
						if (ea) {
							b: {
								for (var i = ea, a = na; i.nodeType !== 8;) if (!a || (i = lm(i.nextSibling), i === null)) {
									i = null;
									break b;
								}
								a = i.data, i = a === "F!" || a === "F" ? i : null;
							}
							if (i) {
								ea = lm(i.nextSibling), r = i.data === "F!";
								break a;
							}
						}
						ia(r);
					}
					r = !1;
				}
				r && (t = n[0]);
			}
		}
		return n = rs(), n.memoizedState = n.baseState = t, r = {
			pending: null,
			lanes: 0,
			dispatch: null,
			lastRenderedReducer: Ds,
			lastRenderedState: t
		}, n.queue = r, n = oc.bind(null, G, r), r.dispatch = n, r = ys(!1), a = cc.bind(null, G, !1, r.queue), r = rs(), i = {
			state: t,
			dispatch: null,
			action: e,
			pending: null
		}, r.queue = i, n = xs.bind(null, G, i, a, n), i.dispatch = n, r.memoizedState = e, [
			t,
			n,
			!1
		];
	}
	function ks(e) {
		return As(is(), zo, e);
	}
	function As(e, t, n) {
		if (t = ds(e, t, Ds)[0], e = us(ls)[0], typeof t == "object" && t && typeof t.then == "function") try {
			var r = os(t);
		} catch (e) {
			throw e === Ga ? qa : e;
		}
		else r = t;
		t = is();
		var i = t.queue, a = i.dispatch;
		return n !== t.memoizedState && (G.flags |= 2048, Ns(9, { destroy: void 0 }, js.bind(null, i, n), null)), [
			r,
			a,
			e
		];
	}
	function js(e, t) {
		e.action = t;
	}
	function Ms(e) {
		var t = is(), n = zo;
		if (n !== null) return As(t, n, e);
		is(), t = t.memoizedState, n = is();
		var r = n.queue.dispatch;
		return n.memoizedState = e, [
			t,
			r,
			!1
		];
	}
	function Ns(e, t, n, r) {
		return e = {
			tag: e,
			create: n,
			deps: r,
			inst: t,
			next: null
		}, t = G.updateQueue, t === null && (t = as(), G.updateQueue = t), n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e), e;
	}
	function Ps() {
		return is().memoizedState;
	}
	function Fs(e, t, n, r) {
		var i = rs();
		G.flags |= e, i.memoizedState = Ns(1 | t, { destroy: void 0 }, n, r === void 0 ? null : r);
	}
	function Is(e, t, n, r) {
		var i = is();
		r = r === void 0 ? null : r;
		var a = i.memoizedState.inst;
		zo !== null && r !== null && Yo(r, zo.memoizedState.deps) ? i.memoizedState = Ns(t, a, n, r) : (G.flags |= e, i.memoizedState = Ns(1 | t, a, n, r));
	}
	function Ls(e, t) {
		Fs(8390656, 8, e, t);
	}
	function Rs(e, t) {
		Is(2048, 8, e, t);
	}
	function zs(e) {
		G.flags |= 4;
		var t = G.updateQueue;
		if (t === null) t = as(), G.updateQueue = t, t.events = [e];
		else {
			var n = t.events;
			n === null ? t.events = [e] : n.push(e);
		}
	}
	function Bs(e) {
		var t = is().memoizedState;
		return zs({
			ref: t,
			nextImpl: e
		}), function() {
			if (q & 2) throw Error(i(440));
			return t.impl.apply(void 0, arguments);
		};
	}
	function Vs(e, t) {
		return Is(4, 2, e, t);
	}
	function Hs(e, t) {
		return Is(4, 4, e, t);
	}
	function Us(e, t) {
		if (typeof t == "function") {
			e = e();
			var n = t(e);
			return function() {
				typeof n == "function" ? n() : t(null);
			};
		}
		if (t != null) return e = e(), t.current = e, function() {
			t.current = null;
		};
	}
	function Ws(e, t, n) {
		n = n == null ? null : n.concat([e]), Is(4, 4, Us.bind(null, t, e), n);
	}
	function Gs() {}
	function Ks(e, t) {
		var n = is();
		t = t === void 0 ? null : t;
		var r = n.memoizedState;
		return t !== null && Yo(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e);
	}
	function qs(e, t) {
		var n = is();
		t = t === void 0 ? null : t;
		var r = n.memoizedState;
		if (t !== null && Yo(t, r[1])) return r[0];
		if (r = e(), Uo) {
			$e(!0);
			try {
				e();
			} finally {
				$e(!1);
			}
		}
		return n.memoizedState = [r, t], r;
	}
	function Js(e, t, n) {
		return n === void 0 || Ro & 1073741824 && !(Y & 261930) ? e.memoizedState = t : (e.memoizedState = n, e = Md(), G.lanes |= e, od |= e, n);
	}
	function Ys(e, t, n, r) {
		return Lr(n, t) ? n : So.current === null ? !(Ro & 106) || Ro & 1073741824 && !(Y & 261930) ? (jc = !0, e.memoizedState = n) : (e = Md(), G.lanes |= e, od |= e, t) : (e = Js(e, n, r), Lr(e, t) || (jc = !0), e);
	}
	function Xs(e, t, n, r, i) {
		var a = N.p;
		N.p = a !== 0 && 8 > a ? a : 8;
		var o = M.T, s = {};
		s.types = o === null ? null : o.types, M.T = s, cc(e, !1, t, n);
		try {
			var c = i(), l = M.S;
			l !== null && l(s, c), typeof c == "object" && c && typeof c.then == "function" ? sc(e, t, za(c, r), jd(e)) : sc(e, t, r, jd(e));
		} catch (n) {
			sc(e, t, {
				then: function() {},
				status: "rejected",
				reason: n
			}, jd());
		} finally {
			N.p = a, o !== null && s.types !== null && (o.types = s.types), M.T = o;
		}
	}
	function Zs() {}
	function Qs(e, t, n, r) {
		if (e.tag !== 5) throw Error(i(476));
		var a = $s(e).queue;
		Xs(e, a, t, ye, n === null ? Zs : function() {
			return ec(e), n(r);
		});
	}
	function $s(e) {
		var t = e.memoizedState;
		if (t !== null) return t;
		t = {
			memoizedState: ye,
			baseState: ye,
			baseQueue: null,
			queue: {
				pending: null,
				lanes: 0,
				dispatch: null,
				lastRenderedReducer: ls,
				lastRenderedState: ye
			},
			next: null
		};
		var n = {};
		return t.next = {
			memoizedState: n,
			baseState: n,
			baseQueue: null,
			queue: {
				pending: null,
				lanes: 0,
				dispatch: null,
				lastRenderedReducer: ls,
				lastRenderedState: n
			},
			next: null
		}, e.memoizedState = t, e = e.alternate, e !== null && (e.memoizedState = t), t;
	}
	function ec(e) {
		var t = $s(e);
		t.next === null && (t = e.alternate.memoizedState), sc(e, t.next.queue, {}, jd());
	}
	function tc() {
		return xa(sh);
	}
	function nc() {
		return is().memoizedState;
	}
	function rc() {
		return is().memoizedState;
	}
	function ic(e) {
		for (var t = e.return; t !== null;) {
			switch (t.tag) {
				case 24:
				case 3:
					var n = jd();
					e = po(n);
					var r = mo(t, e, n);
					r !== null && (Pd(r, t, n), ho(r, t, n)), t = { cache: Oa() }, e.payload = t;
					return;
			}
			t = t.return;
		}
	}
	function ac(e, t, n) {
		var r = jd();
		n = {
			lane: r,
			revertLane: 0,
			gesture: null,
			action: n,
			hasEagerState: !1,
			eagerState: null,
			next: null
		}, lc(e) ? uc(t, n) : (n = Si(e, t, n, r), n !== null && (Pd(n, e, r), dc(n, t, r)));
	}
	function oc(e, t, n) {
		sc(e, t, n, jd());
	}
	function sc(e, t, n, r) {
		var i = {
			lane: r,
			revertLane: 0,
			gesture: null,
			action: n,
			hasEagerState: !1,
			eagerState: null,
			next: null
		};
		if (lc(e)) uc(t, i);
		else {
			var a = e.alternate;
			if (e.lanes === 0 && (a === null || a.lanes === 0) && (a = t.lastRenderedReducer, a !== null)) try {
				var o = t.lastRenderedState, s = a(o, n);
				if (i.hasEagerState = !0, i.eagerState = s, Lr(s, o)) return xi(e, t, i, 0), $u === null && bi(), !1;
			} catch {}
			if (n = Si(e, t, i, r), n !== null) return Pd(n, e, r), dc(n, t, r), !0;
		}
		return !1;
	}
	function cc(e, t, n, r) {
		if (r = {
			lane: 2,
			revertLane: Pf(),
			gesture: null,
			action: r,
			hasEagerState: !1,
			eagerState: null,
			next: null
		}, lc(e)) {
			if (t) throw Error(i(479));
		} else t = Si(e, n, r, 2), t !== null && Pd(t, e, 2);
	}
	function lc(e) {
		var t = e.alternate;
		return e === G || t !== null && t === G;
	}
	function uc(e, t) {
		Ho = Vo = !0;
		var n = e.pending;
		n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t;
	}
	function dc(e, t, n) {
		if (n & 4194048) {
			var r = t.lanes;
			r &= e.pendingLanes, n |= r, t.lanes = n, mt(e, n);
		}
	}
	var fc = {
		readContext: xa,
		use: ss,
		useCallback: Jo,
		useContext: Jo,
		useEffect: Jo,
		useImperativeHandle: Jo,
		useLayoutEffect: Jo,
		useInsertionEffect: Jo,
		useMemo: Jo,
		useReducer: Jo,
		useRef: Jo,
		useState: Jo,
		useDebugValue: Jo,
		useDeferredValue: Jo,
		useTransition: Jo,
		useSyncExternalStore: Jo,
		useId: Jo,
		useHostTransitionStatus: Jo,
		useFormState: Jo,
		useActionState: Jo,
		useOptimistic: Jo,
		useMemoCache: Jo,
		useCacheRefresh: Jo,
		useEffectEvent: Jo
	}, pc = {
		readContext: xa,
		use: ss,
		useCallback: function(e, t) {
			return rs().memoizedState = [e, t === void 0 ? null : t], e;
		},
		useContext: xa,
		useEffect: Ls,
		useImperativeHandle: function(e, t, n) {
			n = n == null ? null : n.concat([e]), Fs(4194308, 4, Us.bind(null, t, e), n);
		},
		useLayoutEffect: function(e, t) {
			return Fs(4194308, 4, e, t);
		},
		useInsertionEffect: function(e, t) {
			Fs(4, 2, e, t);
		},
		useMemo: function(e, t) {
			var n = rs();
			t = t === void 0 ? null : t;
			var r = e();
			if (Uo) {
				$e(!0);
				try {
					e();
				} finally {
					$e(!1);
				}
			}
			return n.memoizedState = [r, t], r;
		},
		useReducer: function(e, t, n) {
			var r = rs();
			if (n !== void 0) {
				var i = n(t);
				if (Uo) {
					$e(!0);
					try {
						n(t);
					} finally {
						$e(!1);
					}
				}
			} else i = t;
			return r.memoizedState = r.baseState = i, e = {
				pending: null,
				lanes: 0,
				dispatch: null,
				lastRenderedReducer: e,
				lastRenderedState: i
			}, r.queue = e, e = e.dispatch = ac.bind(null, G, e), [r.memoizedState, e];
		},
		useRef: function(e) {
			var t = rs();
			return e = { current: e }, t.memoizedState = e;
		},
		useState: function(e) {
			e = ys(e);
			var t = e.queue, n = oc.bind(null, G, t);
			return t.dispatch = n, [e.memoizedState, n];
		},
		useDebugValue: Gs,
		useDeferredValue: function(e, t) {
			return Js(rs(), e, t);
		},
		useTransition: function() {
			var e = ys(!1);
			return e = Xs.bind(null, G, e.queue, !0, !1), rs().memoizedState = e, [!1, e];
		},
		useSyncExternalStore: function(e, t, n) {
			var r = G, a = rs();
			if (W) {
				if (n === void 0) throw Error(i(407));
				n = n();
			} else {
				if (n = t(), $u === null) throw Error(i(349));
				Y & 127 || ms(r, t, n);
			}
			a.memoizedState = n;
			var o = {
				value: n,
				getSnapshot: t
			};
			return a.queue = o, Ls(gs.bind(null, r, o, e), [e]), r.flags |= 2048, Ns(9, { destroy: void 0 }, hs.bind(null, r, o, n, t), null), n;
		},
		useId: function() {
			var e = rs(), t = $u.identifierPrefix;
			if (W) {
				var n = qi, r = Ki;
				n = (r & ~(1 << 32 - L(r) - 1)).toString(32) + n, t = "_" + t + "R_" + n, n = Wo++, 0 < n && (t += "H" + n.toString(32)), t += "_";
			} else n = qo++, t = "_" + t + "r_" + n.toString(32) + "_";
			return e.memoizedState = t;
		},
		useHostTransitionStatus: tc,
		useFormState: Os,
		useActionState: Os,
		useOptimistic: function(e) {
			var t = rs();
			t.memoizedState = t.baseState = e;
			var n = {
				pending: null,
				lanes: 0,
				dispatch: null,
				lastRenderedReducer: null,
				lastRenderedState: null
			};
			return t.queue = n, t = cc.bind(null, G, !0, n), n.dispatch = t, [e, t];
		},
		useMemoCache: cs,
		useCacheRefresh: function() {
			return rs().memoizedState = ic.bind(null, G);
		},
		useEffectEvent: function(e) {
			var t = rs(), n = { impl: e };
			return t.memoizedState = n, function() {
				if (q & 2) throw Error(i(440));
				return n.impl.apply(void 0, arguments);
			};
		}
	}, mc = {
		readContext: xa,
		use: ss,
		useCallback: Ks,
		useContext: xa,
		useEffect: Rs,
		useImperativeHandle: Ws,
		useInsertionEffect: Vs,
		useLayoutEffect: Hs,
		useMemo: qs,
		useReducer: us,
		useRef: Ps,
		useState: function() {
			return us(ls);
		},
		useDebugValue: Gs,
		useDeferredValue: function(e, t) {
			return Ys(is(), zo.memoizedState, e, t);
		},
		useTransition: function() {
			var e = us(ls)[0], t = is().memoizedState;
			return [typeof e == "boolean" ? e : os(e), t];
		},
		useSyncExternalStore: ps,
		useId: nc,
		useHostTransitionStatus: tc,
		useFormState: ks,
		useActionState: ks,
		useOptimistic: function(e, t) {
			return bs(is(), zo, e, t);
		},
		useMemoCache: cs,
		useCacheRefresh: rc,
		useEffectEvent: Bs
	}, hc = {
		readContext: xa,
		use: ss,
		useCallback: Ks,
		useContext: xa,
		useEffect: Rs,
		useImperativeHandle: Ws,
		useInsertionEffect: Vs,
		useLayoutEffect: Hs,
		useMemo: qs,
		useReducer: fs,
		useRef: Ps,
		useState: function() {
			return fs(ls);
		},
		useDebugValue: Gs,
		useDeferredValue: function(e, t) {
			var n = is();
			return zo === null ? Js(n, e, t) : Ys(n, zo.memoizedState, e, t);
		},
		useTransition: function() {
			var e = fs(ls)[0], t = is().memoizedState;
			return [typeof e == "boolean" ? e : os(e), t];
		},
		useSyncExternalStore: ps,
		useId: nc,
		useHostTransitionStatus: tc,
		useFormState: Ms,
		useActionState: Ms,
		useOptimistic: function(e, t) {
			var n = is();
			return zo === null ? (n.baseState = e, [e, n.queue.dispatch]) : bs(n, zo, e, t);
		},
		useMemoCache: cs,
		useCacheRefresh: rc,
		useEffectEvent: Bs
	};
	function gc(e, t, n, r) {
		t = e.memoizedState, n = n(r, t), n = n == null ? t : D({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n);
	}
	var _c = {
		enqueueSetState: function(e, t, n) {
			e = e._reactInternals;
			var r = jd(), i = po(r);
			i.payload = t, n != null && (i.callback = n), t = mo(e, i, r), t !== null && (Pd(t, e, r), ho(t, e, r));
		},
		enqueueReplaceState: function(e, t, n) {
			e = e._reactInternals;
			var r = jd(), i = po(r);
			i.tag = 1, i.payload = t, n != null && (i.callback = n), t = mo(e, i, r), t !== null && (Pd(t, e, r), ho(t, e, r));
		},
		enqueueForceUpdate: function(e, t) {
			e = e._reactInternals;
			var n = jd(), r = po(n);
			r.tag = 2, t != null && (r.callback = t), t = mo(e, r, n), t !== null && (Pd(t, e, n), ho(t, e, n));
		}
	};
	function vc(e, t, n, r, i, a, o) {
		return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, a, o) : t.prototype && t.prototype.isPureReactComponent ? !Rr(n, r) || !Rr(i, a) : !0;
	}
	function yc(e, t, n, r) {
		e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && _c.enqueueReplaceState(t, t.state, null);
	}
	function bc(e, t) {
		var n = t;
		if ("ref" in t) for (var r in n = {}, t) r !== "ref" && (n[r] = t[r]);
		if (e = e.defaultProps) for (var i in n === t && (n = D({}, n)), e) n[i] === void 0 && (n[i] = e[i]);
		return n;
	}
	function xc(e) {
		gi(e);
	}
	function Sc(e) {
		console.error(e);
	}
	function Cc(e) {
		gi(e);
	}
	function wc(e, t) {
		try {
			var n = e.onUncaughtError;
			n(t.value, { componentStack: t.stack });
		} catch (e) {
			setTimeout(function() {
				throw e;
			});
		}
	}
	function Tc(e, t, n) {
		try {
			var r = e.onCaughtError;
			r(n.value, {
				componentStack: n.stack,
				errorBoundary: t.tag === 1 ? t.stateNode : null
			});
		} catch (e) {
			setTimeout(function() {
				throw e;
			});
		}
	}
	function Ec(e, t, n) {
		return n = po(n), n.tag = 3, n.payload = { element: null }, n.callback = function() {
			wc(e, t);
		}, n;
	}
	function Dc(e) {
		return e = po(e), e.tag = 3, e;
	}
	function Oc(e, t, n, r) {
		var i = n.type.getDerivedStateFromError;
		if (typeof i == "function") {
			var a = r.value;
			e.payload = function() {
				return i(a);
			}, e.callback = function() {
				Tc(t, n, r);
			};
		}
		var o = n.stateNode;
		o !== null && typeof o.componentDidCatch == "function" && (e.callback = function() {
			Tc(t, n, r), typeof i != "function" && (vd === null ? vd = /* @__PURE__ */ new Set([this]) : vd.add(this));
			var e = r.stack;
			this.componentDidCatch(r.value, { componentStack: e === null ? "" : e });
		});
	}
	function kc(e, t, n, r, a) {
		if (n.flags |= 32768, typeof r == "object" && r && typeof r.then == "function") {
			if (t = n.alternate, t !== null && va(t, n, a, !0), n = Do.current, n !== null) {
				switch (n.tag) {
					case 31:
					case 13:
					case 19: return Oo === null ? Kd() : n.alternate === null && ad === 0 && (ad = 3), n.flags &= -257, n.flags |= 65536, n.lanes = a, r === Ja ? n.flags |= 16384 : (t = n.updateQueue, t === null ? n.updateQueue = /* @__PURE__ */ new Set([r]) : t.add(r), mf(e, r, a)), !1;
					case 22: return n.flags |= 65536, r === Ja ? n.flags |= 16384 : (t = n.updateQueue, t === null ? (t = {
						transitions: null,
						markerInstances: null,
						retryQueue: /* @__PURE__ */ new Set([r])
					}, n.updateQueue = t) : (n = t.retryQueue, n === null ? t.retryQueue = /* @__PURE__ */ new Set([r]) : n.add(r)), mf(e, r, a)), !1;
				}
				throw Error(i(435, n.tag));
			}
			return mf(e, r, a), Kd(), !1;
		}
		if (W) return t = Do.current, t === null ? (r !== ra && (t = Error(i(423), { cause: r }), ua(Ri(t, n))), e = e.current.alternate, e.flags |= 65536, a &= -a, e.lanes |= a, r = Ri(r, n), a = Ec(e.stateNode, r, a), go(e, a), ad !== 4 && (ad = 2)) : (!(t.flags & 65536) && (t.flags |= 256), t.flags |= 65536, t.lanes = a, r !== ra && (e = Error(i(422), { cause: r }), ua(Ri(e, n)))), !1;
		var o = Error(i(520), { cause: r });
		if (o = Ri(o, n), dd === null ? dd = [o] : dd.push(o), ad !== 4 && (ad = 2), t === null) return !0;
		r = Ri(r, n), n = t;
		do {
			switch (n.tag) {
				case 3: return n.flags |= 65536, e = a & -a, n.lanes |= e, e = Ec(n.stateNode, r, e), go(n, e), !1;
				case 1:
					if (t = n.type, o = n.stateNode, !(n.flags & 128) && (typeof t.getDerivedStateFromError == "function" || o !== null && typeof o.componentDidCatch == "function" && (vd === null || !vd.has(o)))) return n.flags |= 65536, a &= -a, n.lanes |= a, a = Dc(a), Oc(a, e, n, r), go(n, a), !1;
					break;
				case 22: if (n.memoizedState !== null) return n.flags |= 65536, !1;
			}
			n = n.return;
		} while (n !== null);
		return !1;
	}
	var Ac = Error(i(461)), jc = !1;
	function Mc(e, t, n, r) {
		t.child = e === null ? co(t, null, n, r) : so(t, e.child, n, r);
	}
	function Nc(e, t, n, r, i) {
		n = n.render;
		var a = t.ref;
		if ("ref" in r) {
			var o = {};
			for (var s in r) s !== "ref" && (o[s] = r[s]);
		} else o = r;
		return ba(t), r = Xo(e, t, n, o, a, i), s = es(), e !== null && !jc ? (ts(e, t, i), sl(e, t, i)) : (W && s && Xi(t), t.flags |= 1, Mc(e, t, r, i), t.child);
	}
	function Pc(e, t, n, r, i) {
		if (e === null) {
			var a = n.type;
			return typeof a == "function" && !ki(a) && a.defaultProps === void 0 && n.compare === null ? (t.tag = 15, t.type = a, Fc(e, t, a, r, i)) : (e = Mi(n.type, null, r, t, t.mode, i), e.ref = t.ref, e.return = t, t.child = e);
		}
		if (a = e.child, !cl(e, i)) {
			var o = a.memoizedProps;
			if (n = n.compare, n = n === null ? Rr : n, n(o, r) && e.ref === t.ref) return sl(e, t, i);
		}
		return t.flags |= 1, e = Ai(a, r), e.ref = t.ref, e.return = t, t.child = e;
	}
	function Fc(e, t, n, r, i) {
		if (e !== null) {
			var a = e.memoizedProps;
			if (Rr(a, r) && e.ref === t.ref) {
				if (jc = !1, t.pendingProps = r = a, cl(e, i)) e.flags & 131072 && (jc = !0);
				else return t.lanes = e.lanes, sl(e, t, i);
			}
		}
		return Uc(e, t, n, r, i);
	}
	function Ic(e, t, n, r) {
		var i = r.children, a = e === null ? null : e.memoizedState;
		if (e === null && t.stateNode === null && (t.stateNode = {
			_visibility: 1,
			_pendingMarkers: null,
			_retryCache: null,
			_transitions: null
		}), r.mode === "hidden") {
			if (t.flags & 128) {
				if (a = a === null ? n : a.baseLanes | n, e !== null) {
					for (r = t.child = e.child, i = 0; r !== null;) i = i | r.lanes | r.childLanes, r = r.sibling;
					r = i & ~a;
				} else r = 0, t.child = null;
				return Rc(e, t, a, n, r);
			}
			if (n & 536870912) t.memoizedState = {
				baseLanes: 0,
				cachePool: null
			}, e !== null && Ua(t, a === null ? null : a.cachePool), a === null ? To() : wo(t, a), jo(t);
			else return r = t.lanes = 536870912, Rc(e, t, a === null ? n : a.baseLanes | n, n, r);
		} else a === null ? (e !== null && Ua(t, null), To(), Mo()) : (Ua(t, a.cachePool), wo(t, a), Mo(), t.memoizedState = null);
		return Mc(e, t, i, n), t.child;
	}
	function Lc(e, t) {
		return e !== null && e.tag === 22 || t.stateNode !== null || (t.stateNode = {
			_visibility: 1,
			_pendingMarkers: null,
			_retryCache: null,
			_transitions: null
		}), t.sibling;
	}
	function Rc(e, t, n, r, i) {
		var a = Ha();
		return a = a === null ? null : {
			parent: Da._currentValue,
			pool: a
		}, t.memoizedState = {
			baseLanes: n,
			cachePool: a
		}, e !== null && Ua(t, null), To(), jo(t), e !== null && va(e, t, r, !0), t.childLanes = i, null;
	}
	function zc(e, t) {
		return t = Qc({
			mode: t.mode,
			children: t.children
		}, e.mode), t.ref = e.ref, e.child = t, t.return = e, t;
	}
	function Bc(e, t, n) {
		return so(t, e.child, null, n), e = zc(t, t.pendingProps), e.flags |= 2, No(t), t.memoizedState = null, e;
	}
	function Vc(e, t, n) {
		var r = t.pendingProps, a = !!(t.flags & 128);
		if (t.flags &= -129, e === null) {
			if (W) {
				if (r.mode === "hidden") return e = zc(t, r), t.lanes = 536870912, e.memoizedState = {
					baseLanes: 0,
					cachePool: null
				}, Lc(null, e);
				if (Ao(t), (e = ea) ? (e = am(e, na), e = e !== null && e.data === "&" ? e : null, e !== null && (t.memoizedState = {
					dehydrated: e,
					treeContext: Gi === null ? null : {
						id: Ki,
						overflow: qi
					},
					retryLane: 536870912,
					hydrationErrors: null
				}, n = Fi(e), n.return = t, t.child = n, $i = t, ea = null)) : e = null, e === null) throw ia(t);
				return t.lanes = 536870912, null;
			}
			return zc(t, r);
		}
		var o = e.memoizedState;
		if (o !== null) {
			var s = o.dehydrated;
			if (Ao(t), a) {
				if (t.flags & 256) t.flags &= -257, t = Bc(e, t, n);
				else if (t.memoizedState !== null) t.child = e.child, t.flags |= 128, t = null;
				else throw Error(i(558));
			} else if (jc || va(e, t, n, !1), a = (n & e.childLanes) !== 0, jc || a) {
				if (So.current === null) {
					if (r = $u, r !== null && (s = ht(r, n), s !== 0 && s !== o.retryLane)) throw o.retryLane = s, Ci(e, s), Pd(r, e, s), Ac;
					Kd();
				}
				t = Bc(e, t, n);
			} else e = o.treeContext, ea = lm(s.nextSibling), $i = t, W = !0, ta = null, na = !1, e !== null && Qi(t, e), t = zc(t, r), t.flags |= 134221824;
			return t;
		}
		return e = Ai(e.child, {
			mode: r.mode,
			children: r.children
		}), e.ref = t.ref, t.child = e, e.return = t, e;
	}
	function Hc(e, t) {
		var n = t.ref;
		if (n === null) e !== null && e.ref !== null && (t.flags |= 4194816);
		else {
			if (typeof n != "function" && typeof n != "object") throw Error(i(284));
			(e === null || e.ref !== n) && (t.flags |= 4194816);
		}
	}
	function Uc(e, t, n, r, i) {
		return ba(t), n = Xo(e, t, n, r, void 0, i), r = es(), e !== null && !jc ? (ts(e, t, i), sl(e, t, i)) : (W && r && Xi(t), t.flags |= 1, Mc(e, t, n, i), t.child);
	}
	function Wc(e, t, n, r, i, a) {
		return ba(t), t.updateQueue = null, n = Qo(t, r, n, i), Zo(e), r = es(), e !== null && !jc ? (ts(e, t, a), sl(e, t, a)) : (W && r && Xi(t), t.flags |= 1, Mc(e, t, n, a), t.child);
	}
	function Gc(e, t, n, r, i) {
		if (ba(t), t.stateNode === null) {
			var a = Ei, o = n.contextType;
			typeof o == "object" && o && (a = xa(o)), a = new n(r, a), t.memoizedState = a.state !== null && a.state !== void 0 ? a.state : null, a.updater = _c, t.stateNode = a, a._reactInternals = t, a = t.stateNode, a.props = r, a.state = t.memoizedState, a.refs = {}, uo(t), o = n.contextType, a.context = typeof o == "object" && o ? xa(o) : Ei, a.state = t.memoizedState, o = n.getDerivedStateFromProps, typeof o == "function" && (gc(t, n, o, r), a.state = t.memoizedState), typeof n.getDerivedStateFromProps == "function" || typeof a.getSnapshotBeforeUpdate == "function" || typeof a.UNSAFE_componentWillMount != "function" && typeof a.componentWillMount != "function" || (o = a.state, typeof a.componentWillMount == "function" && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == "function" && a.UNSAFE_componentWillMount(), o !== a.state && _c.enqueueReplaceState(a, a.state, null), yo(t, r, a, i), vo(), a.state = t.memoizedState), typeof a.componentDidMount == "function" && (t.flags |= 4194308), r = !0;
		} else if (e === null) {
			a = t.stateNode;
			var s = t.memoizedProps, c = bc(n, s);
			a.props = c;
			var l = a.context, u = n.contextType;
			o = Ei, typeof u == "object" && u && (o = xa(u));
			var d = n.getDerivedStateFromProps;
			u = typeof d == "function" || typeof a.getSnapshotBeforeUpdate == "function", s = t.pendingProps !== s, u || typeof a.UNSAFE_componentWillReceiveProps != "function" && typeof a.componentWillReceiveProps != "function" || (s || l !== o) && yc(t, a, r, o), lo = !1;
			var f = t.memoizedState;
			a.state = f, yo(t, r, a, i), vo(), l = t.memoizedState, s || f !== l || lo ? (typeof d == "function" && (gc(t, n, d, r), l = t.memoizedState), (c = lo || vc(t, n, c, r, f, l, o)) ? (u || typeof a.UNSAFE_componentWillMount != "function" && typeof a.componentWillMount != "function" || (typeof a.componentWillMount == "function" && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == "function" && a.UNSAFE_componentWillMount()), typeof a.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof a.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = l), a.props = r, a.state = l, a.context = o, r = c) : (typeof a.componentDidMount == "function" && (t.flags |= 4194308), r = !1);
		} else {
			a = t.stateNode, fo(e, t), o = t.memoizedProps, u = bc(n, o), a.props = u, d = t.pendingProps, f = a.context, l = n.contextType, c = Ei, typeof l == "object" && l && (c = xa(l)), s = n.getDerivedStateFromProps, (l = typeof s == "function" || typeof a.getSnapshotBeforeUpdate == "function") || typeof a.UNSAFE_componentWillReceiveProps != "function" && typeof a.componentWillReceiveProps != "function" || (o !== d || f !== c) && yc(t, a, r, c), lo = !1, f = t.memoizedState, a.state = f, yo(t, r, a, i), vo();
			var p = t.memoizedState;
			o !== d || f !== p || lo || e !== null && e.dependencies !== null && ya(e.dependencies) ? (typeof s == "function" && (gc(t, n, s, r), p = t.memoizedState), (u = lo || vc(t, n, u, r, f, p, c) || e !== null && e.dependencies !== null && ya(e.dependencies)) ? (l || typeof a.UNSAFE_componentWillUpdate != "function" && typeof a.componentWillUpdate != "function" || (typeof a.componentWillUpdate == "function" && a.componentWillUpdate(r, p, c), typeof a.UNSAFE_componentWillUpdate == "function" && a.UNSAFE_componentWillUpdate(r, p, c)), typeof a.componentDidUpdate == "function" && (t.flags |= 4), typeof a.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof a.componentDidUpdate != "function" || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != "function" || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = p), a.props = r, a.state = p, a.context = c, r = u) : (typeof a.componentDidUpdate != "function" || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != "function" || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), r = !1);
		}
		return a = r, Hc(e, t), r = !!(t.flags & 128), a || r ? (a = t.stateNode, n = r && typeof n.getDerivedStateFromError != "function" ? null : a.render(), t.flags |= 1, e !== null && r ? (t.child = so(t, e.child, null, i), t.child = so(t, null, n, i)) : Mc(e, t, n, i), t.memoizedState = a.state, e = t.child) : e = sl(e, t, i), e;
	}
	function Kc(e, t, n, r) {
		return ca(), t.flags |= 256, Mc(e, t, n, r), t.child;
	}
	var qc = {
		dehydrated: null,
		treeContext: null,
		retryLane: 0,
		hydrationErrors: null
	};
	function Jc(e) {
		return {
			baseLanes: e,
			cachePool: Wa()
		};
	}
	function Yc(e, t, n) {
		return e = e === null ? 0 : e.childLanes & ~n, t && (e |= ld), e;
	}
	function Xc(e, t, n) {
		var r = t.pendingProps, i = !1, a = !!(t.flags & 128), o;
		if ((o = a) || (o = e !== null && e.memoizedState === null ? !1 : !!(Po.current & 2)), o && (i = !0, t.flags &= -129), o = !!(t.flags & 32), t.flags &= -33, e === null) {
			if (W) {
				if (i ? ko(t) : Mo(), (e = ea) ? (e = am(e, na), e = e !== null && e.data !== "&" ? e : null, e !== null && (t.memoizedState = {
					dehydrated: e,
					treeContext: Gi === null ? null : {
						id: Ki,
						overflow: qi
					},
					retryLane: 536870912,
					hydrationErrors: null
				}, n = Fi(e), n.return = t, t.child = n, $i = t, ea = null)) : e = null, e === null) throw ia(t);
				return t.lanes = sm(e) ? 32 : 536870912, null;
			}
			return a = r.children, r = r.fallback, i ? (Mo(), i = t.mode, a = Qc({
				mode: "hidden",
				children: a
			}, i), r = Ni(r, i, n, null), a.return = t, r.return = t, a.sibling = r, t.child = a, r = t.child, r.memoizedState = Jc(n), r.childLanes = Yc(e, o, n), t.memoizedState = qc, Lc(null, r)) : (ko(t), Zc(t, a));
		}
		var s = e.memoizedState;
		if (s !== null) {
			var c = s.dehydrated;
			if (c !== null) return el(e, t, a, o, r, c, s, n);
		}
		return i ? (Mo(), i = r.fallback, a = t.mode, s = e.child, c = s.sibling, r = Ai(s, {
			mode: "hidden",
			children: r.children
		}), r.subtreeFlags = s.subtreeFlags & 1206910976, c === null ? (i = Ni(i, a, n, null), i.flags |= 2) : i = Ai(c, i), i.return = t, r.return = t, r.sibling = i, t.child = r, Lc(null, r), r = t.child, i = e.child.memoizedState, i === null ? i = Jc(n) : (a = i.cachePool, a === null ? a = Wa() : (s = Da._currentValue, a = a.parent === s ? a : {
			parent: s,
			pool: s
		}), i = {
			baseLanes: i.baseLanes | n,
			cachePool: a
		}), r.memoizedState = i, r.childLanes = Yc(e, o, n), t.memoizedState = qc, Lc(e.child, r)) : (ko(t), n = e.child, e = n.sibling, n = Ai(n, {
			mode: "visible",
			children: r.children
		}), n.return = t, n.sibling = null, e !== null && (o = t.deletions, o === null ? (t.deletions = [e], t.flags |= 16) : o.push(e)), t.child = n, t.memoizedState = null, n);
	}
	function Zc(e, t) {
		return t = Qc({
			mode: "visible",
			children: t
		}, e.mode), t.return = e, e.child = t;
	}
	function Qc(e, t) {
		return e = Oi(22, e, null, t), e.lanes = 0, e;
	}
	function $c(e, t, n) {
		return so(t, e.child, null, n), e = Zc(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e;
	}
	function el(e, t, n, r, a, o, s, c) {
		if (n) return t.flags & 256 ? (ko(t), t.flags &= -257, $c(e, t, c)) : t.memoizedState === null ? (Mo(), o = a.fallback, s = t.mode, a = Qc({
			mode: "visible",
			children: a.children
		}, s), o = Ni(o, s, c, null), o.flags |= 2, a.return = t, o.return = t, a.sibling = o, t.child = a, so(t, e.child, null, c), a = t.child, a.memoizedState = Jc(c), a.childLanes = Yc(e, r, c), t.memoizedState = qc, Lc(null, a)) : (Mo(), t.child = e.child, t.flags |= 128, null);
		if (ko(t), sm(o)) {
			if (r = o.nextSibling && o.nextSibling.dataset, r) var l = r.dgst;
			return r = l, r !== "" && (a = Error(i(419)), a.stack = "", a.digest = r, ua({
				value: a,
				source: null,
				stack: null
			})), $c(e, t, c);
		}
		if (jc || va(e, t, c, !1), r = (c & e.childLanes) !== 0, jc || r) {
			if (So.current !== null) return $c(e, t, c);
			if (r = $u, r !== null && (a = ht(r, c), a !== 0 && a !== s.retryLane)) throw s.retryLane = a, Ci(e, a), Pd(r, e, a), Ac;
			return om(o) || Kd(), $c(e, t, c);
		}
		return om(o) ? (t.flags |= 192, t.child = e.child, null) : (e = s.treeContext, ea = lm(o.nextSibling), $i = t, W = !0, ta = null, na = !1, e !== null && Qi(t, e), t = Zc(t, a.children), t.flags |= 134221824, t);
	}
	function tl(e, t, n) {
		e.lanes |= t;
		var r = e.alternate;
		r !== null && (r.lanes |= t), ga(e.return, t, n);
	}
	function nl(e) {
		for (var t = null; e !== null;) {
			var n = e.alternate;
			n !== null && Lo(n) === null && (t = e), e = e.sibling;
		}
		return t;
	}
	function rl(e, t, n, r, i, a) {
		var o = e.memoizedState;
		o === null ? e.memoizedState = {
			isBackwards: t,
			rendering: null,
			renderingStartTime: 0,
			last: r,
			tail: n,
			tailMode: i,
			treeForkCount: a
		} : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = i, o.treeForkCount = a);
	}
	function il(e) {
		var t = e.child;
		for (e.child = null; t !== null;) {
			var n = t.sibling;
			t.sibling = e.child, e.child = t, t = n;
		}
	}
	function al(e, t, n) {
		var r = t.pendingProps, i = r.revealOrder, a = r.tail;
		r = r.children;
		var o = Po.current;
		if (t.flags & 128) return Fo(t, o), null;
		var s = !!(o & 2);
		if (s ? (o = o & 1 | 2, t.flags |= 128) : o &= 1, Fo(t, o), i === "backwards" && e !== null ? (il(e), Mc(e, t, r, n), il(e)) : Mc(e, t, r, n), r = W ? Hi : 0, !s && e !== null && e.flags & 128) a: for (e = t.child; e !== null;) {
			if (e.tag === 13) e.memoizedState !== null && tl(e, n, t);
			else if (e.tag === 19) tl(e, n, t);
			else if (e.child !== null) {
				e.child.return = e, e = e.child;
				continue;
			}
			if (e === t) break a;
			for (; e.sibling === null;) {
				if (e.return === null || e.return === t) break a;
				e = e.return;
			}
			e.sibling.return = e.return, e = e.sibling;
		}
		switch (i) {
			case "backwards":
				n = nl(t.child), n === null ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null, il(t)), rl(t, !0, i, null, a, r);
				break;
			case "unstable_legacy-backwards":
				for (n = null, i = t.child, t.child = null; i !== null;) {
					if (e = i.alternate, e !== null && Lo(e) === null) {
						t.child = i;
						break;
					}
					e = i.sibling, i.sibling = n, n = i, i = e;
				}
				rl(t, !0, n, null, a, r);
				break;
			case "together":
				rl(t, !1, null, null, void 0, r);
				break;
			case "independent":
				t.memoizedState = null;
				break;
			default: n = nl(t.child), n === null ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null), rl(t, !1, i, n, a, r);
		}
		return t.child;
	}
	function ol(e, t, n) {
		var r = t.pendingProps;
		return ma(t, t.type, r.value), Mc(e, t, r.children, n), t.child;
	}
	function sl(e, t, n) {
		if (e !== null && (t.dependencies = e.dependencies), od |= t.lanes, (n & t.childLanes) === 0) {
			if (e !== null) {
				if (va(e, t, n, !1), (n & t.childLanes) === 0) return null;
			} else return null;
		}
		if (e !== null && t.child !== e.child) throw Error(i(153));
		if (t.child !== null) {
			for (e = t.child, n = Ai(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = Ai(e, e.pendingProps), n.return = t;
			n.sibling = null;
		}
		return t.child;
	}
	function cl(e, t) {
		return (e.lanes & t) !== 0 || (e = e.dependencies, !!(e !== null && ya(e)));
	}
	function ll(e, t, n) {
		switch (t.tag) {
			case 3:
				De(t, t.stateNode.containerInfo), ma(t, Da, e.memoizedState.cache), ca();
				break;
			case 27:
			case 5:
				ke(t);
				break;
			case 4:
				De(t, t.stateNode.containerInfo);
				break;
			case 10:
				ma(t, t.type, t.memoizedProps.value);
				break;
			case 31:
				if (t.memoizedState !== null) return t.flags |= 128, Ao(t), null;
				break;
			case 13:
				var r = t.memoizedState;
				if (r !== null) {
					if (r.dehydrated !== null) return ko(t), t.flags |= 128, null;
					r = va(e, t, n, !1);
					var i = t.child.childLanes;
					return r || (n & i) !== 0 ? Xc(e, t, n) : (ko(t), e = sl(e, t, n), e === null ? null : e.sibling);
				}
				ko(t);
				break;
			case 19:
				if (t.flags & 128) return al(e, t, n);
				if (i = !!(e.flags & 128), r = (n & t.childLanes) !== 0, r ||= (va(e, t, n, !1), (n & t.childLanes) !== 0), i) {
					if (r) return al(e, t, n);
					t.flags |= 128;
				}
				if (i = t.memoizedState, i !== null && (i.rendering = null, i.tail = null, i.lastEffect = null), Fo(t, Po.current), r) break;
				return null;
			case 22: return t.lanes = 0, Ic(e, t, n, t.pendingProps);
			case 24: ma(t, Da, e.memoizedState.cache);
		}
		return sl(e, t, n);
	}
	function ul(e, t, n) {
		if (e !== null) {
			if (e.memoizedProps !== t.pendingProps) jc = !0;
			else {
				if (!cl(e, n) && !(t.flags & 128)) return jc = !1, ll(e, t, n);
				jc = !!(e.flags & 131072);
			}
		} else jc = !1, W && t.flags & 1048576 && Yi(t, Hi, t.index);
		switch (t.lanes = 0, t.tag) {
			case 16:
				a: {
					var r = t.pendingProps;
					if (e = Za(t.elementType), t.type = e, typeof e == "function") ki(e) ? (r = bc(e, r), t.tag = 1, t = Gc(null, t, e, r, n)) : (t.tag = 0, t = Uc(null, t, e, r, n));
					else {
						if (e != null) {
							var a = e.$$typeof;
							if (a === ae) {
								t.tag = 11, t = Nc(null, t, e, r, n);
								break a;
							}
							if (a === ce) {
								t.tag = 14, t = Pc(null, t, e, r, n);
								break a;
							}
							if (a === A) {
								t.tag = 10, t.type = e, t = ol(null, t, n);
								break a;
							}
						}
						throw t = _e(e) || e, Error(i(306, t, ""));
					}
				}
				return t;
			case 0: return Uc(e, t, t.type, t.pendingProps, n);
			case 1: return r = t.type, a = bc(r, t.pendingProps), Gc(e, t, r, a, n);
			case 3:
				a: {
					if (De(t, t.stateNode.containerInfo), e === null) throw Error(i(387));
					r = t.pendingProps;
					var o = t.memoizedState;
					a = o.element, fo(e, t), yo(t, r, null, n);
					var s = t.memoizedState;
					if (r = s.cache, ma(t, Da, r), r !== o.cache && _a(t, [Da], n, !0), vo(), r = s.element, o.isDehydrated) {
						if (o = {
							element: r,
							isDehydrated: !1,
							cache: s.cache
						}, t.updateQueue.baseState = o, t.memoizedState = o, t.flags & 256) {
							t = Kc(e, t, r, n);
							break a;
						}
						if (r !== a) {
							a = Ri(Error(i(424)), t), ua(a), t = Kc(e, t, r, n);
							break a;
						}
						switch (e = t.stateNode.containerInfo, e.nodeType) {
							case 9:
								e = e.body;
								break;
							default: e = e.nodeName === "HTML" ? e.ownerDocument.body : e;
						}
						for (ea = lm(e.firstChild), $i = t, W = !0, ta = null, na = !0, n = co(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 134221824, n = n.sibling;
					} else {
						if (ca(), r === a) {
							t = sl(e, t, n);
							break a;
						}
						Mc(e, t, r, n);
					}
					t = t.child;
				}
				return t;
			case 26: return Hc(e, t), e === null ? (n = Nm(t.type, null, t.pendingProps, null)) ? t.memoizedState = n : W || (t.stateNode = fp(t.type, t.pendingProps, Te.current, t)) : t.memoizedState = Nm(t.type, e.memoizedProps, t.pendingProps, e.memoizedState), null;
			case 27: return ke(t), e === null && W && (r = t.stateNode = hm(t.type, t.pendingProps, Te.current), $i = t, na = !0, a = ea, Sp(t.type) ? (um = a, ea = lm(r.firstChild)) : ea = a), Mc(e, t, t.pendingProps.children, n), Hc(e, t), e === null && (t.flags |= 4194304), t.child;
			case 5: return e === null && W && ((a = r = ea) && (r = rm(r, t.type, t.pendingProps, na), r === null ? a = !1 : (t.stateNode = r, $i = t, ea = lm(r.firstChild), na = !1, a = !0)), a || ia(t)), ke(t), a = t.type, o = t.pendingProps, s = e === null ? null : e.memoizedProps, r = o.children, pp(a, o) ? r = null : s !== null && pp(a, s) && (t.flags |= 32), t.memoizedState !== null && (a = Xo(e, t, $o, null, null, n), sh._currentValue = a), Hc(e, t), Mc(e, t, r, n), t.child;
			case 6: return e === null && W && ((e = n = ea) && (n = im(n, t.pendingProps, na), n === null ? e = !1 : (t.stateNode = n, $i = t, ea = null, e = !0)), e || ia(t)), null;
			case 13: return Xc(e, t, n);
			case 4: return De(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = so(t, null, r, n) : Mc(e, t, r, n), t.child;
			case 11: return Nc(e, t, t.type, t.pendingProps, n);
			case 7: return r = t.pendingProps, Hc(e, t), Mc(e, t, r, n), t.child;
			case 8: return Mc(e, t, t.pendingProps.children, n), t.child;
			case 12: return Mc(e, t, t.pendingProps.children, n), t.child;
			case 10: return ol(e, t, n);
			case 9: return a = t.type._context, r = t.pendingProps.children, ba(t), a = xa(a), r = r(a), t.flags |= 1, Mc(e, t, r, n), t.child;
			case 14: return Pc(e, t, t.type, t.pendingProps, n);
			case 15: return Fc(e, t, t.type, t.pendingProps, n);
			case 19: return al(e, t, n);
			case 31: return Vc(e, t, n);
			case 22: return Ic(e, t, n, t.pendingProps);
			case 24: return ba(t), r = xa(Da), e === null ? (a = Ha(), a === null && (a = $u, o = Oa(), a.pooledCache = o, o.refCount++, o !== null && (a.pooledCacheLanes |= n), a = o), t.memoizedState = {
				parent: r,
				cache: a
			}, uo(t), ma(t, Da, a)) : ((e.lanes & n) !== 0 && (fo(e, t), yo(t, null, null, n), vo()), a = e.memoizedState, o = t.memoizedState, a.parent === r ? (r = o.cache, ma(t, Da, r), r !== a.cache && _a(t, [Da], n, !0)) : (a = {
				parent: r,
				cache: r
			}, t.memoizedState = a, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = a), ma(t, Da, r))), Mc(e, t, t.pendingProps.children, n), t.child;
			case 30: return t.stateNode === null && (t.stateNode = {
				autoName: null,
				paired: null,
				clones: null,
				ref: null
			}), r = t.pendingProps, r.name != null && r.name !== "auto" ? t.flags |= e === null ? 18882560 : 18874368 : W && Xi(t), e !== null && e.memoizedProps.name !== r.name ? t.flags |= 4194816 : Hc(e, t), Mc(e, t, r.children, n), t.child;
			case 29: throw t.pendingProps;
		}
		throw Error(i(156, t.tag));
	}
	function dl(e) {
		e.flags |= 4;
	}
	function fl(e, t, n, r, i) {
		var a;
		if ((a = !!(e.mode & 32)) && (a = n === null ? Jm(t, r) : Jm(t, r) && (r.src !== n.src || r.srcSet !== n.srcSet)), a) {
			if (e.flags |= 16777216, (i & 335544128) === i) {
				if (e.stateNode.complete) e.flags |= 8192;
				else if (Ud()) e.flags |= 8192;
				else throw Qa = Ja, Ka;
			}
		} else e.flags &= -16777217;
	}
	function pl(e, t) {
		if (t.type !== "stylesheet" || t.state.loading & 4) e.flags &= -16777217;
		else if (e.flags |= 16777216, !Ym(t)) {
			if (Ud()) e.flags |= 8192;
			else throw Qa = Ja, Ka;
		}
	}
	function ml(e, t) {
		t !== null && (e.flags |= 4), e.flags & 16384 && (t = e.tag === 22 ? 536870912 : lt(), e.lanes |= t, ud |= t);
	}
	function hl(e, t) {
		if (!W) switch (e.tailMode) {
			case "visible": break;
			case "collapsed":
				for (var n = e.tail, r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
				r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null;
				break;
			default:
				for (t = e.tail, n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
				n === null ? e.tail = null : n.sibling = null;
		}
	}
	function gl(e) {
		var t = e.alternate !== null && e.alternate.child === e.child, n = 0, r = 0;
		if (t) for (var i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags & 1206910976, r |= i.flags & 1206910976, i.return = e, i = i.sibling;
		else for (i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags, r |= i.flags, i.return = e, i = i.sibling;
		return e.subtreeFlags |= r, e.childLanes = n, t;
	}
	function _l(e, t, n) {
		var r = t.pendingProps;
		switch (Zi(t), t.tag) {
			case 16:
			case 15:
			case 0:
			case 11:
			case 7:
			case 8:
			case 12:
			case 9:
			case 14: return gl(t), null;
			case 1: return gl(t), null;
			case 3: return n = t.stateNode, r = null, e !== null && (r = e.memoizedState.cache), t.memoizedState.cache !== r && (t.flags |= 2048), ha(Da), Oe(), n.pendingContext && (n.context = n.pendingContext, n.pendingContext = null), (e === null || e.child === null) && (sa(t) ? dl(t) : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, la())), gl(t), null;
			case 26:
				var a = t.type, o = t.memoizedState;
				return e === null ? (dl(t), o === null ? (gl(t), fl(t, a, null, r, n)) : (gl(t), pl(t, o))) : o ? o === e.memoizedState ? (gl(t), t.flags &= -16777217) : (dl(t), gl(t), pl(t, o)) : (e = e.memoizedProps, e !== r && dl(t), gl(t), fl(t, a, e, r, n)), null;
			case 27:
				if (Ae(t), n = Te.current, a = t.type, e !== null && t.stateNode != null) e.memoizedProps !== r && dl(t);
				else {
					if (!r) {
						if (t.stateNode === null) throw Error(i(166));
						return gl(t), t.subtreeFlags &= -33554433, null;
					}
					e = Ce.current, sa(t) ? aa(t, e) : (e = hm(a, r, n), t.stateNode = e, dl(t));
				}
				return gl(t), t.subtreeFlags &= -33554433, null;
			case 5:
				if (Ae(t), a = t.type, e !== null && t.stateNode != null) e.memoizedProps !== r && dl(t);
				else {
					if (!r) {
						if (t.stateNode === null) throw Error(i(166));
						return gl(t), t.subtreeFlags &= -33554433, null;
					}
					if (o = Ce.current, sa(t)) aa(t, o);
					else {
						var s = lp(Te.current);
						switch (o) {
							case 1:
								o = s.createElementNS("http://www.w3.org/2000/svg", a);
								break;
							case 2:
								o = s.createElementNS("http://www.w3.org/1998/Math/MathML", a);
								break;
							default: switch (a) {
								case "svg":
									o = s.createElementNS("http://www.w3.org/2000/svg", a);
									break;
								case "math":
									o = s.createElementNS("http://www.w3.org/1998/Math/MathML", a);
									break;
								case "script":
									o = s.createElement("div"), o.innerHTML = "<script><\/script>", o = o.removeChild(o.firstChild);
									break;
								case "select":
									o = typeof r.is == "string" ? s.createElement("select", { is: r.is }) : s.createElement("select"), r.multiple ? o.multiple = !0 : r.size && (o.size = r.size);
									break;
								default: o = typeof r.is == "string" ? s.createElement(a, { is: r.is }) : s.createElement(a);
							}
						}
						o[B] = t, o[xt] = r;
						a: for (s = t.child; s !== null;) {
							if (s.tag === 5 || s.tag === 6) o.appendChild(s.stateNode);
							else if (s.tag !== 4 && s.tag !== 27 && s.child !== null) {
								s.child.return = s, s = s.child;
								continue;
							}
							if (s === t) break a;
							for (; s.sibling === null;) {
								if (s.return === null || s.return === t) break a;
								s = s.return;
							}
							s.sibling.return = s.return, s = s.sibling;
						}
						t.stateNode = o;
						a: switch (np(o, a, r), a) {
							case "button":
							case "input":
							case "select":
							case "textarea":
								r = !!r.autoFocus;
								break a;
							case "img":
								r = !0;
								break a;
							default: r = !1;
						}
						r && dl(t);
					}
				}
				return gl(t), t.subtreeFlags &= -33554433, fl(t, t.type, e === null ? null : e.memoizedProps, t.pendingProps, n), null;
			case 6:
				if (e && t.stateNode != null) e.memoizedProps !== r && dl(t);
				else {
					if (typeof r != "string" && t.stateNode === null) throw Error(i(166));
					if (e = Te.current, sa(t)) {
						if (e = t.stateNode, n = t.memoizedProps, r = null, a = $i, a !== null) switch (a.tag) {
							case 27:
							case 5: r = a.memoizedProps;
						}
						e[B] = t, e = !!(e.nodeValue === n || r !== null && !0 === r.suppressHydrationWarning || ep(e.nodeValue, n)), e || ia(t, !0);
					} else e = lp(e).createTextNode(r), e[B] = t, t.stateNode = e;
				}
				return gl(t), null;
			case 31:
				if (n = t.memoizedState, e === null || e.memoizedState !== null) {
					if (r = sa(t), n !== null) {
						if (e === null) {
							if (!r) throw Error(i(318));
							if (e = t.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(i(557));
							e[B] = t;
						} else ca(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
						gl(t), e = !1;
					} else n = la(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = n), e = !0;
					if (!e) return t.flags & 256 ? (No(t), t) : (No(t), null);
					if (t.flags & 128) throw Error(i(558));
				}
				return gl(t), null;
			case 13:
				if (r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
					if (a = sa(t), r !== null && r.dehydrated !== null) {
						if (e === null) {
							if (!a) throw Error(i(318));
							if (a = t.memoizedState, a = a === null ? null : a.dehydrated, !a) throw Error(i(317));
							a[B] = t;
						} else ca(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
						gl(t), a = !1;
					} else a = la(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = a), a = !0;
					if (!a) return t.flags & 256 ? (No(t), t) : (No(t), null);
				}
				return No(t), t.flags & 128 ? (t.lanes = n, t) : (n = r !== null, e = e !== null && e.memoizedState !== null, n && (r = t.child, a = null, r.alternate !== null && r.alternate.memoizedState !== null && r.alternate.memoizedState.cachePool !== null && (a = r.alternate.memoizedState.cachePool.pool), o = null, r.memoizedState !== null && r.memoizedState.cachePool !== null && (o = r.memoizedState.cachePool.pool), o !== a && (r.flags |= 2048)), n !== e && n && (t.child.flags |= 8192), ml(t, t.updateQueue), gl(t), null);
			case 4: return Oe(), e === null && Wf(t.stateNode.containerInfo), t.flags |= 67108864, gl(t), null;
			case 10: return ha(t.type), gl(t), null;
			case 19:
				if (Io(t), r = t.memoizedState, r === null) return gl(t), null;
				if (a = !!(t.flags & 128), o = r.rendering, o === null) {
					if (a) hl(r, !1);
					else {
						if (ad !== 0 || e !== null && e.flags & 128) for (e = t.child; e !== null;) {
							if (o = Lo(e), o !== null) {
								for (t.flags |= 128, hl(r, !1), e = o.updateQueue, t.updateQueue = e, ml(t, e), t.subtreeFlags = 0, e = n, n = t.child; n !== null;) ji(n, e), n = n.sibling;
								return Fo(t, Po.current & 1 | 2), W && Ji(t, r.treeForkCount), t.child;
							}
							e = e.sibling;
						}
						r.tail !== null && He() > gd && (t.flags |= 128, a = !0, hl(r, !1), t.lanes = 4194304);
					}
				} else {
					if (!a) {
						if (e = Lo(o), e !== null) {
							if (t.flags |= 128, a = !0, e = e.updateQueue, t.updateQueue = e, ml(t, e), hl(r, !0), r.tail === null && r.tailMode !== "collapsed" && r.tailMode !== "visible" && !o.alternate && !W) return gl(t), null;
						} else 2 * He() - r.renderingStartTime > gd && n !== 536870912 && (t.flags |= 128, a = !0, hl(r, !1), t.lanes = 4194304);
					}
					r.isBackwards ? (o.sibling = t.child, t.child = o) : (e = r.last, e === null ? t.child = o : e.sibling = o, r.last = o);
				}
				if (r.tail !== null) {
					e = r.tail;
					a: {
						for (n = e; n !== null;) {
							if (n.alternate !== null) {
								n = !1;
								break a;
							}
							n = n.sibling;
						}
						n = !0;
					}
					return r.rendering = e, r.tail = e.sibling, r.renderingStartTime = He(), e.sibling = null, o = Po.current, o = a ? o & 1 | 2 : o & 1, r.tailMode === "visible" || r.tailMode === "collapsed" || !n || W ? Fo(t, o) : (n = o, F(Do, t), F(Po, n), Oo === null && (Oo = t)), W && Ji(t, r.treeForkCount), e;
				}
				return gl(t), null;
			case 22:
			case 23: return No(t), Eo(), r = t.memoizedState !== null, e === null ? r && (t.flags |= 8192) : e.memoizedState !== null !== r && (t.flags |= 8192), r ? n & 536870912 && !(t.flags & 128) && (gl(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : gl(t), n = t.updateQueue, n !== null && ml(t, n.retryQueue), n = null, e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), r = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (r = t.memoizedState.cachePool.pool), r !== n && (t.flags |= 2048), e !== null && Se(Va), null;
			case 24: return n = null, e !== null && (n = e.memoizedState.cache), t.memoizedState.cache !== n && (t.flags |= 2048), ha(Da), gl(t), null;
			case 25: return null;
			case 30: return t.flags |= 33554432, gl(t), null;
		}
		throw Error(i(156, t.tag));
	}
	function vl(e, t) {
		switch (Zi(t), t.tag) {
			case 1: return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
			case 3: return ha(Da), Oe(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
			case 26:
			case 27:
			case 5: return Ae(t), null;
			case 31:
				if (t.memoizedState !== null) {
					if (No(t), t.alternate === null) throw Error(i(340));
					ca();
				}
				return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
			case 13:
				if (No(t), e = t.memoizedState, e !== null && e.dehydrated !== null) {
					if (t.alternate === null) throw Error(i(340));
					ca();
				}
				return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
			case 19: return Io(t), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, e = t.memoizedState, e !== null && (e.rendering = null, e.tail = null), t.flags |= 4, t) : null;
			case 4: return Oe(), null;
			case 10: return ha(t.type), null;
			case 22:
			case 23: return No(t), Eo(), e !== null && Se(Va), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
			case 24: return ha(Da), null;
			case 25: return null;
			default: return null;
		}
	}
	function yl(e, t) {
		switch (Zi(t), t.tag) {
			case 3:
				ha(Da), Oe();
				break;
			case 26:
			case 27:
			case 5:
				Ae(t);
				break;
			case 4:
				Oe();
				break;
			case 31:
				t.memoizedState !== null && No(t);
				break;
			case 13:
				No(t);
				break;
			case 19:
				Io(t);
				break;
			case 10:
				ha(t.type);
				break;
			case 22:
			case 23:
				No(t), Eo(), e !== null && Se(Va);
				break;
			case 24: ha(Da);
		}
	}
	function bl(e, t) {
		try {
			var n = t.updateQueue, r = n === null ? null : n.lastEffect;
			if (r !== null) {
				var i = r.next;
				n = i;
				do {
					if ((n.tag & e) === e) {
						r = void 0;
						var a = n.create, o = n.inst;
						r = a(), o.destroy = r;
					}
					n = n.next;
				} while (n !== i);
			}
		} catch (e) {
			Z(t, t.return, e);
		}
	}
	function xl(e, t, n) {
		try {
			var r = t.updateQueue, i = r === null ? null : r.lastEffect;
			if (i !== null) {
				var a = i.next;
				r = a;
				do {
					if ((r.tag & e) === e) {
						var o = r.inst, s = o.destroy;
						if (s !== void 0) {
							o.destroy = void 0, i = t;
							var c = n, l = s;
							try {
								l();
							} catch (e) {
								Z(i, c, e);
							}
						}
					}
					r = r.next;
				} while (r !== a);
			}
		} catch (e) {
			Z(t, t.return, e);
		}
	}
	function Sl(e) {
		var t = e.updateQueue;
		if (t !== null) {
			var n = e.stateNode;
			try {
				xo(t, n);
			} catch (t) {
				Z(e, e.return, t);
			}
		}
	}
	function Cl(e, t, n) {
		n.props = bc(e.type, e.memoizedProps), n.state = e.memoizedState;
		try {
			n.componentWillUnmount();
		} catch (n) {
			Z(e, t, n);
		}
	}
	function wl(e, t) {
		try {
			var n = e.ref;
			if (n !== null) {
				switch (e.tag) {
					case 26:
					case 27:
					case 5:
						var r = e.stateNode;
						break;
					case 30:
						var i = e.stateNode, a = pi(e.memoizedProps, i);
						(i.ref === null || i.ref.name !== a) && (i.ref = Pp(a)), r = i.ref;
						break;
					case 7:
						if (e.stateNode === null) {
							var o = new Fp(e);
							h(e.child, !1, Qp, o, void 0, void 0), e.stateNode = o;
						}
						r = e.stateNode;
						break;
					default: r = e.stateNode;
				}
				typeof n == "function" ? e.refCleanup = n(r) : n.current = r;
			}
		} catch (n) {
			Z(e, t, n);
		}
	}
	function Tl(e, t) {
		var n = e.ref, r = e.refCleanup;
		if (n !== null) {
			if (typeof r == "function") try {
				r();
			} catch (n) {
				Z(e, t, n);
			} finally {
				e.refCleanup = null, e = e.alternate, e != null && (e.refCleanup = null);
			}
			else if (typeof n == "function") try {
				n(null);
			} catch (n) {
				Z(e, t, n);
			}
			else n.current = null;
		}
	}
	function El(e, t) {
		if ((e.tag === 5 || e.tag === 27 || e.tag === 6) && e.alternate === null && t !== null) for (var n = 0; n < t.length; n++) em(e.stateNode, t[n]);
	}
	function Dl(e) {
		for (var t = e.return; t !== null && (Al(t) && em(e.stateNode, t.stateNode), !kl(t));) t = t.return;
	}
	function Ol(e) {
		for (var t = e.return; t !== null && (Al(t) && tm(e.stateNode, t.stateNode), !kl(t));) t = t.return;
	}
	function kl(e) {
		return e.tag === 5 || e.tag === 3 || e.tag === 27;
	}
	function Al(e) {
		return e && e.tag === 7 && e.stateNode !== null;
	}
	function jl(e) {
		var t = e.type, n = e.memoizedProps, r = e.stateNode;
		try {
			a: switch (t) {
				case "button":
				case "input":
				case "select":
				case "textarea":
					n.autoFocus && r.focus();
					break a;
				case "img": n.src ? r.src = n.src : n.srcSet && (r.srcset = n.srcSet);
			}
		} catch (t) {
			Z(e, e.return, t);
		}
	}
	function Ml(e, t, n) {
		try {
			var r = e.stateNode;
			ip(r, e.type, n, t), r[xt] = t;
		} catch (t) {
			Z(e, e.return, t);
		}
	}
	function Nl(e) {
		return e.tag === 5 || e.tag === 3 || e.tag === 26 || e.tag === 27 && Sp(e.type) || e.tag === 4;
	}
	function Pl(e) {
		a: for (;;) {
			for (; e.sibling === null;) {
				if (e.return === null || Nl(e.return)) return null;
				e = e.return;
			}
			for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
				if (e.tag === 27 && Sp(e.type) || e.flags & 2 || e.child === null || e.tag === 4) continue a;
				e.child.return = e, e = e.child;
			}
			if (!(e.flags & 2)) return e.stateNode;
		}
	}
	function Fl(e, t, n, r) {
		var i = e.tag;
		if (i === 5 || i === 6) i = e.stateNode, t ? (n.nodeType === 9 ? n.body : n.nodeName === "HTML" ? n.ownerDocument.body : n).insertBefore(i, t) : (t = n.nodeType === 9 ? n.body : n.nodeName === "HTML" ? n.ownerDocument.body : n, t.appendChild(i), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = hn)), El(e, r), H = !0;
		else if (i !== 4 && (i === 27 && (El(e, r), r = null, Sp(e.type) && (n = e.stateNode, t = null)), e = e.child, e !== null)) for (Fl(e, t, n, r), e = e.sibling; e !== null;) Fl(e, t, n, r), e = e.sibling;
	}
	function Il(e, t, n, r) {
		var i = e.tag;
		if (i === 5 || i === 6) i = e.stateNode, t ? n.insertBefore(i, t) : n.appendChild(i), El(e, r), H = !0;
		else if (i !== 4 && (i === 27 && (El(e, r), r = null, Sp(e.type) && (n = e.stateNode)), e = e.child, e !== null)) for (Il(e, t, n, r), e = e.sibling; e !== null;) Il(e, t, n, r), e = e.sibling;
	}
	function Ll(e) {
		var t = e.stateNode, n = e.memoizedProps;
		try {
			for (var r = e.type, i = t.attributes; i.length;) t.removeAttributeNode(i[0]);
			np(t, r, n), t[B] = e, t[xt] = n;
		} catch (t) {
			Z(e, e.return, t);
		}
	}
	var Rl = !1, zl = null;
	function Bl(e) {
		(e.tag === 30 || e.subtreeFlags & 33554432) && (Rl = !0);
	}
	var Vl = null;
	function Hl() {
		var e = Vl;
		return Vl = null, e;
	}
	var Ul = 0;
	function Wl(e, t, n, r, i) {
		return Ul = 0, Gl(e.child, t, n, r, i);
	}
	function Gl(e, t, n, r, i) {
		for (var a = !1; e !== null;) {
			if (e.tag === 5) {
				var o = e.stateNode;
				if (r !== null) {
					var s = Op(o);
					r.push(s), s.view && (a = !0);
				} else a || Op(o).view && (a = !0);
				Rl = !0, Tp(o, Ul === 0 ? t : t + "_" + Ul, n), Ul++;
			} else e.tag === 22 && e.memoizedState !== null || e.tag === 30 && i || Gl(e.child, t, n, r, i) && (a = !0);
			e = e.sibling;
		}
		return a;
	}
	function Kl(e, t) {
		for (; e !== null;) e.tag === 5 ? Ep(e.stateNode, e.memoizedProps) : e.tag === 22 && e.memoizedState !== null || e.tag === 30 && t || Kl(e.child, t), e = e.sibling;
	}
	function ql(e) {
		if (e.subtreeFlags & 18874368) for (e = e.child; e !== null;) {
			if ((e.tag !== 22 || e.memoizedState === null) && (ql(e), e.tag === 30 && e.flags & 18874368 && e.stateNode.paired)) {
				var t = e.memoizedProps;
				if (t.name == null || t.name === "auto") throw Error(i(544));
				var n = t.name;
				t = hi(t.default, t.share), t !== "none" && (Wl(e, n, t, null, !1) || Kl(e.child, !1));
			}
			e = e.sibling;
		}
	}
	function Jl(e, t) {
		if (e.tag === 30) {
			var n = e.stateNode, r = e.memoizedProps, i = pi(r, n), a = hi(r.default, n.paired ? r.share : r.enter);
			a === "none" ? ql(e) : Wl(e, i, a, null, !1) ? (ql(e), n.paired || t || Nd(e, r.onEnter)) : Kl(e.child, !1);
		} else if (e.subtreeFlags & 33554432) for (e = e.child; e !== null;) Jl(e, t), e = e.sibling;
		else ql(e);
	}
	function Yl(e) {
		if (zl !== null && zl.size !== 0) {
			var t = zl;
			if (e.subtreeFlags & 18874368) for (e = e.child; e !== null;) {
				if (e.tag !== 22 || e.memoizedState === null) {
					if (e.tag === 30 && e.flags & 18874368) {
						var n = e.memoizedProps, r = n.name;
						if (r != null && r !== "auto") {
							var i = t.get(r);
							if (i !== void 0) {
								var a = hi(n.default, n.share);
								if (a !== "none" && (Wl(e, r, a, null, !1) ? (a = e.stateNode, i.paired = a, a.paired = i, Nd(e, n.onShare)) : Kl(e.child, !1)), t.delete(r), t.size === 0) break;
							}
						}
					}
					Yl(e);
				}
				e = e.sibling;
			}
		}
	}
	function Xl(e) {
		if (e.tag === 30) {
			var t = e.memoizedProps, n = pi(t, e.stateNode), r = zl === null ? void 0 : zl.get(n), i = hi(t.default, r === void 0 ? t.exit : t.share);
			i !== "none" && (Wl(e, n, i, null, !1) ? r === void 0 ? Nd(e, t.onExit) : (i = e.stateNode, r.paired = i, i.paired = r, zl.delete(n), Nd(e, t.onShare)) : Kl(e.child, !1)), zl !== null && Yl(e);
		} else if (e.subtreeFlags & 33554432) for (e = e.child; e !== null;) Xl(e), e = e.sibling;
		else zl !== null && Yl(e);
	}
	function Zl(e) {
		for (e = e.child; e !== null;) {
			if (e.tag === 30) {
				var t = e.memoizedProps, n = pi(t, e.stateNode);
				t = hi(t.default, t.update), e.flags &= -5, t !== "none" && Wl(e, n, t, e.memoizedState = [], !1);
			} else e.subtreeFlags & 33554432 && Zl(e);
			e = e.sibling;
		}
	}
	function Ql(e) {
		if (e.subtreeFlags & 18874368) for (e = e.child; e !== null;) {
			if (e.tag !== 22 || e.memoizedState === null) {
				if (e.tag === 30 && e.flags & 18874368) {
					var t = e.stateNode;
					t.paired !== null && (t.paired = null, Kl(e.child, !1));
				}
				Ql(e);
			}
			e = e.sibling;
		}
	}
	function $l(e) {
		if (e.tag === 30) e.stateNode.paired = null, Kl(e.child, !1), Ql(e);
		else if (e.subtreeFlags & 33554432) for (e = e.child; e !== null;) $l(e), e = e.sibling;
		else Ql(e);
	}
	function eu(e) {
		for (e = e.child; e !== null;) e.tag === 30 ? Kl(e.child, !1) : e.subtreeFlags & 33554432 && eu(e), e = e.sibling;
	}
	function tu(e, t, n, r, i, a, o) {
		for (var s = !1; t !== null;) {
			if (t.tag === 5) {
				var c = t.stateNode;
				if (a !== null && Ul < a.length) {
					var l = a[Ul], u = Op(c);
					(l.view || u.view) && (s = !0);
					var d;
					if (d = !(e.flags & 4)) {
						if (u.clip) d = !0;
						else {
							d = l.rect;
							var f = u.rect;
							d = d.y !== f.y || d.x !== f.x || d.height !== f.height || d.width !== f.width;
						}
					}
					d && (e.flags |= 4), u.abs ? u = !l.abs : (l = l.rect, u = u.rect, u = l.height !== u.height || l.width !== u.width), u && (e.flags |= 32);
				} else e.flags |= 32;
				e.flags & 4 && Tp(c, Ul === 0 ? n : n + "_" + Ul, i), s && e.flags & 4 || (Vl === null && (Vl = []), Vl.push(c, Ul === 0 ? r : r + "_" + Ul, t.memoizedProps)), Ul++;
			} else (t.tag !== 22 || t.memoizedState === null) && (t.tag === 30 && o ? e.flags |= t.flags & 32 : tu(e, t.child, n, r, i, a, o) && (s = !0));
			t = t.sibling;
		}
		return s;
	}
	function nu(e, t) {
		for (e = e.child; e !== null;) {
			if (e.tag === 30) {
				var n = e.memoizedProps, r = e.stateNode, i = pi(n, r), a = hi(n.default, n.update);
				if (t) {
					r = r.clones;
					var o = r === null ? null : r.map(kp);
				} else o = e.memoizedState, e.memoizedState = null;
				r = e;
				var s = e.child;
				Ul = 0, i = tu(r, s, i, i, a, o, !1), e.flags & 4 && i && (t || Nd(e, n.onUpdate));
			} else e.subtreeFlags & 33554432 && nu(e, t);
			e = e.sibling;
		}
	}
	var ru = !1, K = !1, iu = !1, au = !1, ou = typeof WeakSet == "function" ? WeakSet : Set, su = null, cu = !1, lu = !1, uu = !1, du = !1;
	function fu(e, t, n) {
		if (e = e.containerInfo, sp = gh, e = Ur(e), Wr(e)) {
			if ("selectionStart" in e) var r = {
				start: e.selectionStart,
				end: e.selectionEnd
			};
			else a: {
				r = (r = e.ownerDocument) && r.defaultView || window;
				var i = r.getSelection && r.getSelection();
				if (i && i.rangeCount !== 0) {
					r = i.anchorNode;
					var a = i.anchorOffset, o = i.focusNode;
					i = i.focusOffset;
					try {
						r.nodeType, o.nodeType;
					} catch {
						r = null;
						break a;
					}
					var s = 0, c = -1, l = -1, u = 0, d = 0, f = e, p = null;
					b: for (;;) {
						for (var m; f !== r || a !== 0 && f.nodeType !== 3 || (c = s + a), f !== o || i !== 0 && f.nodeType !== 3 || (l = s + i), f.nodeType === 3 && (s += f.nodeValue.length), (m = f.firstChild) !== null;) p = f, f = m;
						for (;;) {
							if (f === e) break b;
							if (p === r && ++u === a && (c = s), p === o && ++d === i && (l = s), (m = f.nextSibling) !== null) break;
							f = p, p = f.parentNode;
						}
						f = m;
					}
					r = c === -1 || l === -1 ? null : {
						start: c,
						end: l
					};
				} else r = null;
			}
			r ||= {
				start: 0,
				end: 0
			};
		} else r = null;
		for (cp = {
			focusedElem: e,
			selectionRange: r
		}, gh = !1, n = (n & 335544064) === n, su = t, t = n ? 9270 : 1024; su !== null;) {
			if (e = su, n && (r = e.deletions, r !== null)) for (a = 0; a < r.length; a++) n && Xl(r[a]);
			if (e.alternate === null && e.flags & 2) n && Bl(e), pu(n);
			else {
				if (e.tag === 22) {
					if (r = e.alternate, e.memoizedState !== null) {
						r !== null && r.memoizedState === null && n && Xl(r), pu(n);
						continue;
					}
					if (r !== null && r.memoizedState !== null) {
						n && Bl(e), pu(n);
						continue;
					}
				}
				r = e.child, (e.subtreeFlags & t) !== 0 && r !== null ? (r.return = e, su = r) : (n && Zl(e), pu(n));
			}
		}
		zl = null;
	}
	function pu(e) {
		for (; su !== null;) {
			var t = su, n = e, r = t.alternate, a = t.flags;
			switch (t.tag) {
				case 0:
				case 11:
				case 15: break;
				case 1:
					if (a & 1024 && r !== null) {
						n = void 0, a = r.memoizedProps, r = r.memoizedState;
						var o = t.stateNode;
						try {
							var s = bc(t.type, a);
							n = o.getSnapshotBeforeUpdate(s, r), o.__reactInternalSnapshotBeforeUpdate = n;
						} catch (e) {
							Z(t, t.return, e);
						}
					}
					break;
				case 3:
					if (a & 1024) {
						if (r = t.stateNode.containerInfo, n = r.nodeType, n === 9) nm(r);
						else if (n === 1) switch (r.nodeName) {
							case "HEAD":
							case "HTML":
							case "BODY":
								nm(r);
								break;
							default: r.textContent = "";
						}
					}
					break;
				case 5:
				case 26:
				case 27:
				case 6:
				case 4:
				case 17: break;
				case 30:
					n && r !== null && (n = pi(r.memoizedProps, r.stateNode), a = t.memoizedProps, a = hi(a.default, a.update), a !== "none" && Wl(r, n, a, r.memoizedState = [], !0));
					break;
				default: if (a & 1024) throw Error(i(163));
			}
			if (r = t.sibling, r !== null) {
				r.return = t.return, su = r;
				break;
			}
			su = t.return;
		}
	}
	function mu(e, t, n) {
		var r = n.flags;
		switch (n.tag) {
			case 0:
			case 11:
			case 15:
				Pu(e, n), r & 4 && bl(5, n);
				break;
			case 1:
				if (Pu(e, n), r & 4) {
					if (e = n.stateNode, t === null) try {
						e.componentDidMount();
					} catch (e) {
						Z(n, n.return, e);
					}
					else {
						var i = bc(n.type, t.memoizedProps);
						t = t.memoizedState;
						try {
							e.componentDidUpdate(i, t, e.__reactInternalSnapshotBeforeUpdate);
						} catch (e) {
							Z(n, n.return, e);
						}
					}
				}
				r & 64 && Sl(n), r & 512 && wl(n, n.return);
				break;
			case 3:
				if (Pu(e, n), r & 64 && (e = n.updateQueue, e !== null)) {
					if (t = null, n.child !== null) switch (n.child.tag) {
						case 27:
						case 5:
							t = n.child.stateNode;
							break;
						case 1: t = n.child.stateNode;
					}
					try {
						xo(e, t);
					} catch (e) {
						Z(n, n.return, e);
					}
				}
				break;
			case 27: t === null && r & 4 && Ll(n);
			case 26:
			case 5:
				Pu(e, n), t === null && r & 4 && jl(n), r & 512 && wl(n, n.return);
				break;
			case 12:
				Pu(e, n);
				break;
			case 31:
				Pu(e, n), r & 4 && Cu(e, n);
				break;
			case 13:
				Pu(e, n), r & 4 && wu(e, n), r & 64 && (e = n.memoizedState, e !== null && (e = e.dehydrated, e !== null && (n = _f.bind(null, n), cm(e, n))));
				break;
			case 22:
				if (r = n.memoizedState !== null || ru, !r) {
					var a = t !== null && t.memoizedState !== null || K;
					t = ru, i = K, ru = r, (K = a) && !i ? (r = 2, n.subtreeFlags & 8772 && (r |= 1), Iu(e, n, r)) : Pu(e, n), ru = t, K = i;
				}
				break;
			case 30:
				Pu(e, n), r & 512 && wl(n, n.return);
				break;
			case 7: r & 512 && wl(n, n.return);
			default: Pu(e, n);
		}
	}
	function hu(e, t) {
		for (e = e.child; e !== null;) gu(e, t), e = e.sibling;
	}
	function gu(e, t) {
		switch (e.tag) {
			case 5:
			case 26:
				try {
					var n = e.stateNode;
					if (t) {
						var r = n.style;
						typeof r.setProperty == "function" ? r.setProperty("display", "none", "important") : r.display = "none";
					} else {
						var i = e.stateNode, a = e.memoizedProps.style, o = a != null && a.hasOwnProperty("display") ? a.display : null;
						i.style.display = o == null || typeof o == "boolean" ? "" : ("" + o).trim();
					}
				} catch (t) {
					Z(e, e.return, t);
				}
				_u(e, t);
				break;
			case 6:
				try {
					e.stateNode.nodeValue = t ? "" : e.memoizedProps, H = !0;
				} catch (t) {
					Z(e, e.return, t);
				}
				break;
			case 18:
				try {
					var s = e.stateNode;
					t ? wp(s, !0) : wp(e.stateNode, !1);
				} catch (t) {
					Z(e, e.return, t);
				}
				break;
			case 22:
			case 23:
				e.memoizedState === null && hu(e, t);
				break;
			default: hu(e, t);
		}
	}
	function _u(e, t) {
		if (e.subtreeFlags & 67108864) for (e = e.child; e !== null;) {
			a: {
				var n = e, r = t;
				switch (n.tag) {
					case 4:
						gu(n, r);
						break a;
					case 22:
						n.memoizedState === null && _u(n, r);
						break a;
					default: _u(n, r);
				}
			}
			e = e.sibling;
		}
	}
	function vu(e) {
		var t = e.alternate;
		t !== null && (e.alternate = null, vu(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && kt(t)), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
	}
	var yu = null, bu = !1;
	function xu(e, t, n) {
		for (n = n.child; n !== null;) Su(e, t, n), n = n.sibling;
	}
	function Su(e, t, n) {
		if (Qe && typeof Qe.onCommitFiberUnmount == "function") try {
			Qe.onCommitFiberUnmount(Ze, n);
		} catch {}
		switch (n.tag) {
			case 26:
				K || Tl(n, t), xu(e, t, n), n.memoizedState ? n.memoizedState.count-- : n.stateNode && !K && (n = n.stateNode, n.parentNode.removeChild(n));
				break;
			case 27:
				K || Tl(n, t), Ol(n);
				var r = yu, i = bu;
				Sp(n.type) && (yu = n.stateNode, bu = !1), xu(e, t, n), gm(n.stateNode, n.type, n.memoizedProps), yu = r, bu = i;
				break;
			case 5: K || Tl(n, t), Ol(n);
			case 6:
				if (n.tag === 6 && Ol(n), r = yu, i = bu, yu = null, xu(e, t, n), yu = r, bu = i, yu !== null) {
					if (bu) try {
						(yu.nodeType === 9 ? yu.body : yu.nodeName === "HTML" ? yu.ownerDocument.body : yu).removeChild(n.stateNode), H = !0;
					} catch (e) {
						Z(n, t, e);
					}
					else try {
						yu.removeChild(n.stateNode), H = !0;
					} catch (e) {
						Z(n, t, e);
					}
				}
				break;
			case 18:
				yu !== null && (bu ? (e = yu, Cp(e.nodeType === 9 ? e.body : e.nodeName === "HTML" ? e.ownerDocument.body : e, n.stateNode), Hh(e)) : Cp(yu, n.stateNode));
				break;
			case 4:
				r = yu, i = bu, yu = n.stateNode.containerInfo, bu = !0, xu(e, t, n), yu = r, bu = i;
				break;
			case 0:
			case 11:
			case 14:
			case 15:
				xl(2, n, t), K || xl(4, n, t), xu(e, t, n);
				break;
			case 1:
				K || (Tl(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function" && Cl(n, t, r)), xu(e, t, n);
				break;
			case 21:
				xu(e, t, n);
				break;
			case 22:
				K = (r = K) || n.memoizedState !== null, xu(e, t, n), K = r;
				break;
			case 30:
				Tl(n, t), xu(e, t, n);
				break;
			case 7:
				K || Tl(n, t), xu(e, t, n);
				break;
			default: xu(e, t, n);
		}
	}
	function Cu(e, t) {
		if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null))) {
			e = e.dehydrated;
			try {
				Hh(e);
			} catch (e) {
				Z(t, t.return, e);
			}
		}
	}
	function wu(e, t) {
		if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null && (e = e.dehydrated, e !== null)))) try {
			Hh(e);
		} catch (e) {
			Z(t, t.return, e);
		}
	}
	function Tu(e) {
		switch (e.tag) {
			case 31:
			case 13:
			case 19:
				var t = e.stateNode;
				return t === null && (t = e.stateNode = new ou()), t;
			case 22: return e = e.stateNode, t = e._retryCache, t === null && (t = e._retryCache = new ou()), t;
			default: throw Error(i(435, e.tag));
		}
	}
	function Eu(e, t) {
		var n = Tu(e);
		t.forEach(function(t) {
			if (!n.has(t)) {
				n.add(t);
				var r = vf.bind(null, e, t);
				t.then(r, r);
			}
		});
	}
	function Du(e, t, n) {
		var r = t.deletions;
		if (r !== null) for (var a = 0; a < r.length; a++) {
			var o = r[a], s = e, c = t, l = c;
			a: for (; l !== null;) {
				switch (l.tag) {
					case 27:
						if (Sp(l.type)) {
							yu = l.stateNode, bu = !1;
							break a;
						}
						break;
					case 5:
						yu = l.stateNode, bu = !1;
						break a;
					case 3:
					case 4:
						yu = l.stateNode.containerInfo, bu = !0;
						break a;
				}
				l = l.return;
			}
			if (yu === null) throw Error(i(160));
			Su(s, c, o), yu = null, bu = !1, s = o.alternate, s !== null && (s.return = null), o.return = null;
		}
		if (t.subtreeFlags & 13886) for (t = t.child; t !== null;) ku(t, e, n), t = t.sibling;
	}
	var Ou = null;
	function ku(e, t, n) {
		var r = e.alternate, a = e.flags;
		switch (e.tag) {
			case 0:
			case 11:
			case 14:
			case 15:
				if (a & 4 && (r = e.updateQueue, r = r === null ? null : r.events, r !== null)) for (var o = 0; o < r.length; o++) {
					var s = r[o];
					s.ref.impl = s.nextImpl;
				}
				Du(t, e, n), Au(e), a & 4 && (xl(3, e, e.return), bl(3, e), xl(5, e, e.return));
				break;
			case 1:
				Du(t, e, n), Au(e), a & 512 && (K || r === null || Tl(r, r.return)), a & 64 && ru && (e = e.updateQueue, e !== null && (t = e.callbacks, t !== null && (n = e.shared.hiddenCallbacks, e.shared.hiddenCallbacks = n === null ? t : n.concat(t))));
				break;
			case 26:
				if (o = Ou, Du(t, e, n), Au(e), a & 512 && (K || r === null || Tl(r, r.return)), a & 4) {
					if (a = r === null ? null : r.memoizedState, n = e.memoizedState, r === null) {
						if (n === null) {
							if (e.stateNode === null) {
								if (ru) e.stateNode = fp(e.type, e.memoizedProps, t.containerInfo, e);
								else {
									a: {
										t = e.type, n = e.memoizedProps, a = o.ownerDocument || o;
										b: switch (t) {
											case "title":
												r = a.getElementsByTagName("title")[0], (!r || r[Dt] || r[B] || r.namespaceURI === "http://www.w3.org/2000/svg" || r.hasAttribute("itemprop")) && (r = a.createElement(t), a.head.insertBefore(r, a.querySelector("head > title"))), np(r, t, n), r[B] = e, V(r), t = r;
												break a;
											case "link":
												if (o = Gm("link", "href", a).get(t + (n.href || ""))) {
													for (s = 0; s < o.length; s++) if (r = o[s], r.getAttribute("href") === (n.href == null || n.href === "" ? null : n.href) && r.getAttribute("rel") === (n.rel == null ? null : n.rel) && r.getAttribute("title") === (n.title == null ? null : n.title) && r.getAttribute("crossorigin") === (n.crossOrigin == null ? null : n.crossOrigin)) {
														o.splice(s, 1);
														break b;
													}
												}
												r = a.createElement(t), np(r, t, n), a.head.appendChild(r);
												break;
											case "meta":
												if (o = Gm("meta", "content", a).get(t + (n.content || ""))) {
													for (s = 0; s < o.length; s++) if (r = o[s], r.getAttribute("content") === (n.content == null ? null : "" + n.content) && r.getAttribute("name") === (n.name == null ? null : n.name) && r.getAttribute("property") === (n.property == null ? null : n.property) && r.getAttribute("http-equiv") === (n.httpEquiv == null ? null : n.httpEquiv) && r.getAttribute("charset") === (n.charSet == null ? null : n.charSet)) {
														o.splice(s, 1);
														break b;
													}
												}
												r = a.createElement(t), np(r, t, n), a.head.appendChild(r);
												break;
											default: throw Error(i(468, t));
										}
										r[B] = e, V(r), t = r;
									}
									e.stateNode = t;
								}
							} else ru || Km(o, e.type, e.stateNode);
						} else e.stateNode = Bm(o, n, e.memoizedProps);
					} else a === n ? n === null && e.stateNode !== null && Ml(e, e.memoizedProps, r.memoizedProps) : (a === null ? (t = r.stateNode, t === null || K || t.parentNode.removeChild(t)) : a.count--, n === null ? ru || Km(o, e.type, e.stateNode) : Bm(o, n, e.memoizedProps));
				}
				break;
			case 27:
				Du(t, e, n), Au(e), a & 512 && (K || r === null || Tl(r, r.return)), r !== null && a & 4 && Ml(e, e.memoizedProps, r.memoizedProps);
				break;
			case 5:
				if (o = iu, iu = !1, Du(t, e, n), iu = o, Au(e), a & 512 && (K || r === null || Tl(r, r.return)), e.flags & 32) {
					t = e.stateNode;
					try {
						sn(t, ""), H = !0;
					} catch (t) {
						Z(e, e.return, t);
					}
				}
				a & 4 && e.stateNode != null && (t = e.memoizedProps, Ml(e, t, r === null ? t : r.memoizedProps)), a & 1024 && (au = !0);
				break;
			case 6:
				if (Du(t, e, n), Au(e), a & 4) {
					if (e.stateNode === null) throw Error(i(162));
					t = e.memoizedProps, n = e.stateNode;
					try {
						n.nodeValue = t, H = !0;
					} catch (t) {
						Z(e, e.return, t);
					}
				}
				break;
			case 3:
				if (H = !1, Wm = null, o = Ou, Ou = bm(t.containerInfo), Du(t, e, n), Ou = o, Au(e), a & 4 && r !== null && r.memoizedState.isDehydrated) try {
					Hh(t.containerInfo);
				} catch (t) {
					Z(e, e.return, t);
				}
				au && (au = !1, ju(e)), H = !1;
				break;
			case 4:
				a = iu, iu = ru, r = Ut(), o = Ou, Ou = bm(e.stateNode.containerInfo), Du(t, e, n), Au(e), Ou = o, H && lu && (uu = !0), H = r, iu = a;
				break;
			case 12:
				Du(t, e, n), Au(e);
				break;
			case 31:
				Du(t, e, n), Au(e), a & 4 && (t = e.updateQueue, t !== null && (e.updateQueue = null, Eu(e, t)));
				break;
			case 13:
				Du(t, e, n), Au(e), e.child.flags & 8192 && e.memoizedState !== null != (r !== null && r.memoizedState !== null) && (md = He()), a & 4 && (t = e.updateQueue, t !== null && (e.updateQueue = null, Eu(e, t)));
				break;
			case 22:
				o = e.memoizedState !== null, s = r !== null && r.memoizedState !== null;
				var c = ru, l = K, u = iu;
				ru = c || o, iu = u || o, K = l || s, Du(t, e, n), K = l, iu = u, ru = c, Au(e), a & 8192 && (t = e.stateNode, t._visibility = o ? t._visibility & -2 : t._visibility | 1, !o || r === null || s || ru || K || (t = s || K, n = ru, r = K, ru = o || ru, K = t, Fu(e, 2), ru = n, K = r), !o && iu || hu(e, o)), a & 4 && (t = e.updateQueue, t !== null && (n = t.retryQueue, n !== null && (t.retryQueue = null, Eu(e, n))));
				break;
			case 19:
				Du(t, e, n), Au(e), a & 4 && (t = e.updateQueue, t !== null && (e.updateQueue = null, Eu(e, t)));
				break;
			case 30:
				a & 512 && (K || r === null || Tl(r, r.return)), a = Ut(), o = lu, s = (n & 335544064) === n, c = e.memoizedProps, lu = s && hi(c.default, c.update) !== "none", Du(t, e, n), Au(e), s && r !== null && H && (e.flags |= 4), lu = o, H = a;
				break;
			case 21: break;
			case 7: a & 512 && (K || r === null || Tl(r, r.return)), r && r.stateNode !== null && (r.stateNode._fragmentFiber = e);
			default: Du(t, e, n), Au(e);
		}
	}
	function Au(e) {
		var t = e.flags;
		if (t & 2) {
			try {
				for (var n, r = e.return; r !== null;) {
					if (Nl(r)) {
						n = r;
						break;
					}
					r = r.return;
				}
				r = null;
				for (var a = e.return; a !== null;) {
					if (Al(a)) {
						var o = a.stateNode;
						r === null ? r = [o] : r.push(o);
					}
					if (kl(a)) break;
					a = a.return;
				}
				var s = r;
				if (n == null) throw Error(i(160));
				switch (n.tag) {
					case 27:
						var c = n.stateNode;
						Il(e, Pl(e), c, s);
						break;
					case 5:
						var l = n.stateNode;
						n.flags & 32 && (sn(l, ""), n.flags &= -33), Il(e, Pl(e), l, s);
						break;
					case 3:
					case 4:
						var u = n.stateNode.containerInfo;
						Fl(e, Pl(e), u, s);
						break;
					default: throw Error(i(161));
				}
			} catch (t) {
				Z(e, e.return, t);
			}
			e.flags &= -3;
		}
		t & 4096 && (e.flags &= -4097);
	}
	function ju(e) {
		if (e.subtreeFlags & 1024) for (e = e.child; e !== null;) {
			var t = e;
			ju(t), t.tag === 5 && t.flags & 1024 && (t = t.stateNode, gh = !0, t.reset(), gh = !1), e = e.sibling;
		}
	}
	function Mu(e, t) {
		if (t.subtreeFlags & 9270) for (t = t.child; t !== null;) Nu(t, e), t = t.sibling;
		else nu(t, !1);
	}
	function Nu(e, t) {
		var n = e.alternate;
		if (n === null) Jl(e, !1);
		else switch (e.tag) {
			case 3:
				if (du = cu = !1, Hl(), Mu(t, e), !cu && !uu) {
					if (e = Vl, e !== null) for (var r = 0; r < e.length; r += 3) {
						n = e[r];
						var i = e[r + 1];
						Ep(n, e[r + 2]), n = n.ownerDocument.documentElement, n !== null && n.animate({
							opacity: [0, 0],
							pointerEvents: ["none", "none"]
						}, {
							duration: 0,
							fill: "forwards",
							pseudoElement: "::view-transition-group(" + i + ")"
						});
					}
					e = t.containerInfo, e = e.nodeType === 9 ? e.documentElement : e.ownerDocument.documentElement, e !== null && e.style.viewTransitionName === "" && (e.style.viewTransitionName = "none", e.animate({
						opacity: [0, 0],
						pointerEvents: ["none", "none"]
					}, {
						duration: 0,
						fill: "forwards",
						pseudoElement: "::view-transition-group(root)"
					}), e.animate({
						width: [0, 0],
						height: [0, 0]
					}, {
						duration: 0,
						fill: "forwards",
						pseudoElement: "::view-transition"
					})), du = !0;
				}
				Vl = null;
				break;
			case 5:
				Mu(t, e);
				break;
			case 4:
				r = cu, cu = !1, Mu(t, e), cu && (uu = !0), cu = r;
				break;
			case 22:
				e.memoizedState === null && (n.memoizedState === null ? Mu(t, e) : Jl(e, !1));
				break;
			case 30:
				r = cu, i = Hl(), cu = !1, Mu(t, e), cu && (e.flags |= 4);
				var a = e.memoizedProps, o = e.stateNode;
				t = pi(a, o), o = pi(n.memoizedProps, o);
				var s = hi(a.default, a.update);
				s === "none" ? t = !1 : (a = n.memoizedState, n.memoizedState = null, n = e.child, Ul = 0, t = tu(e, n, t, o, s, a, !0), Ul !== (a === null ? 0 : a.length) && (e.flags |= 32)), e.flags & 4 && t ? (Nd(e, e.memoizedProps.onUpdate), Vl = i) : i !== null && (i.push.apply(i, Vl), Vl = i), cu = e.flags & 32 ? !0 : r;
				break;
			default: Mu(t, e);
		}
	}
	function Pu(e, t) {
		if (t.subtreeFlags & 8772) for (t = t.child; t !== null;) mu(e, t.alternate, t), t = t.sibling;
	}
	function Fu(e, t) {
		for (e = e.child; e !== null;) {
			var n = e, r = t;
			switch (n.tag) {
				case 0:
				case 11:
				case 14:
				case 15:
					xl(4, n, n.return), Fu(n, r);
					break;
				case 1:
					Tl(n, n.return);
					var i = n.stateNode;
					typeof i.componentWillUnmount == "function" && Cl(n, n.return, i), Fu(n, r);
					break;
				case 27: r & 2 && gm(n.stateNode, n.type, n.memoizedProps);
				case 5:
					Tl(n, n.return), n.tag !== 5 && n.tag !== 27 || Ol(n), Fu(n, r);
					break;
				case 6:
					Ol(n);
					break;
				case 26:
					Tl(n, n.return), i = n.stateNode, n.memoizedState !== null || i === null || K || i.parentNode.removeChild(i), Fu(n, r);
					break;
				case 22:
					n.memoizedState === null && Fu(n, r);
					break;
				case 30:
					Tl(n, n.return), Fu(n, r);
					break;
				case 7: Tl(n, n.return);
				default: Fu(n, r);
			}
			e = e.sibling;
		}
	}
	function Iu(e, t, n) {
		for (n = t.subtreeFlags & 8772 ? n : n & -2, t = t.child; t !== null;) {
			var r = t.alternate, i = e, a = t, o = a.flags, s = !!(n & 1);
			switch (a.tag) {
				case 0:
				case 11:
				case 15:
					Iu(i, a, n), bl(4, a);
					break;
				case 1:
					if (Iu(i, a, n), r = a, i = r.stateNode, typeof i.componentDidMount == "function") try {
						i.componentDidMount();
					} catch (e) {
						Z(r, r.return, e);
					}
					if (r = a, i = r.updateQueue, i !== null) {
						var c = r.stateNode;
						try {
							var l = i.shared.hiddenCallbacks;
							if (l !== null) for (i.shared.hiddenCallbacks = null, i = 0; i < l.length; i++) bo(l[i], c);
						} catch (e) {
							Z(r, r.return, e);
						}
					}
					s && o & 64 && Sl(a), wl(a, a.return);
					break;
				case 27: n & 2 && Ll(a);
				case 5:
					a.tag !== 5 && a.tag !== 27 || Dl(a), Iu(i, a, n), s && r === null && o & 4 && jl(a), wl(a, a.return);
					break;
				case 6:
					Dl(a);
					break;
				case 26:
					c = a.stateNode, a.memoizedState !== null || c === null || ru || Km(bm(c.ownerDocument), a.type, c), Iu(i, a, n), s && r === null && o & 4 && jl(a), wl(a, a.return);
					break;
				case 12:
					Iu(i, a, n);
					break;
				case 31:
					Iu(i, a, n), s && o & 4 && Cu(i, a);
					break;
				case 13:
					Iu(i, a, n), s && o & 4 && wu(i, a);
					break;
				case 22:
					a.memoizedState === null && Iu(i, a, n), wl(a, a.return);
					break;
				case 30:
					Iu(i, a, n), wl(a, a.return);
					break;
				case 7: wl(a, a.return);
				default: Iu(i, a, n);
			}
			t = t.sibling;
		}
	}
	function Lu(e, t) {
		var n = null;
		e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), e = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (e = t.memoizedState.cachePool.pool), e !== n && (e != null && e.refCount++, n != null && ka(n));
	}
	function Ru(e, t) {
		e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && ka(e));
	}
	function zu(e, t, n, r) {
		var i = (n & 335544064) === n;
		if (t.subtreeFlags & (i ? 10262 : 10256)) for (t = t.child; t !== null;) Bu(e, t, n, r), t = t.sibling;
		else i && eu(t);
	}
	function Bu(e, t, n, r) {
		var i = (n & 335544064) === n;
		i && t.alternate === null && t.return !== null && t.return.alternate !== null && $l(t);
		var a = t.flags;
		switch (t.tag) {
			case 0:
			case 11:
			case 15:
				zu(e, t, n, r), a & 2048 && bl(9, t);
				break;
			case 1:
				zu(e, t, n, r);
				break;
			case 3:
				zu(e, t, n, r), i && du && (e = e.containerInfo, e = e.nodeType === 9 ? e.body : e.nodeName === "HTML" ? e.ownerDocument.body : e, e.style.viewTransitionName === "root" && (e.style.viewTransitionName = ""), e = e.ownerDocument.documentElement, e !== null && e.style.viewTransitionName === "none" && (e.style.viewTransitionName = "")), a & 2048 && (a = null, t.alternate !== null && (a = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== a && (t.refCount++, a != null && ka(a)));
				break;
			case 12:
				if (a & 2048) {
					zu(e, t, n, r), a = t.stateNode;
					try {
						var o = t.memoizedProps, s = o.id, c = o.onPostCommit;
						typeof c == "function" && c(s, t.alternate === null ? "mount" : "update", a.passiveEffectDuration, -0);
					} catch (e) {
						Z(t, t.return, e);
					}
				} else zu(e, t, n, r);
				break;
			case 31:
				zu(e, t, n, r);
				break;
			case 13:
				zu(e, t, n, r);
				break;
			case 23: break;
			case 22:
				o = t.stateNode, s = t.alternate, t.memoizedState === null ? (i && s !== null && s.memoizedState !== null && $l(t), o._visibility & 2 ? zu(e, t, n, r) : (o._visibility |= 2, Vu(e, t, n, r, !!(t.subtreeFlags & 10256) || !1))) : (i && s !== null && s.memoizedState === null && $l(s), o._visibility & 2 ? zu(e, t, n, r) : Hu(e, t)), a & 2048 && Lu(s, t);
				break;
			case 24:
				zu(e, t, n, r), a & 2048 && Ru(t.alternate, t);
				break;
			case 30:
				i && (a = t.alternate, a !== null && (Kl(a.child, !0), Kl(t.child, !0))), zu(e, t, n, r);
				break;
			default: zu(e, t, n, r);
		}
	}
	function Vu(e, t, n, r, i) {
		for (i &&= !!(t.subtreeFlags & 10256) || !1, t = t.child; t !== null;) {
			var a = e, o = t, s = n, c = r, l = o.flags;
			switch (o.tag) {
				case 0:
				case 11:
				case 15:
					Vu(a, o, s, c, i), bl(8, o);
					break;
				case 23: break;
				case 22:
					var u = o.stateNode;
					o.memoizedState === null ? (u._visibility |= 2, Vu(a, o, s, c, i)) : u._visibility & 2 ? Vu(a, o, s, c, i) : Hu(a, o), i && l & 2048 && Lu(o.alternate, o);
					break;
				case 24:
					Vu(a, o, s, c, i), i && l & 2048 && Ru(o.alternate, o);
					break;
				default: Vu(a, o, s, c, i);
			}
			t = t.sibling;
		}
	}
	function Hu(e, t) {
		if (t.subtreeFlags & 10256) for (t = t.child; t !== null;) {
			var n = e, r = t, i = r.flags;
			switch (r.tag) {
				case 22:
					Hu(n, r), i & 2048 && Lu(r.alternate, r);
					break;
				case 24:
					Hu(n, r), i & 2048 && Ru(r.alternate, r);
					break;
				default: Hu(n, r);
			}
			t = t.sibling;
		}
	}
	var Uu = 8192;
	function Wu(e, t, n) {
		if (e.subtreeFlags & Uu) for (e = e.child; e !== null;) Gu(e, t, n), e = e.sibling;
	}
	function Gu(e, t, n) {
		switch (e.tag) {
			case 26:
				Wu(e, t, n), e.flags & Uu && (e.memoizedState === null ? (e = e.stateNode, (t & 335544128) === t && Zm(n, e)) : Qm(n, Ou, e.memoizedState, e.memoizedProps));
				break;
			case 5:
				Wu(e, t, n), e.flags & Uu && (e = e.stateNode, (t & 335544128) === t && Zm(n, e));
				break;
			case 3:
			case 4:
				var r = Ou;
				Ou = bm(e.stateNode.containerInfo), Wu(e, t, n), Ou = r;
				break;
			case 22:
				e.memoizedState === null && (r = e.alternate, r !== null && r.memoizedState !== null ? (r = Uu, Uu = 16777216, Wu(e, t, n), Uu = r) : Wu(e, t, n));
				break;
			case 30:
				if ((e.flags & Uu) !== 0 && (r = e.memoizedProps.name, r != null && r !== "auto")) {
					var i = e.stateNode;
					i.paired = null, zl === null && (zl = /* @__PURE__ */ new Map()), zl.set(r, i);
				}
				Wu(e, t, n);
				break;
			default: Wu(e, t, n);
		}
	}
	function Ku(e) {
		var t = e.alternate;
		if (t !== null && (e = t.child, e !== null)) {
			t.child = null;
			do
				t = e.sibling, e.sibling = null, e = t;
			while (e !== null);
		}
	}
	function qu(e) {
		var t = e.deletions;
		if (e.flags & 16) {
			if (t !== null) for (var n = 0; n < t.length; n++) {
				var r = t[n];
				su = r, Xu(r, e);
			}
			Ku(e);
		}
		if (e.subtreeFlags & 10256) for (e = e.child; e !== null;) Ju(e), e = e.sibling;
	}
	function Ju(e) {
		switch (e.tag) {
			case 0:
			case 11:
			case 15:
				qu(e), e.flags & 2048 && xl(9, e, e.return);
				break;
			case 3:
				qu(e);
				break;
			case 12:
				qu(e);
				break;
			case 22:
				var t = e.stateNode;
				e.memoizedState !== null && t._visibility & 2 && (e.return === null || e.return.tag !== 13) ? (t._visibility &= -3, Yu(e)) : qu(e);
				break;
			default: qu(e);
		}
	}
	function Yu(e) {
		var t = e.deletions;
		if (e.flags & 16) {
			if (t !== null) for (var n = 0; n < t.length; n++) {
				var r = t[n];
				su = r, Xu(r, e);
			}
			Ku(e);
		}
		for (e = e.child; e !== null;) {
			switch (t = e, t.tag) {
				case 0:
				case 11:
				case 15:
					xl(8, t, t.return), Yu(t);
					break;
				case 22:
					n = t.stateNode, n._visibility & 2 && (n._visibility &= -3, Yu(t));
					break;
				default: Yu(t);
			}
			e = e.sibling;
		}
	}
	function Xu(e, t) {
		for (; su !== null;) {
			var n = su;
			switch (n.tag) {
				case 0:
				case 11:
				case 15:
					xl(8, n, t);
					break;
				case 23:
				case 22:
					if (n.memoizedState !== null && n.memoizedState.cachePool !== null) {
						var r = n.memoizedState.cachePool.pool;
						r != null && r.refCount++;
					}
					break;
				case 24: ka(n.memoizedState.cache);
			}
			if (r = n.child, r !== null) r.return = n, su = r;
			else a: for (n = e; su !== null;) {
				r = su;
				var i = r.sibling, a = r.return;
				if (vu(r), r === n) {
					su = null;
					break a;
				}
				if (i !== null) {
					i.return = a, su = i;
					break a;
				}
				su = a;
			}
		}
	}
	var Zu = {
		getCacheForType: function(e) {
			var t = xa(Da), n = t.data.get(e);
			return n === void 0 && (n = e(), t.data.set(e, n)), n;
		},
		cacheSignal: function() {
			return xa(Da).controller.signal;
		}
	}, Qu = typeof WeakMap == "function" ? WeakMap : Map, q = 0, $u = null, J = null, Y = 0, X = 0, ed = null, td = !1, nd = !1, rd = !1, id = 0, ad = 0, od = 0, sd = 0, cd = 0, ld = 0, ud = 0, dd = null, fd = null, pd = !1, md = 0, hd = 0, gd = Infinity, _d = null, vd = null, yd = 0, bd = null, xd = null, Sd = 0, Cd = 0, wd = null, Td = null, Ed = null, Dd = null, Od = null, kd = 0, Ad = null;
	function jd() {
		return q & 2 && Y !== 0 ? Y & -Y : M.T === null ? vt() : Pf();
	}
	function Md() {
		if (ld === 0) {
			if (!(Y & 536870912) || W) {
				var e = z;
				z <<= 1, !(z & 3932160) && (z = 262144), ld = e;
			} else ld = 536870912;
		}
		return e = Do.current, e !== null && (e.flags |= 32), ld;
	}
	function Nd(e, t) {
		if (t != null) {
			var n = e.stateNode, r = n.ref;
			r === null && (r = n.ref = Pp(pi(e.memoizedProps, n))), Dd === null && (Dd = []), Dd.push(t.bind(null, r));
		}
	}
	function Pd(e, t, n) {
		(e === $u && (X === 2 || X === 9) || e.cancelPendingCommit !== null) && (Vd(e, 0), Rd(e, Y, ld, !1)), dt(e, n), q & 2 && e === $u || (e === $u && (!(q & 2) && (sd |= n), ad === 4 && Rd(e, Y, ld, !1)), Ef(e));
	}
	function Fd(e, t, n) {
		if (q & 6) throw Error(i(327));
		var r = !n && !(t & 127) && (t & e.expiredLanes) === 0 || ot(e, t), a = r ? Yd(e, t) : qd(e, t, !0), o = r;
		do {
			if (a === 0) {
				nd && !r && Rd(e, t, 0, !1);
				break;
			}
			if (n = e.current.alternate, o && !Ld(n)) a = qd(e, t, !1), o = !1;
			else {
				if (a === 2) {
					if (o = t, e.errorRecoveryDisabledLanes & o) var s = 0;
					else s = e.pendingLanes & -536870913, s = s === 0 ? s & 536870912 ? 536870912 : 0 : s;
					if (s !== 0) {
						t = s;
						a: {
							var c = e;
							a = dd;
							var l = c.current.memoizedState.isDehydrated;
							if (l && (Vd(c, s).flags |= 256), s = qd(c, s, !1), s !== 2 && s !== 6) {
								if (rd && !l) {
									c.errorRecoveryDisabledLanes |= o, sd |= o, a = 4;
									break a;
								}
								o = fd, fd = a, o !== null && (fd === null ? fd = o : fd.push.apply(fd, o));
							}
							a = s;
						}
						if (o = !1, a !== 2) continue;
					}
				}
				if (a === 1) {
					Vd(e, 0), Rd(e, t, 0, !0);
					break;
				}
				a: {
					switch (r = e, o = a, o) {
						case 0:
						case 1: throw Error(i(345));
						case 4: if ((t & 4194048) !== t && (t & 62914560) !== t) break;
						case 6:
							Rd(r, t, ld, !td);
							break a;
						case 2:
							fd = null;
							break;
						case 3:
						case 5: break;
						default: throw Error(i(329));
					}
					if ((t & 62914560) === t && (a = md + 300 - He(), 10 < a)) {
						if (Rd(r, t, ld, !td), at(r, 0, !0) !== 0) break a;
						Sd = t, r.timeoutHandle = gp(Id.bind(null, r, n, fd, _d, pd, t, ld, sd, ud, td, o, "Throttled", -0, 0), a);
						break a;
					}
					Id(r, n, fd, _d, pd, t, ld, sd, ud, td, o, null, -0, 0);
				}
				break;
			}
		} while (1);
		Ef(e);
	}
	function Id(e, t, n, r, i, a, o, s, c, l, u, d, f, p) {
		e.timeoutHandle = -1;
		var m = t.subtreeFlags, h = (a & 335544064) === a;
		d = null, (h || m & 8192 || (m & 16785408) == 16785408) && (d = {
			stylesheets: null,
			count: 0,
			imgCount: 0,
			imgBytes: 0,
			suspenseyImages: [],
			waitingForImages: !0,
			waitingForViewTransition: !1,
			unsuspend: hn
		}, zl = null, Gu(t, a, d), h && (m = d, h = e.containerInfo, h = (h.nodeType === 9 ? h : h.ownerDocument).__reactViewTransition, h != null && (m.count++, m.waitingForViewTransition = !0, m = nh.bind(m), h.finished.then(m, m))), m = (a & 62914560) === a ? md - He() : (a & 4194048) === a ? hd - He() : 0, m = eh(d, m), m !== null) ? (Sd = a, e.cancelPendingCommit = m(nf.bind(null, e, t, a, n, r, i, o, s, c, l, u, d, null, f, p)), Rd(e, a, o, !l)) : nf(e, t, a, n, r, i, o, s, c, l, u, d);
	}
	function Ld(e) {
		for (var t = e;;) {
			var n = t.tag;
			if ((n === 0 || n === 11 || n === 15) && t.flags & 16384 && (n = t.updateQueue, n !== null && (n = n.stores, n !== null))) for (var r = 0; r < n.length; r++) {
				var i = n[r], a = i.getSnapshot;
				i = i.value;
				try {
					if (!Lr(a(), i)) return !1;
				} catch {
					return !1;
				}
			}
			if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
			else {
				if (t === e) break;
				for (; t.sibling === null;) {
					if (t.return === null || t.return === e) return !0;
					t = t.return;
				}
				t.sibling.return = t.return, t = t.sibling;
			}
		}
		return !0;
	}
	function Rd(e, t, n, r) {
		t = st(e, t), t &= ~cd, t &= ~sd, e.suspendedLanes |= t, e.pingedLanes &= ~t, r && (e.warmLanes |= t), r = e.expirationTimes;
		for (var i = t; 0 < i;) {
			var a = 31 - L(i), o = 1 << a;
			r[a] = -1, i &= ~o;
		}
		n !== 0 && pt(e, n, t);
	}
	function zd() {
		return q & 6 ? !0 : (Df(0, !1), !1);
	}
	function Bd() {
		if (J !== null) {
			if (X === 0) var e = J.return;
			else e = J, pa = fa = null, ns(e), to = null, no = 0, e = J;
			for (; e !== null;) yl(e.alternate, e), e = e.return;
			J = null;
		}
	}
	function Vd(e, t) {
		var n = e.timeoutHandle;
		return n !== -1 && (e.timeoutHandle = -1, _p(n)), n = e.cancelPendingCommit, n !== null && (e.cancelPendingCommit = null, n()), Sd = 0, Bd(), $u = e, J = n = Ai(e.current, null), Y = t, X = 0, ed = null, td = !1, nd = ot(e, t), rd = !1, ud = ld = cd = sd = od = ad = 0, fd = dd = null, pd = !1, id = st(e, t), bi(), n;
	}
	function Hd(e, t) {
		G = null, M.H = fc, t === Ga || t === qa ? (t = $a(), X = 3) : t === Ka ? (t = $a(), X = 4) : X = t === Ac ? 8 : typeof t == "object" && t && typeof t.then == "function" ? 6 : 1, ed = t, J === null && (ad = 1, wc(e, Ri(t, e.current)));
	}
	function Ud() {
		var e = Do.current;
		return e === null ? !0 : (Y & 4194048) === Y ? Oo === null : (Y & 62914560) === Y || Y & 536870912 ? e === Oo : !1;
	}
	function Wd() {
		var e = M.H;
		return M.H = fc, e === null ? fc : e;
	}
	function Gd() {
		var e = M.A;
		return M.A = Zu, e;
	}
	function Kd() {
		ad = 4, td || (Y & 4194048) !== Y && Do.current !== null || (nd = !0), !(od & 134217727) && !(sd & 134217727) || $u === null || Rd($u, Y, ld, !1);
	}
	function qd(e, t, n) {
		var r = q;
		q |= 2;
		var i = Wd(), a = Gd();
		($u !== e || Y !== t) && (_d = null, Vd(e, t)), t = !1;
		var o = ad;
		a: do
			try {
				if (X !== 0 && J !== null) {
					var s = J, c = ed;
					switch (X) {
						case 8:
							Bd(), o = 6;
							break a;
						case 3:
						case 2:
						case 9:
						case 6:
							Do.current === null && (t = !0);
							var l = X;
							if (X = 0, ed = null, $d(e, s, c, l), n && nd) {
								o = 0;
								break a;
							}
							break;
						default: l = X, X = 0, ed = null, $d(e, s, c, l);
					}
				}
				Jd(), o = ad;
				break;
			} catch (t) {
				Hd(e, t);
			}
		while (1);
		return t && e.shellSuspendCounter++, pa = fa = null, q = r, M.H = i, M.A = a, J === null && ($u = null, Y = 0, bi()), o;
	}
	function Jd() {
		for (; J !== null;) Zd(J);
	}
	function Yd(e, t) {
		var n = q;
		q |= 2;
		var r = Wd(), a = Gd();
		$u !== e || Y !== t ? (_d = null, gd = He() + 500, Vd(e, t)) : nd = ot(e, t);
		a: do
			try {
				if (X !== 0 && J !== null) {
					t = J;
					var o = ed;
					b: switch (X) {
						case 1:
							X = 0, ed = null, $d(e, t, o, 1);
							break;
						case 2:
						case 9:
							if (Ya(o)) {
								X = 0, ed = null, Qd(t);
								break;
							}
							t = function() {
								X !== 2 && X !== 9 || $u !== e || (X = 7), Ef(e);
							}, o.then(t, t);
							break a;
						case 3:
							X = 7;
							break a;
						case 4:
							X = 5;
							break a;
						case 7:
							Ya(o) ? (X = 0, ed = null, Qd(t)) : (X = 0, ed = null, $d(e, t, o, 7));
							break;
						case 5:
							var s = null;
							switch (J.tag) {
								case 26: s = J.memoizedState;
								case 5:
								case 27:
									var c = J;
									if (s ? Ym(s) : c.stateNode.complete) {
										X = 0, ed = null;
										var l = c.sibling;
										if (l !== null) J = l;
										else {
											var u = c.return;
											u === null ? J = null : (J = u, ef(u));
										}
										break b;
									}
							}
							X = 0, ed = null, $d(e, t, o, 5);
							break;
						case 6:
							X = 0, ed = null, $d(e, t, o, 6);
							break;
						case 8:
							Bd(), ad = 6;
							break a;
						default: throw Error(i(462));
					}
				}
				Xd();
				break;
			} catch (t) {
				Hd(e, t);
			}
		while (1);
		return pa = fa = null, M.H = r, M.A = a, q = n, J === null ? ($u = null, Y = 0, bi(), ad) : 0;
	}
	function Xd() {
		for (; J !== null && !Be();) Zd(J);
	}
	function Zd(e) {
		var t = ul(e.alternate, e, id);
		e.memoizedProps = e.pendingProps, t === null ? ef(e) : J = t;
	}
	function Qd(e) {
		var t = e, n = t.alternate;
		switch (t.tag) {
			case 15:
			case 0:
				t = Wc(n, t, t.pendingProps, t.type, void 0, Y);
				break;
			case 11:
				t = Wc(n, t, t.pendingProps, t.type.render, t.ref, Y);
				break;
			case 5:
				ns(t);
				var r = t;
				r === $i && (W ? (oa(r), r.tag === 5 && r.stateNode != null && (ea = r.stateNode)) : (oa(r), W = !0));
			default: yl(n, t), t = J = ji(t, id), t = ul(n, t, id);
		}
		e.memoizedProps = e.pendingProps, t === null ? ef(e) : J = t;
	}
	function $d(e, t, n, r) {
		pa = fa = null, ns(t), to = null, no = 0;
		var i = t.return;
		try {
			if (kc(e, i, t, n, Y)) {
				ad = 1, wc(e, Ri(n, e.current)), J = null;
				return;
			}
		} catch (t) {
			if (i !== null) throw J = i, t;
			ad = 1, wc(e, Ri(n, e.current)), J = null;
			return;
		}
		t.flags & 32768 ? (W || r === 1 ? e = !0 : nd || Y & 536870912 ? e = !1 : (td = e = !0, (r === 2 || r === 9 || r === 3 || r === 6) && (r = Do.current, r !== null && r.tag === 13 && (r.flags |= 16384))), tf(t, e)) : ef(t);
	}
	function ef(e) {
		var t = e;
		do {
			if (t.flags & 32768) {
				tf(t, td);
				return;
			}
			e = t.return;
			var n = _l(t.alternate, t, id);
			if (n !== null) {
				J = n;
				return;
			}
			if (t = t.sibling, t !== null) {
				J = t;
				return;
			}
			J = t = e;
		} while (t !== null);
		ad === 0 && (ad = 5);
	}
	function tf(e, t) {
		do {
			var n = vl(e.alternate, e);
			if (n !== null) {
				n.flags &= 32767, J = n;
				return;
			}
			if (n = e.return, n !== null && (n.flags |= 32768, n.subtreeFlags = 0, n.deletions = null), !t && (e = e.sibling, e !== null)) {
				J = e;
				return;
			}
			J = e = n;
		} while (e !== null);
		ad = 6, J = null;
	}
	function nf(e, t, n, r, a, o, s, c, l, u, d, f) {
		e.cancelPendingCommit = null;
		do
			df();
		while (yd !== 0);
		if (q & 6) throw Error(i(327));
		if (t !== null) {
			if (t === e.current) throw Error(i(177));
			e === $u && (J = $u = null, Y = 0), xd = t, bd = e, Sd = n, wd = a, Td = r, rf(e, t, n, s, c, l, f);
		}
	}
	function rf(e, t, n, r, i, a, o) {
		var s = t.lanes | t.childLanes;
		if (Cd = s, s |= yi, ft(e, n, s, r, i, a), Dd = null, (n & 335544064) === n ? (Od = Ma(e), r = 10262) : (Od = null, r = 10256), (t.subtreeFlags & r) !== 0 || (t.flags & r) !== 0 ? (e.callbackNode = null, e.callbackPriority = 0, yf(Ke, function() {
			return ff(), null;
		})) : (e.callbackNode = null, e.callbackPriority = 0), Rl = !1, r = !!(t.flags & 13878), t.subtreeFlags & 13878 || r) {
			r = M.T, M.T = null, i = N.p, N.p = 2, a = q, q |= 4;
			try {
				fu(e, t, n);
			} finally {
				q = a, N.p = i, M.T = r;
			}
		}
		yd = 1, Rl ? Ed = Mp(o, e.containerInfo, Od, sf, cf, of, lf, ff, af, null, null) : (sf(), cf(), lf());
	}
	function af(e) {
		if (yd !== 0) {
			var t = bd.onRecoverableError;
			t(e, { componentStack: null });
		}
	}
	function of() {
		yd === 3 && (yd = 0, Nu(xd, bd), yd = 4);
	}
	function sf() {
		if (yd === 1) {
			yd = 0;
			var e = bd, t = xd, n = Sd, r = !!(t.flags & 13878);
			if (t.subtreeFlags & 13878 || r) {
				r = M.T, M.T = null;
				var i = N.p;
				N.p = 2;
				var a = q;
				q |= 4;
				try {
					lu = uu = !1, ku(t, e, n), n = cp;
					var o = Ur(e.containerInfo), s = n.focusedElem, c = n.selectionRange;
					if (o !== s && s && s.ownerDocument && Hr(s.ownerDocument.documentElement, s)) {
						if (c !== null && Wr(s)) {
							var l = c.start, u = c.end;
							if (u === void 0 && (u = l), "selectionStart" in s) s.selectionStart = l, s.selectionEnd = Math.min(u, s.value.length);
							else {
								var d = s.ownerDocument || document, f = d && d.defaultView || window;
								if (f.getSelection) {
									var p = f.getSelection(), m = s.textContent.length, h = Math.min(c.start, m), g = c.end === void 0 ? h : Math.min(c.end, m);
									!p.extend && h > g && (o = g, g = h, h = o);
									var _ = Vr(s, h), v = Vr(s, g);
									if (_ && v && (p.rangeCount !== 1 || p.anchorNode !== _.node || p.anchorOffset !== _.offset || p.focusNode !== v.node || p.focusOffset !== v.offset)) {
										var y = d.createRange();
										y.setStart(_.node, _.offset), p.removeAllRanges(), h > g ? (p.addRange(y), p.extend(v.node, v.offset)) : (y.setEnd(v.node, v.offset), p.addRange(y));
									}
								}
							}
						}
						for (d = [], p = s; p = p.parentNode;) p.nodeType === 1 && d.push({
							element: p,
							left: p.scrollLeft,
							top: p.scrollTop
						});
						for (typeof s.focus == "function" && s.focus(), s = 0; s < d.length; s++) {
							var b = d[s];
							b.element.scrollLeft = b.left, b.element.scrollTop = b.top;
						}
					}
					gh = !!sp, cp = sp = null;
				} finally {
					q = a, N.p = i, M.T = r;
				}
			}
			e.current = t, yd = 2;
		}
	}
	function cf() {
		if (yd === 2) {
			yd = 0;
			var e = bd, t = xd, n = !!(t.flags & 8772);
			if (t.subtreeFlags & 8772 || n) {
				n = M.T, M.T = null;
				var r = N.p;
				N.p = 2;
				var i = q;
				q |= 4;
				try {
					mu(e, t.alternate, t);
				} finally {
					q = i, N.p = r, M.T = n;
				}
			}
			yd = 3;
		}
	}
	function lf() {
		if (yd === 4 || yd === 3) {
			yd = 0;
			var e = Ed;
			Ed = null, Ve();
			var t = bd, n = xd, r = Sd, i = Td, a = (r & 335544064) === r ? 10262 : 10256;
			if ((n.subtreeFlags & a) !== 0 || (n.flags & a) !== 0 ? yd = 5 : (yd = 0, xd = bd = null, uf(t, t.pendingLanes)), a = t.pendingLanes, a === 0 && (vd = null), _t(r), n = n.stateNode, Qe && typeof Qe.onCommitFiberRoot == "function") try {
				Qe.onCommitFiberRoot(Ze, n, void 0, (n.current.flags & 128) == 128);
			} catch {}
			if (i !== null) {
				n = M.T, a = N.p, N.p = 2, M.T = null;
				try {
					for (var o = t.onRecoverableError, s = 0; s < i.length; s++) {
						var c = i[s];
						o(c.value, { componentStack: c.stack });
					}
				} finally {
					M.T = n, N.p = a;
				}
			}
			if (i = Dd, o = Od, Od = null, i !== null && (Dd = null, o === null && (o = []), e !== null)) for (c = 0; c < i.length; c++) n = (0, i[c])(o), n !== void 0 && e.finished.finally(n);
			Sd & 3 && df(), Ef(t), a = t.pendingLanes, r & 261930 && a & 42 ? t === Ad ? kd++ : (kd = 0, Ad = t) : (kd = 0, Ad = null), Df(0, !1);
		}
	}
	function uf(e, t) {
		(e.pooledCacheLanes &= t) === 0 && (t = e.pooledCache, t != null && (e.pooledCache = null, ka(t)));
	}
	function df() {
		return Ed !== null && (Ed.skipTransition(), Ed = null), sf(), cf(), lf(), ff();
	}
	function ff() {
		if (yd !== 5) return !1;
		var e = bd, t = Cd;
		Cd = 0;
		var n = _t(Sd), r = M.T, a = N.p;
		try {
			N.p = 32 > n ? 32 : n, M.T = null, n = wd, wd = null;
			var o = bd, s = Sd;
			if (yd = 0, xd = bd = null, Sd = 0, q & 6) throw Error(i(331));
			var c = q;
			if (q |= 4, Ju(o.current), Bu(o, o.current, s, n), q = c, Df(0, !1), Qe && typeof Qe.onPostCommitFiberRoot == "function") try {
				Qe.onPostCommitFiberRoot(Ze, o);
			} catch {}
			return !0;
		} finally {
			N.p = a, M.T = r, uf(e, t);
		}
	}
	function pf(e, t, n) {
		t = Ri(n, t), t = Ec(e.stateNode, t, 2), e = mo(e, t, 2), e !== null && (dt(e, 2), Ef(e));
	}
	function Z(e, t, n) {
		if (e.tag === 3) pf(e, e, n);
		else for (; t !== null;) {
			if (t.tag === 3) {
				pf(t, e, n);
				break;
			}
			if (t.tag === 1) {
				var r = t.stateNode;
				if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (vd === null || !vd.has(r))) {
					e = Ri(n, e), n = Dc(2), r = mo(t, n, 2), r !== null && (Oc(n, r, t, e), dt(r, 2), Ef(r));
					break;
				}
			}
			t = t.return;
		}
	}
	function mf(e, t, n) {
		var r = e.pingCache;
		if (r === null) {
			r = e.pingCache = new Qu();
			var i = /* @__PURE__ */ new Set();
			r.set(t, i);
		} else i = r.get(t), i === void 0 && (i = /* @__PURE__ */ new Set(), r.set(t, i));
		i.has(n) || (rd = !0, i.add(n), e = hf.bind(null, e, t, n), t.then(e, e));
	}
	function hf(e, t, n) {
		var r = e.pingCache;
		r !== null && r.delete(t), e.pingedLanes |= e.suspendedLanes & n, e.warmLanes &= ~n, $u === e && (Y & n) === n && (ad === 4 || ad === 3 && (Y & 62914560) === Y && 300 > He() - md ? q & 2 ? cd |= n : Vd(e, 0) : cd |= n, ud === Y && (ud = 0)), Ef(e);
	}
	function gf(e, t) {
		t === 0 && (t = lt()), e = Ci(e, t), e !== null && (dt(e, t), Ef(e));
	}
	function _f(e) {
		var t = e.memoizedState, n = 0;
		t !== null && (n = t.retryLane), gf(e, n);
	}
	function vf(e, t) {
		var n = 0;
		switch (e.tag) {
			case 31:
			case 13:
				var r = e.stateNode, a = e.memoizedState;
				a !== null && (n = a.retryLane);
				break;
			case 19:
				r = e.stateNode;
				break;
			case 22:
				r = e.stateNode._retryCache;
				break;
			default: throw Error(i(314));
		}
		r !== null && r.delete(t), gf(e, n);
	}
	function yf(e, t) {
		return Re(e, t);
	}
	var bf = null, xf = null, Sf = !1, Cf = !1, wf = !1, Tf = 0;
	function Ef(e) {
		e !== xf && e.next === null && (xf === null ? bf = xf = e : xf = xf.next = e), Cf = !0, Sf || (Sf = !0, Nf());
	}
	function Df(e, t) {
		if (!wf && Cf) {
			wf = !0;
			do
				for (var n = !1, r = bf; r !== null;) {
					if (!t) {
						if (e !== 0) {
							var i = r.pendingLanes;
							if (i === 0) var a = 0;
							else {
								var o = r.suspendedLanes, s = r.pingedLanes;
								a = (1 << 31 - L(42 | e) + 1) - 1, a &= i & ~(o & ~s), a = a & 201326741 ? a & 201326741 | 1 : a ? a | 2 : 0;
							}
							a !== 0 && (n = !0, Mf(r, a));
						} else a = Y, a = at(r, r === $u ? a : 0, r.cancelPendingCommit !== null || r.timeoutHandle !== -1), !(a & 3) || ot(r, a) || (n = !0, Mf(r, a));
					}
					r = r.next;
				}
			while (n);
			wf = !1;
		}
	}
	function Of() {
		kf();
	}
	function kf() {
		Cf = Sf = !1;
		var e = 0;
		Tf !== 0 && hp() && (e = Tf);
		for (var t = He(), n = null, r = bf; r !== null;) {
			var i = r.next, a = Af(r, t);
			a === 0 ? (r.next = null, n === null ? bf = i : n.next = i, i === null && (xf = n)) : (n = r, (e !== 0 || a & 3) && (Cf = !0)), r = i;
		}
		yd !== 0 && yd !== 5 || Df(e, !1), Tf !== 0 && (Tf = 0);
	}
	function Af(e, t) {
		for (var n = e.suspendedLanes, r = e.pingedLanes, i = e.expirationTimes, a = e.pendingLanes & -62914561; 0 < a;) {
			var o = 31 - L(a), s = 1 << o, c = i[o];
			c === -1 ? ((s & n) === 0 || (s & r) !== 0) && (i[o] = ct(s, t)) : c <= t && (e.expiredLanes |= s), a &= ~s;
		}
		if (t = $u, n = Y, n = at(e, e === t ? n : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), r = e.callbackNode, n === 0 || e === t && (X === 2 || X === 9) || e.cancelPendingCommit !== null) return r !== null && r !== null && ze(r), e.callbackNode = null, e.callbackPriority = 0;
		if (!(n & 3) || ot(e, n)) {
			if (t = n & -n, t === e.callbackPriority) return t;
			switch (r !== null && ze(r), _t(n)) {
				case 2:
				case 8:
					n = Ge;
					break;
				case 32:
					n = Ke;
					break;
				case 268435456:
					n = Je;
					break;
				default: n = Ke;
			}
			return r = jf.bind(null, e), n = Re(n, r), e.callbackPriority = t, e.callbackNode = n, t;
		}
		return r !== null && r !== null && ze(r), e.callbackPriority = 2, e.callbackNode = null, 2;
	}
	function jf(e, t) {
		if (yd !== 0 && yd !== 5) return e.callbackNode = null, e.callbackPriority = 0, null;
		var n = e.callbackNode;
		if (df() && e.callbackNode !== n) return null;
		var r = Y;
		return r = at(e, e === $u ? r : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), r === 0 ? null : (Fd(e, r, t), Af(e, He()), e.callbackNode != null && e.callbackNode === n ? jf.bind(null, e) : null);
	}
	function Mf(e, t) {
		if (df()) return null;
		Fd(e, t, !0);
	}
	function Nf() {
		bp(function() {
			q & 6 ? Re(We, Of) : kf();
		});
	}
	function Pf() {
		if (Tf === 0) {
			var e = Fa;
			e === 0 && (e = nt, nt <<= 1, !(nt & 261888) && (nt = 256)), Tf = e;
		}
		return Tf;
	}
	function Ff(e) {
		return e == null || typeof e == "symbol" || typeof e == "boolean" ? null : typeof e == "function" ? e : mn(e);
	}
	function If(e, t, n, r, i) {
		if (t === "submit" && n && n.stateNode === i) {
			var a = Ff((i[xt] || null).action), o = r.submitter;
			o && (t = (t = o[xt] || null) ? Ff(t.formAction) : o.getAttribute("formAction"), t !== null && (a = t, o = null));
			var s = new In("action", "action", null, r, i);
			e.push({
				event: s,
				listeners: [{
					instance: null,
					listener: function() {
						if (r.defaultPrevented) {
							if (Tf !== 0) {
								var e = new FormData(i, o);
								Qs(n, {
									pending: !0,
									data: e,
									method: i.method,
									action: a
								}, null, e);
							}
						} else typeof a == "function" && (s.preventDefault(), e = new FormData(i, o), Qs(n, {
							pending: !0,
							data: e,
							method: i.method,
							action: a
						}, a, e));
					},
					currentTarget: i
				}]
			});
		}
	}
	for (var Lf = 0; Lf < ui.length; Lf++) {
		var Rf = ui[Lf];
		di(Rf.toLowerCase(), "on" + (Rf[0].toUpperCase() + Rf.slice(1)));
	}
	di(ni, "onAnimationEnd"), di(ri, "onAnimationIteration"), di(ii, "onAnimationStart"), di("dblclick", "onDoubleClick"), di("focusin", "onFocus"), di("focusout", "onBlur"), di(ai, "onTransitionRun"), di(oi, "onTransitionStart"), di(si, "onTransitionCancel"), di(ci, "onTransitionEnd"), Rt("onMouseEnter", ["mouseout", "mouseover"]), Rt("onMouseLeave", ["mouseout", "mouseover"]), Rt("onPointerEnter", ["pointerout", "pointerover"]), Rt("onPointerLeave", ["pointerout", "pointerover"]), Lt("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), Lt("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), Lt("onBeforeInput", [
		"compositionend",
		"keypress",
		"textInput",
		"paste"
	]), Lt("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), Lt("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), Lt("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
	var zf = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), Bf = new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(zf));
	function Vf(e, t) {
		t = !!(t & 4);
		for (var n = 0; n < e.length; n++) {
			var r = e[n], i = r.event;
			r = r.listeners;
			a: {
				var a = void 0;
				if (t) for (var o = r.length - 1; 0 <= o; o--) {
					var s = r[o], c = s.instance, l = s.currentTarget;
					if (s = s.listener, c !== a && i.isPropagationStopped()) break a;
					a = s, i.currentTarget = l;
					try {
						a(i);
					} catch (e) {
						gi(e);
					}
					i.currentTarget = null, a = c;
				}
				else for (o = 0; o < r.length; o++) {
					if (s = r[o], c = s.instance, l = s.currentTarget, s = s.listener, c !== a && i.isPropagationStopped()) break a;
					a = s, i.currentTarget = l;
					try {
						a(i);
					} catch (e) {
						gi(e);
					}
					i.currentTarget = null, a = c;
				}
			}
		}
	}
	function Q(e, t) {
		var n = t[Ct];
		n === void 0 && (n = t[Ct] = /* @__PURE__ */ new Set());
		var r = e + "__bubble";
		n.has(r) || (Gf(t, e, 2, !1), n.add(r));
	}
	function Hf(e, t, n) {
		var r = 0;
		t && (r |= 4), Gf(n, e, r, t);
	}
	var Uf = "_reactListening" + Math.random().toString(36).slice(2);
	function Wf(e) {
		if (!e[Uf]) {
			e[Uf] = !0, Ft.forEach(function(t) {
				t !== "selectionchange" && (Bf.has(t) || Hf(t, !1, e), Hf(t, !0, e));
			});
			var t = e.nodeType === 9 ? e : e.ownerDocument;
			t === null || t[Uf] || (t[Uf] = !0, Hf("selectionchange", !1, t));
		}
	}
	function Gf(e, t, n, r) {
		switch (Ch(t)) {
			case 2:
				var i = _h;
				break;
			case 8:
				i = vh;
				break;
			default: i = yh;
		}
		n = i.bind(null, t, n, e), i = void 0, !Tn || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (i = !0), r ? i === void 0 ? e.addEventListener(t, n, !0) : e.addEventListener(t, n, {
			capture: !0,
			passive: i
		}) : i === void 0 ? e.addEventListener(t, n, !1) : e.addEventListener(t, n, { passive: i });
	}
	function Kf(e, t, n, r, i) {
		var a = r;
		if (!(t & 1) && !(t & 2) && r !== null) a: for (;;) {
			if (r === null) return;
			var s = r.tag;
			if (s === 3 || s === 4) {
				var c = r.stateNode.containerInfo;
				if (c === i) break;
				if (s === 4) for (s = r.return; s !== null;) {
					var l = s.tag;
					if ((l === 3 || l === 4) && s.stateNode.containerInfo === i) return;
					s = s.return;
				}
				for (; c !== null;) {
					if (s = At(c), s === null) return;
					if (l = s.tag, l === 5 || l === 6 || l === 26 || l === 27) {
						r = a = s;
						continue a;
					}
					c = c.parentNode;
				}
			}
			r = r.return;
		}
		Sn(function() {
			var r = a, i = _n(n), s = [];
			a: {
				var c = li.get(e);
				if (c !== void 0) {
					var l = In, u = e;
					switch (e) {
						case "keypress": if (jn(n) === 0) break a;
						case "keydown":
						case "keyup":
							l = er;
							break;
						case "focusin":
							u = "focus", l = Gn;
							break;
						case "focusout":
							u = "blur", l = Gn;
							break;
						case "beforeblur":
						case "afterblur":
							l = Gn;
							break;
						case "click": if (n.button === 2) break a;
						case "auxclick":
						case "dblclick":
						case "mousedown":
						case "mousemove":
						case "mouseup":
						case "mouseout":
						case "mouseover":
						case "contextmenu":
							l = Un;
							break;
						case "drag":
						case "dragend":
						case "dragenter":
						case "dragexit":
						case "dragleave":
						case "dragover":
						case "dragstart":
						case "drop":
							l = Wn;
							break;
						case "touchcancel":
						case "touchend":
						case "touchmove":
						case "touchstart":
							l = rr;
							break;
						case ni:
						case ri:
						case ii:
							l = Kn;
							break;
						case ci:
							l = ir;
							break;
						case "scroll":
						case "scrollend":
							l = Rn;
							break;
						case "wheel":
							l = ar;
							break;
						case "copy":
						case "cut":
						case "paste":
							l = qn;
							break;
						case "gotpointercapture":
						case "lostpointercapture":
						case "pointercancel":
						case "pointerdown":
						case "pointermove":
						case "pointerout":
						case "pointerover":
						case "pointerup":
							l = tr;
							break;
						case "submit":
							l = nr;
							break;
						case "toggle":
						case "beforetoggle": l = or;
					}
					var d = !!(t & 4), f = !d && (e === "scroll" || e === "scrollend"), p = d ? c === null ? null : c + "Capture" : c;
					d = [];
					for (var m = r, h; m !== null;) {
						var g = m;
						if (h = g.stateNode, g = g.tag, g !== 5 && g !== 26 && g !== 27 || h === null || p === null || (g = Cn(m, p), g != null && d.push(qf(m, g, h))), f) break;
						m = m.return;
					}
					0 < d.length && (c = new l(c, u, null, n, i), s.push({
						event: c,
						listeners: d
					}));
				}
			}
			if (!(t & 7)) {
				a: {
					if (l = e === "mouseover" || e === "pointerover", c = e === "mouseout" || e === "pointerout", l && n !== gn && (u = n.relatedTarget || n.fromElement) && (At(u) || u[St])) break a;
					(c || l) && (u = i.window === i ? i : (l = i.ownerDocument) ? l.defaultView || l.parentWindow : window, c ? (l = n.relatedTarget || n.toElement, c = r, l = l ? At(l) : null, l !== null && (f = o(l), d = l.tag, l !== f || d !== 5 && d !== 27 && d !== 6) && (l = null)) : (c = null, l = r), c !== l && (d = Un, g = "onMouseLeave", p = "onMouseEnter", m = "mouse", (e === "pointerout" || e === "pointerover") && (d = tr, g = "onPointerLeave", p = "onPointerEnter", m = "pointer"), f = c == null ? u : Mt(c), h = l == null ? u : Mt(l), u = new d(g, m + "leave", c, n, i), u.target = f, u.relatedTarget = h, g = null, At(i) === r && (d = new d(p, m + "enter", l, n, i), d.target = h, d.relatedTarget = f, g = d), f = g, d = c && l ? E(c, l, Yf) : null, c !== null && Xf(s, u, c, d, !1), l !== null && f !== null && Xf(s, f, l, d, !0)));
				}
				a: {
					if (c = r ? Mt(r) : window, l = c.nodeName && c.nodeName.toLowerCase(), l === "select" || l === "input" && c.type === "file") var _ = Tr;
					else if (yr(c)) {
						if (Er) _ = Fr;
						else {
							_ = Nr;
							var v = Mr;
						}
					} else l = c.nodeName, !l || l.toLowerCase() !== "input" || c.type !== "checkbox" && c.type !== "radio" ? r && dn(r.elementType) && (_ = Tr) : _ = Pr;
					if (_ &&= _(e, r)) {
						br(s, _, n, i);
						break a;
					}
					v && v(e, c, r);
				}
				switch (v = r ? Mt(r) : window, e) {
					case "focusin":
						(yr(v) || v.contentEditable === "true") && (Kr = v, qr = r, Jr = null);
						break;
					case "focusout":
						Jr = qr = Kr = null;
						break;
					case "mousedown":
						Yr = !0;
						break;
					case "contextmenu":
					case "mouseup":
					case "dragend":
						Yr = !1, Xr(s, n, i);
						break;
					case "selectionchange": if (Gr) break;
					case "keydown":
					case "keyup": Xr(s, n, i);
				}
				var y;
				if (cr) b: {
					switch (e) {
						case "compositionstart":
							var b = "onCompositionStart";
							break b;
						case "compositionend":
							b = "onCompositionEnd";
							break b;
						case "compositionupdate":
							b = "onCompositionUpdate";
							break b;
					}
					b = void 0;
				}
				else hr ? pr(e, n) && (b = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (b = "onCompositionStart");
				b && (ur && n.locale !== "ko" && (hr || b !== "onCompositionStart" ? b === "onCompositionEnd" && hr && (y = An()) : (Dn = i, On = "value" in Dn ? Dn.value : Dn.textContent, hr = !0)), v = Jf(r, b), 0 < v.length && (b = new Jn(b, e, null, n, i), s.push({
					event: b,
					listeners: v
				}), y ? b.data = y : (y = mr(n), y !== null && (b.data = y)))), (y = lr ? gr(e, n) : _r(e, n)) && (b = Jf(r, "onBeforeInput"), 0 < b.length && (v = new Jn("onBeforeInput", "beforeinput", null, n, i), s.push({
					event: v,
					listeners: b
				}), v.data = y)), If(s, e, r, n, i);
			}
			Vf(s, t);
		});
	}
	function qf(e, t, n) {
		return {
			instance: e,
			listener: t,
			currentTarget: n
		};
	}
	function Jf(e, t) {
		for (var n = t + "Capture", r = []; e !== null;) {
			var i = e, a = i.stateNode;
			if (i = i.tag, i !== 5 && i !== 26 && i !== 27 || a === null || (i = Cn(e, n), i != null && r.unshift(qf(e, i, a)), i = Cn(e, t), i != null && r.push(qf(e, i, a))), e.tag === 3) return r;
			e = e.return;
		}
		return [];
	}
	function Yf(e) {
		if (e === null) return null;
		do
			e = e.return;
		while (e && e.tag !== 5 && e.tag !== 27);
		return e || null;
	}
	function Xf(e, t, n, r, i) {
		for (var a = t._reactName, o = []; n !== null && n !== r;) {
			var s = n, c = s.alternate, l = s.stateNode;
			if (s = s.tag, c !== null && c === r) break;
			s !== 5 && s !== 26 && s !== 27 || l === null || (c = l, i ? (l = Cn(n, a), l != null && o.unshift(qf(n, l, c))) : i || (l = Cn(n, a), l != null && o.push(qf(n, l, c)))), n = n.return;
		}
		o.length !== 0 && e.push({
			event: t,
			listeners: o
		});
	}
	var Zf = /\r\n?/g, Qf = /\u0000|\uFFFD/g;
	function $f(e) {
		return (typeof e == "string" ? e : "" + e).replace(Zf, "\n").replace(Qf, "");
	}
	function ep(e, t) {
		return t = $f(t), $f(e) === t;
	}
	function $(e, t, n, r, a, o) {
		switch (n) {
			case "children":
				if (typeof r == "string") t === "body" || t === "textarea" && r === "" || sn(e, r);
				else if (typeof r == "number" || typeof r == "bigint") t !== "body" && sn(e, "" + r);
				else return;
				break;
			case "className":
				Gt(e, "class", r);
				break;
			case "tabIndex":
				Gt(e, "tabindex", r);
				break;
			case "dir":
			case "role":
			case "viewBox":
			case "width":
			case "height":
				Gt(e, n, r);
				break;
			case "style":
				un(e, r, o);
				return;
			case "data": if (t !== "object") {
				Gt(e, "data", r);
				break;
			}
			case "src":
			case "href":
				if (r === "" && (t !== "a" || n !== "href") || r == null || typeof r == "function" || typeof r == "symbol" || typeof r == "boolean") {
					e.removeAttribute(n);
					break;
				}
				r = mn(r), e.setAttribute(n, r);
				break;
			case "action":
			case "formAction":
				if (typeof r == "function") {
					e.setAttribute(n, "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");
					break;
				}
				if (typeof o == "function" && (n === "formAction" ? (t !== "input" && $(e, t, "name", a.name, a, null), $(e, t, "formEncType", a.formEncType, a, null), $(e, t, "formMethod", a.formMethod, a, null), $(e, t, "formTarget", a.formTarget, a, null)) : ($(e, t, "encType", a.encType, a, null), $(e, t, "method", a.method, a, null), $(e, t, "target", a.target, a, null))), r == null || typeof r == "symbol" || typeof r == "boolean") {
					e.removeAttribute(n);
					break;
				}
				r = mn(r), e.setAttribute(n, r);
				break;
			case "onClick":
				r != null && (e.onclick = hn);
				return;
			case "onScroll":
				r != null && Q("scroll", e);
				return;
			case "onScrollEnd":
				r != null && Q("scrollend", e);
				return;
			case "dangerouslySetInnerHTML":
				if (r != null) {
					if (typeof r != "object" || !("__html" in r)) throw Error(i(61));
					if (n = r.__html, n != null) {
						if (a.children != null) throw Error(i(60));
						o?.__html !== n && (e.innerHTML = n);
					}
				}
				break;
			case "multiple":
				e.multiple = r && typeof r != "function" && typeof r != "symbol";
				break;
			case "muted":
				e.muted = r && typeof r != "function" && typeof r != "symbol";
				break;
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "defaultValue":
			case "defaultChecked":
			case "innerHTML":
			case "ref": break;
			case "autoFocus": break;
			case "xlinkHref":
				if (r == null || typeof r == "function" || typeof r == "boolean" || typeof r == "symbol") {
					e.removeAttribute("xlink:href");
					break;
				}
				n = mn(r), e.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", n);
				break;
			case "contentEditable":
			case "spellCheck":
			case "draggable":
			case "value":
			case "autoReverse":
			case "externalResourcesRequired":
			case "focusable":
			case "preserveAlpha":
				r != null && typeof r != "function" && typeof r != "symbol" ? e.setAttribute(n, r) : e.removeAttribute(n);
				break;
			case "inert":
			case "allowFullScreen":
			case "async":
			case "autoPlay":
			case "controls":
			case "credentialless":
			case "default":
			case "defer":
			case "disabled":
			case "disablePictureInPicture":
			case "disableRemotePlayback":
			case "formNoValidate":
			case "hidden":
			case "loop":
			case "noModule":
			case "noValidate":
			case "open":
			case "playsInline":
			case "readOnly":
			case "required":
			case "reversed":
			case "scoped":
			case "seamless":
			case "itemScope":
				r && typeof r != "function" && typeof r != "symbol" ? e.setAttribute(n, "") : e.removeAttribute(n);
				break;
			case "capture":
			case "download":
				!0 === r ? e.setAttribute(n, "") : !1 !== r && r != null && typeof r != "function" && typeof r != "symbol" ? e.setAttribute(n, r) : e.removeAttribute(n);
				break;
			case "cols":
			case "rows":
			case "size":
			case "span":
				r != null && typeof r != "function" && typeof r != "symbol" && !isNaN(r) && 1 <= r ? e.setAttribute(n, r) : e.removeAttribute(n);
				break;
			case "rowSpan":
			case "start":
				r == null || typeof r == "function" || typeof r == "symbol" || isNaN(r) ? e.removeAttribute(n) : e.setAttribute(n, r);
				break;
			case "popover":
				Q("beforetoggle", e), Q("toggle", e), Wt(e, "popover", r);
				break;
			case "xlinkActuate":
				Kt(e, "http://www.w3.org/1999/xlink", "xlink:actuate", r);
				break;
			case "xlinkArcrole":
				Kt(e, "http://www.w3.org/1999/xlink", "xlink:arcrole", r);
				break;
			case "xlinkRole":
				Kt(e, "http://www.w3.org/1999/xlink", "xlink:role", r);
				break;
			case "xlinkShow":
				Kt(e, "http://www.w3.org/1999/xlink", "xlink:show", r);
				break;
			case "xlinkTitle":
				Kt(e, "http://www.w3.org/1999/xlink", "xlink:title", r);
				break;
			case "xlinkType":
				Kt(e, "http://www.w3.org/1999/xlink", "xlink:type", r);
				break;
			case "xmlBase":
				Kt(e, "http://www.w3.org/XML/1998/namespace", "xml:base", r);
				break;
			case "xmlLang":
				Kt(e, "http://www.w3.org/XML/1998/namespace", "xml:lang", r);
				break;
			case "xmlSpace":
				Kt(e, "http://www.w3.org/XML/1998/namespace", "xml:space", r);
				break;
			case "is":
				Wt(e, "is", r);
				break;
			case "innerText":
			case "textContent": return;
			default: if (!(2 < n.length) || n[0] !== "o" && n[0] !== "O" || n[1] !== "n" && n[1] !== "N") n = fn.get(n) || n, Wt(e, n, r);
			else return;
		}
		H = !0;
	}
	function tp(e, t, n, r, a, o) {
		switch (n) {
			case "style":
				un(e, r, o);
				return;
			case "dangerouslySetInnerHTML":
				if (r != null) {
					if (typeof r != "object" || !("__html" in r)) throw Error(i(61));
					if (n = r.__html, n != null) {
						if (a.children != null) throw Error(i(60));
						o?.__html !== n && (e.innerHTML = n);
					}
				}
				break;
			case "children":
				if (typeof r == "string") sn(e, r);
				else if (typeof r == "number" || typeof r == "bigint") sn(e, "" + r);
				else return;
				break;
			case "onScroll":
				r != null && Q("scroll", e);
				return;
			case "onScrollEnd":
				r != null && Q("scrollend", e);
				return;
			case "onClick":
				r != null && (e.onclick = hn);
				return;
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "innerHTML":
			case "ref": return;
			case "innerText":
			case "textContent": return;
			default:
				if (!It.hasOwnProperty(n)) a: {
					if (n[0] === "o" && n[1] === "n" && (a = n.endsWith("Capture"), o = n.slice(2, a ? n.length - 7 : void 0), t = e[xt] || null, t = t == null ? null : t[n], typeof t == "function" && e.removeEventListener(o, t, a), typeof r == "function")) {
						typeof t != "function" && t !== null && (n in e ? e[n] = null : e.hasAttribute(n) && e.removeAttribute(n)), e.addEventListener(o, r, a);
						break a;
					}
					H = !0, n in e ? e[n] = r : !0 === r ? e.setAttribute(n, "") : Wt(e, n, r);
				}
				return;
		}
		H = !0;
	}
	function np(e, t, n) {
		switch (t) {
			case "div":
			case "span":
			case "svg":
			case "path":
			case "a":
			case "g":
			case "p":
			case "li": break;
			case "img":
				Q("error", e), Q("load", e);
				var r = !1, a = !1, o;
				for (o in n) if (n.hasOwnProperty(o)) {
					var s = n[o];
					if (s != null) switch (o) {
						case "src":
							r = !0;
							break;
						case "srcSet":
							a = !0;
							break;
						case "children":
						case "dangerouslySetInnerHTML": throw Error(i(137, t));
						default: $(e, t, o, s, n, null);
					}
				}
				a && $(e, t, "srcSet", n.srcSet, n, null), r && $(e, t, "src", n.src, n, null);
				return;
			case "input":
				Q("invalid", e);
				var c = o = s = a = null, l = null, u = null;
				for (r in n) if (n.hasOwnProperty(r)) {
					var d = n[r];
					if (d != null) switch (r) {
						case "name":
							a = d;
							break;
						case "type":
							s = d;
							break;
						case "checked":
							l = d;
							break;
						case "defaultChecked":
							u = d;
							break;
						case "value":
							o = d;
							break;
						case "defaultValue":
							c = d;
							break;
						case "children":
						case "dangerouslySetInnerHTML":
							if (d != null) throw Error(i(137, t));
							break;
						default: $(e, t, r, d, n, null);
					}
				}
				tn(e, o, c, l, u, s, a, !1);
				return;
			case "select":
				for (a in Q("invalid", e), r = s = o = null, n) if (n.hasOwnProperty(a) && (c = n[a], c != null)) switch (a) {
					case "value":
						o = c;
						break;
					case "defaultValue":
						s = c;
						break;
					case "multiple": r = c;
					default: $(e, t, a, c, n, null);
				}
				t = o, n = s, e.multiple = !!r, t == null ? n != null && rn(e, !!r, n, !0) : rn(e, !!r, t, !1);
				return;
			case "textarea":
				for (s in Q("invalid", e), o = a = r = null, n) if (n.hasOwnProperty(s) && (c = n[s], c != null)) switch (s) {
					case "value":
						r = c;
						break;
					case "defaultValue":
						a = c;
						break;
					case "children":
						o = c;
						break;
					case "dangerouslySetInnerHTML":
						if (c != null) throw Error(i(91));
						break;
					default: $(e, t, s, c, n, null);
				}
				on(e, r, a, o);
				return;
			case "option":
				for (l in n) if (n.hasOwnProperty(l) && (r = n[l], r != null)) switch (l) {
					case "selected":
						e.selected = r && typeof r != "function" && typeof r != "symbol";
						break;
					default: $(e, t, l, r, n, null);
				}
				return;
			case "dialog":
				Q("beforetoggle", e), Q("toggle", e), Q("cancel", e), Q("close", e);
				break;
			case "iframe":
			case "object":
				Q("load", e);
				break;
			case "video":
			case "audio":
				for (r = 0; r < zf.length; r++) Q(zf[r], e);
				break;
			case "image":
				Q("error", e), Q("load", e);
				break;
			case "details":
				Q("toggle", e);
				break;
			case "embed":
			case "source":
			case "link": Q("error", e), Q("load", e);
			case "area":
			case "base":
			case "br":
			case "col":
			case "hr":
			case "keygen":
			case "meta":
			case "param":
			case "track":
			case "wbr":
			case "menuitem":
				for (u in n) if (n.hasOwnProperty(u) && (r = n[u], r != null)) switch (u) {
					case "children":
					case "dangerouslySetInnerHTML": throw Error(i(137, t));
					default: $(e, t, u, r, n, null);
				}
				return;
			default: if (dn(t)) {
				for (d in n) n.hasOwnProperty(d) && (r = n[d], r !== void 0 && tp(e, t, d, r, n, void 0));
				return;
			}
		}
		for (c in n) n.hasOwnProperty(c) && (r = n[c], r != null && $(e, t, c, r, n, null));
	}
	var rp = {};
	function ip(e, t, n, r) {
		switch (t) {
			case "div":
			case "span":
			case "svg":
			case "path":
			case "a":
			case "g":
			case "p":
			case "li": break;
			case "input":
				var a = null, o = null, s = null, c = null, l = null, u = null, d = null;
				for (m in n) {
					var f = n[m];
					if (n.hasOwnProperty(m) && f != null) switch (m) {
						case "checked": break;
						case "value": break;
						case "defaultValue": l = f;
						default: r.hasOwnProperty(m) || $(e, t, m, null, r, f);
					}
				}
				for (var p in r) {
					var m = r[p];
					if (f = n[p], r.hasOwnProperty(p) && (m != null || f != null)) switch (p) {
						case "type":
							m !== f && (H = !0), o = m;
							break;
						case "name":
							m !== f && (H = !0), a = m;
							break;
						case "checked":
							m !== f && (H = !0), u = m;
							break;
						case "defaultChecked":
							m !== f && (H = !0), d = m;
							break;
						case "value":
							m !== f && (H = !0), s = m;
							break;
						case "defaultValue":
							m !== f && (H = !0), c = m;
							break;
						case "children":
						case "dangerouslySetInnerHTML":
							if (m != null) throw Error(i(137, t));
							break;
						default: m !== f && $(e, t, p, m, r, f);
					}
				}
				en(e, s, c, l, u, d, o, a);
				return;
			case "select":
				for (o in m = s = c = p = null, n) if (l = n[o], n.hasOwnProperty(o) && l != null) switch (o) {
					case "value": break;
					case "multiple": m = l;
					default: r.hasOwnProperty(o) || $(e, t, o, null, r, l);
				}
				for (a in r) if (o = r[a], l = n[a], r.hasOwnProperty(a) && (o != null || l != null)) switch (a) {
					case "value":
						o !== l && (H = !0), p = o;
						break;
					case "defaultValue":
						o !== l && (H = !0), c = o;
						break;
					case "multiple": o !== l && (H = !0), s = o;
					default: o !== l && $(e, t, a, o, r, l);
				}
				t = c, n = s, r = m, p == null ? !!r != !!n && (t == null ? rn(e, !!n, n ? [] : "", !1) : rn(e, !!n, t, !0)) : rn(e, !!n, p, !1);
				return;
			case "textarea":
				for (c in m = p = null, n) if (a = n[c], n.hasOwnProperty(c) && a != null && !r.hasOwnProperty(c)) switch (c) {
					case "value": break;
					case "children": break;
					default: $(e, t, c, null, r, a);
				}
				for (s in r) if (a = r[s], o = n[s], r.hasOwnProperty(s) && (a != null || o != null)) switch (s) {
					case "value":
						a !== o && (H = !0), p = a;
						break;
					case "defaultValue":
						a !== o && (H = !0), m = a;
						break;
					case "children": break;
					case "dangerouslySetInnerHTML":
						if (a != null) throw Error(i(91));
						break;
					default: a !== o && $(e, t, s, a, r, o);
				}
				an(e, p, m);
				return;
			case "option":
				for (var h in n) if (p = n[h], n.hasOwnProperty(h) && p != null && !r.hasOwnProperty(h)) switch (h) {
					case "selected":
						e.selected = !1;
						break;
					default: $(e, t, h, null, r, p);
				}
				for (l in r) if (p = r[l], m = n[l], r.hasOwnProperty(l) && p !== m && (p != null || m != null)) switch (l) {
					case "selected":
						p !== m && (H = !0), e.selected = p && typeof p != "function" && typeof p != "symbol";
						break;
					default: $(e, t, l, p, r, m);
				}
				return;
			case "img":
			case "link":
			case "area":
			case "base":
			case "br":
			case "col":
			case "embed":
			case "hr":
			case "keygen":
			case "meta":
			case "param":
			case "source":
			case "track":
			case "wbr":
			case "menuitem":
				for (var g in n) p = n[g], n.hasOwnProperty(g) && p != null && !r.hasOwnProperty(g) && $(e, t, g, null, r, p);
				for (u in r) if (p = r[u], m = n[u], r.hasOwnProperty(u) && p !== m && (p != null || m != null)) switch (u) {
					case "children":
					case "dangerouslySetInnerHTML":
						if (p != null) throw Error(i(137, t));
						break;
					default: $(e, t, u, p, r, m);
				}
				return;
			default: if (dn(t)) {
				for (var _ in n) p = n[_], n.hasOwnProperty(_) && p !== void 0 && !r.hasOwnProperty(_) && tp(e, t, _, void 0, r, p);
				for (d in r) p = r[d], m = n[d], !r.hasOwnProperty(d) || p === m || p === void 0 && m === void 0 || tp(e, t, d, p, r, m);
				return;
			}
		}
		for (var v in n) p = n[v], n.hasOwnProperty(v) && p != null && !r.hasOwnProperty(v) && $(e, t, v, null, r, p);
		for (f in r) p = r[f], m = n[f], !r.hasOwnProperty(f) || p === m || p == null && m == null || $(e, t, f, p, r, m);
	}
	function ap(e) {
		switch (e) {
			case "css":
			case "script":
			case "font":
			case "img":
			case "image":
			case "input":
			case "link": return !0;
			default: return !1;
		}
	}
	function op() {
		if (typeof performance.getEntriesByType == "function") {
			for (var e = 0, t = 0, n = performance.getEntriesByType("resource"), r = 0; r < n.length; r++) {
				var i = n[r], a = i.transferSize, o = i.initiatorType, s = i.duration;
				if (a && s && ap(o)) {
					for (o = 0, s = i.responseEnd, r += 1; r < n.length; r++) {
						var c = n[r], l = c.startTime;
						if (l > s) break;
						var u = c.transferSize, d = c.initiatorType;
						u && ap(d) && (c = c.responseEnd, o += u * (c < s ? 1 : (s - l) / (c - l)));
					}
					if (--r, t += 8 * (a + o) / (i.duration / 1e3), e++, 10 < e) break;
				}
			}
			if (0 < e) return t / e / 1e6;
		}
		return navigator.connection && (e = navigator.connection.downlink, typeof e == "number") ? e : 5;
	}
	var sp = null, cp = null;
	function lp(e) {
		return e.nodeType === 9 ? e : e.ownerDocument;
	}
	function up(e) {
		switch (e) {
			case "http://www.w3.org/2000/svg": return 1;
			case "http://www.w3.org/1998/Math/MathML": return 2;
			default: return 0;
		}
	}
	function dp(e, t) {
		if (e === 0) switch (t) {
			case "svg": return 1;
			case "math": return 2;
			default: return 0;
		}
		return e === 1 && t === "foreignObject" ? 0 : e;
	}
	function fp(e, t, n, r) {
		return n = lp(n).createElement(e), n[B] = r, n[xt] = t, np(n, e, t), V(n), n;
	}
	function pp(e, t) {
		return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.children == "bigint" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
	}
	var mp = null;
	function hp() {
		var e = window.event;
		return e && e.type === "popstate" ? e !== mp && (mp = e, !0) : (mp = null, !1);
	}
	var gp = typeof setTimeout == "function" ? setTimeout : void 0, _p = typeof clearTimeout == "function" ? clearTimeout : void 0, vp = typeof Promise == "function" ? Promise : void 0, yp = typeof requestAnimationFrame == "function" ? requestAnimationFrame : gp, bp = typeof queueMicrotask == "function" ? queueMicrotask : vp === void 0 ? gp : function(e) {
		return vp.resolve(null).then(e).catch(xp);
	};
	function xp(e) {
		setTimeout(function() {
			throw e;
		});
	}
	function Sp(e) {
		return e === "head";
	}
	function Cp(e, t) {
		var n = t, r = 0;
		do {
			var i = n.nextSibling;
			if (e.removeChild(n), i && i.nodeType === 8) {
				if (n = i.data, n === "/$" || n === "/&") {
					if (r === 0) {
						e.removeChild(i), Hh(t);
						return;
					}
					r--;
				} else if (n === "$" || n === "$?" || n === "$~" || n === "$!" || n === "&") r++;
				else if (n === "html") _m(e.ownerDocument.documentElement);
				else if (n === "head") {
					n = e.ownerDocument.head, _m(n);
					for (var a = n.firstChild; a;) {
						var o = a.nextSibling, s = a.nodeName;
						a[Dt] || s === "SCRIPT" || s === "STYLE" || s === "LINK" && a.rel.toLowerCase() === "stylesheet" || n.removeChild(a), a = o;
					}
				} else n === "body" && _m(e.ownerDocument.body);
			}
			n = i;
		} while (n);
		Hh(t);
	}
	function wp(e, t) {
		var n = e;
		e = 0;
		do {
			var r = n.nextSibling;
			if (n.nodeType === 1 ? t ? (n._stashedDisplay = n.style.display, n.style.display = "none") : (n.style.display = n._stashedDisplay || "", n.getAttribute("style") === "" && n.removeAttribute("style")) : n.nodeType === 3 && (t ? (n._stashedText = n.nodeValue, n.nodeValue = "") : n.nodeValue = n._stashedText || ""), r && r.nodeType === 8) {
				if (n = r.data, n === "/$") {
					if (e === 0) break;
					e--;
				} else n !== "$" && n !== "$?" && n !== "$~" && n !== "$!" || e++;
			}
			n = r;
		} while (n);
	}
	function Tp(e, t, n) {
		if (t = CSS.escape(t) === t ? t : "r-" + btoa(t).replace(/=/g, ""), e.style.viewTransitionName = t, n != null && (e.style.viewTransitionClass = n), n = getComputedStyle(e), n.display === "inline") {
			if (t = e.getClientRects(), t.length === 1) var r = 1;
			else for (var i = r = 0; i < t.length; i++) {
				var a = t[i];
				0 < a.width && 0 < a.height && r++;
			}
			r === 1 && (e = e.style, e.display = t.length === 1 ? "inline-block" : "block", e.marginTop = "-" + n.paddingTop, e.marginBottom = "-" + n.paddingBottom);
		}
	}
	function Ep(e, t) {
		e = e.style, t = t.style;
		var n = t == null ? null : t.hasOwnProperty("viewTransitionName") ? t.viewTransitionName : t.hasOwnProperty("view-transition-name") ? t["view-transition-name"] : null;
		e.viewTransitionName = n == null || typeof n == "boolean" ? "" : ("" + n).trim(), n = t == null ? null : t.hasOwnProperty("viewTransitionClass") ? t.viewTransitionClass : t.hasOwnProperty("view-transition-class") ? t["view-transition-class"] : null, e.viewTransitionClass = n == null || typeof n == "boolean" ? "" : ("" + n).trim(), e.display === "inline-block" && (t == null ? e.display = e.margin = "" : (n = t.display, e.display = n == null || typeof n == "boolean" ? "" : n, n = t.margin, n == null ? (n = t.hasOwnProperty("marginTop") ? t.marginTop : t["margin-top"], e.marginTop = n == null || typeof n == "boolean" ? "" : n, t = t.hasOwnProperty("marginBottom") ? t.marginBottom : t["margin-bottom"], e.marginBottom = t == null || typeof t == "boolean" ? "" : t) : e.margin = n));
	}
	function Dp(e, t, n) {
		return n = n.ownerDocument.defaultView, {
			rect: e,
			abs: t.position === "absolute" || t.position === "fixed",
			clip: t.clipPath !== "none" || t.overflow !== "visible" || t.filter !== "none" || t.mask !== "none" || t.mask !== "none" || t.borderRadius !== "0px",
			view: 0 <= e.bottom && 0 <= e.right && e.top <= n.innerHeight && e.left <= n.innerWidth
		};
	}
	function Op(e) {
		return Dp(e.getBoundingClientRect(), getComputedStyle(e), e);
	}
	function kp(e) {
		var t = e.getBoundingClientRect();
		t = new DOMRect(t.x + 2e4, t.y + 2e4, t.width, t.height);
		var n = getComputedStyle(e);
		return Dp(t, n, e);
	}
	function Ap(e) {
		return e.documentElement.clientHeight;
	}
	function jp(e) {
		this.addEventListener("load", e), this.addEventListener("error", e);
	}
	function Mp(e, t, n, r, i, a, o, s, c) {
		var l = t.nodeType === 9 ? t : t.ownerDocument;
		try {
			var u = l.startViewTransition({
				update: function() {
					var t = l.defaultView, n = t.navigation && t.navigation.transition, o = l.fonts.status;
					r();
					var s = [];
					if (o === "loaded" && (Ap(l), l.fonts.status === "loading" && s.push(l.fonts.ready)), o = s.length, e !== null) for (var c = e.suspenseyImages, u = 0, d = 0; d < c.length; d++) {
						var f = c[d];
						if (!f.complete) {
							var p = f.getBoundingClientRect();
							if (0 < p.bottom && 0 < p.right && p.top < t.innerHeight && p.left < t.innerWidth) {
								if (u += Xm(f), u > $m) {
									s.length = o;
									break;
								}
								f = new Promise(jp.bind(f)), s.push(f);
							}
						}
					}
					if (0 < s.length) return t = Promise.race([Promise.all(s), new Promise(function(e) {
						return setTimeout(e, 500);
					})]).then(i, i), (n ? Promise.allSettled([n.finished, t]) : t).then(a, a);
					if (i(), n) return n.finished.then(a, a);
					a();
				},
				types: n
			});
			l.__reactViewTransition = u;
			var d = [];
			return u.ready.then(function() {
				for (var e = l.documentElement.getAnimations({ subtree: !0 }), t = 0; t < e.length; t++) {
					var n = e[t], r = n.effect, i = r.pseudoElement;
					if (i != null && i.startsWith("::view-transition")) {
						d.push(n), n = r.getKeyframes();
						for (var a = i = void 0, s = !0, c = 0; c < n.length; c++) {
							var u = n[c], f = u.width;
							if (i === void 0) i = f;
							else if (i !== f) {
								s = !1;
								break;
							}
							if (f = u.height, a === void 0) a = f;
							else if (a !== f) {
								s = !1;
								break;
							}
							delete u.width, delete u.height, u.transform === "none" && delete u.transform;
						}
						s && i !== void 0 && a !== void 0 && (r.setKeyframes(n), s = getComputedStyle(r.target, r.pseudoElement), s.width !== i || s.height !== a) && (s = n[0], s.width = i, s.height = a, s = n[n.length - 1], s.width = i, s.height = a, r.setKeyframes(n));
					}
				}
				o();
			}, function(e) {
				l.__reactViewTransition === u && (l.__reactViewTransition = null);
				try {
					if (typeof e == "object" && e) switch (e.name) {
						case "InvalidStateError": (e.message === "View transition was skipped because document visibility state is hidden." || e.message === "Skipping view transition because document visibility state has become hidden." || e.message === "Skipping view transition because viewport size changed." || e.message === "Transition was aborted because of invalid state") && (e = null);
					}
					e !== null && c(e);
				} finally {
					r(), i(), o();
				}
			}), u.finished.finally(function() {
				for (var e = 0; e < d.length; e++) d[e].cancel();
				l.__reactViewTransition === u && (l.__reactViewTransition = null), s();
			}), u;
		} catch {
			return r(), i(), o(), null;
		}
	}
	function Np(e, t) {
		this._scope = document.documentElement, this._selector = "::view-transition-" + e + "(" + t + ")";
	}
	Np.prototype.animate = function(e, t) {
		return t = typeof t == "number" ? { duration: t } : D({}, t), t.pseudoElement = this._selector, this._scope.animate(e, t);
	}, Np.prototype.getAnimations = function() {
		for (var e = this._scope, t = this._selector, n = e.getAnimations({ subtree: !0 }), r = [], i = 0; i < n.length; i++) {
			var a = n[i].effect;
			a !== null && a.target === e && a.pseudoElement === t && r.push(n[i]);
		}
		return r;
	}, Np.prototype.getComputedStyle = function() {
		return getComputedStyle(this._scope, this._selector);
	};
	function Pp(e) {
		return {
			name: e,
			group: new Np("group", e),
			imagePair: new Np("image-pair", e),
			old: new Np("old", e),
			new: new Np("new", e)
		};
	}
	function Fp(e) {
		this._fragmentFiber = e, this._observers = this._eventListeners = null;
	}
	Fp.prototype.addEventListener = function(e, t, n) {
		var r = null, i = null;
		if (!(n != null && typeof n != "boolean" && (r = n.signal || null, r !== null && r.aborted))) {
			this._eventListeners === null && (this._eventListeners = []);
			var a = this._eventListeners;
			if (Bp(a, e, t, n) === -1) {
				var o = this, s = t;
				n != null && typeof n != "boolean" && !0 === n.once && (s = function(r) {
					o.removeEventListener(e, t, n), typeof t == "function" ? t.call(this, r) : t.handleEvent(r);
				}), r !== null && (i = o.removeEventListener.bind(o, e, t, n), r.addEventListener("abort", i, { once: !0 }), i = r.removeEventListener.bind(r, "abort", i)), r = Rp(n), a.push({
					type: e,
					listener: t,
					optionsOrUseCapture: n,
					attachedListener: s,
					cleanup: i
				}), h(this._fragmentFiber.child, !1, Ip, e, s, r);
			}
			this._eventListeners = a;
		}
	};
	function Ip(e, t, n, r) {
		return b(e).addEventListener(t, n, r), !1;
	}
	Fp.prototype.removeEventListener = function(e, t, n) {
		var r = this._eventListeners;
		if (r !== null && (t = Bp(r, e, t, n), t !== -1)) {
			var i = r[t];
			n = i.attachedListener;
			var a = i.cleanup;
			i = Rp(i.optionsOrUseCapture), h(this._fragmentFiber.child, !1, Lp, e, n, i), r.splice(t, 1), a !== null && a();
		}
	};
	function Lp(e, t, n, r) {
		return b(e).removeEventListener(t, n, r), !1;
	}
	function Rp(e) {
		return e != null && typeof e != "boolean" && (!0 === e.once || e.signal instanceof AbortSignal) ? {
			capture: e.capture,
			passive: e.passive
		} : e;
	}
	function zp(e) {
		return e == null ? "c=0" : typeof e == "boolean" ? "c=" + (e ? "1" : "0") : "c=" + (e.capture ? "1" : "0");
	}
	function Bp(e, t, n, r) {
		if (e.length === 0) return -1;
		r = zp(r);
		for (var i = 0; i < e.length; i++) {
			var a = e[i];
			if (a.type === t && a.listener === n && zp(a.optionsOrUseCapture) === r) return i;
		}
		return -1;
	}
	Fp.prototype.dispatchEvent = function(e) {
		var t = g(this._fragmentFiber);
		if (t === null) return !0;
		t = b(t);
		var n = this._eventListeners;
		if (n !== null && 0 < n.length || !e.bubbles) {
			var r = t.nodeType === 9 ? t.createComment("") : document.createTextNode("");
			if (n) for (var i = 0; i < n.length; i++) {
				var a = n[i];
				r.addEventListener(a.type, a.attachedListener, Rp(a.optionsOrUseCapture));
			}
			if (t.appendChild(r), e = r.dispatchEvent(e), n) for (i = 0; i < n.length; i++) a = n[i], r.removeEventListener(a.type, a.attachedListener, Rp(a.optionsOrUseCapture));
			return t.removeChild(r), e;
		}
		return t.dispatchEvent(e);
	}, Fp.prototype.focus = function(e) {
		h(this._fragmentFiber.child, !0, Vp, e, void 0, void 0);
	};
	function Vp(e, t) {
		return e.tag !== 6 && (e = b(e), pm(e, t));
	}
	Fp.prototype.focusLast = function(e) {
		var t = [];
		h(this._fragmentFiber.child, !0, Hp, t, void 0, void 0);
		for (var n = t.length - 1; 0 <= n && !Vp(t[n], e); n--);
	};
	function Hp(e, t) {
		return t.push(e), !1;
	}
	Fp.prototype.blur = function() {
		var e = g(this._fragmentFiber);
		e !== null && (e = b(e), e = lp(e).activeElement, e !== null && h(this._fragmentFiber.child, !1, Up, e, void 0, void 0));
	};
	function Up(e, t) {
		return e.tag !== 6 && (e = b(e), e === t || e.contains(t) ? (t.blur(), !0) : !1);
	}
	Fp.prototype.observeUsing = function(e) {
		this._observers === null && (this._observers = /* @__PURE__ */ new Set()), this._observers.add(e), h(this._fragmentFiber.child, !1, Wp, e, void 0, void 0);
	};
	function Wp(e, t) {
		return e.tag === 6 || (e = b(e), t.observe(e)), !1;
	}
	Fp.prototype.unobserveUsing = function(e) {
		var t = this._observers;
		if (t !== null && t.has(e)) {
			t.delete(e), h(this._fragmentFiber.child, !1, Gp, e, void 0, void 0);
			for (var n = t = 0; n < Kp.length; n++) {
				var r = Kp[n];
				r.fragmentInstance === this && r.observer === e ? e.unobserve(r.instance) : Kp[t++] = r;
			}
			Kp.length = t;
		}
	};
	function Gp(e, t) {
		return e.tag === 6 || (e = b(e), t.unobserve(e)), !1;
	}
	var Kp = [], qp = !1;
	function Jp(e, t, n) {
		Kp.push({
			fragmentInstance: e,
			observer: t,
			instance: n
		}), qp || (qp = !0, mm(function() {
			qp = !1;
			var e = Kp;
			Kp = [];
			for (var t = 0; t < e.length; t++) {
				var n = e[t];
				n.observer.unobserve(n.instance);
			}
		}));
	}
	Fp.prototype.getClientRects = function() {
		var e = [];
		return h(this._fragmentFiber.child, !1, Yp, e, void 0, void 0), e;
	};
	function Yp(e, t) {
		if (e.tag === 6) {
			e = e.stateNode;
			var n = e.ownerDocument.createRange();
			n.selectNodeContents(e), t.push.apply(t, n.getClientRects());
		} else e = b(e), t.push.apply(t, e.getClientRects());
		return !1;
	}
	Fp.prototype.getRootNode = function(e) {
		var t = g(this._fragmentFiber);
		return t === null ? this : b(t).getRootNode(e);
	}, Fp.prototype.compareDocumentPosition = function(e) {
		var t = g(this._fragmentFiber);
		if (t === null) return Node.DOCUMENT_POSITION_DISCONNECTED;
		var n = [];
		h(this._fragmentFiber.child, !1, Hp, n, void 0, void 0);
		var r = b(t);
		if (n.length === 0) {
			if (n = r, _(this._fragmentFiber)) {
				a: {
					for (t = this._fragmentFiber.return; t !== null;) {
						if (t.tag === 4) {
							t = t.stateNode.containerInfo;
							break a;
						}
						if (t.tag === 3 || t.tag === 5 || t.tag === 27) break;
						t = t.return;
					}
					t = null;
				}
				t != null && (n = t);
			}
			t = this._fragmentFiber;
			var i = r = n.compareDocumentPosition(e);
			return n === e ? i = Node.DOCUMENT_POSITION_CONTAINS : r & Node.DOCUMENT_POSITION_CONTAINED_BY && (n = v(t)[1], n === null ? i = Node.DOCUMENT_POSITION_PRECEDING : (e = b(n).compareDocumentPosition(e), i = e === 0 || e & Node.DOCUMENT_POSITION_FOLLOWING ? Node.DOCUMENT_POSITION_FOLLOWING : Node.DOCUMENT_POSITION_PRECEDING)), i |= Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC;
		}
		t = b(n[0]), i = b(n[n.length - 1]);
		var a = _(this._fragmentFiber) ? t.parentElement : r;
		if (a == null) return Node.DOCUMENT_POSITION_DISCONNECTED;
		r = a.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_CONTAINED_BY, a = a.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_CONTAINED_BY;
		var o = t.compareDocumentPosition(e), s = i.compareDocumentPosition(e), c = o & Node.DOCUMENT_POSITION_CONTAINED_BY || s & Node.DOCUMENT_POSITION_CONTAINED_BY;
		return s = r && a && o & Node.DOCUMENT_POSITION_FOLLOWING && s & Node.DOCUMENT_POSITION_PRECEDING, t = r && t === e || a && i === e || c || s ? Node.DOCUMENT_POSITION_CONTAINED_BY : !r && t === e || !a && i === e ? Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC : o, t & Node.DOCUMENT_POSITION_DISCONNECTED || t & Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC || Xp(t, this._fragmentFiber, n[0], n[n.length - 1], e) ? t : Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC;
	};
	function Xp(e, t, n, r, i) {
		var a = At(i);
		if (e & Node.DOCUMENT_POSITION_CONTAINED_BY) {
			if (n = !!a) a: {
				for (; a !== null;) {
					if (a.tag === 7 && (a === t || a.alternate === t)) {
						n = !0;
						break a;
					}
					a = a.return;
				}
				n = !1;
			}
			return n;
		}
		if (e & Node.DOCUMENT_POSITION_CONTAINS) {
			if (a === null) return a = i.ownerDocument, i === a || i === a.documentElement || i === a.body;
			a: {
				for (a = t, t = g(t); a !== null;) {
					if (!(a.tag !== 5 && a.tag !== 3 && a.tag !== 27 || a !== t && a.alternate !== t)) {
						a = !0;
						break a;
					}
					a = a.return;
				}
				a = !1;
			}
			return a;
		}
		return e & Node.DOCUMENT_POSITION_PRECEDING ? ((t = !!a) && !(t = a === n) && (t = E(n, a, T), t === null ? t = !1 : (h(t, !0, C, a, n), a = x, x = null, t = a !== null)), t) : e & Node.DOCUMENT_POSITION_FOLLOWING ? ((t = !!a) && !(t = a === r) && (t = E(r, a, T), t === null ? t = !1 : (h(t, !0, w, a, r), a = x, S = x = null, t = a !== null)), t) : !1;
	}
	function Zp(e, t) {
		var n = e.ownerDocument.createRange();
		n.selectNodeContents(e), e = n.getBoundingClientRect(), window.scrollTo(window.scrollX + e.left, t ? window.scrollY + e.top : window.scrollY + e.bottom - window.innerHeight);
	}
	Fp.prototype.scrollIntoView = function(e) {
		if (typeof e == "object") throw Error(i(566));
		var t = [];
		h(this._fragmentFiber.child, !1, Hp, t, void 0, void 0);
		var n = !1 !== e;
		if (t.length === 0) {
			var r = v(this._fragmentFiber);
			if (r = n ? r[1] || r[0] || g(this._fragmentFiber) : r[0] || r[1], r === null) return;
			if (r.tag === 6) {
				e = b(r), Zp(e, n);
				return;
			}
			if (r = b(r), r.nodeType !== 9) {
				if (r.nodeType === 11) {
					n = "host" in r ? r.host : null, n !== null && n.scrollIntoView(e);
					return;
				}
				r.scrollIntoView(e);
			}
		}
		for (r = n ? t.length - 1 : 0; r !== (n ? -1 : t.length);) {
			var a = t[r];
			a.tag === 6 ? (a = b(a), Zp(a, n)) : b(a).scrollIntoView(e), r += n ? -1 : 1;
		}
	};
	function Qp(e, t) {
		return e = b(e), $p(e, t), !1;
	}
	function $p(e, t) {
		e.reactFragments ??= /* @__PURE__ */ new Set(), e.reactFragments.add(t);
	}
	function em(e, t) {
		var n = t._eventListeners;
		if (n !== null) for (var r = 0; r < n.length; r++) {
			var i = n[r];
			e.addEventListener(i.type, i.attachedListener, Rp(i.optionsOrUseCapture));
		}
		e.nodeType !== 3 && (n = t._observers, n !== null && n.forEach(function(n) {
			for (var r = 0, i = 0; i < Kp.length; i++) {
				var a = Kp[i];
				(a.fragmentInstance !== t || a.observer !== n || a.instance !== e) && (Kp[r++] = a);
			}
			Kp.length = r, n.observe(e);
		}), $p(e, t));
	}
	function tm(e, t) {
		var n = t._eventListeners;
		if (n !== null) for (var r = 0; r < n.length; r++) {
			var i = n[r];
			e.removeEventListener(i.type, i.attachedListener, Rp(i.optionsOrUseCapture));
		}
		e.nodeType !== 3 && (n = t._observers, n !== null && n.forEach(function(n) {
			typeof n.rootMargin == "string" ? Jp(t, n, e) : n.unobserve(e);
		}), e.reactFragments != null && e.reactFragments.delete(t));
	}
	function nm(e) {
		var t = e.firstChild;
		for (t && t.nodeType === 10 && (t = t.nextSibling); t;) {
			var n = t;
			switch (t = t.nextSibling, n.nodeName) {
				case "HTML":
				case "HEAD":
				case "BODY":
					nm(n), kt(n);
					continue;
				case "SCRIPT":
				case "STYLE": continue;
				case "LINK": if (n.rel.toLowerCase() === "stylesheet") continue;
			}
			e.removeChild(n);
		}
	}
	function rm(e, t, n, r) {
		for (; e.nodeType === 1;) {
			var i = n;
			if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
				if (!r && (e.nodeName !== "INPUT" || e.type !== "hidden")) break;
			} else if (!r) {
				if (t === "input" && e.type === "hidden") {
					var a = i.name == null ? null : "" + i.name;
					if (i.type === "hidden" && e.getAttribute("name") === a) return e;
				} else return e;
			} else if (!e[Dt]) switch (t) {
				case "meta":
					if (!e.hasAttribute("itemprop")) break;
					return e;
				case "link":
					if (a = e.getAttribute("rel"), a === "stylesheet" && e.hasAttribute("data-precedence") || a !== i.rel || e.getAttribute("href") !== (i.href == null || i.href === "" ? null : i.href) || e.getAttribute("crossorigin") !== (i.crossOrigin == null ? null : i.crossOrigin) || e.getAttribute("title") !== (i.title == null ? null : i.title)) break;
					return e;
				case "style":
					if (e.hasAttribute("data-precedence")) break;
					return e;
				case "script":
					if (a = e.getAttribute("src"), (a !== (i.src == null ? null : i.src) || e.getAttribute("type") !== (i.type == null ? null : i.type) || e.getAttribute("crossorigin") !== (i.crossOrigin == null ? null : i.crossOrigin)) && a && e.hasAttribute("async") && !e.hasAttribute("itemprop")) break;
					return e;
				default: return e;
			}
			if (e = lm(e.nextSibling), e === null) break;
		}
		return null;
	}
	function im(e, t, n) {
		if (t === "") return null;
		for (; e.nodeType !== 3;) if ((e.nodeType !== 1 || e.nodeName !== "INPUT" || e.type !== "hidden") && !n || (e = lm(e.nextSibling), e === null)) return null;
		return e;
	}
	function am(e, t) {
		for (; e.nodeType !== 8;) if ((e.nodeType !== 1 || e.nodeName !== "INPUT" || e.type !== "hidden") && !t || (e = lm(e.nextSibling), e === null)) return null;
		return e;
	}
	function om(e) {
		return e.data === "$?" || e.data === "$~";
	}
	function sm(e) {
		return e.data === "$!" || e.data === "$?" && e.ownerDocument.readyState !== "loading";
	}
	function cm(e, t) {
		var n = e.ownerDocument;
		if (e.data === "$~") e._reactRetry = t;
		else if (e.data !== "$?" || n.readyState !== "loading") t();
		else {
			var r = function() {
				t(), n.removeEventListener("DOMContentLoaded", r);
			};
			n.addEventListener("DOMContentLoaded", r), e._reactRetry = r;
		}
	}
	function lm(e) {
		for (; e != null; e = e.nextSibling) {
			var t = e.nodeType;
			if (t === 1 || t === 3) break;
			if (t === 8) {
				if (t = e.data, t === "$" || t === "$!" || t === "$?" || t === "$~" || t === "&" || t === "F!" || t === "F") break;
				if (t === "/$" || t === "/&") return null;
			}
		}
		return e;
	}
	var um = null;
	function dm(e) {
		e = e.nextSibling;
		for (var t = 0; e;) {
			if (e.nodeType === 8) {
				var n = e.data;
				if (n === "/$" || n === "/&") {
					if (t === 0) return lm(e.nextSibling);
					t--;
				} else n !== "$" && n !== "$!" && n !== "$?" && n !== "$~" && n !== "&" || t++;
			}
			e = e.nextSibling;
		}
		return null;
	}
	function fm(e) {
		e = e.previousSibling;
		for (var t = 0; e;) {
			if (e.nodeType === 8) {
				var n = e.data;
				if (n === "$" || n === "$!" || n === "$?" || n === "$~" || n === "&") {
					if (t === 0) return e;
					t--;
				} else n !== "/$" && n !== "/&" || t++;
			}
			e = e.previousSibling;
		}
		return null;
	}
	function pm(e, t) {
		function n() {
			r = !0;
		}
		if (e.ownerDocument.activeElement === e) return !0;
		var r = !1;
		try {
			e.ownerDocument.addEventListener("focus", n, !0), (e.focus || HTMLElement.prototype.focus).call(e, t);
		} finally {
			e.ownerDocument.removeEventListener("focus", n, !0);
		}
		return r;
	}
	function mm(e) {
		yp(function() {
			yp(function(t) {
				return e(t);
			});
		});
	}
	function hm(e, t, n) {
		switch (t = lp(n), e) {
			case "html":
				if (e = t.documentElement, !e) throw Error(i(452));
				return e;
			case "head":
				if (e = t.head, !e) throw Error(i(453));
				return e;
			case "body":
				if (e = t.body, !e) throw Error(i(454));
				return e;
			default: throw Error(i(451));
		}
	}
	function gm(e, t, n) {
		for (var r in n) {
			var i = n[r];
			n.hasOwnProperty(r) && i != null && $(e, t, r, null, rp, i);
		}
		n.dangerouslySetInnerHTML != null && (e.textContent = ""), e.onclick === hn && (e.onclick = null), kt(e);
	}
	function _m(e) {
		for (var t = e.attributes; t.length;) e.removeAttributeNode(t[0]);
		kt(e);
	}
	var vm = /* @__PURE__ */ new Map(), ym = /* @__PURE__ */ new Set();
	function bm(e) {
		if (typeof e.getRootNode == "function") {
			var t = e.getRootNode();
			if (t.nodeType === 9 || t.nodeType === 11) return t;
		}
		return e.nodeType === 9 ? e : e.ownerDocument;
	}
	var xm = N.d;
	N.d = {
		f: Sm,
		r: Cm,
		D: Em,
		C: Dm,
		L: Om,
		m: km,
		X: jm,
		S: Am,
		M: Mm
	};
	function Sm() {
		var e = xm.f(), t = zd();
		return e || t;
	}
	function Cm(e) {
		var t = jt(e);
		t !== null && t.tag === 5 && t.type === "form" ? ec(t) : xm.r(e);
	}
	var wm = typeof document > "u" ? null : document;
	function Tm(e, t, n) {
		var r = wm;
		if (r && typeof t == "string" && t) {
			var i = $t(t);
			i = "link[rel=\"" + e + "\"][href=\"" + i + "\"]", typeof n == "string" && (i += "[crossorigin=\"" + n + "\"]"), ym.has(i) || (ym.add(i), e = {
				rel: e,
				crossOrigin: n,
				href: t
			}, r.querySelector(i) === null && (t = r.createElement("link"), np(t, "link", e), V(t), r.head.appendChild(t)));
		}
	}
	function Em(e) {
		xm.D(e), Tm("dns-prefetch", e, null);
	}
	function Dm(e, t) {
		xm.C(e, t), Tm("preconnect", e, t);
	}
	function Om(e, t, n) {
		xm.L(e, t, n);
		var r = wm;
		if (r && e && t) {
			var i = "link[rel=\"preload\"][as=\"" + $t(t) + "\"]";
			t === "image" && n && n.imageSrcSet ? (i += "[imagesrcset=\"" + $t(n.imageSrcSet) + "\"]", typeof n.imageSizes == "string" && (i += "[imagesizes=\"" + $t(n.imageSizes) + "\"]")) : i += "[href=\"" + $t(e) + "\"]";
			var a = i;
			switch (t) {
				case "style":
					a = Pm(e);
					break;
				case "script": a = Rm(e);
			}
			if (!(vm.has(a) || (e = D({
				rel: "preload",
				href: t === "image" && n && n.imageSrcSet ? void 0 : e,
				as: t
			}, n), vm.set(a, e), r.querySelector(i) !== null || t === "style" && r.querySelector(Fm(a)) || t === "script" && r.querySelector(zm(a))))) {
				var o = r.createElement("link");
				np(o, "link", e), t === "style" && (o[Ot] = !0, o.onload = o.onerror = function() {
					Pt(o);
				}), V(o), r.head.appendChild(o);
			}
		}
	}
	function km(e, t) {
		xm.m(e, t);
		var n = wm;
		if (n && e) {
			var r = t && typeof t.as == "string" ? t.as : "script", i = "link[rel=\"modulepreload\"][as=\"" + $t(r) + "\"][href=\"" + $t(e) + "\"]", a = i;
			switch (r) {
				case "audioworklet":
				case "paintworklet":
				case "serviceworker":
				case "sharedworker":
				case "worker":
				case "script": a = Rm(e);
			}
			if (!vm.has(a) && (e = D({
				rel: "modulepreload",
				href: e
			}, t), vm.set(a, e), n.querySelector(i) === null)) {
				switch (r) {
					case "audioworklet":
					case "paintworklet":
					case "serviceworker":
					case "sharedworker":
					case "worker":
					case "script": if (n.querySelector(zm(a))) return;
				}
				r = n.createElement("link"), np(r, "link", e), V(r), n.head.appendChild(r);
			}
		}
	}
	function Am(e, t, n) {
		xm.S(e, t, n);
		var r = wm;
		if (r && e) {
			var i = Nt(r).hoistableStyles, a = Pm(e);
			t ||= "default";
			var o = i.get(a);
			if (!o) {
				var s = {
					loading: 0,
					preload: null
				};
				if (o = r.querySelector(Fm(a))) s.loading = 5;
				else {
					e = D({
						rel: "stylesheet",
						href: e,
						"data-precedence": t
					}, n), (n = vm.get(a)) && Hm(e, n);
					var c = o = r.createElement("link");
					V(c), np(c, "link", e), c._p = new Promise(function(e, t) {
						c.onload = e, c.onerror = t;
					}), c.addEventListener("load", function() {
						s.loading |= 1;
					}), c.addEventListener("error", function() {
						s.loading |= 2;
					}), s.loading |= 4, Vm(o, t, r);
				}
				o = {
					type: "stylesheet",
					instance: o,
					count: 1,
					state: s
				}, i.set(a, o);
			}
		}
	}
	function jm(e, t) {
		xm.X(e, t);
		var n = wm;
		if (n && e) {
			var r = Nt(n).hoistableScripts, i = Rm(e), a = r.get(i);
			a || (a = n.querySelector(zm(i)), a || (e = D({
				src: e,
				async: !0
			}, t), (t = vm.get(i)) && Um(e, t), a = n.createElement("script"), V(a), np(a, "link", e), n.head.appendChild(a)), a = {
				type: "script",
				instance: a,
				count: 1,
				state: null
			}, r.set(i, a));
		}
	}
	function Mm(e, t) {
		xm.M(e, t);
		var n = wm;
		if (n && e) {
			var r = Nt(n).hoistableScripts, i = Rm(e), a = r.get(i);
			a || (a = n.querySelector(zm(i)), a || (e = D({
				src: e,
				async: !0,
				type: "module"
			}, t), (t = vm.get(i)) && Um(e, t), a = n.createElement("script"), V(a), np(a, "link", e), n.head.appendChild(a)), a = {
				type: "script",
				instance: a,
				count: 1,
				state: null
			}, r.set(i, a));
		}
	}
	function Nm(e, t, n, r) {
		var a = (a = Te.current) ? bm(a) : null;
		if (!a) throw Error(i(446));
		switch (e) {
			case "meta":
			case "title": return null;
			case "style": return typeof n.precedence == "string" && typeof n.href == "string" ? (n = Pm(n.href), t = Nt(a).hoistableStyles, r = t.get(n), r || (r = {
				type: "style",
				instance: null,
				count: 0,
				state: null
			}, t.set(n, r)), r) : {
				type: "void",
				instance: null,
				count: 0,
				state: null
			};
			case "link":
				if (n.rel === "stylesheet" && typeof n.href == "string" && typeof n.precedence == "string") {
					e = Pm(n.href);
					var o = Nt(a).hoistableStyles, s = o.get(e);
					if (s || (a = a.ownerDocument || a, s = {
						type: "stylesheet",
						instance: null,
						count: 0,
						state: {
							loading: 0,
							preload: null
						}
					}, o.set(e, s), (o = a.querySelector(Fm(e))) ? o._p || (s.instance = o, s.state.loading = 5) : (o = vm.get(e), o || (o = {
						rel: "preload",
						as: "style",
						href: n.href,
						crossOrigin: n.crossOrigin,
						integrity: n.integrity,
						media: n.media,
						hrefLang: n.hrefLang,
						referrerPolicy: n.referrerPolicy
					}, vm.set(e, o)), Lm(a, e, o, s.state))), t && r === null) throw Error(i(528, ""));
					return s;
				}
				if (t && r !== null) throw Error(i(529, ""));
				return null;
			case "script": return t = n.async, n = n.src, typeof n == "string" && t && typeof t != "function" && typeof t != "symbol" ? (n = Rm(n), t = Nt(a).hoistableScripts, r = t.get(n), r || (r = {
				type: "script",
				instance: null,
				count: 0,
				state: null
			}, t.set(n, r)), r) : {
				type: "void",
				instance: null,
				count: 0,
				state: null
			};
			default: throw Error(i(444, e));
		}
	}
	function Pm(e) {
		return "href=\"" + $t(e) + "\"";
	}
	function Fm(e) {
		return "link[rel=\"stylesheet\"][" + e + "]";
	}
	function Im(e) {
		return D({}, e, {
			"data-precedence": e.precedence,
			precedence: null
		});
	}
	function Lm(e, t, n, r) {
		if (t = e.querySelector("link[rel=\"preload\"][as=\"style\"][" + t + "]")) {
			if (!0 !== t[Ot]) {
				r.loading = 1;
				return;
			}
		} else t = e.createElement("link"), t[Ot] = !0, t.onload = t.onerror = Pt.bind(null, t), np(t, "link", n), V(t), e.head.appendChild(t);
		r.preload = t, t.addEventListener("load", function() {
			return r.loading |= 1;
		}), t.addEventListener("error", function() {
			return r.loading |= 2;
		});
	}
	function Rm(e) {
		return "[src=\"" + $t(e) + "\"]";
	}
	function zm(e) {
		return "script[async]" + e;
	}
	function Bm(e, t, n) {
		if (t.count++, t.instance === null) switch (t.type) {
			case "style":
				var r = e.querySelector("style[data-href~=\"" + $t(n.href) + "\"]");
				if (r) return t.instance = r, V(r), r;
				var a = D({}, n, {
					"data-href": n.href,
					"data-precedence": n.precedence,
					href: null,
					precedence: null
				});
				return r = (e.ownerDocument || e).createElement("style"), V(r), np(r, "style", a), Vm(r, n.precedence, e), t.instance = r;
			case "stylesheet":
				a = Pm(n.href);
				var o = e.querySelector(Fm(a));
				if (o) return t.state.loading |= 4, t.instance = o, V(o), o;
				r = Im(n), (a = vm.get(a)) && Hm(r, a), o = (e.ownerDocument || e).createElement("link"), V(o);
				var s = o;
				return s._p = new Promise(function(e, t) {
					s.onload = e, s.onerror = t;
				}), np(o, "link", r), t.state.loading |= 4, Vm(o, n.precedence, e), t.instance = o;
			case "script": return o = Rm(n.src), (a = e.querySelector(zm(o))) ? (t.instance = a, V(a), a) : (r = n, (a = vm.get(o)) && (r = D({}, n), Um(r, a)), e = e.ownerDocument || e, a = e.createElement("script"), V(a), np(a, "link", r), e.head.appendChild(a), t.instance = a);
			case "void": return null;
			default: throw Error(i(443, t.type));
		}
		else t.type === "stylesheet" && !(t.state.loading & 4) && (r = t.instance, t.state.loading |= 4, Vm(r, n.precedence, e));
		return t.instance;
	}
	function Vm(e, t, n) {
		for (var r = n.querySelectorAll("link[rel=\"stylesheet\"][data-precedence],style[data-precedence]"), i = r.length ? r[r.length - 1] : null, a = i, o = 0; o < r.length; o++) {
			var s = r[o];
			if (s.dataset.precedence === t) a = s;
			else if (a !== i) break;
		}
		a ? a.parentNode.insertBefore(e, a.nextSibling) : (t = n.nodeType === 9 ? n.head : n, t.insertBefore(e, t.firstChild));
	}
	function Hm(e, t) {
		e.crossOrigin ??= t.crossOrigin, e.referrerPolicy ??= t.referrerPolicy, e.title ??= t.title;
	}
	function Um(e, t) {
		e.crossOrigin ??= t.crossOrigin, e.referrerPolicy ??= t.referrerPolicy, e.integrity ??= t.integrity;
	}
	var Wm = null;
	function Gm(e, t, n) {
		if (Wm === null) {
			var r = /* @__PURE__ */ new Map(), i = Wm = /* @__PURE__ */ new Map();
			i.set(n, r);
		} else i = Wm, r = i.get(n), r || (r = /* @__PURE__ */ new Map(), i.set(n, r));
		if (r.has(e)) return r;
		for (r.set(e, null), n = n.getElementsByTagName(e), i = 0; i < n.length; i++) {
			var a = n[i];
			if (!(a[Dt] || a[B] || e === "link" && a.getAttribute("rel") === "stylesheet") && a.namespaceURI !== "http://www.w3.org/2000/svg") {
				var o = a.getAttribute(t) || "";
				o = e + o;
				var s = r.get(o);
				s ? s.push(a) : r.set(o, [a]);
			}
		}
		return r;
	}
	function Km(e, t, n) {
		e = e.ownerDocument || e, e.head.insertBefore(n, t === "title" ? e.querySelector("head > title") : null);
	}
	function qm(e, t, n) {
		if (n === 1 || t.itemProp != null) return !1;
		switch (e) {
			case "meta":
			case "title": return !0;
			case "style":
				if (typeof t.precedence != "string" || typeof t.href != "string" || t.href === "") break;
				return !0;
			case "link":
				if (typeof t.rel != "string" || typeof t.href != "string" || t.href === "" || t.onLoad || t.onError) break;
				switch (t.rel) {
					case "stylesheet": return e = t.disabled, typeof t.precedence == "string" && e == null;
					default: return !0;
				}
			case "script": if (t.async && typeof t.async != "function" && typeof t.async != "symbol" && !t.onLoad && !t.onError && t.src && typeof t.src == "string") return !0;
		}
		return !1;
	}
	function Jm(e, t) {
		return e === "img" && t.src != null && t.src !== "" && t.onLoad == null && t.loading !== "lazy";
	}
	function Ym(e) {
		return !(e.type === "stylesheet" && !(e.state.loading & 3));
	}
	function Xm(e) {
		return (e.width || 100) * (e.height || 100) * (typeof devicePixelRatio == "number" ? devicePixelRatio : 1) * .25;
	}
	function Zm(e, t) {
		typeof t.decode == "function" && (e.imgCount++, t.complete || (e.imgBytes += Xm(t), e.suspenseyImages.push(t)), e = rh.bind(e), t.decode().then(e, e));
	}
	function Qm(e, t, n, r) {
		if (n.type === "stylesheet" && (typeof r.media != "string" || !1 !== matchMedia(r.media).matches) && !(n.state.loading & 4)) {
			if (n.instance === null) {
				var i = Pm(r.href), a = t.querySelector(Fm(i));
				if (a) {
					t = a._p, typeof t == "object" && t && typeof t.then == "function" && (e.count++, e = nh.bind(e), t.then(e, e)), n.state.loading |= 4, n.instance = a, V(a);
					return;
				}
				a = t.ownerDocument || t, r = Im(r), (i = vm.get(i)) && Hm(r, i), a = a.createElement("link"), V(a);
				var o = a;
				o._p = new Promise(function(e, t) {
					o.onload = e, o.onerror = t;
				}), np(a, "link", r), n.instance = a;
			}
			e.stylesheets === null && (e.stylesheets = /* @__PURE__ */ new Map()), e.stylesheets.set(n, t), (t = n.state.preload) && !(n.state.loading & 3) && (e.count++, n = nh.bind(e), t.addEventListener("load", n), t.addEventListener("error", n));
		}
	}
	var $m = 0;
	function eh(e, t) {
		return e.stylesheets && e.count === 0 && ah(e, e.stylesheets), 0 < e.count || 0 < e.imgCount ? function(n) {
			var r = setTimeout(function() {
				if (e.stylesheets && ah(e, e.stylesheets), e.unsuspend) {
					var t = e.unsuspend;
					e.unsuspend = null, t();
				}
			}, 6e4 + t);
			0 < e.imgBytes && $m === 0 && ($m = 62500 * op());
			var i = setTimeout(function() {
				if (e.waitingForImages = !1, e.count === 0 && (e.stylesheets && ah(e, e.stylesheets), e.unsuspend)) {
					var t = e.unsuspend;
					e.unsuspend = null, t();
				}
			}, (e.imgBytes > $m ? 50 : 800) + t);
			return e.unsuspend = n, function() {
				e.unsuspend = null, clearTimeout(r), clearTimeout(i);
			};
		} : null;
	}
	function th(e) {
		if (e.count === 0 && (e.imgCount === 0 || !e.waitingForImages)) {
			if (e.stylesheets) ah(e, e.stylesheets);
			else if (e.unsuspend) {
				var t = e.unsuspend;
				e.unsuspend = null, t();
			}
		}
	}
	function nh() {
		this.count--, th(this);
	}
	function rh() {
		this.imgCount--, th(this);
	}
	var ih = null;
	function ah(e, t) {
		e.stylesheets = null, e.unsuspend !== null && (e.count++, ih = /* @__PURE__ */ new Map(), t.forEach(oh, e), ih = null, nh.call(e));
	}
	function oh(e, t) {
		if (!(t.state.loading & 4)) {
			var n = ih.get(e);
			if (n) var r = n.get(null);
			else {
				n = /* @__PURE__ */ new Map(), ih.set(e, n);
				for (var i = e.querySelectorAll("link[data-precedence],style[data-precedence]"), a = 0; a < i.length; a++) {
					var o = i[a];
					(o.nodeName === "LINK" || o.getAttribute("media") !== "not all") && (n.set(o.dataset.precedence, o), r = o);
				}
				r && n.set(null, r);
			}
			i = t.instance, o = i.getAttribute("data-precedence"), a = n.get(o) || r, a === r && n.set(null, i), n.set(o, i), this.count++, r = nh.bind(this), i.addEventListener("load", r), i.addEventListener("error", r), a ? a.parentNode.insertBefore(i, a.nextSibling) : (e = e.nodeType === 9 ? e.head : e, e.insertBefore(i, e.firstChild)), t.state.loading |= 4;
		}
	}
	var sh = {
		$$typeof: A,
		Provider: null,
		Consumer: null,
		_currentValue: ye,
		_currentValue2: ye,
		_threadCount: 0
	};
	function ch(e, t, n, r, i, a, o, s, c) {
		this.tag = 1, this.containerInfo = e, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = ut(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = ut(0), this.hiddenUpdates = ut(null), this.identifierPrefix = r, this.onUncaughtError = i, this.onCaughtError = a, this.onRecoverableError = o, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = c, this.transitionTypes = null, this.incompleteTransitions = /* @__PURE__ */ new Map();
	}
	function lh(e, t, n, r, i, a, o, s, c, l, u, d) {
		return e = new ch(e, t, n, o, c, l, u, d, s), t = 1, !0 === a && (t |= 24), a = Oi(3, null, null, t), e.current = a, a.stateNode = e, t = Oa(), t.refCount++, e.pooledCache = t, t.refCount++, a.memoizedState = {
			element: r,
			isDehydrated: n,
			cache: t
		}, uo(a), e;
	}
	function uh(e) {
		return e ? (e = Ei, e) : Ei;
	}
	function dh(e, t, n, r, i, a) {
		i = uh(i), r.context === null ? r.context = i : r.pendingContext = i, r = po(t), r.payload = { element: n }, a = a === void 0 ? null : a, a !== null && (r.callback = a), n = mo(e, r, t), n !== null && (Pd(n, e, t), ho(n, e, t));
	}
	function fh(e, t) {
		if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
			var n = e.retryLane;
			e.retryLane = n !== 0 && n < t ? n : t;
		}
	}
	function ph(e, t) {
		fh(e, t), (e = e.alternate) && fh(e, t);
	}
	function mh(e) {
		if (e.tag === 13 || e.tag === 31) {
			var t = Ci(e, 67108864);
			t !== null && Pd(t, e, 67108864), ph(e, 67108864);
		}
	}
	function hh(e) {
		if (e.tag === 13 || e.tag === 31) {
			var t = jd();
			t = gt(t);
			var n = Ci(e, t);
			n !== null && Pd(n, e, t), ph(e, t);
		}
	}
	var gh = !0;
	function _h(e, t, n, r) {
		var i = M.T;
		M.T = null;
		var a = N.p;
		try {
			N.p = 2, yh(e, t, n, r);
		} finally {
			N.p = a, M.T = i;
		}
	}
	function vh(e, t, n, r) {
		var i = M.T;
		M.T = null;
		var a = N.p;
		try {
			N.p = 8, yh(e, t, n, r);
		} finally {
			N.p = a, M.T = i;
		}
	}
	function yh(e, t, n, r) {
		if (gh) {
			var i = bh(r);
			if (i === null) Kf(e, t, r, xh, n), Mh(e, r);
			else if (Ph(i, e, t, n, r)) r.stopPropagation();
			else if (Mh(e, r), t & 4 && -1 < jh.indexOf(e)) {
				for (; i !== null;) {
					var a = jt(i);
					if (a !== null) switch (a.tag) {
						case 3:
							if (a = a.stateNode, a.current.memoizedState.isDehydrated) {
								var o = it(a.pendingLanes);
								if (o !== 0) {
									var s = a;
									for (s.pendingLanes |= 2, s.entangledLanes |= 2; o;) {
										var c = 1 << 31 - L(o);
										s.entanglements[1] |= c, o &= ~c;
									}
									Ef(a), !(q & 6) && (gd = He() + 500, Df(0, !1));
								}
							}
							break;
						case 31:
						case 13: s = Ci(a, 2), s !== null && Pd(s, a, 2), zd(), ph(a, 2);
					}
					if (a = bh(r), a === null && Kf(e, t, r, xh, n), a === i) break;
					i = a;
				}
				i !== null && r.stopPropagation();
			} else Kf(e, t, r, null, n);
		}
	}
	function bh(e) {
		return e = _n(e), Sh(e);
	}
	var xh = null;
	function Sh(e) {
		if (xh = null, e = At(e), e !== null) {
			var t = o(e);
			if (t === null) e = null;
			else {
				var n = t.tag;
				if (n === 13) {
					if (e = s(t), e !== null) return e;
					e = null;
				} else if (n === 31) {
					if (e = c(t), e !== null) return e;
					e = null;
				} else if (n === 3) {
					if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
					e = null;
				} else t !== e && (e = null);
			}
		}
		return xh = e, null;
	}
	function Ch(e) {
		switch (e) {
			case "beforetoggle":
			case "cancel":
			case "click":
			case "close":
			case "contextmenu":
			case "copy":
			case "cut":
			case "auxclick":
			case "dblclick":
			case "dragend":
			case "dragstart":
			case "drop":
			case "focusin":
			case "focusout":
			case "input":
			case "invalid":
			case "keydown":
			case "keypress":
			case "keyup":
			case "mousedown":
			case "mouseup":
			case "paste":
			case "pause":
			case "play":
			case "pointercancel":
			case "pointerdown":
			case "pointerup":
			case "ratechange":
			case "reset":
			case "seeked":
			case "submit":
			case "toggle":
			case "touchcancel":
			case "touchend":
			case "touchstart":
			case "volumechange":
			case "change":
			case "selectionchange":
			case "textInput":
			case "compositionstart":
			case "compositionend":
			case "compositionupdate":
			case "beforeblur":
			case "afterblur":
			case "beforeinput":
			case "blur":
			case "fullscreenchange":
			case "fullscreenerror":
			case "focus":
			case "hashchange":
			case "popstate":
			case "select":
			case "selectstart": return 2;
			case "drag":
			case "dragenter":
			case "dragexit":
			case "dragleave":
			case "dragover":
			case "mousemove":
			case "mouseout":
			case "mouseover":
			case "pointermove":
			case "pointerout":
			case "pointerover":
			case "resize":
			case "scroll":
			case "touchmove":
			case "wheel":
			case "mouseenter":
			case "mouseleave":
			case "pointerenter":
			case "pointerleave": return 8;
			case "message": switch (Ue()) {
				case We: return 2;
				case Ge: return 8;
				case Ke:
				case qe: return 32;
				case Je: return 268435456;
				default: return 32;
			}
			default: return 32;
		}
	}
	var wh = !1, Th = null, Eh = null, Dh = null, Oh = /* @__PURE__ */ new Map(), kh = /* @__PURE__ */ new Map(), Ah = [], jh = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");
	function Mh(e, t) {
		switch (e) {
			case "focusin":
			case "focusout":
				Th = null;
				break;
			case "dragenter":
			case "dragleave":
				Eh = null;
				break;
			case "mouseover":
			case "mouseout":
				Dh = null;
				break;
			case "pointerover":
			case "pointerout":
				Oh.delete(t.pointerId);
				break;
			case "gotpointercapture":
			case "lostpointercapture": kh.delete(t.pointerId);
		}
	}
	function Nh(e, t, n, r, i, a) {
		return e === null || e.nativeEvent !== a ? (e = {
			blockedOn: t,
			domEventName: n,
			eventSystemFlags: r,
			nativeEvent: a,
			targetContainers: [i]
		}, t !== null && (t = jt(t), t !== null && mh(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, i !== null && t.indexOf(i) === -1 && t.push(i), e);
	}
	function Ph(e, t, n, r, i) {
		switch (t) {
			case "focusin": return Th = Nh(Th, e, t, n, r, i), !0;
			case "dragenter": return Eh = Nh(Eh, e, t, n, r, i), !0;
			case "mouseover": return Dh = Nh(Dh, e, t, n, r, i), !0;
			case "pointerover":
				var a = i.pointerId;
				return Oh.set(a, Nh(Oh.get(a) || null, e, t, n, r, i)), !0;
			case "gotpointercapture": return a = i.pointerId, kh.set(a, Nh(kh.get(a) || null, e, t, n, r, i)), !0;
		}
		return !1;
	}
	function Fh(e) {
		var t = At(e.target);
		if (t !== null) {
			var n = o(t);
			if (n !== null) {
				if (t = n.tag, t === 13) {
					if (t = s(n), t !== null) {
						e.blockedOn = t, yt(e.priority, function() {
							hh(n);
						});
						return;
					}
				} else if (t === 31) {
					if (t = c(n), t !== null) {
						e.blockedOn = t, yt(e.priority, function() {
							hh(n);
						});
						return;
					}
				} else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
					e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
					return;
				}
			}
		}
		e.blockedOn = null;
	}
	function Ih(e) {
		if (e.blockedOn !== null) return !1;
		for (var t = e.targetContainers; 0 < t.length;) {
			var n = bh(e.nativeEvent);
			if (n === null) {
				n = e.nativeEvent;
				var r = new n.constructor(n.type, n);
				gn = r, n.target.dispatchEvent(r), gn = null;
			} else return t = jt(n), t !== null && mh(t), e.blockedOn = n, !1;
			t.shift();
		}
		return !0;
	}
	function Lh(e, t, n) {
		Ih(e) && n.delete(t);
	}
	function Rh() {
		wh = !1, Th !== null && Ih(Th) && (Th = null), Eh !== null && Ih(Eh) && (Eh = null), Dh !== null && Ih(Dh) && (Dh = null), Oh.forEach(Lh), kh.forEach(Lh);
	}
	function zh(e, n) {
		e.blockedOn === n && (e.blockedOn = null, wh || (wh = !0, t.unstable_scheduleCallback(t.unstable_NormalPriority, Rh)));
	}
	var Bh = null;
	function Vh(e) {
		Bh !== e && (Bh = e, t.unstable_scheduleCallback(t.unstable_NormalPriority, function() {
			Bh === e && (Bh = null);
			for (var t = 0; t < e.length; t += 3) {
				var n = e[t], r = e[t + 1], i = e[t + 2];
				if (typeof r != "function") {
					if (Sh(r || n) === null) continue;
					break;
				}
				var a = jt(n);
				a !== null && (e.splice(t, 3), t -= 3, Qs(a, {
					pending: !0,
					data: i,
					method: n.method,
					action: r
				}, r, i));
			}
		}));
	}
	function Hh(e) {
		function t(t) {
			return zh(t, e);
		}
		Th !== null && zh(Th, e), Eh !== null && zh(Eh, e), Dh !== null && zh(Dh, e), Oh.forEach(t), kh.forEach(t);
		for (var n = 0; n < Ah.length; n++) {
			var r = Ah[n];
			r.blockedOn === e && (r.blockedOn = null);
		}
		for (; 0 < Ah.length && (n = Ah[0], n.blockedOn === null);) Fh(n), n.blockedOn === null && Ah.shift();
		if (n = (e.ownerDocument || e).$$reactFormReplay, n != null) for (r = 0; r < n.length; r += 3) {
			var i = n[r], a = n[r + 1], o = i[xt] || null;
			if (typeof a == "function") o || Vh(n);
			else if (o) {
				var s = null;
				if (a && a.hasAttribute("formAction")) {
					if (i = a, o = a[xt] || null) s = o.formAction;
					else if (Sh(i) !== null) continue;
				} else s = o.action;
				typeof s == "function" ? n[r + 1] = s : (n.splice(r, 3), r -= 3), Vh(n);
			}
		}
	}
	function Uh() {
		function e(e) {
			e.canIntercept && e.info === "react-transition" && e.intercept({
				handler: function() {
					return new Promise(function(e) {
						return i = e;
					});
				},
				focusReset: "manual",
				scroll: "manual"
			});
		}
		function t() {
			i !== null && (i(), i = null), r || setTimeout(n, 20);
		}
		function n() {
			if (!r && !navigation.transition) {
				var e = navigation.currentEntry;
				e && e.url != null && navigation.navigate(e.url, {
					state: e.getState(),
					info: "react-transition",
					history: "replace"
				});
			}
		}
		if (typeof navigation == "object") {
			var r = !1, i = null;
			return navigation.addEventListener("navigate", e), navigation.addEventListener("navigatesuccess", t), navigation.addEventListener("navigateerror", t), setTimeout(n, 100), function() {
				r = !0, navigation.removeEventListener("navigate", e), navigation.removeEventListener("navigatesuccess", t), navigation.removeEventListener("navigateerror", t), i !== null && (i(), i = null);
			};
		}
	}
	function Wh(e) {
		this._internalRoot = e;
	}
	Gh.prototype.render = Wh.prototype.render = function(e) {
		var t = this._internalRoot;
		if (t === null) throw Error(i(409));
		var n = t.current;
		dh(n, jd(), e, t, null, null);
	}, Gh.prototype.unmount = Wh.prototype.unmount = function() {
		var e = this._internalRoot;
		if (e !== null) {
			this._internalRoot = null;
			var t = e.containerInfo;
			dh(e.current, 2, null, e, null, null), zd(), t[St] = null;
		}
	};
	function Gh(e) {
		this._internalRoot = e;
	}
	Gh.prototype.unstable_scheduleHydration = function(e) {
		if (e) {
			var t = vt();
			e = {
				blockedOn: null,
				target: e,
				priority: t
			};
			for (var n = 0; n < Ah.length && t !== 0 && t < Ah[n].priority; n++);
			Ah.splice(n, 0, e), n === 0 && Fh(e);
		}
	};
	var Kh = n.version;
	if (Kh !== "19.3.1") throw Error(i(527, Kh, "19.3.1"));
	N.findDOMNode = function(e) {
		var t = e._reactInternals;
		if (t === void 0) throw typeof e.render == "function" ? Error(i(188)) : (e = Object.keys(e).join(","), Error(i(268, e)));
		return e = d(t), e = e === null ? null : p(e), e = e === null ? null : e.stateNode, e;
	};
	var qh = {
		bundleType: 0,
		version: "19.3.1",
		rendererPackageName: "react-dom",
		currentDispatcherRef: M,
		reconcilerVersion: "19.3.1"
	};
	if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
		var Jh = __REACT_DEVTOOLS_GLOBAL_HOOK__;
		if (!Jh.isDisabled && Jh.supportsFiber) try {
			Ze = Jh.inject(qh), Qe = Jh;
		} catch {}
	}
	e.createRoot = function(e, t) {
		if (!a(e)) throw Error(i(299));
		var n = !1, r = "", o = xc, s = Sc, c = Cc;
		return t != null && (!0 === t.unstable_strictMode && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onUncaughtError !== void 0 && (o = t.onUncaughtError), t.onCaughtError !== void 0 && (s = t.onCaughtError), t.onRecoverableError !== void 0 && (c = t.onRecoverableError)), t = lh(e, 1, !1, null, null, n, r, null, o, s, c, Uh), e[St] = t.current, Wf(e), new Wh(t);
	};
})), g = /* @__PURE__ */ o(((e, t) => {
	function n() {
		if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE == "function") try {
			__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n);
		} catch (e) {
			console.error(e);
		}
	}
	n(), t.exports = h();
})), _ = /* @__PURE__ */ c(u(), 1), v = g(), y = "2026-11", b = [
	"january",
	"february",
	"march",
	"april",
	"may",
	"june",
	"july",
	"august",
	"september",
	"october",
	"november",
	"december"
], x = "finance.selected_period", S = (e) => /^\d{4}-(0[1-9]|1[0-2])$/.test(e || ""), C = (e) => {
	if (!S(e)) return "No period";
	let [t, n] = e.split("-").map(Number);
	return `${b[n - 1][0].toUpperCase()}${b[n - 1].slice(1)} ${t}`;
}, w = (e) => S(e) ? `${C(e).slice(0, 3)} ${e.slice(0, 4)}` : "Select month", T = (e) => S(e) ? `FY${e.slice(0, 4)} · P${e.slice(5)}` : "";
function E(e) {
	let t = String(e || "").toLowerCase(), n = t.match(/\b(2025|2026)-(0[1-9]|1[0-2])\b/);
	if (n) return n[0];
	for (let e = 1; e <= 12; e += 1) {
		let n = b[e - 1], r = t.match(RegExp(`\\b(?:${n}|${n.slice(0, 3)})\\s+(2025|2026)\\b`));
		if (r) return `${r[1]}-${String(e).padStart(2, "0")}`;
	}
	return null;
}
function D(e) {
	let t = String(e || "").toLowerCase();
	if (E(t)) return null;
	let n = t.match(/* @__PURE__ */ RegExp("\\b(?:20\\d{2}-(?:0[1-9]|1[0-2])|(?:january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)\\s+20\\d{2})\\b"));
	return n ? n[0] : null;
}
function O() {
	try {
		let e = new URLSearchParams(window.location.search).get("period");
		if (S(e)) return e;
	} catch {}
	try {
		let e = window.sessionStorage.getItem(x);
		if (S(e)) return e;
	} catch {}
	return y;
}
function k(e) {
	try {
		window.sessionStorage.setItem(x, e);
	} catch {}
	try {
		let t = new URL(window.location.href);
		t.searchParams.set("period", e), window.history.replaceState(null, "", t);
	} catch {}
}
// src/cockpit.js
function ee(e = []) {
	let t = e || [], n = Object.fromEntries(t.map((e) => [e.id, e])), r = t.find((e) => e.default) || t[0] || null, i = t.filter((e) => e.routing?.words?.length).map((e) => ({
		id: e.id,
		priority: e.routing.priority,
		re: RegExp(`\\b(${e.routing.words.join("|")})\\b`)
	})), a = (e, t) => String(e || "").replace("{period}", C(t));
	return {
		modules: t,
		byId: n,
		def: r,
		route: (e) => {
			let t = String(e || "").toLowerCase(), n = i.filter((e) => e.re.test(t));
			return n.length ? n.reduce((e, t) => t.priority > e.priority ? t : e).id : r?.id || "reconciliation";
		},
		ask: (e, t) => a((n[e] || r)?.ask_template, t),
		examples: (e, t) => ((n[e] || r)?.examples || []).map((e) => a(e, t)),
		label: (e) => n[e]?.family_label || e || "",
		name: (e) => n[e]?.name || e || "",
		tabs: t.filter((e) => e.tab)
	};
}
var te = (0, _.createContext)(null), ne = ({ value: e, children: t }) => (0, _.createElement)(te.Provider, { value: e }, t), re = () => (0, _.useContext)(te) || ee([]), ie = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element"), n = Symbol.for("react.fragment");
	function r(e, n, r) {
		var i = null;
		if (r !== void 0 && (i = "" + r), n.key !== void 0 && (i = "" + n.key), "key" in n) for (var a in r = {}, n) a !== "key" && (r[a] = n[a]);
		else r = n;
		return n = r.ref, {
			$$typeof: t,
			type: e,
			key: i,
			ref: n === void 0 ? null : n,
			props: r
		};
	}
	e.Fragment = n, e.jsx = r, e.jsxs = r;
})), A = (/* @__PURE__ */ o(((e, t) => {
	t.exports = ie();
})))(), ae = [
	[
		"actor",
		"Actor",
		"#0e7c86",
		"#e9f6f8"
	],
	[
		"process",
		"Process",
		"#6b4fb3",
		"#f1ecfa"
	],
	[
		"entity",
		"Entity",
		"#0a6ed1",
		"#e8f1fb"
	],
	[
		"measure",
		"Measure",
		"#107E3E",
		"#f2faf4"
	],
	[
		"rule",
		"Rule",
		"#d99a25",
		"#fff8eb"
	],
	[
		"artifact",
		"Artifact",
		"#6b7f8f",
		"#f4f6f8"
	]
], oe = Object.fromEntries(ae.map(([e, t, n, r]) => [e, {
	label: t,
	stroke: n,
	fill: r
}])), se = {
	DOCUMENTED: ["Documented by SAP", "ok"],
	SAP_TERM: ["SAP term, not source-checked", "warn"],
	DEMO_ONLY: ["Demo concept only", ""]
}, ce = 190, j = 46, le = 70, ue = 34, de = 12;
function fe(e, t) {
	let n = {}, r = t.filter((t) => e.some((e) => e.module === t.id));
	r.forEach((t, r) => {
		e.filter((e) => e.module === t.id).sort((e, t) => ae.findIndex((t) => t[0] === e.kind) - ae.findIndex((e) => e[0] === t.kind) || e.label.localeCompare(t.label)).forEach((e, t) => {
			n[e.id] = {
				x: de + r * 260,
				y: ue + t * 60
			};
		});
	});
	let i = Math.max(1, ...r.map((t) => e.filter((e) => e.module === t.id).length));
	return {
		pos: n,
		cols: r,
		width: 24 + r.length * ce + Math.max(0, r.length - 1) * le,
		height: ue + i * 60 + de
	};
}
function pe(e, t) {
	if (e.x === t.x) {
		let n = e.x + ce;
		return `M${n},${e.y + j / 2} C${n + 36},${e.y + j / 2} ${n + 36},${t.y + j / 2} ${n},${t.y + j / 2}`;
	}
	let n = e.x < t.x, r = n ? e.x + ce : e.x, i = n ? t.x : t.x + ce, a = Math.max(30, Math.abs(i - r) / 2) * (n ? 1 : -1);
	return `M${r},${e.y + j / 2} C${r + a},${e.y + j / 2} ${i - a},${t.y + j / 2} ${i},${t.y + j / 2}`;
}
function me({ ontology: e, references: t = [], focus: n, onOpenTab: r }) {
	let [i, a] = (0, _.useState)("all"), [o, s] = (0, _.useState)(""), [c, l] = (0, _.useState)(n || null);
	(0, _.useEffect)(() => {
		n && (l(n), a("all"), s(""));
	}, [n]);
	let u = e?.classes || [], d = e?.relations || [], f = e?.modules || [], p = (0, _.useMemo)(() => Object.fromEntries(u.map((e) => [e.id, e])), [u]), m = Object.fromEntries(t.map((e) => [e.id, e])), h = o.trim().toLowerCase(), g = u.filter((e) => (i === "all" || e.module === i || e.module === "core" && i !== "all" && d.some((t) => t.from === e.id && p[t.to]?.module === i || t.to === e.id && p[t.from]?.module === i)) && (!h || `${e.label} ${e.description} ${e.sap_term || ""}`.toLowerCase().includes(h))), v = new Set(g.map((e) => e.id)), { pos: y, cols: b, width: x, height: S } = (0, _.useMemo)(() => fe(g, f), [g.map((e) => e.id).join("|"), f.length]), C = d.filter((e) => v.has(e.from) && v.has(e.to)), w = c && p[c] ? p[c] : null, T = new Set(w ? [w.id, ...C.filter((e) => e.from === w.id || e.to === w.id).flatMap((e) => [e.from, e.to])] : []), E = w ? d.filter((e) => e.from === w.id || e.to === w.id) : [];
	return e ? /* @__PURE__ */ (0, A.jsxs)("main", {
		className: "ontology-page",
		"aria-label": "Ontology",
		"data-testid": "ontology-view",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("header", {
				className: "surface ont-head",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
					/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "ONTOLOGY · THE CONCEPTS THE AGENTS WORK WITH"
					}),
					/* @__PURE__ */ (0, A.jsx)("h2", { children: "Ontology" }),
					/* @__PURE__ */ (0, A.jsxs)("p", { children: [
						u.length,
						" concepts and ",
						d.length,
						" relations. Each agent module brings its own concepts; shared concepts are listed once. ",
						e.note
					] })
				] }), /* @__PURE__ */ (0, A.jsxs)("div", {
					className: "ont-controls",
					children: [
						/* @__PURE__ */ (0, A.jsx)("div", {
							className: "ont-chips",
							role: "group",
							"aria-label": "Show concepts from",
							children: [{
								id: "all",
								name: "All"
							}, ...f].map((e) => /* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								className: i === e.id ? "active" : "",
								"aria-pressed": i === e.id,
								onClick: () => a(e.id),
								children: e.name
							}, e.id))
						}),
						/* @__PURE__ */ (0, A.jsx)("label", {
							className: "sr-only",
							htmlFor: "ont-search",
							children: "Search concepts"
						}),
						/* @__PURE__ */ (0, A.jsx)("input", {
							id: "ont-search",
							type: "search",
							placeholder: "Search concepts",
							value: o,
							onChange: (e) => s(e.target.value)
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "ont-body",
				children: [/* @__PURE__ */ (0, A.jsxs)("section", {
					className: "surface ont-graph",
					"aria-label": "Ontology graph",
					children: [/* @__PURE__ */ (0, A.jsxs)("svg", {
						viewBox: `0 0 ${x} ${S}`,
						width: x,
						height: S,
						role: "img",
						"aria-label": "Concepts and their relations",
						onClick: (e) => {
							e.target.tagName === "svg" && l(null);
						},
						children: [
							b.map((e, t) => /* @__PURE__ */ (0, A.jsx)("text", {
								x: de + t * 260,
								y: 20,
								fontSize: "11",
								fontWeight: "800",
								fill: "#557695",
								letterSpacing: ".05em",
								children: e.name.toUpperCase()
							}, e.id)),
							C.map((e, t) => {
								let n = y[e.from], r = y[e.to], i = w && (e.from === w.id || e.to === w.id), a = (n.x + r.x + ce) / 2, o = (n.y + r.y + j) / 2;
								return /* @__PURE__ */ (0, A.jsxs)("g", {
									opacity: w ? i ? 1 : .08 : .45,
									children: [/* @__PURE__ */ (0, A.jsx)("path", {
										d: pe(n, r),
										fill: "none",
										stroke: i ? "#0a6ed1" : "#8aa2b4",
										strokeWidth: i ? 1.8 : 1
									}), i && /* @__PURE__ */ (0, A.jsx)("text", {
										x: a,
										y: o - 3,
										fontSize: "10",
										textAnchor: "middle",
										fill: "#075793",
										paintOrder: "stroke",
										stroke: "#fff",
										strokeWidth: "3",
										children: e.label
									})]
								}, t);
							}),
							g.map((e) => {
								let t = y[e.id], n = oe[e.kind] || oe.artifact, r = w && !T.has(e.id);
								return /* @__PURE__ */ (0, A.jsxs)("g", {
									"data-testid": "ontology-node",
									"data-id": e.id,
									opacity: r ? .3 : 1,
									tabIndex: 0,
									role: "button",
									"aria-label": `${e.label}, ${n.label}`,
									onClick: () => l(e.id),
									onKeyDown: (t) => {
										(t.key === "Enter" || t.key === " ") && (t.preventDefault(), l(e.id));
									},
									style: { cursor: "pointer" },
									children: [
										/* @__PURE__ */ (0, A.jsx)("rect", {
											x: t.x,
											y: t.y,
											width: ce,
											height: j,
											rx: "5",
											fill: n.fill,
											stroke: w?.id === e.id ? "#0a4f9e" : n.stroke,
											strokeWidth: w?.id === e.id ? 3 : e.sap_status === "DOCUMENTED" ? 2 : 1.2,
											strokeDasharray: e.sap_status === "DEMO_ONLY" ? "4 3" : void 0
										}),
										/* @__PURE__ */ (0, A.jsx)("text", {
											x: t.x + 9,
											y: t.y + 19,
											fontSize: "12",
											fontWeight: "700",
											fill: "#1d2d3e",
											children: e.label.length > 25 ? e.label.slice(0, 24) + "…" : e.label
										}),
										/* @__PURE__ */ (0, A.jsxs)("text", {
											x: t.x + 9,
											y: t.y + 35,
											fontSize: "9.5",
											fill: "#587184",
											children: [
												n.label,
												" · ",
												(se[e.sap_status] || [e.sap_status])[0]
											]
										})
									]
								}, e.id);
							})
						]
					}), /* @__PURE__ */ (0, A.jsxs)("div", {
						className: "ont-legend",
						"aria-label": "Legend",
						children: [
							ae.map(([e, t, n, r]) => /* @__PURE__ */ (0, A.jsxs)("span", { children: [/* @__PURE__ */ (0, A.jsx)("i", { style: {
								background: r,
								borderColor: n
							} }), t] }, e)),
							/* @__PURE__ */ (0, A.jsxs)("span", { children: [/* @__PURE__ */ (0, A.jsx)("i", { className: "dashed" }), "Dashed: demo concept only"] }),
							/* @__PURE__ */ (0, A.jsxs)("span", { children: [/* @__PURE__ */ (0, A.jsx)("i", { className: "solid" }), "Bold: documented by SAP"] })
						]
					})]
				}), /* @__PURE__ */ (0, A.jsx)("aside", {
					className: "surface ont-detail",
					"aria-live": "polite",
					"data-testid": "ontology-detail",
					children: w ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
						/* @__PURE__ */ (0, A.jsxs)("span", {
							className: "eyebrow",
							children: [
								(oe[w.kind] || oe.artifact).label.toUpperCase(),
								" · ",
								(f.find((e) => e.id === w.module) || {}).name
							]
						}),
						/* @__PURE__ */ (0, A.jsx)("h3", { children: w.label }),
						/* @__PURE__ */ (0, A.jsx)("p", { children: w.description }),
						w.properties?.length > 0 && /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [/* @__PURE__ */ (0, A.jsx)("h4", { children: "Properties" }), /* @__PURE__ */ (0, A.jsx)("p", {
							className: "ont-props",
							children: w.properties.join(" · ")
						})] }),
						/* @__PURE__ */ (0, A.jsx)("h4", { children: "SAP grounding" }),
						/* @__PURE__ */ (0, A.jsxs)("p", { children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: `ont-chip ${(se[w.sap_status] || [])[1] || ""}`,
								children: (se[w.sap_status] || [w.sap_status])[0]
							}),
							" ",
							w.sap_term || "No SAP counterpart is claimed."
						] }),
						w.sources?.length > 0 && /* @__PURE__ */ (0, A.jsx)("ul", {
							className: "ont-list",
							children: w.sources.map((e) => m[e] ? /* @__PURE__ */ (0, A.jsxs)("li", { children: [
								/* @__PURE__ */ (0, A.jsxs)("a", {
									href: m[e].url,
									target: "_blank",
									rel: "noreferrer",
									children: [
										e,
										" · ",
										m[e].title,
										" ↗"
									]
								}),
								" ",
								/* @__PURE__ */ (0, A.jsxs)("small", { children: [
									"[",
									m[e].status,
									"]"
								] })
							] }, e) : /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e))
						}),
						/* @__PURE__ */ (0, A.jsx)("h4", { children: "Used by" }),
						w.used_by?.length ? /* @__PURE__ */ (0, A.jsx)("ul", {
							className: "ont-list",
							"data-testid": "ontology-used-by",
							children: w.used_by.map((e, t) => /* @__PURE__ */ (0, A.jsxs)("li", { children: [
								/* @__PURE__ */ (0, A.jsx)("b", { children: e.agent || e.module }),
								" · ",
								/* @__PURE__ */ (0, A.jsx)("code", { children: e.tool }),
								" ",
								/* @__PURE__ */ (0, A.jsx)("small", { children: e.access === "reads" ? "reads" : "produces" })
							] }, t))
						}) : /* @__PURE__ */ (0, A.jsx)("p", {
							className: "ont-note",
							children: "No tool reads or produces it directly."
						}),
						/* @__PURE__ */ (0, A.jsx)("h4", { children: "Relations" }),
						E.length ? /* @__PURE__ */ (0, A.jsx)("ul", {
							className: "ont-list",
							children: E.map((e, t) => {
								let n = e.from === w.id, r = p[n ? e.to : e.from];
								return /* @__PURE__ */ (0, A.jsxs)("li", { children: [n ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
									"this ",
									/* @__PURE__ */ (0, A.jsx)("em", { children: e.label }),
									" "
								] }) : /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
									/* @__PURE__ */ (0, A.jsx)("button", {
										type: "button",
										className: "ont-link",
										onClick: () => l(r.id),
										children: r.label
									}),
									" ",
									/* @__PURE__ */ (0, A.jsx)("em", { children: e.label }),
									" this"
								] }), n && /* @__PURE__ */ (0, A.jsx)("button", {
									type: "button",
									className: "ont-link",
									onClick: () => l(r.id),
									children: r.label
								})] }, t);
							})
						}) : /* @__PURE__ */ (0, A.jsx)("p", {
							className: "ont-note",
							children: "None."
						}),
						w.where && r && /* @__PURE__ */ (0, A.jsxs)("button", {
							type: "button",
							className: "ont-open",
							onClick: () => r(w.where.tab),
							children: [
								"Open ",
								w.where.label,
								" →"
							]
						})
					] }) : /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [/* @__PURE__ */ (0, A.jsx)("h3", { children: "Select a concept" }), /* @__PURE__ */ (0, A.jsx)("p", {
						className: "ont-note",
						children: "Click a box to see what it means, where SAP describes it, which agents and tools use it, and how it relates to other concepts. Relations of the selected concept are labelled on the graph."
					})] })
				})]
			}),
			/* @__PURE__ */ (0, A.jsxs)("details", {
				className: "surface ont-table",
				children: [/* @__PURE__ */ (0, A.jsxs)("summary", { children: [
					/* @__PURE__ */ (0, A.jsx)("strong", { children: "Table view" }),
					" ",
					/* @__PURE__ */ (0, A.jsxs)("span", { children: [g.length, " concepts"] })
				] }), /* @__PURE__ */ (0, A.jsxs)("table", {
					className: "rr-table",
					children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Concept" }),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Kind" }),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Module" }),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "SAP term" }),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Status" })
					] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: g.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.label }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: (oe[e.kind] || {}).label }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: (f.find((t) => t.id === e.module) || {}).name }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.sap_term || "none claimed" }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: (se[e.sap_status] || [e.sap_status])[0] })
					] }, e.id)) })]
				})]
			})
		]
	}) : /* @__PURE__ */ (0, A.jsx)("main", {
		className: "ontology-page",
		children: /* @__PURE__ */ (0, A.jsx)("div", {
			className: "empty-state",
			role: "status",
			children: /* @__PURE__ */ (0, A.jsx)("strong", { children: "Loading the ontology…" })
		})
	});
}
// src/Blocks.jsx
var he = (e) => Number(e || 0).toLocaleString("en-US"), ge = (e) => `${Number(e) > 0 ? "+" : Number(e) < 0 ? "−" : ""}${he(Math.abs(Number(e || 0)))}`;
function _e(e, t) {
	let n = t[e.key];
	return e.tones ? /* @__PURE__ */ (0, A.jsx)("span", {
		className: `blk-chip ${e.tones[n] || ""}`,
		children: e.words && e.words[n] || n
	}) : e.format === "int" ? he(n) : e.format === "signed" ? ge(n) : n ?? "";
}
function ve(e, t) {
	return e ? e.equals === void 0 ? e.notequals !== void 0 && t[e.key] !== e.notequals : t[e.key] === e.equals : !1;
}
function M({ blocks: e = [] }) {
	return /* @__PURE__ */ (0, A.jsx)("div", {
		className: "blk-stack",
		children: e.map((e, t) => e.type === "kpis" ? /* @__PURE__ */ (0, A.jsx)("div", {
			className: "blk-kpis",
			children: e.items.map((e) => /* @__PURE__ */ (0, A.jsxs)("div", {
				className: e.tone || "",
				children: [
					/* @__PURE__ */ (0, A.jsx)("span", { children: e.label }),
					/* @__PURE__ */ (0, A.jsx)("strong", { children: e.value }),
					e.note && /* @__PURE__ */ (0, A.jsx)("small", { children: e.note })
				]
			}, e.label))
		}, t) : e.type === "table" ? /* @__PURE__ */ (0, A.jsxs)("section", {
			className: "blk-table",
			children: [e.title && /* @__PURE__ */ (0, A.jsx)("h4", { children: e.title }), /* @__PURE__ */ (0, A.jsx)("div", {
				className: "blk-scroll",
				children: /* @__PURE__ */ (0, A.jsxs)("table", { children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsx)("tr", { children: e.columns.map((e) => /* @__PURE__ */ (0, A.jsx)("th", {
					className: e.align === "right" ? "num" : "",
					children: e.label
				}, e.key)) }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: e.rows.map((t, n) => /* @__PURE__ */ (0, A.jsx)("tr", {
					className: ve(e.highlight, t) ? "hl" : "",
					children: e.columns.map((e) => /* @__PURE__ */ (0, A.jsx)("td", {
						className: e.align === "right" ? "num" : "",
						children: _e(e, t)
					}, e.key))
				}, n)) })] })
			})]
		}, t) : e.type === "list" ? /* @__PURE__ */ (0, A.jsxs)("section", {
			className: "blk-list",
			children: [e.title && /* @__PURE__ */ (0, A.jsx)("h4", { children: e.title }), /* @__PURE__ */ (0, A.jsx)("ul", { children: e.items.map((e, t) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, t)) })]
		}, t) : e.type === "note" ? /* @__PURE__ */ (0, A.jsx)("p", {
			className: `blk-note ${e.tone || ""}`,
			children: e.text
		}, t) : null)
	});
}
// src/PeriodUi.jsx
function N({ period: e, periods: t, onPeriod: n, label: r = "Period", id: i }) {
	let a = t?.length ? t : [e], o = a.includes(e) ? a : [e, ...a];
	return /* @__PURE__ */ (0, A.jsxs)("label", {
		className: "period-select",
		children: [/* @__PURE__ */ (0, A.jsx)("span", { children: r }), /* @__PURE__ */ (0, A.jsx)("select", {
			id: i,
			value: e,
			onChange: (e) => n(e.target.value),
			"aria-label": r,
			children: o.map((e) => /* @__PURE__ */ (0, A.jsxs)("option", {
				value: e,
				children: [
					w(e),
					" · ",
					T(e),
					a.includes(e) ? "" : " · no data"
				]
			}, e))
		})]
	});
}
function ye({ text: e, period: t, periods: n }) {
	let r = E(e), i = D(e), a = r || t;
	return i ? /* @__PURE__ */ (0, A.jsxs)("span", {
		className: "period-effective bad",
		role: "status",
		children: ["NO DATA AVAILABLE FOR ", i.toUpperCase()]
	}) : n?.length && !n.includes(a) ? /* @__PURE__ */ (0, A.jsxs)("span", {
		className: "period-effective bad",
		role: "status",
		children: ["NO DATA AVAILABLE FOR ", C(a).toUpperCase()]
	}) : /* @__PURE__ */ (0, A.jsxs)("span", {
		className: "period-effective",
		role: "status",
		children: [
			"Effective period: ",
			/* @__PURE__ */ (0, A.jsx)("b", { children: C(a) }),
			/* @__PURE__ */ (0, A.jsx)("em", { children: r ? r === t ? "selector and request agree" : "taken from your request" : "taken from the selector" })
		]
	});
}
function be(e, t) {
	let n = re(), [r, i] = (0, _.useState)(null), a = (0, _.useRef)({
		period: e,
		domain: t
	});
	return (0, _.useEffect)(() => {
		(a.current.period !== e || a.current.domain !== t) && (a.current = {
			period: e,
			domain: t
		}, i(null));
	}, [e, t]), [r ?? n.ask(t, e), i];
}
function P({ text: e }) {
	let t = re(), n = t.route(e);
	return /* @__PURE__ */ (0, A.jsxs)("span", {
		className: `route-chip ${n}`,
		"data-testid": "route-chip",
		"data-domain": n,
		children: ["Routed to ", /* @__PURE__ */ (0, A.jsx)("b", { children: t.label(n) })]
	});
}
function xe({ provenance: e, compact: t }) {
	let n = e || {
		data_source: "SYNTHETIC / DEMONSTRATION",
		sap_access: "NOT CONNECTED / NOT VERIFIED",
		execution_mode: "READ-ONLY PROPOSED WORKFLOW"
	};
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: `provenance ${t ? "compact" : ""}`,
		role: "group",
		"aria-label": "Data source and SAP access",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("span", { children: [/* @__PURE__ */ (0, A.jsx)("i", { children: "DATA SOURCE" }), /* @__PURE__ */ (0, A.jsx)("b", { children: n.data_source })] }),
			/* @__PURE__ */ (0, A.jsxs)("span", { children: [/* @__PURE__ */ (0, A.jsx)("i", { children: "SAP ACCESS" }), /* @__PURE__ */ (0, A.jsx)("b", { children: n.sap_access })] }),
			/* @__PURE__ */ (0, A.jsxs)("span", { children: [/* @__PURE__ */ (0, A.jsx)("i", { children: "EXECUTION MODE" }), /* @__PURE__ */ (0, A.jsx)("b", { children: n.execution_mode })] })
		]
	});
}
// src/GenericModuleView.jsx
function Se({ module: e, period: t, view: n, state: r, onAsk: i }) {
	if (r === "none") return /* @__PURE__ */ (0, A.jsx)("main", {
		className: "module-page",
		children: /* @__PURE__ */ (0, A.jsxs)("div", {
			className: "period-nodata",
			role: "alert",
			"data-testid": "module-nodata",
			children: ["NO DATA AVAILABLE FOR ", C(t).toUpperCase()]
		})
	});
	if (!n) return /* @__PURE__ */ (0, A.jsx)("main", {
		className: "module-page",
		children: /* @__PURE__ */ (0, A.jsx)("div", {
			className: "empty-state",
			role: "status",
			children: /* @__PURE__ */ (0, A.jsxs)("strong", { children: [
				"Loading ",
				C(t),
				"…"
			] })
		})
	});
	let a = n.ui || {
		title: e.name,
		blocks: []
	};
	return /* @__PURE__ */ (0, A.jsxs)("main", {
		className: "module-page",
		"aria-label": e.name,
		"data-testid": "module-page",
		"data-module": e.id,
		"data-period": n.period,
		children: [/* @__PURE__ */ (0, A.jsxs)("section", {
			className: "surface module-head",
			children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
				/* @__PURE__ */ (0, A.jsx)("span", {
					className: "eyebrow",
					children: e.name.toUpperCase()
				}),
				/* @__PURE__ */ (0, A.jsx)("h2", { children: a.title }),
				/* @__PURE__ */ (0, A.jsxs)("p", { children: [
					a.subtitle,
					" · ",
					C(t),
					" · ",
					T(t)
				] })
			] }), /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "tr-head-actions",
				children: [/* @__PURE__ */ (0, A.jsx)(xe, {
					provenance: n.provenance,
					compact: !0
				}), e.examples?.length > 0 && /* @__PURE__ */ (0, A.jsx)("div", {
					className: "tr-buttons",
					children: /* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						className: "primary",
						onClick: () => i(e.ask_template.replace("{period}", C(t))),
						children: "Ask this agent"
					})
				})]
			})]
		}), /* @__PURE__ */ (0, A.jsx)("section", {
			className: "surface module-body",
			children: /* @__PURE__ */ (0, A.jsx)(M, { blocks: a.blocks })
		})]
	});
}
// src/TreasuryCockpit.jsx
var F = (e) => Number(e || 0).toLocaleString("en-US"), Ce = (e) => `${Number(e) > 0 ? "+" : Number(e) < 0 ? "−" : ""}${F(Math.abs(Number(e || 0)))}`, we = {
	DEFICIT: "Deficit",
	IDLE_CASH: "Idle cash",
	WITHIN_POLICY: "Within policy"
}, Te = {
	DEFICIT: "bad",
	IDLE_CASH: "warn",
	WITHIN_POLICY: "ok"
}, Ee = ({ status: e }) => /* @__PURE__ */ (0, A.jsx)("span", {
	className: `tr-chip ${Te[e] || ""}`,
	children: we[e] || e
});
function De({ series: e, minimum: t, label: n }) {
	if (!e?.length) return null;
	let r = e.map((e) => e.balance), i = Math.min(...r, t ?? Infinity) * .98, a = Math.max(...r) * 1.02, o = (t) => 6 + 308 * (t / Math.max(1, e.length - 1)), s = (e) => 6 + 84 * (1 - (e - i) / Math.max(1, a - i)), c = e.map((e, t) => `${t ? "L" : "M"}${o(t).toFixed(1)},${s(e.balance).toFixed(1)}`).join(" ");
	return /* @__PURE__ */ (0, A.jsxs)("svg", {
		className: "tr-spark",
		viewBox: "0 0 320 96",
		role: "img",
		"aria-label": n,
		children: [
			t ? /* @__PURE__ */ (0, A.jsx)("line", {
				x1: 6,
				x2: 314,
				y1: s(t),
				y2: s(t),
				stroke: "#BB0000",
				strokeDasharray: "4 3",
				strokeWidth: "1"
			}) : null,
			/* @__PURE__ */ (0, A.jsx)("path", {
				d: `${c} L${o(e.length - 1)},90 L${o(0)},90 Z`,
				fill: "#0a6ed122"
			}),
			/* @__PURE__ */ (0, A.jsx)("path", {
				d: c,
				fill: "none",
				stroke: "#0a6ed1",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ (0, A.jsx)("text", {
				x: 6,
				y: 95,
				fontSize: "9",
				fill: "#587184",
				children: e[0].date.slice(5)
			}),
			/* @__PURE__ */ (0, A.jsx)("text", {
				x: 314,
				y: 95,
				fontSize: "9",
				fill: "#587184",
				textAnchor: "end",
				children: e[e.length - 1].date.slice(5)
			})
		]
	});
}
function Oe({ period: e, data: t, state: n, role: r, onRole: i, onOpenDetail: a, onDecision: o, onAsk: s }) {
	if (n === "none") return /* @__PURE__ */ (0, A.jsx)("main", {
		className: "treasury-page",
		children: /* @__PURE__ */ (0, A.jsxs)("div", {
			className: "period-nodata",
			role: "alert",
			"data-testid": "treasury-nodata",
			children: ["NO DATA AVAILABLE FOR ", C(e).toUpperCase()]
		})
	});
	if (!t) return /* @__PURE__ */ (0, A.jsx)("main", {
		className: "treasury-page",
		children: /* @__PURE__ */ (0, A.jsx)("div", {
			className: "empty-state",
			role: "status",
			children: /* @__PURE__ */ (0, A.jsxs)("strong", { children: [
				"Loading ",
				C(e),
				"…"
			] })
		})
	});
	let c = t.position, l = c.totals, u = t.forecast[30], d = t.recommendations, f = c.policy_checks.filter((e) => e.status === "BREACH"), p = Object.fromEntries((t.proposals || []).map((e) => [e.proposal_id, e])), m = u.by_currency.reduce((e, t) => e + Math.round(t.minimum_required * (c.fx[t.ccy] || 1)), 0), h = u.by_currency.filter((e) => e.first_shortfall);
	return /* @__PURE__ */ (0, A.jsxs)("main", {
		className: "treasury-page",
		"aria-label": "Cash and treasury",
		"data-testid": "treasury-page",
		"data-period": c.period,
		children: [
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface tr-head",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
					/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "FINANCE / CASH & TREASURY"
					}),
					/* @__PURE__ */ (0, A.jsx)("h2", { children: "Cash & treasury" }),
					/* @__PURE__ */ (0, A.jsxs)("p", {
						className: "tr-sub",
						children: [
							"Daily cash positioning as of ",
							/* @__PURE__ */ (0, A.jsx)("b", { children: c.as_of }),
							" · ",
							C(e),
							" · ",
							T(e),
							" · display currency ",
							c.display_currency,
							", rate type ",
							c.exchange_rate_type
						]
					})
				] }), /* @__PURE__ */ (0, A.jsxs)("div", {
					className: "tr-head-actions",
					children: [/* @__PURE__ */ (0, A.jsx)(xe, {
						provenance: c.provenance,
						compact: !0
					}), /* @__PURE__ */ (0, A.jsxs)("div", {
						className: "tr-buttons",
						children: [/* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							className: "primary",
							onClick: () => a("position"),
							children: "Open detailed cash & treasury view →"
						}), /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							onClick: () => s("Propose transfers to cover shortfalls"),
							children: "Ask the treasury agents"
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "tr-kpis",
				"aria-label": "Key figures",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						"data-testid": "kpi-cash",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Group cash (USD equivalent)" }),
							/* @__PURE__ */ (0, A.jsx)("strong", { children: F(l.usd_opening) }),
							/* @__PURE__ */ (0, A.jsxs)("small", { children: [
								l.accounts,
								" accounts · ",
								Object.keys(l.by_currency).join(" · ")
							] })
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: l.deficit ? "attn" : "",
						"data-testid": "kpi-deficit",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Deficit accounts" }),
							/* @__PURE__ */ (0, A.jsx)("strong", { children: l.deficit }),
							/* @__PURE__ */ (0, A.jsx)("small", { children: "expected close below minimum" })
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: l.idle ? "warn" : "",
						"data-testid": "kpi-idle",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Idle-cash accounts" }),
							/* @__PURE__ */ (0, A.jsx)("strong", { children: l.idle }),
							/* @__PURE__ */ (0, A.jsx)("small", { children: "above 1.5 × target" })
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: f.length ? "attn" : "",
						"data-testid": "kpi-policy",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Policy rules breached" }),
							/* @__PURE__ */ (0, A.jsxs)("strong", { children: [
								f.length,
								" of ",
								c.policy_checks.length
							] }),
							/* @__PURE__ */ (0, A.jsx)("small", { children: f.map((e) => e.rule).join(" · ") || "none" })
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: c.statements.ready ? "" : "warn",
						"data-testid": "kpi-statements",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Bank statements" }),
							/* @__PURE__ */ (0, A.jsxs)("strong", { children: [
								c.statements.complete,
								" of ",
								c.statements.expected
							] }),
							/* @__PURE__ */ (0, A.jsxs)("small", { children: [c.statements.opening_mismatches.length, " opening-balance mismatch(es)"] })
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: u.shortfall ? "warn" : "",
						"data-testid": "kpi-forecast",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "30-day forecast" }),
							/* @__PURE__ */ (0, A.jsx)("strong", { children: h.length ? "Shortfall" : "No shortfall" }),
							/* @__PURE__ */ (0, A.jsx)("small", { children: h.length ? h.map((e) => `${e.ccy} ${e.first_shortfall.date.slice(5)}`).join(" · ") : "all currencies above minimum" })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "tr-grid",
				children: [/* @__PURE__ */ (0, A.jsxs)("section", {
					className: "surface tr-card",
					"aria-label": "Bank accounts",
					children: [/* @__PURE__ */ (0, A.jsx)("h3", { children: "Bank accounts · opening balance and expected close" }), /* @__PURE__ */ (0, A.jsx)("div", {
						className: "tr-scroll",
						children: /* @__PURE__ */ (0, A.jsxs)("table", {
							className: "tr-table",
							"data-testid": "treasury-accounts",
							children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, A.jsx)("th", { children: "Account" }),
								/* @__PURE__ */ (0, A.jsx)("th", { children: "Bank" }),
								/* @__PURE__ */ (0, A.jsx)("th", { children: "Ccy" }),
								/* @__PURE__ */ (0, A.jsx)("th", {
									className: "num",
									children: "Opening"
								}),
								/* @__PURE__ */ (0, A.jsx)("th", {
									className: "num",
									children: "Expected close"
								}),
								/* @__PURE__ */ (0, A.jsx)("th", {
									className: "num",
									children: "Minimum"
								}),
								/* @__PURE__ */ (0, A.jsx)("th", { children: "Status" }),
								/* @__PURE__ */ (0, A.jsx)("th", { children: "Statement" })
							] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: c.accounts.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", {
								className: e.status === "DEFICIT" ? "hl" : "",
								children: [
									/* @__PURE__ */ (0, A.jsxs)("td", { children: [
										/* @__PURE__ */ (0, A.jsx)("b", { children: e.id }),
										" ",
										/* @__PURE__ */ (0, A.jsx)("small", { children: e.kind })
									] }),
									/* @__PURE__ */ (0, A.jsx)("td", { children: e.bank_name }),
									/* @__PURE__ */ (0, A.jsx)("td", { children: e.ccy }),
									/* @__PURE__ */ (0, A.jsx)("td", {
										className: "num",
										children: F(e.opening)
									}),
									/* @__PURE__ */ (0, A.jsx)("td", {
										className: "num",
										children: F(e.expected_closing)
									}),
									/* @__PURE__ */ (0, A.jsx)("td", {
										className: "num",
										children: F(e.min)
									}),
									/* @__PURE__ */ (0, A.jsx)("td", { children: /* @__PURE__ */ (0, A.jsx)(Ee, { status: e.status }) }),
									/* @__PURE__ */ (0, A.jsx)("td", { children: e.statement.complete && e.statement.opening_check === "OK" ? /* @__PURE__ */ (0, A.jsx)("span", {
										className: "tr-ok",
										children: "OK"
									}) : /* @__PURE__ */ (0, A.jsx)("span", {
										className: "tr-flag",
										title: `${e.statement.complete ? "" : `Statement ${e.statement.gap_days} business days old. `}${e.statement.opening_check === "OK" ? "" : `Opening differs from prior closing by ${Ce(e.statement.opening_difference)}`}`,
										children: e.statement.complete ? "Opening mismatch" : "Missing"
									}) })
								]
							}, e.id)) })]
						})
					})]
				}), /* @__PURE__ */ (0, A.jsxs)("div", {
					className: "tr-side",
					children: [
						/* @__PURE__ */ (0, A.jsxs)("section", {
							className: "surface tr-card",
							"aria-label": "Liquidity forecast",
							children: [
								/* @__PURE__ */ (0, A.jsx)("h3", { children: "30-day liquidity (USD equivalent)" }),
								/* @__PURE__ */ (0, A.jsx)(De, {
									series: u.usd_series,
									minimum: m,
									label: "Projected group cash for the next 30 days"
								}),
								/* @__PURE__ */ (0, A.jsxs)("p", {
									className: "tr-note",
									children: [h.length ? `First shortfall: ${h.map((e) => `${e.ccy} on ${e.first_shortfall.date}`).join("; ")}. ` : "No currency falls below the sum of its account minimums. ", "Dashed line is the minimum."]
								})
							]
						}),
						/* @__PURE__ */ (0, A.jsxs)("section", {
							className: "surface tr-card",
							"aria-label": "Transfer recommendations",
							children: [
								/* @__PURE__ */ (0, A.jsx)("h3", { children: "Transfer recommendations" }),
								d.recommendations.length ? /* @__PURE__ */ (0, A.jsx)("ul", {
									className: "tr-recs",
									"data-testid": "treasury-recs",
									children: d.recommendations.map((e) => {
										let t = p[e.proposal_id];
										return /* @__PURE__ */ (0, A.jsxs)("li", { children: [
											/* @__PURE__ */ (0, A.jsxs)("div", { children: [
												/* @__PURE__ */ (0, A.jsxs)("b", { children: [
													F(e.amount),
													" ",
													e.ccy
												] }),
												" ",
												e.from_account,
												" → ",
												e.to_account,
												" ",
												/* @__PURE__ */ (0, A.jsxs)("small", { children: [
													"(",
													e.template,
													" · ",
													e.template_name,
													")"
												] })
											] }),
											/* @__PURE__ */ (0, A.jsx)("small", { children: e.reason }),
											e.caveat && /* @__PURE__ */ (0, A.jsx)("small", {
												className: "tr-caveat",
												children: e.caveat
											}),
											/* @__PURE__ */ (0, A.jsx)("div", {
												className: "tr-rec-actions",
												children: t ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [/* @__PURE__ */ (0, A.jsx)("span", {
													className: `tr-chip ${t.status === "approved_marker" ? "ok" : t.status === "rejected" ? "bad" : "warn"}`,
													children: t.status.replace("_", " ")
												}), t.status === "awaiting_approval" && /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [/* @__PURE__ */ (0, A.jsx)("button", {
													type: "button",
													disabled: r !== "approver",
													onClick: () => o(t, !0),
													children: "Approve (marker)"
												}), /* @__PURE__ */ (0, A.jsx)("button", {
													type: "button",
													disabled: r !== "approver",
													onClick: () => o(t, !1),
													children: "Reject"
												})] })] }) : /* @__PURE__ */ (0, A.jsx)("button", {
													type: "button",
													onClick: () => s("Propose transfers to cover shortfalls"),
													children: "Ask the agents to draft it"
												})
											})
										] }, e.proposal_id);
									})
								}) : /* @__PURE__ */ (0, A.jsx)("p", {
									className: "tr-note",
									children: "No deficit that a transfer template can fund."
								}),
								d.unfunded.length > 0 && /* @__PURE__ */ (0, A.jsxs)("p", {
									className: "tr-caveat",
									"data-testid": "treasury-unfunded",
									children: [
										"Not covered by any template: ",
										d.unfunded.map((e) => `${e.account} (${F(e.remaining)} ${e.ccy})`).join(", "),
										". A person must decide."
									]
								}),
								/* @__PURE__ */ (0, A.jsxs)("label", {
									className: "tr-role",
									children: ["Demo role ", /* @__PURE__ */ (0, A.jsxs)("select", {
										value: r,
										onChange: (e) => i(e.target.value),
										children: [/* @__PURE__ */ (0, A.jsx)("option", {
											value: "maker",
											children: "Finance maker"
										}), /* @__PURE__ */ (0, A.jsx)("option", {
											value: "approver",
											children: "Finance approver"
										})]
									})]
								}),
								/* @__PURE__ */ (0, A.jsx)("p", {
									className: "tr-note",
									children: "Approval records a local synthetic marker only. No bank transfer is initiated and SAP is not changed."
								})
							]
						}),
						/* @__PURE__ */ (0, A.jsxs)("section", {
							className: "surface tr-card",
							"aria-label": "Bank concentration",
							children: [/* @__PURE__ */ (0, A.jsxs)("h3", { children: [
								"Bank concentration · limit ",
								c.policy.concentration_limit_pct,
								"%"
							] }), /* @__PURE__ */ (0, A.jsx)("ul", {
								className: "tr-bars",
								children: c.banks.map((e) => /* @__PURE__ */ (0, A.jsxs)("li", {
									className: e.share_pct > c.policy.concentration_limit_pct ? "over" : "",
									children: [
										/* @__PURE__ */ (0, A.jsx)("span", { children: e.name }),
										/* @__PURE__ */ (0, A.jsx)("i", { style: { width: `${Math.min(100, e.share_pct)}%` } }),
										/* @__PURE__ */ (0, A.jsxs)("b", { children: [e.share_pct, "%"] })
									]
								}, e.bank))
							})]
						})
					]
				})]
			})
		]
	});
}
// src/TreasuryDetail.jsx
var ke = [
	["position", "Position"],
	["forecast", "Forecast"],
	["banks", "Bank relationships"],
	["policy", "Policy & statements"],
	["proposals", "Transfer proposals"],
	["sap", "SAP guidance & sources"]
], Ae = [
	["Cash Position (F1737)", "Daily positions by account. Display currency and exchange rate type are mandatory fields in SAP."],
	["Liquidity Forecast Details (F0741)", "Forecast flows by liquidity item."],
	["Cash Flow Analyzer", "Combines cash position details, liquidity forecast detail and actual cash flow."],
	["Bank transfer templates and Make Bank Transfers", "Where a person with authorization creates the transfer from an approved proposal."],
	["Manage Bank Accounts", "Bank account master data."]
];
function je({ data: e }) {
	let t = e.position;
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		children: [/* @__PURE__ */ (0, A.jsxs)("table", {
			className: "rr-table",
			"data-testid": "detail-accounts",
			children: [
				/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Account" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Entity" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Bank" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Ccy" }),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Opening"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "+ Receipts"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "− Payments"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Expected close"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Minimum"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Target"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Status" }),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "USD equiv. close"
					})
				] }) }),
				/* @__PURE__ */ (0, A.jsx)("tbody", { children: t.accounts.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", {
					className: e.status === "DEFICIT" ? "hl" : "",
					children: [
						/* @__PURE__ */ (0, A.jsxs)("td", { children: [
							e.id,
							" ",
							/* @__PURE__ */ (0, A.jsx)("small", { children: e.kind })
						] }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.entity }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.bank_name }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.ccy }),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.opening)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.receipts)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.payments)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.expected_closing)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.min)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.target)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", { children: /* @__PURE__ */ (0, A.jsx)(Ee, { status: e.status }) }),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.usd_closing)
						})
					]
				}, e.id)) }),
				/* @__PURE__ */ (0, A.jsx)("tfoot", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsx)("th", {
					colSpan: "11",
					children: "Group total, USD equivalent"
				}), /* @__PURE__ */ (0, A.jsx)("td", {
					className: "num",
					children: F(t.totals.usd_closing)
				})] }) })
			]
		}), /* @__PURE__ */ (0, A.jsxs)("p", {
			className: "rr-note",
			children: [
				"Expected close = opening + expected receipts − expected payments for the as-of business day. Deficit = expected close below the minimum. Idle cash = opening above 1.5 × target. Rates are synthetic (",
				Object.entries(t.fx).map(([e, t]) => `${e} ${t}`).join(", "),
				")."
			]
		})]
	});
}
function Me({ data: e }) {
	let [t, n] = (0, _.useState)("30"), r = e.forecast[t];
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		"data-testid": "detail-forecast",
		children: [
			/* @__PURE__ */ (0, A.jsx)("div", {
				className: "tr-horizon",
				role: "group",
				"aria-label": "Forecast horizon",
				children: [
					"7",
					"30",
					"90"
				].map((e) => /* @__PURE__ */ (0, A.jsxs)("button", {
					type: "button",
					className: t === e ? "active" : "",
					"aria-pressed": t === e,
					onClick: () => n(e),
					children: [e, " days"]
				}, e))
			}),
			/* @__PURE__ */ (0, A.jsxs)("table", {
				className: "rr-table",
				children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Currency" }),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Opening"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Projected close"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Net"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Sum of minimums"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Lowest"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "First shortfall" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "If paid on due date" })
				] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: r.by_currency.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", {
					className: e.first_shortfall ? "hl" : "",
					children: [
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.ccy }),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.opening)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.closing)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: Ce(e.net)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.minimum_required)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.lowest)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.first_shortfall ? e.first_shortfall.date : "none" }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.first_shortfall_if_paid_on_due_date ? e.first_shortfall_if_paid_on_due_date.date : "none" })
					]
				}, e.ccy)) })]
			}),
			/* @__PURE__ */ (0, A.jsx)(De, {
				series: r.usd_series,
				label: `Projected group cash, ${t} days`
			}),
			/* @__PURE__ */ (0, A.jsx)("h3", { children: "Flows by flow type and liquidity item" }),
			/* @__PURE__ */ (0, A.jsxs)("table", {
				className: "rr-table",
				children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Flow type" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Liquidity item" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Planning level" }),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "USD equivalent"
					})
				] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: r.by_flow_type.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.name }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.liquidity_item }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.planning_level }),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: Ce(e.usd)
					})
				] }, e.flow_type)) })]
			}),
			/* @__PURE__ */ (0, A.jsxs)("p", {
				className: "rr-note",
				children: [
					"Receipts are moved by observed payment behaviour (",
					r.payment_behaviour.map((e) => `${e.segment} ${e.days_late} days late`).join(", "),
					"). ",
					r.basis
				]
			})
		]
	});
}
function Ne({ data: e }) {
	let t = e.banks;
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		children: [/* @__PURE__ */ (0, A.jsxs)("table", {
			className: "rr-table",
			"data-testid": "detail-banks",
			children: [
				/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Bank" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Accounts" }),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Balance (USD)"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Share"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Average balance"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Payments"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Volume (USD)"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Credit line"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Drawn"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Borrowings"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Investments"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Fees (USD)"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Fee per payment"
					})
				] }) }),
				/* @__PURE__ */ (0, A.jsx)("tbody", { children: t.banks.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", {
					className: e.share_pct > t.concentration_limit_pct ? "hl" : "",
					children: [
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.name }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.accounts.join(", ") }),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.usd_balance)
						}),
						/* @__PURE__ */ (0, A.jsxs)("td", {
							className: "num",
							children: [e.share_pct, "%"]
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.avg_balance_usd)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.payment_count)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.payment_volume_usd)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.credit_line_limit)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.credit_line_drawn)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.borrowings)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.investments)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: F(e.fees_total_usd)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: e.fee_per_payment_usd.toFixed(2)
						})
					]
				}, e.bank)) }),
				/* @__PURE__ */ (0, A.jsx)("tfoot", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", {
						colSpan: "7",
						children: "Total"
					}),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: F(t.totals.credit_limit)
					}),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: F(t.totals.credit_drawn)
					}),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: F(t.totals.borrowings)
					}),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: F(t.totals.investments)
					}),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: F(t.totals.fees_usd)
					}),
					/* @__PURE__ */ (0, A.jsx)("td", {})
				] }) })
			]
		}), /* @__PURE__ */ (0, A.jsxs)("p", {
			className: "rr-note",
			children: [t.over_concentration_limit.length ? `Over the ${t.concentration_limit_pct}% concentration limit: ${t.over_concentration_limit.join(", ")}. ` : `No bank is over the ${t.concentration_limit_pct}% limit. `, "Credit lines, borrowings, investments, volumes and fees are synthetic."]
		})]
	});
}
function I({ data: e }) {
	let t = e.position, n = t.statements;
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("table", {
				className: "rr-table",
				"data-testid": "detail-policy",
				children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Rule" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Policy" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Result" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Detail" })
				] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: t.policy_checks.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", {
					className: e.status === "BREACH" ? "hl" : "",
					children: [
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.rule }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.text }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: /* @__PURE__ */ (0, A.jsx)("span", {
							className: `tr-chip ${e.status === "PASS" ? "ok" : "bad"}`,
							children: e.status
						}) }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.detail })
					]
				}, e.rule)) })]
			}),
			/* @__PURE__ */ (0, A.jsx)("h3", { children: "Bank statements" }),
			/* @__PURE__ */ (0, A.jsxs)("p", {
				className: "rr-note",
				children: [
					n.complete,
					" of ",
					n.expected,
					" complete. ",
					n.missing.length ? `Missing: ${n.missing.join(", ")}. ` : "",
					n.opening_mismatches.length ? `Opening balance differs from prior closing: ${n.opening_mismatches.map((e) => `${e.account} (${Ce(e.difference)} ${e.ccy})`).join(", ")}.` : "All opening balances agree with the prior closing."
				]
			})
		]
	});
}
function Pe({ data: e, role: t, onDecision: n, onAsk: r }) {
	let i = Object.fromEntries((e.proposals || []).map((e) => [e.proposal_id, e])), a = e.recommendations;
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		"data-testid": "detail-proposals",
		children: [
			a.recommendations.length ? /* @__PURE__ */ (0, A.jsxs)("table", {
				className: "rr-table",
				children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Proposal" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "From" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "To" }),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Amount"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Template" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Policy rule" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Status" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Decision" })
				] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: a.recommendations.map((e) => {
					let a = i[e.proposal_id];
					return /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.proposal_id }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.from_account }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.to_account }),
						/* @__PURE__ */ (0, A.jsxs)("td", {
							className: "num",
							children: [
								F(e.amount),
								" ",
								e.ccy
							]
						}),
						/* @__PURE__ */ (0, A.jsxs)("td", { children: [
							e.template,
							" · ",
							e.template_name
						] }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.policy_rule }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: a ? a.status.replace("_", " ") : "not yet drafted" }),
						/* @__PURE__ */ (0, A.jsxs)("td", { children: [a ? a.status === "awaiting_approval" ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
							/* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								disabled: t !== "approver",
								onClick: () => n(a, !0),
								children: "Approve (marker)"
							}),
							" ",
							/* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								disabled: t !== "approver",
								onClick: () => n(a, !1),
								children: "Reject"
							})
						] }) : a.note : /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							onClick: () => r("Propose transfers to cover shortfalls"),
							children: "Ask the agents to draft"
						}), e.caveat && /* @__PURE__ */ (0, A.jsxs)("small", {
							className: "tr-caveat",
							children: [" ", e.caveat]
						})] })
					] }, e.proposal_id);
				}) })]
			}) : /* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-empty",
				children: "No deficit that a transfer template can fund for this period."
			}),
			a.unfunded.length > 0 && /* @__PURE__ */ (0, A.jsxs)("p", {
				className: "tr-caveat",
				children: [
					"Not covered by any template: ",
					a.unfunded.map((e) => `${e.account} (${F(e.remaining)} ${e.ccy})`).join(", "),
					". ",
					a.unfunded[0].reason
				]
			}),
			/* @__PURE__ */ (0, A.jsx)("h3", { children: "Bank transfer templates" }),
			/* @__PURE__ */ (0, A.jsxs)("table", {
				className: "rr-table",
				children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Template" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "From" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "To" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Ccy" }),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Maximum"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Name" })
				] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: e.templates.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.template }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.from }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.to }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.ccy }),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: F(e.max_amount)
					}),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.name })
				] }, e.template)) })]
			}),
			/* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-note",
				children: "SAP describes initiating a bank transfer from an approved proposal. Here an approval records a local marker; nothing is initiated and SAP is not changed."
			})
		]
	});
}
function Fe({ refs: e }) {
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		"data-testid": "detail-sap",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "rr-banner warn",
				children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "Manual in SAP" }), /* @__PURE__ */ (0, A.jsx)("span", { children: "This demo never initiates a bank transfer. A person with authorization does it in SAP from an approved proposal, then the position is refreshed and checked again." })]
			}),
			/* @__PURE__ */ (0, A.jsx)("h3", { children: "Where a person verifies in SAP" }),
			/* @__PURE__ */ (0, A.jsx)("ul", { children: Ae.map(([e, t]) => /* @__PURE__ */ (0, A.jsxs)("li", { children: [
				/* @__PURE__ */ (0, A.jsx)("b", { children: e }),
				": ",
				t
			] }, e)) }),
			/* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-note",
				children: "App names and IDs come from SAP knowledge base articles and SAP Learning. They are NOT_VERIFIED for your release and roles: confirm each one in the SAP Fiori Apps Reference Library."
			}),
			/* @__PURE__ */ (0, A.jsx)("h3", { children: "What SAP documents, and what this demo imitates" }),
			/* @__PURE__ */ (0, A.jsxs)("table", {
				className: "rr-table",
				children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Source" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Supports" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Status" })
				] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: e.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("td", { children: /* @__PURE__ */ (0, A.jsxs)("a", {
						href: e.url,
						target: "_blank",
						rel: "noreferrer",
						children: [
							e.id,
							" · ",
							e.title,
							" ↗"
						]
					}) }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.supports }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.status })
				] }, e.id)) })]
			})
		]
	});
}
function Ie({ data: e, period: t, periods: n, onPeriod: r, role: i, onDecision: a, onAsk: o, refs: s, initial: c = "position", onClose: l }) {
	let u = (0, _.useRef)(null), [d, f] = (0, _.useState)(c);
	(0, _.useEffect)(() => {
		let e = u.current;
		return e && !e.open && e.showModal(), () => {
			e?.open && e.close();
		};
	}, []);
	let p = e?.position, m = (e) => {
		let t = ke.findIndex(([e]) => e === d);
		e.key === "ArrowRight" && (f(ke[(t + 1) % ke.length][0]), e.preventDefault()), e.key === "ArrowLeft" && (f(ke[(t + ke.length - 1) % ke.length][0]), e.preventDefault());
	}, h = e ? {
		position: /* @__PURE__ */ (0, A.jsx)(je, { data: e }),
		forecast: /* @__PURE__ */ (0, A.jsx)(Me, { data: e }),
		banks: /* @__PURE__ */ (0, A.jsx)(Ne, { data: e }),
		policy: /* @__PURE__ */ (0, A.jsx)(I, { data: e }),
		proposals: /* @__PURE__ */ (0, A.jsx)(Pe, {
			data: e,
			role: i,
			onDecision: a,
			onAsk: o
		}),
		sap: /* @__PURE__ */ (0, A.jsx)(Fe, { refs: s || [] })
	}[d] : null;
	return /* @__PURE__ */ (0, A.jsxs)("dialog", {
		ref: u,
		className: "rr-dialog",
		"aria-labelledby": "tr-title",
		onClose: l,
		children: [/* @__PURE__ */ (0, A.jsxs)("header", {
			className: "rr-header",
			children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
				/* @__PURE__ */ (0, A.jsxs)("span", {
					className: "eyebrow",
					children: ["SYNTHETIC CASH & TREASURY VIEW · AS OF ", p?.as_of || "…"]
				}),
				/* @__PURE__ */ (0, A.jsx)("h2", {
					id: "tr-title",
					children: e ? `${C(t)} (${T(t)}) · display currency ${p.display_currency}` : `Loading ${C(t)}…`
				}),
				p && /* @__PURE__ */ (0, A.jsx)(xe, {
					provenance: p.provenance,
					compact: !0
				})
			] }), /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "rr-actions",
				children: [r && /* @__PURE__ */ (0, A.jsx)(N, {
					period: t,
					periods: n,
					onPeriod: r,
					id: "tr-period"
				}), /* @__PURE__ */ (0, A.jsx)("button", {
					type: "button",
					onClick: l,
					"aria-label": "Close cash and treasury view",
					children: "×"
				})]
			})]
		}), e ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [/* @__PURE__ */ (0, A.jsx)("div", {
			className: "rr-tabs",
			role: "tablist",
			"aria-label": "Cash and treasury sections",
			onKeyDown: m,
			children: ke.map(([e, t]) => /* @__PURE__ */ (0, A.jsx)("button", {
				type: "button",
				role: "tab",
				"aria-selected": d === e,
				tabIndex: d === e ? 0 : -1,
				className: d === e ? "active" : "",
				onClick: () => f(e),
				children: t
			}, e))
		}), /* @__PURE__ */ (0, A.jsx)("div", {
			className: "rr-body",
			role: "tabpanel",
			children: h
		})] }) : /* @__PURE__ */ (0, A.jsx)("div", {
			className: "rr-body",
			children: /* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-empty",
				role: "status",
				children: "Loading the synthetic treasury view…"
			})
		})]
	});
}
// src/CloseCockpit.jsx
var Le = (e) => new Intl.NumberFormat("en-US", {
	style: "currency",
	currency: "USD",
	maximumFractionDigits: 0
}).format(Number(e || 0)), Re = (e) => `${Number(e) > 0 ? "+" : Number(e) < 0 ? "−" : ""}${Le(Math.abs(Number(e || 0)))}`;
function ze({ period: e, onPeriod: t, onOpenReport: n, onAsk: r, banner: i, conditions: a = [], onCondition: o, history: s, cases: c = [], currentCase: l, proposal: u, role: d, onRole: f, approve: p, onOpenEvidence: m, summary: h, periodPanel: g, extrasLeft: v, extrasRight: y }) {
	let [b, x] = (0, _.useState)("all"), [S, w] = (0, _.useState)(""), [E, D] = (0, _.useState)(""), O = s?.periods || [], k = (e) => Object.entries(e.sources || {}).filter(([, e]) => e.freshness !== "current").map(([e]) => e.toUpperCase()), ee = O.filter((e) => k(e).length > 0), te = O.filter((e) => b === "all" || b === "exception" == k(e).length > 0);
	h?.summary;
	let ne = l?.result;
	return /* @__PURE__ */ (0, A.jsxs)("section", {
		className: "close-screen",
		"aria-label": "Close and reconcile",
		"data-testid": "close-screen",
		children: [/* @__PURE__ */ (0, A.jsxs)("div", {
			className: "surface cl-head",
			children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
				/* @__PURE__ */ (0, A.jsx)("span", {
					className: "eyebrow",
					children: "FINANCE / PERIOD-END CLOSE"
				}),
				/* @__PURE__ */ (0, A.jsx)("h2", { children: "Close & reconcile" }),
				i || /* @__PURE__ */ (0, A.jsxs)("p", { children: [
					"S/4HANA versus Central Finance for company code 1000, ledger 0L, USD · selected ",
					C(e),
					" · ",
					T(e)
				] })
			] }), /* @__PURE__ */ (0, A.jsx)("div", {
				className: "cl-head-actions",
				children: /* @__PURE__ */ (0, A.jsxs)("div", {
					className: "cl-buttons",
					children: [/* @__PURE__ */ (0, A.jsxs)("button", {
						type: "button",
						className: "primary",
						onClick: r,
						children: ["Ask the agents about ", C(e)]
					}), /* @__PURE__ */ (0, A.jsxs)("button", {
						type: "button",
						className: "rr-row-report",
						onClick: () => n?.(e),
						children: [
							"Detailed report for ",
							e,
							" →"
						]
					})]
				})
			})]
		}), /* @__PURE__ */ (0, A.jsxs)("div", {
			className: "cl-grid",
			children: [/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface cl-left",
				"aria-label": "Monthly reconciliation",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "cl-toolbar",
						children: [/* @__PURE__ */ (0, A.jsxs)("h3", { children: [
							"Monthly reconciliation · ",
							O.length,
							" periods · ",
							O.length - ee.length,
							" comparable · ",
							/* @__PURE__ */ (0, A.jsxs)("span", {
								className: ee.length ? "cl-bad" : "",
								children: [ee.length, " exceptions"]
							})
						] }), /* @__PURE__ */ (0, A.jsx)("div", {
							className: "cl-filter",
							role: "group",
							"aria-label": "Status filter",
							children: [
								["all", "All"],
								["ready", "Ready"],
								["exception", "Exception"]
							].map(([e, t]) => /* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								className: b === e ? "active" : "",
								"aria-pressed": b === e,
								onClick: () => x(e),
								children: t
							}, e))
						})]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "cl-cols",
						"aria-hidden": "true",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Period" }),
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "num",
								children: "S/4HANA"
							}),
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "num",
								children: "Central Finance"
							}),
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "num",
								children: "Variance"
							}),
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Status" })
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "worklist",
						children: [te.map((n) => {
							let r = k(n), i = n.sources.s4.balance - n.sources.cfin.balance;
							return /* @__PURE__ */ (0, A.jsxs)("button", {
								type: "button",
								className: e === n.period ? "selected" : "",
								"aria-pressed": e === n.period,
								onClick: () => t?.(n.period),
								title: r.length ? `${r.join(", ")} freshness requires review` : void 0,
								children: [
									/* @__PURE__ */ (0, A.jsx)("span", { children: n.period }),
									/* @__PURE__ */ (0, A.jsx)("span", {
										className: "num",
										children: Le(n.sources.s4.balance)
									}),
									/* @__PURE__ */ (0, A.jsx)("span", {
										className: "num",
										children: Le(n.sources.cfin.balance)
									}),
									/* @__PURE__ */ (0, A.jsx)("strong", {
										className: "num",
										children: r.length ? "Source review" : Re(i)
									}),
									/* @__PURE__ */ (0, A.jsx)("em", {
										className: r.length ? "warn" : "ok",
										children: r.length ? "EXCEPTION" : "READY"
									})
								]
							}, n.period);
						}), !te.length && /* @__PURE__ */ (0, A.jsx)("p", {
							className: "fi-empty-filter",
							children: "No periods match the filter."
						})]
					}),
					a.length > 0 && /* @__PURE__ */ (0, A.jsxs)("div", {
						className: "rr-condition cl-lab",
						role: "group",
						"aria-label": "Simulate a close condition",
						children: [
							/* @__PURE__ */ (0, A.jsx)("div", { children: /* @__PURE__ */ (0, A.jsx)("span", {
								className: "eyebrow",
								children: "SCENARIO LAB · SYNTHETIC"
							}) }),
							/* @__PURE__ */ (0, A.jsxs)("select", {
								value: S,
								onChange: (e) => {
									w(e.target.value), D("");
								},
								"aria-label": "Condition",
								children: [/* @__PURE__ */ (0, A.jsx)("option", {
									value: "",
									children: "Choose a condition…"
								}), a.map((e) => /* @__PURE__ */ (0, A.jsx)("option", {
									value: e.id,
									children: e.label
								}, e.id))]
							}),
							/* @__PURE__ */ (0, A.jsxs)("button", {
								type: "button",
								disabled: !S,
								onClick: () => {
									o?.(e, S), D(S);
								},
								children: ["Apply to ", e]
							}),
							(E || S) && /* @__PURE__ */ (0, A.jsx)("span", {
								className: "rr-condition-note",
								role: "status",
								children: E ? `${a.find((e) => e.id === E)?.what} Run the period again, then open the detailed report.` : a.find((e) => e.id === S)?.what
							})
						]
					}),
					v
				]
			}), /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "cl-right",
				children: [
					g,
					y,
					/* @__PURE__ */ (0, A.jsxs)("details", {
						className: "surface cl-case",
						children: [
							/* @__PURE__ */ (0, A.jsxs)("summary", { children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "Case, evidence and approval" }), /* @__PURE__ */ (0, A.jsxs)("span", { children: [c.length, " case(s) reviewed this session"] })] }),
							ne ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
								ne.scope?.period === e && ne.advisory_explanation && /* @__PURE__ */ (0, A.jsx)("p", {
									className: "micro",
									"data-testid": "case-explanation",
									children: ne.advisory_explanation
								}),
								/* @__PURE__ */ (0, A.jsxs)("div", {
									className: "detail-line",
									children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Case" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: l.case_id })]
								}),
								/* @__PURE__ */ (0, A.jsxs)("div", {
									className: "detail-line",
									children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Period / route" }), /* @__PURE__ */ (0, A.jsxs)("strong", { children: [
										ne.scope.period,
										" · ",
										l.scenario
									] })]
								}),
								/* @__PURE__ */ (0, A.jsxs)("div", {
									className: "detail-line",
									children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "S/4HANA − Central Finance" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: Le(ne.variance.amount) })]
								}),
								/* @__PURE__ */ (0, A.jsxs)("div", {
									className: "detail-line",
									children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Source status" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: ne.variance.state })]
								}),
								/* @__PURE__ */ (0, A.jsx)("button", {
									className: "detail-toggle",
									type: "button",
									onClick: m,
									children: "Open account, document and correlation evidence →"
								})
							] }) : /* @__PURE__ */ (0, A.jsx)("p", {
								className: "micro",
								children: "Ask the agents for a reconciliation to attach a case and its source lineage."
							}),
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: "approval-lane",
								children: [
									/* @__PURE__ */ (0, A.jsx)("span", {
										className: "eyebrow",
										children: "SEPARATE SYNTHETIC APPROVAL LANE"
									}),
									/* @__PURE__ */ (0, A.jsx)("p", { children: u ? `Proposal ${u.proposal_id} · ${u.status} · signed variance marker ${Le(u.amount)}` : "No proposal for this case." }),
									/* @__PURE__ */ (0, A.jsx)("label", {
										htmlFor: "demo-role",
										children: "Demo role"
									}),
									/* @__PURE__ */ (0, A.jsxs)("select", {
										id: "demo-role",
										value: d,
										onChange: (e) => f(e.target.value),
										children: [/* @__PURE__ */ (0, A.jsx)("option", {
											value: "maker",
											children: "Finance maker"
										}), /* @__PURE__ */ (0, A.jsx)("option", {
											value: "approver",
											children: "Finance approver"
										})]
									}),
									/* @__PURE__ */ (0, A.jsx)("button", {
										type: "button",
										disabled: d !== "approver" || u?.status !== "awaiting_approval",
										onClick: p,
										children: "Approve variance marker"
									}),
									/* @__PURE__ */ (0, A.jsx)("small", { children: "Approval records a local synthetic marker only; it does not determine accounts or post to SAP." })
								]
							})
						]
					})
				]
			})]
		})]
	});
}
// src/EvidenceShortcut.jsx
function Be({ investigation: e, onOpen: t }) {
	let n = e?.diagnosis?.classification?.replaceAll("_", " ");
	return /* @__PURE__ */ (0, A.jsxs)("section", {
		className: "surface evidence-shortcut",
		children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
			/* @__PURE__ */ (0, A.jsx)("span", {
				className: "eyebrow",
				children: "EVIDENCE & CORRELATION"
			}),
			/* @__PURE__ */ (0, A.jsx)("strong", { children: e ? `${n || "Investigation in progress"} · ${e.status.replaceAll("_", " ")}` : "Trace the agent’s proof" }),
			/* @__PURE__ */ (0, A.jsx)("small", { children: e ? `${e.proof?.length || 0} evidence items · ${e.plan?.filter((e) => e.status === "complete").length || 0} plan steps complete` : "Document comparison, decisions, source lineage and component events" })
		] }), /* @__PURE__ */ (0, A.jsx)("button", {
			type: "button",
			className: "text-link",
			onClick: t,
			children: "Open proof & correlation →"
		})]
	});
}
// src/ProofDossier.jsx
var Ve = (e) => e == null ? "—" : new Intl.NumberFormat("en-US", {
	style: "currency",
	currency: "USD",
	maximumFractionDigits: 0
}).format(Number(e));
function He({ investigation: e, currentCase: t, busy: n, onStart: r, onResolve: i, onTrace: a, architect: o = !1 }) {
	let [s, c] = (0, _.useState)("replication_gap"), [l, u] = (0, _.useState)(null), d = t?.status === "complete" && t?.scope?.period === "2026-11" && t?.result?.variance?.state === "comparable" && Number(t?.result?.variance?.amount) !== 0, f = e && (e.case_id === t?.case_id || e.after?.case_id === t?.case_id) ? e : null, p = f?.proof?.find((e) => e.proof_id === l) || f?.proof?.at(-1);
	return /* @__PURE__ */ (0, A.jsxs)("section", {
		className: `surface proof-dossier ${o ? "proof-architect" : ""}`,
		"aria-label": "Dynamic proof dossier",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "section-heading",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
					className: "eyebrow",
					children: "AGENTIC INVESTIGATION · DOCUMENT PROOF"
				}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "Dynamic proof dossier" })] }), /* @__PURE__ */ (0, A.jsx)("span", {
					className: `pill ${f?.status === "held" ? "warn" : f?.status === "resolved" ? "ok" : "quiet"}`,
					children: f?.status?.replaceAll("_", " ") || "Ready for a case"
				})]
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "proof-intro",
				children: [/* @__PURE__ */ (0, A.jsx)("p", { children: "Trace the agent’s plan, each tool observation, its rule, and the before/after result. All evidence is synthetic and scoped to November 2026." }), /* @__PURE__ */ (0, A.jsxs)("div", {
					className: "proof-actions",
					children: [
						/* @__PURE__ */ (0, A.jsxs)("label", { children: ["Fault profile", /* @__PURE__ */ (0, A.jsxs)("select", {
							value: s,
							onChange: (e) => c(e.target.value),
							disabled: n,
							children: [/* @__PURE__ */ (0, A.jsx)("option", {
								value: "replication_gap",
								children: "Missing replication"
							}), /* @__PURE__ */ (0, A.jsx)("option", {
								value: "mapping_conflict",
								children: "Mapping conflict"
							})]
						})] }),
						/* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							className: "primary",
							disabled: !d || n || f?.status === "running" || f?.status === "reconciling",
							onClick: () => r(s),
							children: n ? "Working…" : "Investigate variance"
						}),
						f && /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							onClick: () => a(f.case_id),
							children: "Inspect investigation trace"
						})
					]
				})]
			}),
			f ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
				/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "proof-summary",
					children: [
						/* @__PURE__ */ (0, A.jsxs)("div", { children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Before" }),
							/* @__PURE__ */ (0, A.jsx)("strong", { children: Ve(f.before?.variance?.amount) }),
							/* @__PURE__ */ (0, A.jsx)("small", { children: f.before?.case_id })
						] }),
						/* @__PURE__ */ (0, A.jsx)("div", {
							className: "proof-arrow",
							children: "→"
						}),
						/* @__PURE__ */ (0, A.jsxs)("div", { children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "After" }),
							/* @__PURE__ */ (0, A.jsx)("strong", { children: f.after ? Ve(f.after.variance?.amount) : "Awaiting action" }),
							/* @__PURE__ */ (0, A.jsx)("small", { children: f.after?.case_id || f.diagnosis?.classification?.replaceAll("_", " ") || "Plan in progress" })
						] })
					]
				}),
				/* @__PURE__ */ (0, A.jsx)("div", {
					className: "proof-plan",
					children: f.plan.map((e, t) => /* @__PURE__ */ (0, A.jsxs)("div", {
						className: `proof-step proof-step-${e.status}`,
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "proof-step-no",
								children: String(t + 1).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: e.label }), /* @__PURE__ */ (0, A.jsxs)("small", { children: [
								e.component_id.replaceAll("_", " "),
								" · ",
								e.status
							] })] }),
							/* @__PURE__ */ (0, A.jsxs)("span", { children: [e.proof_ids.length, " proof"] })
						]
					}, e.step_id))
				}),
				/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "proof-decision",
					children: [
						/* @__PURE__ */ (0, A.jsx)("span", {
							className: "eyebrow",
							children: "AGENT DECISION"
						}),
						/* @__PURE__ */ (0, A.jsx)("strong", { children: f.diagnosis?.classification?.replaceAll("_", " ") || "Testing hypotheses" }),
						/* @__PURE__ */ (0, A.jsx)("p", { children: f.reason || "Document and source evidence are being checked." }),
						f.status === "action_proposed" && /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							disabled: n,
							onClick: () => i(f.investigation_id),
							children: "Apply simulated reprocess and re-reconcile"
						}),
						f.status === "held" && /* @__PURE__ */ (0, A.jsx)("small", { children: "Held for finance and integration review. No source mutation was made." }),
						f.status === "resolved" && /* @__PURE__ */ (0, A.jsx)("small", { children: "Reprocess and downstream refresh were simulated locally. No SAP document was posted." })
					]
				}),
				/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "proof-evidence",
					children: [
						/* @__PURE__ */ (0, A.jsxs)("div", {
							className: "proof-evidence-head",
							children: [/* @__PURE__ */ (0, A.jsx)("span", {
								className: "eyebrow",
								children: "EVIDENCE LEDGER"
							}), /* @__PURE__ */ (0, A.jsxs)("strong", { children: [f.proof.length, " items"] })]
						}),
						/* @__PURE__ */ (0, A.jsx)("div", {
							className: "proof-evidence-list",
							children: f.proof.map((e) => /* @__PURE__ */ (0, A.jsxs)("button", {
								type: "button",
								className: p?.proof_id === e.proof_id ? "selected" : "",
								onClick: () => u(e.proof_id),
								children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: e.label }), /* @__PURE__ */ (0, A.jsx)("span", { children: e.evidence_id })]
							}, e.proof_id))
						}),
						p && /* @__PURE__ */ (0, A.jsxs)("div", {
							className: "proof-inspector",
							children: [
								/* @__PURE__ */ (0, A.jsx)("strong", { children: p.label }),
								/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Owner" }), /* @__PURE__ */ (0, A.jsx)("b", { children: p.component_id.replaceAll("_", " ") })] }),
								/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Evidence ID" }), /* @__PURE__ */ (0, A.jsx)("b", { children: p.evidence_id })] }),
								/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "SHA-256" }), /* @__PURE__ */ (0, A.jsx)("code", { children: p.sha256 })] }),
								!o && /* @__PURE__ */ (0, A.jsx)("pre", { children: JSON.stringify(p.data, null, 2) }),
								o && /* @__PURE__ */ (0, A.jsx)("p", { children: "Open the business workspace to inspect document values. This architecture view shows neutral evidence references and the decision path." })
							]
						})
					]
				})
			] }) : /* @__PURE__ */ (0, A.jsx)("div", {
				className: "proof-empty",
				children: "Run a comparable November case, then investigate. The missing-document and mapping-conflict profiles show a resolution path and a controlled hold."
			})
		]
	});
}
// src/EvidenceDetails.jsx
var Ue = {
	s4: "S/4HANA",
	cfin: "Central Finance",
	bw: "BW/4HANA",
	databricks: "Databricks"
}, We = (e) => e == null ? "Not comparable" : new Intl.NumberFormat("en-US", {
	style: "currency",
	currency: "USD",
	maximumFractionDigits: 0
}).format(Number(e));
function Ge({ currentCase: e, history: t, historyDetail: n }) {
	let r = e?.result?.variance ? e.result : null;
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "finance-evidence",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "section-heading",
					children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "DETERMINISTIC FINANCE OUTPUT"
					}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "Source snapshots and calculation" })] }), r && /* @__PURE__ */ (0, A.jsx)("span", {
						className: "pill quiet",
						children: r.case_id
					})]
				}), r ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "finance-evidence-summary",
						children: [
							/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Variance" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: We(r.variance.amount) })] }),
							/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Comparability" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: r.variance.state })] }),
							/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Period · route" }), /* @__PURE__ */ (0, A.jsxs)("strong", { children: [
								r.scope.period,
								" · ",
								r.scenario
							] })] })
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("p", {
						className: "report-note",
						children: [
							/* @__PURE__ */ (0, A.jsx)("strong", { children: "Calculation:" }),
							" ",
							r.variance.formula,
							". The model explanation is advisory."
						]
					}),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "finance-evidence-table",
						children: /* @__PURE__ */ (0, A.jsxs)("table", { children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, A.jsx)("th", { children: "Source" }),
							/* @__PURE__ */ (0, A.jsx)("th", { children: "Balance" }),
							/* @__PURE__ */ (0, A.jsx)("th", { children: "Freshness" }),
							/* @__PURE__ */ (0, A.jsx)("th", { children: "Snapshot UTC" }),
							/* @__PURE__ */ (0, A.jsx)("th", { children: "Evidence ID" })
						] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: Object.values(r.sources || {}).map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, A.jsx)("th", {
								scope: "row",
								children: Ue[e.source] || e.source
							}),
							/* @__PURE__ */ (0, A.jsx)("td", { children: We(e.balance) }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.freshness }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.timestamp_utc }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.evidence_id })
						] }, e.source)) })] })
					}),
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "report-note",
						children: r.advisory_explanation
					})
				] }) : /* @__PURE__ */ (0, A.jsx)("p", {
					className: "empty-inline",
					children: "Run a synthetic reconciliation to see source balances, timestamps and evidence IDs."
				})]
			}),
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "section-heading",
					children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "SQLITE SYNTHETIC HISTORY"
					}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "12-month evidence set" })] }), /* @__PURE__ */ (0, A.jsxs)("span", {
						className: "pill quiet",
						children: [t?.account_count || 6, " G/L accounts"]
					})]
				}), /* @__PURE__ */ (0, A.jsx)("div", {
					className: "evidence-months",
					children: (t?.periods || []).map((e) => /* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: e.period }), /* @__PURE__ */ (0, A.jsx)("span", { children: Object.values(e.sources || {}).some((e) => e.freshness !== "current") ? "Source review" : We(e.sources.s4.balance - e.sources.cfin.balance) })] }, e.period))
				})]
			}),
			n && /* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface source-evidence",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "section-heading",
						children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
							className: "eyebrow",
							children: "MONTHLY SOURCE LINEAGE"
						}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "Account and journal evidence" })] }), /* @__PURE__ */ (0, A.jsx)("span", {
							className: "pill quiet",
							children: n.period
						})]
					}),
					/* @__PURE__ */ (0, A.jsx)("p", { children: "Illustrative seeded rows; closing balances are aggregate source snapshots." }),
					/* @__PURE__ */ (0, A.jsxs)("details", { children: [/* @__PURE__ */ (0, A.jsxs)("summary", { children: [
						"Open ",
						n.balances.length,
						" G/L account balances"
					] }), /* @__PURE__ */ (0, A.jsx)("div", {
						className: "source-evidence-rows",
						children: n.balances.map((e) => /* @__PURE__ */ (0, A.jsxs)("div", { children: [
							/* @__PURE__ */ (0, A.jsx)("strong", { children: e.account }),
							/* @__PURE__ */ (0, A.jsx)("span", { children: e.source.toUpperCase() }),
							/* @__PURE__ */ (0, A.jsxs)("b", { children: [Number(e.balance).toLocaleString("en-US"), " USD"] }),
							/* @__PURE__ */ (0, A.jsx)("small", { children: e.evidence_id })
						] }, `${e.source}-${e.account}`))
					})] }),
					/* @__PURE__ */ (0, A.jsxs)("details", { children: [/* @__PURE__ */ (0, A.jsxs)("summary", { children: [
						"Open ",
						n.journals.length,
						" journal evidence records"
					] }), /* @__PURE__ */ (0, A.jsx)("div", {
						className: "source-evidence-rows",
						children: n.journals.map((e) => /* @__PURE__ */ (0, A.jsxs)("div", { children: [
							/* @__PURE__ */ (0, A.jsx)("strong", { children: e.journal_id }),
							/* @__PURE__ */ (0, A.jsx)("span", { children: e.account }),
							/* @__PURE__ */ (0, A.jsxs)("b", { children: [Number(e.amount).toLocaleString("en-US"), " USD"] }),
							/* @__PURE__ */ (0, A.jsx)("small", { children: e.description })
						] }, e.journal_id))
					})] })
				]
			})
		]
	});
}
function Ke({ run: e, questions: t = [], requestedSeq: n }) {
	let [r, i] = (0, _.useState)(null);
	(0, _.useEffect)(() => i(n || e?.steps?.[0]?.seq || null), [e?.run_id, n]);
	let a = e?.steps?.find((e) => e.seq === r) || e?.steps?.[0], o = t.find((t) => t.id === e?.question_id);
	function s() {
		if (!e) return;
		let t = document.createElement("a"), n = new Blob([JSON.stringify({
			...e,
			meeting_status: "OPEN — no human decision recorded"
		}, null, 2)], { type: "application/json" });
		t.href = URL.createObjectURL(n), t.download = `${e.run_id}-architecture-decision.json`, t.click(), setTimeout(() => URL.revokeObjectURL(t.href), 1e3);
	}
	return /* @__PURE__ */ (0, A.jsxs)("section", {
		className: "surface question-evidence",
		children: [/* @__PURE__ */ (0, A.jsxs)("div", {
			className: "section-heading",
			children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
				className: "eyebrow",
				children: "ARCHITECTURE DECISION EVIDENCE"
			}), /* @__PURE__ */ (0, A.jsx)("h2", { children: o?.title || "Question handoffs" })] }), e && /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "heading-actions",
				children: [/* @__PURE__ */ (0, A.jsxs)("span", {
					className: "pill quiet",
					children: [
						e.status,
						" · ",
						e.route
					]
				}), /* @__PURE__ */ (0, A.jsx)("button", {
					type: "button",
					className: "export-button",
					onClick: s,
					children: "Download synthetic decision packet"
				})]
			})]
		}), e ? /* @__PURE__ */ (0, A.jsxs)("div", {
			className: "question-evidence-body",
			children: [/* @__PURE__ */ (0, A.jsx)("div", {
				className: "question-evidence-steps",
				children: (e.steps || []).map((e) => /* @__PURE__ */ (0, A.jsxs)("button", {
					type: "button",
					className: a?.seq === e.seq ? "selected" : "",
					onClick: () => i(e.seq),
					children: [
						/* @__PURE__ */ (0, A.jsx)("span", { children: String(e.seq).padStart(2, "0") }),
						/* @__PURE__ */ (0, A.jsx)("strong", { children: e.component }),
						/* @__PURE__ */ (0, A.jsx)("small", { children: e.status })
					]
				}, e.seq))
			}), /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "question-evidence-detail",
				children: [
					a ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [/* @__PURE__ */ (0, A.jsx)("h3", { children: a.component }), /* @__PURE__ */ (0, A.jsxs)("dl", { children: [
						/* @__PURE__ */ (0, A.jsx)("dt", { children: "Received input" }),
						/* @__PURE__ */ (0, A.jsx)("dd", { children: a.input }),
						/* @__PURE__ */ (0, A.jsx)("dt", { children: "Control and owner" }),
						/* @__PURE__ */ (0, A.jsxs)("dd", { children: [
							a.control,
							/* @__PURE__ */ (0, A.jsx)("br", {}),
							a.owner
						] }),
						/* @__PURE__ */ (0, A.jsx)("dt", { children: "Passed output" }),
						/* @__PURE__ */ (0, A.jsx)("dd", { children: a.output }),
						/* @__PURE__ */ (0, A.jsx)("dt", { children: "Identity reference" }),
						/* @__PURE__ */ (0, A.jsx)("dd", { children: a.identity }),
						/* @__PURE__ */ (0, A.jsx)("dt", { children: "Proof still needed" }),
						/* @__PURE__ */ (0, A.jsx)("dd", { children: a.proof_gap }),
						/* @__PURE__ */ (0, A.jsx)("dt", { children: "Synthetic evidence ID" }),
						/* @__PURE__ */ (0, A.jsx)("dd", { children: a.evidence_id })
					] })] }) : /* @__PURE__ */ (0, A.jsx)("p", { children: "Select a handoff." }),
					/* @__PURE__ */ (0, A.jsx)("h3", { children: "Proof gates" }),
					/* @__PURE__ */ (0, A.jsx)("ul", { children: (o?.gates || []).map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) }),
					/* @__PURE__ */ (0, A.jsx)("h3", { children: "Control ownership" }),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "question-evidence-matrix",
						children: (e.control_matrix || []).map((e) => /* @__PURE__ */ (0, A.jsxs)("div", { children: [
							/* @__PURE__ */ (0, A.jsx)("strong", { children: e.component }),
							/* @__PURE__ */ (0, A.jsx)("span", { children: e.owner }),
							/* @__PURE__ */ (0, A.jsx)("p", { children: e.responsibility })
						] }, e.component))
					})
				]
			})]
		}) : /* @__PURE__ */ (0, A.jsx)("p", {
			className: "empty-inline",
			children: "Run an architecture question to inspect its input, output, owner and remaining proof."
		})]
	});
}
// src/ImplementationEvidence.jsx
var qe = [
	["External agent contract", "The agent host, identity and MCP client are named simulator components (the V5.1 hosts are SAP BTP Cloud Foundry in S1 and S3 and AgentCore Runtime in S2). The local Python runtime follows a bounded plan; no external agent is connected."],
	["SAP-owned capability", "The SAP finance tool, Apigee gateway, Integration Suite path and backend roles are simulated boundaries. No SAP tenant call or principal propagation is proved."],
	["Presentation", "The Fiori-inspired interface is built with React and Node.js tooling. Streamlit hosts its compiled assets; Node.js is not an agent in the runtime path."],
	["Execution and proof", "Python evaluates the finance rules and SQLite stores synthetic snapshots, cases and request/response events. The variance amount comes from the deterministic engine."]
];
function Je({ currentCase: e, events: t = [] }) {
	return /* @__PURE__ */ (0, A.jsxs)("section", {
		className: "surface implementation-evidence",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "section-heading",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
					className: "eyebrow",
					children: "IMPLEMENTATION AND VALIDATION BOUNDARY"
				}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "What the external-agent view represents" })] }), /* @__PURE__ */ (0, A.jsx)("span", {
					className: "pill simulated",
					children: "SYNTHETIC"
				})]
			}),
			/* @__PURE__ */ (0, A.jsx)("p", {
				className: "implementation-intro",
				children: "The live diagram presents a proposed external agent calling SAP-owned finance capabilities. The runnable demo uses one local simulator process and does not establish deployed gateway, SAP, or identity integration."
			}),
			/* @__PURE__ */ (0, A.jsx)("div", {
				className: "implementation-grid",
				children: qe.map(([e, t]) => /* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: e }), /* @__PURE__ */ (0, A.jsx)("p", { children: t })] }, e))
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "implementation-state",
				children: [
					/* @__PURE__ */ (0, A.jsx)("strong", { children: "Current trace" }),
					/* @__PURE__ */ (0, A.jsxs)("span", { children: [
						e?.case_id || "No case selected",
						" · ",
						t.length,
						" stored events"
					] }),
					/* @__PURE__ */ (0, A.jsx)("span", { children: "Simulator runs S1, S2 and S3 · all three scenarios remain proposals" })
				]
			})
		]
	});
}
// src/EvidenceCorrelation.jsx
function Ye({ investigation: e, currentCase: t, history: n, historyDetail: r, events: i, caseEvents: a, decisionRun: o, decisionQuestions: s, componentDetails: c, reviewPanel: l, focus: u, busy: d, onStart: f, onResolve: p, onTrace: m }) {
	let [h, g] = (0, _.useState)(null), [v, y] = (0, _.useState)(""), [b, x] = (0, _.useState)("investigation"), [S, C] = (0, _.useState)("proof");
	(0, _.useEffect)(() => {
		u?.section && C(u.section);
	}, [u?.nonce]);
	let w = (0, _.useRef)(null), T = Math.min(...e?.plan?.map((e) => e.last_event_seq).filter(Boolean) || []), E = Number.isFinite(T) ? T - 2 : 0, D = (0, _.useMemo)(() => i.filter((e) => (b === "full" || e.seq >= E) && `${e.operation} ${e.source_component_id} ${e.target_component_id} ${e.status}`.toLowerCase().includes(v.toLowerCase())), [
		i,
		v,
		b,
		E
	]), O = i.find((e) => e.seq === h) || D.at(-1);
	return (0, _.useEffect)(() => {
		h && w.current?.querySelector(`[data-seq="${h}"]`)?.scrollIntoView({ block: "nearest" });
	}, [h, D]), /* @__PURE__ */ (0, A.jsxs)("main", {
		className: "evidence-workspace",
		"aria-label": "Evidence and correlation",
		children: [/* @__PURE__ */ (0, A.jsx)("nav", {
			className: "evidence-section-nav",
			"aria-label": "Evidence sections",
			children: [
				["proof", "Investigation proof"],
				["finance", "Finance sources"],
				["components", "Component trace"],
				["questions", "Question handoffs"],
				["implementation", "Implementation"]
			].map(([e, t]) => /* @__PURE__ */ (0, A.jsx)("button", {
				type: "button",
				className: S === e ? "active" : "",
				onClick: () => C(e),
				children: t
			}, e))
		}), /* @__PURE__ */ (0, A.jsxs)("div", {
			className: "evidence-stage",
			children: [
				S === "proof" && /* @__PURE__ */ (0, A.jsxs)("div", {
					className: "evidence-layout",
					children: [/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "evidence-detail-column",
						children: [/* @__PURE__ */ (0, A.jsx)(He, {
							investigation: e,
							currentCase: t,
							busy: d,
							onStart: f,
							onResolve: p,
							onTrace: m
						}), r && /* @__PURE__ */ (0, A.jsxs)("section", {
							className: "surface source-evidence",
							children: [
								/* @__PURE__ */ (0, A.jsxs)("div", {
									className: "section-heading",
									children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
										className: "eyebrow",
										children: "MONTHLY SOURCE LINEAGE"
									}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "Account and journal evidence" })] }), /* @__PURE__ */ (0, A.jsx)("span", {
										className: "pill quiet",
										children: r.period
									})]
								}),
								/* @__PURE__ */ (0, A.jsx)("p", { children: "Illustrative seeded rows; closing balances are aggregate source snapshots." }),
								/* @__PURE__ */ (0, A.jsxs)("details", { children: [/* @__PURE__ */ (0, A.jsxs)("summary", { children: [
									"Open ",
									r.balances.length,
									" G/L account balances"
								] }), /* @__PURE__ */ (0, A.jsx)("div", {
									className: "source-evidence-rows",
									children: r.balances.map((e) => /* @__PURE__ */ (0, A.jsxs)("div", { children: [
										/* @__PURE__ */ (0, A.jsx)("strong", { children: e.account }),
										/* @__PURE__ */ (0, A.jsx)("span", { children: e.source.toUpperCase() }),
										/* @__PURE__ */ (0, A.jsxs)("b", { children: [Number(e.balance).toLocaleString("en-US"), " USD"] }),
										/* @__PURE__ */ (0, A.jsx)("small", { children: e.evidence_id })
									] }, `${e.source}-${e.account}`))
								})] }),
								/* @__PURE__ */ (0, A.jsxs)("details", { children: [/* @__PURE__ */ (0, A.jsxs)("summary", { children: [
									"Open ",
									r.journals.length,
									" journal evidence records"
								] }), /* @__PURE__ */ (0, A.jsx)("div", {
									className: "source-evidence-rows",
									children: r.journals.map((e) => /* @__PURE__ */ (0, A.jsxs)("div", { children: [
										/* @__PURE__ */ (0, A.jsx)("strong", { children: e.journal_id }),
										/* @__PURE__ */ (0, A.jsx)("span", { children: e.account }),
										/* @__PURE__ */ (0, A.jsxs)("b", { children: [Number(e.amount).toLocaleString("en-US"), " USD"] }),
										/* @__PURE__ */ (0, A.jsx)("small", { children: e.description })
									] }, e.journal_id))
								})] })
							]
						})]
					}), /* @__PURE__ */ (0, A.jsxs)("section", {
						className: "surface correlation-panel",
						children: [
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: "section-heading",
								children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
									className: "eyebrow",
									children: "PERSISTED COMPONENT COMMUNICATION"
								}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "Evidence correlation" })] }), /* @__PURE__ */ (0, A.jsxs)("span", {
									className: "pill quiet",
									children: [i.length, " events"]
								})]
							}),
							/* @__PURE__ */ (0, A.jsx)("p", {
								className: "correlation-intro",
								children: "Select a plan step or event to see which component received the request, returned the result, and recorded the decision."
							}),
							e && /* @__PURE__ */ (0, A.jsx)("div", {
								className: "correlation-steps",
								children: e.plan.map((e) => /* @__PURE__ */ (0, A.jsxs)("button", {
									type: "button",
									onClick: () => g(e.last_event_seq),
									disabled: !e.last_event_seq,
									children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: e.label }), /* @__PURE__ */ (0, A.jsx)("span", { children: e.last_event_seq ? `Event #${e.last_event_seq}` : e.status })]
								}, e.step_id))
							}),
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: "correlation-segment",
								children: [/* @__PURE__ */ (0, A.jsx)("button", {
									type: "button",
									className: b === "investigation" ? "active" : "",
									onClick: () => x("investigation"),
									children: "Investigation segment"
								}), /* @__PURE__ */ (0, A.jsx)("button", {
									type: "button",
									className: b === "full" ? "active" : "",
									onClick: () => x("full"),
									children: "Entire request"
								})]
							}),
							/* @__PURE__ */ (0, A.jsxs)("label", {
								className: "correlation-filter",
								children: ["Find operation or component", /* @__PURE__ */ (0, A.jsx)("input", {
									value: v,
									onChange: (e) => y(e.target.value),
									placeholder: "compare, gateway, policy…"
								})]
							}),
							/* @__PURE__ */ (0, A.jsx)("div", {
								className: "correlation-events",
								ref: w,
								children: D.map((e) => /* @__PURE__ */ (0, A.jsxs)("button", {
									type: "button",
									"data-seq": e.seq,
									className: O?.seq === e.seq ? "selected" : "",
									onClick: () => g(e.seq),
									children: [
										/* @__PURE__ */ (0, A.jsxs)("span", { children: ["#", e.seq] }),
										/* @__PURE__ */ (0, A.jsx)("strong", { children: e.operation.replaceAll("_", " ") }),
										/* @__PURE__ */ (0, A.jsxs)("small", { children: [
											e.source_component_id.replaceAll("_", " "),
											" → ",
											e.target_component_id.replaceAll("_", " ")
										] }),
										/* @__PURE__ */ (0, A.jsxs)("em", { children: [
											e.direction,
											" · ",
											e.status
										] })
									]
								}, e.seq))
							}),
							O && /* @__PURE__ */ (0, A.jsxs)("div", {
								className: "correlation-inspector",
								children: [
									/* @__PURE__ */ (0, A.jsxs)("span", {
										className: "eyebrow",
										children: ["SELECTED MESSAGE · #", O.seq]
									}),
									/* @__PURE__ */ (0, A.jsx)("strong", { children: O.operation.replaceAll("_", " ") }),
									/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "From" }), /* @__PURE__ */ (0, A.jsx)("b", { children: O.source_component_id.replaceAll("_", " ") })] }),
									/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "To" }), /* @__PURE__ */ (0, A.jsx)("b", { children: O.target_component_id.replaceAll("_", " ") })] }),
									/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Direction" }), /* @__PURE__ */ (0, A.jsxs)("b", { children: [
										O.direction,
										" · ",
										O.status
									] })] }),
									/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Time" }), /* @__PURE__ */ (0, A.jsx)("b", { children: O.timestamp_utc })] }),
									/* @__PURE__ */ (0, A.jsx)("pre", { children: JSON.stringify(O.payload_summary || {}, null, 2) })
								]
							})
						]
					})]
				}),
				S === "finance" && /* @__PURE__ */ (0, A.jsx)(Ge, {
					currentCase: t,
					history: n,
					historyDetail: r
				}),
				S === "components" && /* @__PURE__ */ (0, A.jsxs)("div", {
					className: "evidence-component-layout",
					children: [/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "evidence-component-details",
						children: [c, l]
					}), /* @__PURE__ */ (0, A.jsxs)("section", {
						className: "surface evidence-component-link",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "eyebrow",
								children: "PERSISTED TRACE"
							}),
							/* @__PURE__ */ (0, A.jsxs)("h2", { children: [a?.length || 0, " component events"] }),
							/* @__PURE__ */ (0, A.jsx)("p", { children: "Open Investigation proof to filter and inspect the selected case events." }),
							/* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								onClick: () => C("proof"),
								children: "Inspect event messages →"
							})
						]
					})]
				}),
				S === "questions" && /* @__PURE__ */ (0, A.jsx)(Ke, {
					run: o,
					questions: s,
					requestedSeq: u?.section === "questions" ? u.stepSeq : null
				}),
				S === "implementation" && /* @__PURE__ */ (0, A.jsx)(Je, {
					currentCase: t,
					events: a || i
				})
			]
		})]
	});
}
// src/ArchitectureQuestions.jsx
var Xe = [
	{
		id: "S1",
		label: "S1 · SAP-centric"
	},
	{
		id: "S2",
		label: "S2 · AWS AgentCore-centric"
	},
	{
		id: "S3",
		label: "S3 · SAP-hosted hybrid"
	}
];
function Ze({ step: e, selected: t, processing: n, onSelect: r }) {
	return /* @__PURE__ */ (0, A.jsxs)("button", {
		type: "button",
		"data-seq": e.seq,
		className: `lab-node ${e.status} ${t ? "selected" : ""} ${n ? "processing" : ""}`,
		onClick: r,
		"aria-label": `Step ${e.seq}: ${e.component}, ${e.status}`,
		children: [
			/* @__PURE__ */ (0, A.jsxs)("small", { children: [
				String(e.seq).padStart(2, "0"),
				" · ",
				e.phase
			] }),
			/* @__PURE__ */ (0, A.jsx)("strong", { children: e.component }),
			/* @__PURE__ */ (0, A.jsx)("span", { children: e.status.toUpperCase() })
		]
	});
}
function Qe({ playbooks: e, question: t, initialRoute: n, onClose: r }) {
	let [i, a] = (0, _.useState)(n), [o, s] = (0, _.useState)(0), c = e[i], l = c?.steps?.[o];
	return (0, _.useEffect)(() => {
		let e = (e) => {
			e.key === "Escape" && r();
		};
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}, [r]), /* @__PURE__ */ (0, A.jsx)("div", {
		className: "route-plan-backdrop",
		onMouseDown: (e) => {
			e.target === e.currentTarget && r();
		},
		children: /* @__PURE__ */ (0, A.jsxs)("section", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": "Gateway implementation plan",
			className: "route-plan-dialog",
			children: [
				/* @__PURE__ */ (0, A.jsxs)("header", { children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
					/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "ARCHITECTURE IMPLEMENTATION PLAN · CANDIDATE ONLY"
					}),
					/* @__PURE__ */ (0, A.jsx)("h2", { children: "What must be built and proved" }),
					/* @__PURE__ */ (0, A.jsx)("p", { children: "Choose a scenario and a handoff to inspect its configuration, dependency and acceptance proof." })
				] }), /* @__PURE__ */ (0, A.jsx)("button", {
					type: "button",
					onClick: r,
					"aria-label": "Close implementation plan",
					children: "Close ×"
				})] }),
				/* @__PURE__ */ (0, A.jsx)("nav", {
					className: "route-plan-tabs",
					"aria-label": "Gateway scenarios",
					children: Xe.map((e) => /* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						className: i === e.id ? "active" : "",
						onClick: () => {
							a(e.id), s(0);
						},
						"aria-pressed": i === e.id,
						children: e.label
					}, e.id))
				}),
				c ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "route-plan-summary",
						children: [
							/* @__PURE__ */ (0, A.jsx)("strong", { children: c.title }),
							/* @__PURE__ */ (0, A.jsx)("span", { children: c.status }),
							/* @__PURE__ */ (0, A.jsx)("p", { children: c.path }),
							/* @__PURE__ */ (0, A.jsxs)("small", { children: [
								/* @__PURE__ */ (0, A.jsx)("b", { children: "Hosting:" }),
								" ",
								c.hosting
							] })
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "route-plan-body",
						children: [
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: "route-plan-sequence",
								children: [/* @__PURE__ */ (0, A.jsx)("h3", { children: "Build sequence" }), c.steps.map((e, t) => /* @__PURE__ */ (0, A.jsxs)("button", {
									type: "button",
									className: o === t ? "active" : "",
									onClick: () => s(t),
									"aria-pressed": o === t,
									children: [
										/* @__PURE__ */ (0, A.jsx)("em", { children: String(t + 1).padStart(2, "0") }),
										/* @__PURE__ */ (0, A.jsx)("span", { children: e.handoff }),
										/* @__PURE__ */ (0, A.jsx)("b", {
											"aria-hidden": "true",
											children: "›"
										})
									]
								}, e.handoff))]
							}),
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: "route-plan-detail",
								children: [
									/* @__PURE__ */ (0, A.jsxs)("span", {
										className: "eyebrow",
										children: [
											"HANDOFF ",
											o + 1,
											" OF ",
											c.steps.length
										]
									}),
									/* @__PURE__ */ (0, A.jsx)("h3", { children: l?.handoff }),
									/* @__PURE__ */ (0, A.jsxs)("dl", { children: [
										/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("dt", { children: "Configure" }), /* @__PURE__ */ (0, A.jsx)("dd", { children: l?.configure })] }),
										/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("dt", { children: "Depends on" }), /* @__PURE__ */ (0, A.jsx)("dd", { children: l?.dependency })] }),
										/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("dt", { children: "Proof to accept" }), /* @__PURE__ */ (0, A.jsx)("dd", { children: l?.proof })] }),
										/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("dt", { children: "Accountable team" }), /* @__PURE__ */ (0, A.jsx)("dd", { children: l?.owner })] })
									] })
								]
							}),
							/* @__PURE__ */ (0, A.jsxs)("aside", {
								className: "route-plan-decisions",
								children: [
									/* @__PURE__ */ (0, A.jsx)("h3", { children: "Open decisions for this route" }),
									/* @__PURE__ */ (0, A.jsx)("ol", { children: c.decisions.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) }),
									t && /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
										/* @__PURE__ */ (0, A.jsxs)("h3", { children: ["For this question: ", t.title] }),
										/* @__PURE__ */ (0, A.jsx)("ul", { children: (t.dependencies || []).map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) }),
										/* @__PURE__ */ (0, A.jsxs)("strong", { children: ["Next: ", t.next_action] })
									] })
								]
							})
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("footer", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Reference designs only. Hosting, credentials, identity and SAP authorization require tenant proof and owner approval." }), /* @__PURE__ */ (0, A.jsx)("div", { children: c.sources.map((e) => /* @__PURE__ */ (0, A.jsxs)("a", {
						href: e.url,
						target: "_blank",
						rel: "noreferrer",
						children: [e.label, " ↗"]
					}, e.url)) })] })
				] }) : /* @__PURE__ */ (0, A.jsx)("p", {
					className: "empty-inline",
					children: "No route plan is available."
				})
			]
		})
	});
}
function $e({ questions: e = [], routePlaybooks: t = {}, focus: n, run: r, onRun: i, busy: a, onOpenEvidence: o }) {
	let [s, c] = (0, _.useState)(r?.question_id || null), [l, u] = (0, _.useState)(r?.route || "S3"), [d, f] = (0, _.useState)(r?.probe || ""), [p, m] = (0, _.useState)(null), [h, g] = (0, _.useState)(!0), [v, y] = (0, _.useState)(!1), b = (0, _.useRef)(null), x = e.find((e) => e.id === s), S = r?.question_id === s ? r : null, C = S?.steps || [], w = C.filter((e) => e.phase === "design-time"), T = C.filter((e) => e.phase !== "design-time"), E = C.find((e) => e.seq === p) || C.at(-1), D = C.findIndex((e) => e.seq === E?.seq);
	(0, _.useEffect)(() => {
		C.length && (h || p === null || !C.some((e) => e.seq === p)) && m(C.at(-1).seq);
	}, [
		S?.run_id,
		C.length,
		h
	]), (0, _.useEffect)(() => {
		S?.status === "complete" && h && C.length && (m(C[0].seq), g(!1));
	}, [
		S?.run_id,
		S?.status,
		C.length,
		h
	]), (0, _.useEffect)(() => {
		if (!n?.id || n.nonce === b.current) return;
		let t = e.find((e) => e.id === n.id);
		t && (b.current = n.nonce, O(t));
	}, [n?.nonce, e]);
	function O(e) {
		let t = e.default_route || "S3", n = e.probes[0].id;
		c(e.id), u(t), f(n), m(null), g(!0), i(e.id, t, n);
	}
	function k() {
		x && (m(null), g(!0), i(x.id, l, d));
	}
	function ee(e) {
		let t = C[D + e];
		t && (m(t.seq), g(!1));
	}
	return /* @__PURE__ */ (0, A.jsxs)("main", {
		className: "question-lab",
		"aria-label": "Architecture questions",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("aside", {
				className: "surface question-rail",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "section-heading",
						children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
							className: "eyebrow",
							children: "ARCHITECTURE ALIGNMENT"
						}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "Open questions" })] }), /* @__PURE__ */ (0, A.jsx)("span", {
							className: "pill simulated",
							children: "6 decisions"
						})]
					}),
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "lab-intro",
						children: "Select a question to run a synthetic component path. Each result remains an open architecture decision."
					}),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "question-list",
						children: e.map((e, t) => /* @__PURE__ */ (0, A.jsxs)("button", {
							type: "button",
							className: `question-card ${s === e.id ? "selected" : ""}`,
							onClick: () => O(e),
							"aria-pressed": s === e.id,
							children: [
								/* @__PURE__ */ (0, A.jsxs)("span", { children: [
									"Q",
									t + 1,
									" · OPEN"
								] }),
								/* @__PURE__ */ (0, A.jsx)("strong", { children: e.title }),
								/* @__PURE__ */ (0, A.jsx)("small", { children: e.summary })
							]
						}, e.id))
					}),
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "lab-footnote",
						children: "Each probe walks the selected scenario: S1 SAP-centric (Cloud Foundry agent, Apigee), S2 AWS AgentCore-centric (AgentCore Runtime and Gateway, then Apigee) and S3 SAP-hosted hybrid (Cloud Foundry agent, Apigee, AWS Agent Registry for registration only). Results are simulated; approval remains open."
					})
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "lab-center",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("section", {
						className: "surface lab-command",
						children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "eyebrow",
								children: "EXTERNAL AGENT / SAP ALIGNMENT PROBE"
							}),
							/* @__PURE__ */ (0, A.jsx)("h2", { children: x?.title || "Choose an architecture question" }),
							/* @__PURE__ */ (0, A.jsx)("p", { children: x?.summary || "Run a question to inspect the propagated request and response at each component." })
						] }), x && /* @__PURE__ */ (0, A.jsxs)("div", {
							className: "lab-controls",
							children: [
								/* @__PURE__ */ (0, A.jsxs)("label", { children: ["Route", /* @__PURE__ */ (0, A.jsx)("select", {
									"aria-label": "Architecture route",
									value: l,
									onChange: (e) => u(e.target.value),
									children: Xe.map((e) => /* @__PURE__ */ (0, A.jsx)("option", {
										value: e.id,
										children: e.label
									}, e.id))
								})] }),
								/* @__PURE__ */ (0, A.jsxs)("label", { children: ["Probe", /* @__PURE__ */ (0, A.jsx)("select", {
									"aria-label": "Architecture probe",
									value: d,
									onChange: (e) => f(e.target.value),
									children: x.probes.map((e) => /* @__PURE__ */ (0, A.jsx)("option", {
										value: e.id,
										children: e.label
									}, e.id))
								})] }),
								/* @__PURE__ */ (0, A.jsx)("button", {
									type: "button",
									className: "primary",
									onClick: k,
									disabled: a,
									children: a ? "Running…" : "Run selected probe"
								}),
								/* @__PURE__ */ (0, A.jsx)("button", {
									type: "button",
									className: "route-plan-open",
									onClick: () => y(!0),
									children: "Hosting & dependencies →"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, A.jsxs)("section", {
						className: "surface lab-flow-panel",
						children: [/* @__PURE__ */ (0, A.jsxs)("div", {
							className: "section-heading",
							children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
								className: "eyebrow",
								children: "COMPONENT HANDOFFS"
							}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "Propagated flow" })] }), /* @__PURE__ */ (0, A.jsxs)("div", {
								className: "lab-step-nav",
								children: [
									/* @__PURE__ */ (0, A.jsx)("button", {
										type: "button",
										onClick: () => ee(-1),
										disabled: D <= 0,
										"aria-label": "Previous handoff",
										children: "←"
									}),
									/* @__PURE__ */ (0, A.jsx)("span", { children: E ? `${E.seq}/${S.total_steps}` : "—" }),
									/* @__PURE__ */ (0, A.jsx)("button", {
										type: "button",
										onClick: () => ee(1),
										disabled: D < 0 || D >= C.length - 1,
										"aria-label": "Next handoff",
										children: "→"
									}),
									/* @__PURE__ */ (0, A.jsx)("span", {
										className: `pill ${S?.outcome === "DENIED" ? "warn" : "quiet"}`,
										children: S ? `${C.length}/${S.total_steps} steps · ${S.status}` : "Awaiting question"
									})
								]
							})]
						}), S ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: "lab-route-note",
								children: [
									/* @__PURE__ */ (0, A.jsx)("strong", { children: S.route_label }),
									/* @__PURE__ */ (0, A.jsx)("span", { children: S.route_status }),
									/* @__PURE__ */ (0, A.jsx)("span", { children: S.outcome })
								]
							}),
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: "lab-design-branch",
								children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "DESIGN-TIME PREREQUISITE · NOT A RUNTIME HOP" }), w.map((e) => /* @__PURE__ */ (0, A.jsx)(Ze, {
									step: e,
									selected: E?.seq === e.seq,
									processing: S.status === "running" && e.seq === C.at(-1)?.seq,
									onSelect: () => {
										m(e.seq), g(!1);
									}
								}, e.seq))]
							}),
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: "lab-flow",
								"aria-label": "Architecture runtime call path",
								children: [
									/* @__PURE__ */ (0, A.jsx)("span", {
										className: "lab-flow-caption",
										children: "RUNTIME CALL PATH · LEFT TO RIGHT, THEN NEXT ROW"
									}),
									T.map((e) => /* @__PURE__ */ (0, A.jsx)(Ze, {
										step: e,
										selected: E?.seq === e.seq,
										processing: S.status === "running" && e.seq === C.at(-1)?.seq,
										onSelect: () => {
											m(e.seq), g(!1);
										}
									}, e.seq)),
									S.status === "running" && /* @__PURE__ */ (0, A.jsx)("div", {
										className: "lab-pending",
										"aria-live": "polite",
										children: "Evaluating next handoff…"
									})
								]
							})
						] }) : /* @__PURE__ */ (0, A.jsx)("div", {
							className: "empty-inline",
							children: "Click an open question to generate its route and control trace."
						})]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "lab-evidence-link",
						children: [/* @__PURE__ */ (0, A.jsx)("span", { children: E ? `Selected handoff · ${E.component}` : "Select a question to trace its route" }), /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							onClick: () => o?.(E?.seq),
							disabled: !S,
							children: "Inspect handoff details in Evidence →"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("aside", {
				className: "surface lab-decision",
				children: [/* @__PURE__ */ (0, A.jsx)("div", {
					className: "section-heading",
					children: /* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "MEETING DECISION RECORD"
					}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "Required alignment" })] })
				}), x ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "lab-position",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Discussion baseline · not approved policy" }),
							/* @__PURE__ */ (0, A.jsx)("p", { children: x.current_position }),
							x.scenario_position?.[l] && /* @__PURE__ */ (0, A.jsxs)("p", {
								"data-testid": "scenario-position",
								children: [
									/* @__PURE__ */ (0, A.jsxs)("strong", { children: [l, ":"] }),
									" ",
									x.scenario_position[l]
								]
							})
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "lab-decision-question",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Decision to resolve" }),
							/* @__PURE__ */ (0, A.jsx)("strong", { children: x.decision }),
							/* @__PURE__ */ (0, A.jsxs)("small", { children: ["Owner · ", x.owner] })
						]
					}),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "lab-open-status",
						children: "OPEN · No policy or tenant approval is asserted by this simulator."
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "lab-next-action",
						children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Next action" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: x.next_action })]
					}),
					/* @__PURE__ */ (0, A.jsx)("h3", { children: "Proof required to close" }),
					/* @__PURE__ */ (0, A.jsx)("ul", {
						className: "lab-gates",
						children: x.gates.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e))
					}),
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "lab-decision-hint",
						children: "Detailed handoff records and the synthetic decision packet are in Evidence & correlation."
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						className: "lab-export",
						onClick: () => o?.(E?.seq),
						children: "Open decision evidence →"
					})
				] }) : /* @__PURE__ */ (0, A.jsx)("p", {
					className: "empty-inline",
					children: "Select an open question to see its decision owner and required architecture alignment. Control details are in Evidence."
				})]
			}),
			v && /* @__PURE__ */ (0, A.jsx)(Qe, {
				playbooks: t,
				question: x,
				initialRoute: l,
				onClose: () => y(!1)
			})
		]
	});
}
var L = {
	version: "5.1",
	banner: "PROPOSED DESIGN FOR EVALUATION · NOT TENANT-VERIFIED · NOT AN APPROVED ARCHITECTURE",
	ids: [
		"S1",
		"S2",
		"S3"
	],
	scenarios: /* @__PURE__ */ JSON.parse("{\"S1\":{\"id\":\"S1\",\"name\":\"S1 · SAP-centric\",\"short\":\"SAP-centric\",\"status\":\"Evaluation candidate\",\"objective\":\"SAP owns agent execution and the domain's MCP capability. Apigee is the SAP-facing MCP/API gateway. Registration is domain-managed; no AWS component takes part.\",\"agent_runtime\":\"SAP BTP Cloud Foundry\",\"agent_hosting_owner\":\"SAP BTP platform team\",\"agent_execution_endpoint\":\"Cloud Foundry application route (agent API)\",\"ui_hosting\":\"SAP Fiori launchpad or the existing application UI\",\"mcp_client\":\"Inside the agent process on Cloud Foundry\",\"mcp_endpoint_type\":\"Apigee-managed MCP endpoint (Pattern A); custom MCP server behind Apigee only where logic is needed (Pattern B)\",\"mcp_gateway\":\"Google Apigee (SAP-facing MCP/API gateway and policy layer)\",\"custom_mcp_runtime\":\"SAP BTP Cloud Foundry, only if required\",\"custom_mcp_hosting_owner\":\"SAP BTP platform team\",\"mcp_tool_execution_location\":\"Pattern A: API operation behind Apigee. Pattern B: the custom MCP service on Cloud Foundry\",\"agent_registry\":\"Domain-managed catalog · product selection pending\",\"mcp_registry\":\"Domain-managed catalog · product selection pending\",\"registry_publisher_approver\":\"Domain team publishes; approval owner TBD · REQUIRES VALIDATION\",\"registry_sync\":\"Not defined. No product is selected, so no synchronization mechanism exists\",\"agent_discovery\":\"Domain-managed catalog lookup (mechanism TBD · REQUIRES VALIDATION)\",\"mcp_tool_discovery\":\"Apigee MCP tools/list at the endpoint; catalog lookup TBD · REQUIRES VALIDATION\",\"agentcore_runtime\":false,\"agentcore_gateway\":false,\"aws_agent_registry\":false,\"llm_gateway\":\"Portkey\",\"llm_boundary\":\"Cloud Foundry agent → Portkey → approved LLM provider. No direct provider route\",\"integration_suite\":\"SAP Integration Suite (API Management / Cloud Integration)\",\"cloud_connector\":\"SAP Cloud Connector, where the system connectivity model needs it (conditional)\",\"backend_authorization\":\"Target SAP backend roles of the mapped user or service identity\",\"identity_boundary\":\"Enterprise IdP or SAP Cloud Identity Services (IAS, candidate); token exchange and user mapping subject to validation\",\"persistence\":\"Conditional: SAP HANA Cloud or an existing approved store, only if durable state is required\",\"monitoring_audit\":\"SAP BTP logs for the agent; Apigee analytics; Integration Suite monitoring; SAP change documents\",\"artifact_repository\":\"Organization Git; Cloud Foundry application artifacts; Apigee proxy bundles and OpenAPI specs\",\"trust_boundaries\":[\"SAP BTP\",\"Google Apigee\",\"SAP landscape\",\"Portkey / LLM provider\"],\"assumptions\":[\"Apigee MCP is enabled for the organization and fronts approved Integration Suite APIs\",\"An enterprise IdP can issue tokens to the Cloud Foundry agent\"],\"unverified\":[\"Registry product for agents and MCP\",\"Apigee-to-Integration Suite identity mapping\",\"Principal propagation to the SAP backend\"],\"policy_dependencies\":[\"Whether the enterprise requires central registration of agents and MCP servers\",\"Who owns domain MCP interfaces\"],\"hosting_note\":\"Registry is Domain-managed — product selection pending. Do not read it as an SAP-native Agent Registry.\"},\"S2\":{\"id\":\"S2\",\"name\":\"S2 · AWS AgentCore-centric\",\"short\":\"AgentCore-centric\",\"status\":\"Evaluation candidate\",\"objective\":\"AWS owns agent execution, any custom MCP code hosting, the runtime gateway and enterprise registration. Apigee remains the SAP-facing MCP/API gateway behind AgentCore Gateway.\",\"agent_runtime\":\"AWS AgentCore Runtime\",\"agent_hosting_owner\":\"AWS cloud platform team\",\"agent_execution_endpoint\":\"AgentCore Runtime agent invocation endpoint\",\"ui_hosting\":\"Existing application UI or SAP Fiori acting as an agent client\",\"mcp_client\":\"Inside the agent process on AgentCore Runtime\",\"mcp_endpoint_type\":\"AgentCore Gateway MCP endpoint toward the agent; Apigee-managed MCP endpoint (Pattern A) toward SAP; custom MCP on AgentCore Runtime only if required (Pattern B)\",\"mcp_gateway\":\"AWS AgentCore Gateway (enterprise MCP gateway) and Google Apigee (SAP-facing MCP/API gateway)\",\"custom_mcp_runtime\":\"AWS AgentCore Runtime, if required\",\"custom_mcp_hosting_owner\":\"AWS cloud platform team\",\"mcp_tool_execution_location\":\"Pattern A: API operation behind Apigee. Pattern B: custom MCP on AgentCore Runtime, reached through Apigee as a cross-cloud target (conditional)\",\"agent_registry\":\"AWS Agent Registry\",\"mcp_registry\":\"AWS Agent Registry\",\"registry_publisher_approver\":\"AI Foundry publishes; approval owner TBD · REQUIRES VALIDATION\",\"registry_sync\":\"Registry records created from agent and MCP descriptors; external sources via registry synchronization where supported\",\"agent_discovery\":\"AWS Agent Registry search, approved records only\",\"mcp_tool_discovery\":\"AgentCore Gateway tools/list; MCP descriptor in AWS Agent Registry\",\"agentcore_runtime\":true,\"agentcore_gateway\":true,\"aws_agent_registry\":true,\"llm_gateway\":\"Portkey\",\"llm_boundary\":\"AgentCore Runtime agent → Portkey → approved LLM provider. No direct provider route\",\"integration_suite\":\"SAP Integration Suite (API Management / Cloud Integration)\",\"cloud_connector\":\"SAP Cloud Connector, where the system connectivity model needs it (conditional)\",\"backend_authorization\":\"Target SAP backend roles of the mapped user or service identity\",\"identity_boundary\":\"Enterprise IdP and AgentCore Identity toward the gateway; Apigee and Integration Suite identities beyond; token exchange and user mapping subject to validation\",\"persistence\":\"Conditional: approved AWS persistence, only if durable state is required\",\"monitoring_audit\":\"AgentCore Runtime and Gateway observability; Apigee analytics; Integration Suite monitoring; SAP change documents\",\"artifact_repository\":\"Organization Git; container registry for the runtime image; gateway target definitions; Apigee bundles and specs\",\"trust_boundaries\":[\"AWS\",\"Google Apigee\",\"SAP landscape\",\"Portkey / LLM provider\"],\"assumptions\":[\"AgentCore Gateway can register Apigee's MCP endpoint as a target\",\"An AWS-hosted custom MCP can be proxied by Apigee (conditional)\"],\"unverified\":[\"AgentCore Gateway to Apigee protocol and token exchange; target classification of an external MCP server (MCP or HTTP target) is unclear in the documentation\",\"Two policy points on one call (gateway then Apigee)\",\"AWS Agent Registry availability and region\"],\"policy_dependencies\":[\"Whether AI Foundry requires AgentCore for all agent hosting\",\"Ownership of duplicated gateway policy\"],\"hosting_note\":\"AgentCore Runtime, AgentCore Gateway and AWS Agent Registry are three distinct capabilities.\"},\"S3\":{\"id\":\"S3\",\"name\":\"S3 · SAP-hosted hybrid\",\"short\":\"SAP-hosted hybrid\",\"status\":\"Preferred candidate — subject to AI Foundry policy and POC validation\",\"objective\":\"SAP retains execution ownership while AI Foundry manages central discovery and registration. Hosting on SAP BTP, registration in AWS Agent Registry, no AWS execution hop.\",\"agent_runtime\":\"SAP BTP Cloud Foundry\",\"agent_hosting_owner\":\"SAP BTP platform team\",\"agent_execution_endpoint\":\"Cloud Foundry application route (agent API)\",\"ui_hosting\":\"SAP Fiori launchpad or the existing application UI\",\"mcp_client\":\"Inside the agent process on Cloud Foundry\",\"mcp_endpoint_type\":\"Apigee-managed MCP endpoint (Pattern A); custom MCP server behind Apigee only where logic is needed (Pattern B)\",\"mcp_gateway\":\"Google Apigee (SAP-facing MCP/API gateway and policy layer)\",\"custom_mcp_runtime\":\"SAP BTP Cloud Foundry, if required\",\"custom_mcp_hosting_owner\":\"SAP BTP platform team\",\"mcp_tool_execution_location\":\"Pattern A: API operation behind Apigee. Pattern B: the custom MCP service on Cloud Foundry\",\"agent_registry\":\"AWS Agent Registry\",\"mcp_registry\":\"AWS Agent Registry\",\"registry_publisher_approver\":\"AI Foundry approves; domain team publishes SAP-hosted agent and Apigee MCP endpoint metadata\",\"registry_sync\":\"Registry records for SAP-hosted agent and Apigee MCP endpoint, created or synchronized from external sources where supported (control plane only)\",\"agent_discovery\":\"AWS Agent Registry search, approved records only\",\"mcp_tool_discovery\":\"Apigee MCP tools/list at the endpoint; endpoint metadata in AWS Agent Registry\",\"agentcore_runtime\":false,\"agentcore_gateway\":false,\"aws_agent_registry\":true,\"llm_gateway\":\"Portkey\",\"llm_boundary\":\"Cloud Foundry agent → Portkey → approved LLM provider. No direct provider route\",\"integration_suite\":\"SAP Integration Suite (API Management / Cloud Integration)\",\"cloud_connector\":\"SAP Cloud Connector, where the system connectivity model needs it (conditional)\",\"backend_authorization\":\"Target SAP backend roles of the mapped user or service identity\",\"identity_boundary\":\"Enterprise IdP or SAP Cloud Identity Services (IAS, candidate); registry access is a separate control-plane identity; token exchange and user mapping subject to validation\",\"persistence\":\"Conditional: SAP HANA Cloud or an existing approved store, only if durable state is required\",\"monitoring_audit\":\"SAP BTP logs for the agent; Apigee analytics; Integration Suite monitoring; SAP change documents; registry audit for publication events\",\"artifact_repository\":\"Organization Git; Cloud Foundry application artifacts; Apigee bundles and specs; registry record definitions\",\"trust_boundaries\":[\"SAP BTP\",\"Google Apigee\",\"SAP landscape\",\"AWS (control plane only)\",\"Portkey / LLM provider\"],\"assumptions\":[\"AWS Agent Registry can hold records for agents and MCP servers that run outside AWS (record sync connects from AWS to the endpoint URL with outbound credentials)\",\"Registration does not require AWS to host or invoke anything\"],\"unverified\":[\"Registry synchronization from the external sources in this tenant: AWS must be able to reach the Apigee or Cloud Foundry URL with an outbound credential from a provider in the same account\",\"AI Foundry stance on tool calls that bypass AgentCore Gateway\",\"Cross-cloud administration of registry records\"],\"policy_dependencies\":[\"AI Foundry policy on whether AgentCore Gateway is mandatory for all tool invocations (see S3-B)\"],\"hosting_note\":\"AWS Agent Registry handles registration, discovery and governance metadata. It is never an execution hop.\",\"variant_b\":\"S3-B (policy-dependent, not baseline): if AI Foundry mandates AgentCore Gateway for every tool invocation, AgentCore Gateway sits between the agent and Apigee. It is documented as an option, not a fourth primary scenario.\"}}"),
	comparison: [
		[
			"Agent hosting",
			"SAP BTP Cloud Foundry",
			"AWS AgentCore Runtime",
			"SAP BTP Cloud Foundry"
		],
		[
			"Agent execution",
			"Cloud Foundry application",
			"AgentCore Runtime agent",
			"Cloud Foundry application"
		],
		[
			"MCP gateway",
			"Google Apigee",
			"AgentCore Gateway (enterprise) in front of Google Apigee (SAP-facing)",
			"Google Apigee"
		],
		[
			"Managed MCP endpoint versus custom server",
			"Pattern A is the default: an approved API exposed as an MCP tool through Apigee, no custom server. Pattern B only where logic needs code",
			"Same two patterns behind Apigee; AgentCore Gateway fronts both",
			"Same as S1"
		],
		[
			"Custom MCP server hosting",
			"SAP BTP Cloud Foundry, only if required",
			"AWS AgentCore Runtime, if required (proxied by Apigee: cross-cloud, conditional)",
			"SAP BTP Cloud Foundry, if required"
		],
		[
			"MCP tool execution",
			"Behind Apigee: API operation, or the Cloud Foundry service",
			"Behind Apigee: API operation, or the AgentCore-hosted service through a cross-cloud target",
			"Behind Apigee: API operation, or the Cloud Foundry service"
		],
		[
			"Agent registry",
			"Domain-managed catalog · product selection pending",
			"AWS Agent Registry",
			"AWS Agent Registry"
		],
		[
			"MCP registry",
			"Domain-managed catalog · product selection pending",
			"AWS Agent Registry",
			"AWS Agent Registry"
		],
		[
			"LLM routing",
			"Portkey",
			"Portkey",
			"Portkey"
		],
		[
			"Persistence",
			"Conditional: SAP HANA Cloud or an existing approved store",
			"Conditional: approved AWS persistence",
			"Conditional: SAP HANA Cloud or an existing approved store"
		],
		[
			"Identity propagation",
			"Enterprise IdP or IAS to agent, Apigee, Integration Suite; mapping to validate",
			"Adds AgentCore Identity and a second gateway hop; mapping to validate",
			"As S1 plus a separate control-plane identity to the registry"
		],
		[
			"SAP connectivity",
			"Apigee → SAP Integration Suite → Cloud Connector where applicable → SAP backend",
			"Same after Apigee",
			"Same as S1"
		],
		[
			"Business authorization",
			"SAP backend, always",
			"SAP backend, always",
			"SAP backend, always"
		],
		[
			"Operational responsibility",
			"SAP BTP team runs the agent and any custom MCP; the integration team runs Apigee",
			"AWS team runs agent, gateway and any custom MCP; the integration team runs Apigee",
			"As S1; AI Foundry runs the registry"
		],
		[
			"Monitoring and audit",
			"BTP logs, Apigee analytics, Integration Suite monitoring; correlation id to propagate",
			"AgentCore observability plus the same SAP-side sources; two gateway logs to correlate",
			"As S1 plus registry publication audit"
		],
		[
			"Scalability",
			"Cloud Foundry application scaling; limited by BTP quota",
			"AgentCore managed runtime scaling",
			"As S1"
		],
		[
			"Network complexity",
			"Cloud Foundry → Apigee (cross-cloud) → Integration Suite",
			"AWS → Apigee (cross-cloud) → Integration Suite; Pattern B adds Apigee → AWS",
			"As S1; registry traffic is separate control-plane traffic"
		],
		[
			"Cost drivers",
			"BTP runtime, Apigee, Integration Suite, Portkey",
			"AgentCore Runtime and Gateway, Agent Registry, Apigee, Integration Suite, Portkey",
			"BTP runtime, Agent Registry, Apigee, Integration Suite, Portkey"
		],
		[
			"Vendor and platform dependencies",
			"SAP BTP, Google Apigee",
			"AWS, Google Apigee",
			"SAP BTP, AWS (registry only), Google Apigee"
		],
		[
			"Enterprise governance alignment",
			"Registry unresolved: governance for discovery is a gap",
			"Aligned with AWS-centric AI Foundry governance",
			"Central registration under AI Foundry with SAP execution ownership"
		],
		[
			"Deployment prerequisites",
			"Cloud Foundry space, Apigee MCP enablement, Integration Suite APIs, IdP, Portkey route",
			"AgentCore access in region, Gateway target for Apigee, registry, Apigee MCP, IdP, Portkey route",
			"As S1 plus Agent Registry access and record synchronization method"
		],
		[
			"Open architecture decisions",
			"Which registry product; who approves publication",
			"Gateway-to-Apigee token exchange; duplicate policy ownership",
			"Whether AgentCore Gateway is mandated (S3-B); registry synchronization method"
		]
	],
	connCols: [
		"Source",
		"Destination",
		"Plane",
		"Protocol",
		"Authentication",
		"Verification"
	],
	connections: {
		S1: [
			[
				"SAP Fiori / existing UI",
				"Cloud Foundry agent (MCP client)",
				"Runtime",
				"HTTPS",
				"User sign-in; delegated token to validate",
				"Design assumption"
			],
			[
				"Cloud Foundry agent (MCP client)",
				"Apigee MCP endpoint",
				"Runtime",
				"MCP over Streamable HTTP",
				"OAuth 2.1 / OIDC bearer or API key per product",
				"Vendor-documented · tenant NOT_VERIFIED"
			],
			[
				"Apigee MCP/API",
				"SAP Integration Suite",
				"Runtime",
				"HTTPS REST or OData",
				"OAuth client or certificate; mapping to validate",
				"Design assumption"
			],
			[
				"SAP Integration Suite",
				"SAP Cloud Connector (conditional)",
				"Runtime",
				"HTTPS tunnel",
				"Cloud Connector subaccount trust",
				"Applicable only for private connectivity"
			],
			[
				"SAP Cloud Connector or Integration Suite",
				"SAP backend (S/4HANA · Central Finance)",
				"Runtime",
				"RFC / OData",
				"Principal propagation or technical user; SAP roles decide",
				"Design assumption"
			],
			[
				"Cloud Foundry agent (MCP client)",
				"Portkey",
				"LLM",
				"HTTPS",
				"Portkey credential; provider keys held in Portkey",
				"Design assumption"
			],
			[
				"Portkey",
				"Approved LLM provider",
				"LLM",
				"HTTPS",
				"Provider credential held in Portkey",
				"Design assumption"
			],
			[
				"Cloud Foundry agent (MCP client)",
				"Domain-managed catalog · product selection pending",
				"Registration / discovery (not invocation)",
				"Registry API",
				"Registry identity",
				"TBD · REQUIRES VALIDATION"
			],
			[
				"Apigee MCP endpoint",
				"Custom MCP server on Cloud Foundry (Pattern B)",
				"Runtime (conditional)",
				"HTTPS proxy target",
				"Target credential held by Apigee",
				"Only where custom logic is required"
			]
		],
		S2: [
			[
				"SAP Fiori / existing UI",
				"AgentCore Runtime agent (MCP client)",
				"Runtime",
				"HTTPS",
				"User sign-in; delegated token to validate",
				"Design assumption"
			],
			[
				"AgentCore Runtime agent (MCP client)",
				"AgentCore Gateway",
				"Runtime",
				"MCP over Streamable HTTP",
				"JWT bearer validated by the gateway authorizer, or IAM",
				"Vendor-documented · tenant NOT_VERIFIED"
			],
			[
				"AgentCore Gateway",
				"Apigee MCP endpoint",
				"Runtime",
				"MCP over Streamable HTTP; protocol compatibility unproven",
				"Outbound OAuth or API key via AgentCore Identity; token exchange to validate",
				"TBD · REQUIRES VALIDATION"
			],
			[
				"Apigee MCP/API",
				"SAP Integration Suite",
				"Runtime",
				"HTTPS REST or OData",
				"OAuth client or certificate; mapping to validate",
				"Design assumption"
			],
			[
				"SAP Integration Suite",
				"SAP Cloud Connector (conditional)",
				"Runtime",
				"HTTPS tunnel",
				"Cloud Connector subaccount trust",
				"Applicable only for private connectivity"
			],
			[
				"SAP Cloud Connector or Integration Suite",
				"SAP backend (S/4HANA · Central Finance)",
				"Runtime",
				"RFC / OData",
				"Principal propagation or technical user; SAP roles decide",
				"Design assumption"
			],
			[
				"AgentCore Runtime agent (MCP client)",
				"Portkey",
				"LLM",
				"HTTPS",
				"Portkey credential; provider keys held in Portkey",
				"Design assumption"
			],
			[
				"Portkey",
				"Approved LLM provider",
				"LLM",
				"HTTPS",
				"Provider credential held in Portkey",
				"Design assumption"
			],
			[
				"AgentCore Runtime agent (MCP client)",
				"AWS Agent Registry",
				"Registration / discovery (not invocation)",
				"Registry API",
				"Registry identity",
				"Vendor-documented · tenant NOT_VERIFIED"
			],
			[
				"Apigee MCP endpoint",
				"Custom MCP on AgentCore Runtime (Pattern B)",
				"Runtime (conditional, cross-cloud)",
				"HTTPS proxy target",
				"Target credential held by Apigee",
				"Only where custom logic is required; extra network hop"
			]
		],
		S3: [
			[
				"SAP Fiori / existing UI",
				"Cloud Foundry agent (MCP client)",
				"Runtime",
				"HTTPS",
				"User sign-in; delegated token to validate",
				"Design assumption"
			],
			[
				"Cloud Foundry agent (MCP client)",
				"Apigee MCP endpoint",
				"Runtime",
				"MCP over Streamable HTTP",
				"OAuth 2.1 / OIDC bearer or API key per product",
				"Vendor-documented · tenant NOT_VERIFIED"
			],
			[
				"Apigee MCP/API",
				"SAP Integration Suite",
				"Runtime",
				"HTTPS REST or OData",
				"OAuth client or certificate; mapping to validate",
				"Design assumption"
			],
			[
				"SAP Integration Suite",
				"SAP Cloud Connector (conditional)",
				"Runtime",
				"HTTPS tunnel",
				"Cloud Connector subaccount trust",
				"Applicable only for private connectivity"
			],
			[
				"SAP Cloud Connector or Integration Suite",
				"SAP backend (S/4HANA · Central Finance)",
				"Runtime",
				"RFC / OData",
				"Principal propagation or technical user; SAP roles decide",
				"Design assumption"
			],
			[
				"Cloud Foundry agent (MCP client)",
				"Portkey",
				"LLM",
				"HTTPS",
				"Portkey credential; provider keys held in Portkey",
				"Design assumption"
			],
			[
				"Portkey",
				"Approved LLM provider",
				"LLM",
				"HTTPS",
				"Provider credential held in Portkey",
				"Design assumption"
			],
			[
				"Cloud Foundry agent (MCP client)",
				"AWS Agent Registry",
				"Registration / discovery (not invocation)",
				"Registry API",
				"Registry identity",
				"Vendor-documented · tenant NOT_VERIFIED"
			],
			[
				"Apigee MCP endpoint metadata",
				"AWS Agent Registry",
				"Registration (not invocation)",
				"Registry API or synchronization where supported",
				"Registry identity, separate from runtime identity",
				"TBD · REQUIRES VALIDATION"
			],
			[
				"Apigee MCP endpoint",
				"Custom MCP server on Cloud Foundry (Pattern B)",
				"Runtime (conditional)",
				"HTTPS proxy target",
				"Target credential held by Apigee",
				"Only where custom logic is required"
			]
		]
	},
	diagrams: /* @__PURE__ */ JSON.parse("{\"D1\":{\"id\":\"D1\",\"scenario\":null,\"title\":\"Enterprise architecture overview\",\"chain\":\"Control plane · runtime plane · evidence plane, common to S1, S2 and S3\",\"banner\":\"PROPOSED DESIGN FOR EVALUATION · NOT TENANT-VERIFIED · NOT AN APPROVED ARCHITECTURE\",\"cols\":6,\"nh\":100,\"ys\":[118,258,398,528,668],\"height\":840,\"nodes\":[{\"id\":\"idp\",\"row\":0,\"col\":0,\"title\":\"Identity providers\",\"sub\":\"Enterprise IdP, SAP Cloud Identity (candidate); trust boundaries\",\"kind\":\"identity\"},{\"id\":\"reg\",\"row\":0,\"col\":2,\"title\":\"Agent and MCP registries\",\"sub\":\"Control plane: catalog, discovery, approval\",\"kind\":\"registry\"},{\"id\":\"ent\",\"row\":0,\"col\":4,\"title\":\"AI Foundry governance\",\"sub\":\"Approval and publication authority\",\"kind\":\"decision\"},{\"id\":\"ui\",\"row\":1,\"col\":0,\"title\":\"SAP Fiori / existing UI\",\"sub\":\"Finance user entry\",\"kind\":\"ui\"},{\"id\":\"agent\",\"row\":1,\"col\":1,\"title\":\"Agent execution platform\",\"sub\":\"Runtime plane · hosts agent and MCP client\",\"kind\":\"agent\"},{\"id\":\"gw\",\"row\":1,\"col\":2,\"title\":\"MCP gateway / API layer\",\"sub\":\"Google Apigee; AgentCore Gateway in S2 only\",\"kind\":\"gateway\"},{\"id\":\"int\",\"row\":1,\"col\":3,\"title\":\"SAP Integration Suite\",\"sub\":\"SAP integration boundary\",\"kind\":\"integration\"},{\"id\":\"cc\",\"row\":1,\"col\":4,\"title\":\"SAP Cloud Connector\",\"sub\":\"Conditional\",\"kind\":\"integration\",\"dashed\":true},{\"id\":\"sap\",\"row\":1,\"col\":5,\"title\":\"SAP Finance backend\",\"sub\":\"S/4HANA · Central Finance\",\"kind\":\"backend\"},{\"id\":\"portkey\",\"row\":2,\"col\":0,\"title\":\"Portkey\",\"sub\":\"LLM gateway\",\"kind\":\"llm\"},{\"id\":\"llm\",\"row\":2,\"col\":1,\"title\":\"Approved LLM provider\",\"sub\":\"Only through Portkey\",\"kind\":\"llm\"},{\"id\":\"custom\",\"row\":2,\"col\":2,\"title\":\"Custom MCP runtime\",\"sub\":\"Only where logic needs code; platform per scenario\",\"kind\":\"domain\",\"dashed\":true},{\"id\":\"obs\",\"row\":3,\"col\":3,\"title\":\"Observability and audit\",\"sub\":\"Evidence plane: logs, traces, change documents\",\"kind\":\"store\",\"span\":3}],\"edges\":[[\"ui\",\"agent\",\"invoke\",\"\"],[\"agent\",\"gw\",\"invoke\",\"MCP tools/call\"],[\"gw\",\"int\",\"invoke\",\"API call\"],[\"int\",\"cc\",\"invoke\",\"if private\"],[\"cc\",\"sap\",\"invoke\",\"RFC / OData\"],[\"gw\",\"custom\",\"invoke\",\"proxy target (if needed)\"],[\"agent\",\"portkey\",\"llm\",\"LLM request\",{\"off\":-14}],[\"portkey\",\"llm\",\"llm\",\"model call\"],[\"idp\",\"agent\",\"identity\",\"tokens\"],[\"agent\",\"reg\",\"registry\",\"register / discover\",{\"off\":14}],[\"ent\",\"reg\",\"approval\",\"approve\"],[\"cc\",\"obs\",\"audit\",\"evidence\"],[\"sap\",\"obs\",\"audit\",\"evidence\"]],\"bounds\":[[\"SAP landscape\",[\"int\",\"cc\",\"sap\"],\"sap\"]],\"lanes\":[[0,\"CONTROL PLANE\"],[1,\"RUNTIME PLANE\"],[2,\"LLM · OPTIONAL\"],[3,\"EVIDENCE PLANE\"]],\"legend\":[\"invoke\",\"registry\",\"llm\",\"identity\",\"audit\",\"approval\"],\"footer\":\"No registry is a runtime hop. Per-scenario placement of the agent platform and gateway is in D2 to D4.\"},\"D2\":{\"id\":\"D2\",\"scenario\":\"S1\",\"title\":\"S1 · SAP-centric · topology\",\"chain\":\"UI → Cloud Foundry agent → Apigee MCP/API → Integration Suite → Cloud Connector (conditional) → SAP backend\",\"banner\":\"PROPOSED DESIGN FOR EVALUATION · NOT TENANT-VERIFIED · NOT AN APPROVED ARCHITECTURE\",\"cols\":6,\"nh\":100,\"ys\":[118,258,398,528,668],\"height\":840,\"nodes\":[{\"id\":\"ui\",\"row\":1,\"col\":0,\"title\":\"SAP Fiori / existing UI\",\"sub\":\"Finance user entry; application unchanged\",\"kind\":\"ui\"},{\"id\":\"idp\",\"row\":0,\"col\":0,\"title\":\"Enterprise identity\",\"sub\":\"IdP or SAP Cloud Identity (IAS, candidate); mapping to validate\",\"kind\":\"identity\"},{\"id\":\"agent\",\"row\":1,\"col\":1,\"title\":\"Agent · SAP BTP Cloud Foundry\",\"sub\":\"Agent execution and MCP client\",\"kind\":\"agent\"},{\"id\":\"apigee\",\"row\":1,\"col\":2,\"title\":\"Google Apigee MCP/API\",\"sub\":\"SAP-facing gateway; managed MCP endpoint (Pattern A)\",\"kind\":\"gateway\"},{\"id\":\"int\",\"row\":1,\"col\":3,\"title\":\"SAP Integration Suite\",\"sub\":\"SAP integration boundary\",\"kind\":\"integration\"},{\"id\":\"cc\",\"row\":1,\"col\":4,\"title\":\"SAP Cloud Connector\",\"sub\":\"Conditional, private connectivity only\",\"kind\":\"integration\",\"dashed\":true},{\"id\":\"sap\",\"row\":1,\"col\":5,\"title\":\"SAP backend\",\"sub\":\"S/4HANA · Central Finance; business authorization\",\"kind\":\"backend\"},{\"id\":\"custom\",\"row\":2,\"col\":3,\"title\":\"Custom MCP · SAP BTP Cloud Foundry\",\"sub\":\"Pattern B, only if required; behind Apigee\",\"kind\":\"domain\",\"dashed\":true},{\"id\":\"portkey\",\"row\":0,\"col\":1,\"title\":\"Portkey\",\"sub\":\"LLM gateway: model selection, credentials, fallback\",\"kind\":\"llm\"},{\"id\":\"llm\",\"row\":0,\"col\":2,\"title\":\"Approved LLM provider\",\"sub\":\"Reached only through Portkey\",\"kind\":\"llm\"},{\"id\":\"db\",\"row\":2,\"col\":0,\"title\":\"Persistence · conditional\",\"sub\":\"SAP HANA Cloud or existing approved store, only if needed\",\"kind\":\"store\",\"dashed\":true},{\"id\":\"reg_agent\",\"row\":3,\"col\":1,\"title\":\"Agent registry\",\"sub\":\"Domain-managed catalog\",\"kind\":\"registry\",\"dashed\":true,\"status\":\"PRODUCT SELECTION PENDING\",\"statusColor\":\"#B3261E\"},{\"id\":\"reg_mcp\",\"row\":3,\"col\":2,\"title\":\"MCP registry\",\"sub\":\"Domain-managed catalog\",\"kind\":\"registry\",\"dashed\":true,\"status\":\"PRODUCT SELECTION PENDING\",\"statusColor\":\"#B3261E\"}],\"edges\":[[\"ui\",\"agent\",\"invoke\",\"\"],[\"agent\",\"apigee\",\"invoke\",\"MCP tools/call\"],[\"apigee\",\"int\",\"invoke\",\"API call\"],[\"int\",\"cc\",\"invoke\",\"if private\"],[\"cc\",\"sap\",\"invoke\",\"RFC / OData\"],[\"apigee\",\"custom\",\"invoke\",\"proxy target\"],[\"agent\",\"portkey\",\"llm\",\"LLM request\",{\"off\":-14}],[\"portkey\",\"llm\",\"llm\",\"model call\"],[\"idp\",\"agent\",\"identity\",\"workload / user token\"],[\"agent\",\"db\",\"invoke\",\"state if required\",{\"off\":20}],[\"agent\",\"reg_agent\",\"registry\",\"register / discover\",{\"off\":-20,\"labelAt\":\"mid\"}],[\"apigee\",\"reg_mcp\",\"registry\",\"register / discover\",{\"off\":-20,\"labelAt\":\"mid\"}]],\"bounds\":[[\"SAP BTP\",[\"agent\"],\"sap\"],[\"Google Apigee\",[\"apigee\"],\"google\"],[\"SAP landscape\",[\"int\",\"cc\",\"sap\"],\"sap\"]],\"lanes\":[[0,\"IDENTITY · LLM\"],[1,\"RUNTIME PATH\"],[2,\"OPTIONAL\"],[3,\"CONTROL PLANE\"]],\"legend\":[\"invoke\",\"llm\",\"identity\",\"registry\"],\"footer\":\"No AWS AgentCore component takes part. The registry is not selected yet: a plain API catalog is not a complete agent registry.\"},\"D3\":{\"id\":\"D3\",\"scenario\":\"S2\",\"title\":\"S2 · AWS AgentCore-centric · topology\",\"chain\":\"UI → AgentCore Runtime agent → AgentCore Gateway → Apigee MCP/API → Integration Suite → Cloud Connector (conditional) → SAP backend\",\"banner\":\"PROPOSED DESIGN FOR EVALUATION · NOT TENANT-VERIFIED · NOT AN APPROVED ARCHITECTURE\",\"cols\":7,\"nh\":100,\"ys\":[118,258,398,528,668],\"height\":840,\"nodes\":[{\"id\":\"ui\",\"row\":1,\"col\":0,\"title\":\"SAP Fiori / existing UI\",\"sub\":\"Finance user entry; application unchanged\",\"kind\":\"ui\"},{\"id\":\"idp\",\"row\":0,\"col\":0,\"title\":\"Enterprise identity\",\"sub\":\"IdP or SAP Cloud Identity (IAS, candidate); mapping to validate\",\"kind\":\"identity\"},{\"id\":\"agent\",\"row\":1,\"col\":1,\"title\":\"Agent · AWS AgentCore Runtime\",\"sub\":\"Agent execution and MCP client\",\"kind\":\"agent\"},{\"id\":\"gw\",\"row\":1,\"col\":2,\"title\":\"AWS AgentCore Gateway\",\"sub\":\"Enterprise MCP gateway; routes and authorizes\",\"kind\":\"gateway\"},{\"id\":\"apigee\",\"row\":1,\"col\":3,\"title\":\"Google Apigee MCP/API\",\"sub\":\"SAP-facing gateway; managed MCP endpoint (Pattern A)\",\"kind\":\"gateway\"},{\"id\":\"int\",\"row\":1,\"col\":4,\"title\":\"SAP Integration Suite\",\"sub\":\"SAP integration boundary\",\"kind\":\"integration\"},{\"id\":\"cc\",\"row\":1,\"col\":5,\"title\":\"SAP Cloud Connector\",\"sub\":\"Conditional, private connectivity only\",\"kind\":\"integration\",\"dashed\":true},{\"id\":\"sap\",\"row\":1,\"col\":6,\"title\":\"SAP backend\",\"sub\":\"S/4HANA · Central Finance; business authorization\",\"kind\":\"backend\"},{\"id\":\"custom\",\"row\":2,\"col\":3,\"title\":\"Custom MCP · AgentCore Runtime\",\"sub\":\"Pattern B, conditional; via Apigee, cross-cloud\",\"kind\":\"domain\",\"dashed\":true},{\"id\":\"reg_agent\",\"row\":3,\"col\":1,\"title\":\"Agent registry · AWS Agent Registry\",\"sub\":\"Agent descriptor; discovery and approval\",\"kind\":\"registry\"},{\"id\":\"reg_mcp\",\"row\":3,\"col\":2,\"title\":\"MCP registry · AWS Agent Registry\",\"sub\":\"MCP descriptor; discovery and approval\",\"kind\":\"registry\"},{\"id\":\"portkey\",\"row\":0,\"col\":1,\"title\":\"Portkey\",\"sub\":\"LLM gateway: model selection, credentials, fallback\",\"kind\":\"llm\"},{\"id\":\"llm\",\"row\":0,\"col\":2,\"title\":\"Approved LLM provider\",\"sub\":\"Reached only through Portkey\",\"kind\":\"llm\"},{\"id\":\"db\",\"row\":2,\"col\":0,\"title\":\"Persistence · conditional\",\"sub\":\"Approved AWS store, only if durable state is needed\",\"kind\":\"store\",\"dashed\":true}],\"edges\":[[\"ui\",\"agent\",\"invoke\",\"\"],[\"agent\",\"gw\",\"invoke\",\"MCP tools/call\"],[\"gw\",\"apigee\",\"invoke\",\"\"],[\"apigee\",\"int\",\"invoke\",\"API call\"],[\"int\",\"cc\",\"invoke\",\"if private\"],[\"cc\",\"sap\",\"invoke\",\"RFC / OData\"],[\"apigee\",\"custom\",\"invoke\",\"proxy target · cross-cloud\",{\"off\":-30}],[\"agent\",\"portkey\",\"llm\",\"LLM request\",{\"off\":-14}],[\"portkey\",\"llm\",\"llm\",\"model call\"],[\"idp\",\"agent\",\"identity\",\"workload / user token\"],[\"agent\",\"reg_agent\",\"registry\",\"agent descriptor\",{\"off\":-20,\"labelAt\":\"mid\"}],[\"gw\",\"reg_mcp\",\"registry\",\"MCP descriptor\",{\"off\":-20,\"labelAt\":\"mid\"}],[\"agent\",\"db\",\"invoke\",\"state if required\",{\"off\":20}]],\"bounds\":[[\"AWS\",[\"agent\",\"gw\"],\"aws\"],[\"Google Apigee\",[\"apigee\"],\"google\"],[\"SAP landscape\",[\"int\",\"cc\",\"sap\"],\"sap\"]],\"lanes\":[[0,\"IDENTITY · LLM\"],[1,\"RUNTIME PATH\"],[2,\"OPTIONAL\"],[3,\"CONTROL PLANE\"]],\"legend\":[\"invoke\",\"llm\",\"identity\",\"registry\"],\"footer\":\"Registration/discovery goes to AWS Agent Registry and is separate from the runtime path. AgentCore Runtime, Gateway and Registry are three capabilities. Apigee stays mandatory.\"},\"D4\":{\"id\":\"D4\",\"scenario\":\"S3\",\"title\":\"S3 · SAP-hosted hybrid · topology\",\"chain\":\"UI → Cloud Foundry agent → Apigee MCP/API → Integration Suite → Cloud Connector (conditional) → SAP backend\",\"banner\":\"PROPOSED DESIGN FOR EVALUATION · NOT TENANT-VERIFIED · NOT AN APPROVED ARCHITECTURE\",\"cols\":6,\"nh\":100,\"ys\":[118,258,398,528,668],\"height\":840,\"nodes\":[{\"id\":\"ui\",\"row\":1,\"col\":0,\"title\":\"SAP Fiori / existing UI\",\"sub\":\"Finance user entry; application unchanged\",\"kind\":\"ui\"},{\"id\":\"idp\",\"row\":0,\"col\":0,\"title\":\"Enterprise identity\",\"sub\":\"IdP or SAP Cloud Identity (IAS, candidate); mapping to validate\",\"kind\":\"identity\"},{\"id\":\"agent\",\"row\":1,\"col\":1,\"title\":\"Agent · SAP BTP Cloud Foundry\",\"sub\":\"Agent execution and MCP client\",\"kind\":\"agent\"},{\"id\":\"apigee\",\"row\":1,\"col\":2,\"title\":\"Google Apigee MCP/API\",\"sub\":\"SAP-facing gateway; managed MCP endpoint (Pattern A)\",\"kind\":\"gateway\"},{\"id\":\"int\",\"row\":1,\"col\":3,\"title\":\"SAP Integration Suite\",\"sub\":\"SAP integration boundary\",\"kind\":\"integration\"},{\"id\":\"cc\",\"row\":1,\"col\":4,\"title\":\"SAP Cloud Connector\",\"sub\":\"Conditional, private connectivity only\",\"kind\":\"integration\",\"dashed\":true},{\"id\":\"sap\",\"row\":1,\"col\":5,\"title\":\"SAP backend\",\"sub\":\"S/4HANA · Central Finance; business authorization\",\"kind\":\"backend\"},{\"id\":\"custom\",\"row\":2,\"col\":3,\"title\":\"Custom MCP · SAP BTP Cloud Foundry\",\"sub\":\"Pattern B, only if required; behind Apigee\",\"kind\":\"domain\",\"dashed\":true},{\"id\":\"portkey\",\"row\":0,\"col\":1,\"title\":\"Portkey\",\"sub\":\"LLM gateway: model selection, credentials, fallback\",\"kind\":\"llm\"},{\"id\":\"llm\",\"row\":0,\"col\":2,\"title\":\"Approved LLM provider\",\"sub\":\"Reached only through Portkey\",\"kind\":\"llm\"},{\"id\":\"db\",\"row\":2,\"col\":0,\"title\":\"Persistence · conditional\",\"sub\":\"SAP HANA Cloud or existing approved store, only if needed\",\"kind\":\"store\",\"dashed\":true},{\"id\":\"reg_agent\",\"row\":3,\"col\":1,\"title\":\"Agent registry · AWS Agent Registry\",\"sub\":\"SAP-hosted agent metadata\",\"kind\":\"registry\"},{\"id\":\"reg_mcp\",\"row\":3,\"col\":2,\"title\":\"MCP registry · AWS Agent Registry\",\"sub\":\"Apigee MCP endpoint metadata\",\"kind\":\"registry\"},{\"id\":\"s3b\",\"row\":4,\"col\":0,\"title\":\"S3-B variant · not baseline\",\"sub\":\"Only if AI Foundry mandates AgentCore Gateway for all tool calls: it would sit between agent and Apigee. Policy-dependent option.\",\"kind\":\"decision\",\"span\":4,\"h\":70,\"dashed\":true}],\"edges\":[[\"ui\",\"agent\",\"invoke\",\"\"],[\"agent\",\"apigee\",\"invoke\",\"MCP tools/call\"],[\"apigee\",\"int\",\"invoke\",\"API call\"],[\"int\",\"cc\",\"invoke\",\"if private\"],[\"cc\",\"sap\",\"invoke\",\"RFC / OData\"],[\"apigee\",\"custom\",\"invoke\",\"proxy target\"],[\"agent\",\"portkey\",\"llm\",\"LLM request\",{\"off\":-14}],[\"portkey\",\"llm\",\"llm\",\"model call\"],[\"idp\",\"agent\",\"identity\",\"workload / user token\"],[\"agent\",\"db\",\"invoke\",\"state if required\",{\"off\":20}],[\"agent\",\"reg_agent\",\"registry\",\"agent metadata\",{\"off\":-20,\"labelAt\":\"mid\"}],[\"apigee\",\"reg_mcp\",\"registry\",\"endpoint metadata\",{\"off\":-20,\"labelAt\":\"mid\"}]],\"bounds\":[[\"SAP BTP\",[\"agent\"],\"sap\"],[\"Google Apigee\",[\"apigee\"],\"google\"],[\"SAP landscape\",[\"int\",\"cc\",\"sap\"],\"sap\"],[\"AWS control plane only\",[\"reg_agent\",\"reg_mcp\"],\"aws\"]],\"lanes\":[[0,\"IDENTITY · LLM\"],[1,\"RUNTIME PATH\"],[2,\"OPTIONAL\"],[3,\"CONTROL PLANE\"]],\"legend\":[\"invoke\",\"llm\",\"identity\",\"registry\"],\"footer\":\"AWS Agent Registry registers and governs. It is not an execution hop: no AgentCore Runtime, and no AgentCore Gateway in the baseline.\"},\"D5\":{\"id\":\"D5\",\"scenario\":null,\"title\":\"MCP hosting versus registration\",\"chain\":\"Four independent decisions, plus the MCP gateway and the LLM gateway as separate shared responsibilities\",\"banner\":\"PROPOSED DESIGN FOR EVALUATION · NOT TENANT-VERIFIED · NOT AN APPROVED ARCHITECTURE\",\"cols\":4,\"nh\":76,\"ys\":[104,208,312,416,520,624],\"height\":840,\"nodes\":[{\"id\":\"l0\",\"row\":0,\"col\":0,\"title\":\"Agent hosting and execution\",\"sub\":\"Independent decision\",\"kind\":\"decision\"},{\"id\":\"c0_1\",\"row\":0,\"col\":1,\"title\":\"SAP BTP Cloud Foundry\",\"sub\":\"S1 · SAP-centric\",\"kind\":\"agent\"},{\"id\":\"c0_2\",\"row\":0,\"col\":2,\"title\":\"AWS AgentCore Runtime\",\"sub\":\"S2 · AWS AgentCore-centric\",\"kind\":\"agent\"},{\"id\":\"c0_3\",\"row\":0,\"col\":3,\"title\":\"SAP BTP Cloud Foundry\",\"sub\":\"S3 · SAP-hosted hybrid\",\"kind\":\"agent\"},{\"id\":\"l1\",\"row\":1,\"col\":0,\"title\":\"Agent registration and discovery\",\"sub\":\"Independent decision\",\"kind\":\"decision\"},{\"id\":\"c1_1\",\"row\":1,\"col\":1,\"title\":\"Domain-managed catalog · product selection pending\",\"sub\":\"S1 · SAP-centric\",\"kind\":\"registry\",\"dashed\":true,\"status\":\"PRODUCT PENDING\",\"statusColor\":\"#B3261E\"},{\"id\":\"c1_2\",\"row\":1,\"col\":2,\"title\":\"AWS Agent Registry\",\"sub\":\"S2 · AWS AgentCore-centric\",\"kind\":\"registry\"},{\"id\":\"c1_3\",\"row\":1,\"col\":3,\"title\":\"AWS Agent Registry\",\"sub\":\"S3 · SAP-hosted hybrid\",\"kind\":\"registry\"},{\"id\":\"l2\",\"row\":2,\"col\":0,\"title\":\"MCP implementation hosting and execution\",\"sub\":\"Independent decision\",\"kind\":\"decision\"},{\"id\":\"c2_1\",\"row\":2,\"col\":1,\"title\":\"Cloud Foundry, only if custom code is needed\",\"sub\":\"S1 · SAP-centric\",\"kind\":\"domain\"},{\"id\":\"c2_2\",\"row\":2,\"col\":2,\"title\":\"AgentCore Runtime, only if custom code is needed\",\"sub\":\"S2 · AWS AgentCore-centric\",\"kind\":\"domain\"},{\"id\":\"c2_3\",\"row\":2,\"col\":3,\"title\":\"Cloud Foundry, only if custom code is needed\",\"sub\":\"S3 · SAP-hosted hybrid\",\"kind\":\"domain\"},{\"id\":\"l3\",\"row\":3,\"col\":0,\"title\":\"MCP registration and discovery\",\"sub\":\"Independent decision\",\"kind\":\"decision\"},{\"id\":\"c3_1\",\"row\":3,\"col\":1,\"title\":\"Domain-managed catalog · product selection pending\",\"sub\":\"S1 · SAP-centric\",\"kind\":\"registry\",\"dashed\":true,\"status\":\"PRODUCT PENDING\",\"statusColor\":\"#B3261E\"},{\"id\":\"c3_2\",\"row\":3,\"col\":2,\"title\":\"AWS Agent Registry\",\"sub\":\"S2 · AWS AgentCore-centric\",\"kind\":\"registry\"},{\"id\":\"c3_3\",\"row\":3,\"col\":3,\"title\":\"AWS Agent Registry\",\"sub\":\"S3 · SAP-hosted hybrid\",\"kind\":\"registry\"},{\"id\":\"l4\",\"row\":4,\"col\":0,\"title\":\"MCP gateway / exposure (shared responsibility)\",\"sub\":\"Shared across scenarios\",\"kind\":\"gateway\"},{\"id\":\"c4_1\",\"row\":4,\"col\":1,\"title\":\"Google Apigee\",\"sub\":\"S1 · SAP-centric\",\"kind\":\"gateway\"},{\"id\":\"c4_2\",\"row\":4,\"col\":2,\"title\":\"AgentCore Gateway + Google Apigee\",\"sub\":\"S2 · AWS AgentCore-centric\",\"kind\":\"gateway\"},{\"id\":\"c4_3\",\"row\":4,\"col\":3,\"title\":\"Google Apigee\",\"sub\":\"S3 · SAP-hosted hybrid\",\"kind\":\"gateway\"},{\"id\":\"l5\",\"row\":5,\"col\":0,\"title\":\"LLM gateway (common to all)\",\"sub\":\"Shared across scenarios\",\"kind\":\"llm\"},{\"id\":\"c5_1\",\"row\":5,\"col\":1,\"title\":\"Portkey\",\"sub\":\"S1 · SAP-centric\",\"kind\":\"llm\"},{\"id\":\"c5_2\",\"row\":5,\"col\":2,\"title\":\"Portkey\",\"sub\":\"S2 · AWS AgentCore-centric\",\"kind\":\"llm\"},{\"id\":\"c5_3\",\"row\":5,\"col\":3,\"title\":\"Portkey\",\"sub\":\"S3 · SAP-hosted hybrid\",\"kind\":\"llm\"}],\"edges\":[[\"c0_1\",\"c1_1\",\"registry\",\"metadata only\",{\"off\":0}],[\"c2_1\",\"c3_1\",\"registry\",\"metadata only\"],[\"c0_2\",\"c1_2\",\"registry\",\"metadata\",{\"off\":0}],[\"c2_2\",\"c3_2\",\"registry\",\"metadata only\"],[\"c0_3\",\"c1_3\",\"registry\",\"metadata only\",{\"off\":0}],[\"c2_3\",\"c3_3\",\"registry\",\"metadata only\"]],\"bounds\":[],\"lanes\":[],\"legend\":[\"registry\"],\"footer\":\"Using AWS Agent Registry (S3) does not require AWS agent hosting: the agent still runs on SAP BTP Cloud Foundry. The dashed arrow carries metadata only.\"},\"D6\":{\"id\":\"D6\",\"scenario\":null,\"title\":\"Identity, authorization and principal propagation\",\"chain\":\"Six identities, five boundaries; SAP decides business authorization\",\"banner\":\"PROPOSED DESIGN FOR EVALUATION · NOT TENANT-VERIFIED · NOT AN APPROVED ARCHITECTURE\",\"cols\":6,\"nh\":96,\"ys\":[118,258,398,528,668],\"height\":840,\"nodes\":[{\"id\":\"idp\",\"row\":0,\"col\":1,\"title\":\"SAP Cloud Identity Services (IAS) · candidate trust component\",\"sub\":\"Evaluate as trust component; Global User ID as identity-correlation attribute where supported\",\"kind\":\"identity\",\"span\":3,\"h\":70},{\"id\":\"user\",\"row\":1,\"col\":0,\"title\":\"Business user\",\"sub\":\"Authenticates at the IdP\",\"kind\":\"ui\"},{\"id\":\"agent\",\"row\":1,\"col\":1,\"title\":\"Agent workload identity\",\"sub\":\"Identity of the agent runtime\",\"kind\":\"agent\"},{\"id\":\"mcp\",\"row\":1,\"col\":2,\"title\":\"MCP client identity\",\"sub\":\"Token the client presents to the gateway\",\"kind\":\"agent\"},{\"id\":\"gw\",\"row\":1,\"col\":3,\"title\":\"Gateway identity\",\"sub\":\"Apigee (and AgentCore Gateway in S2)\",\"kind\":\"gateway\"},{\"id\":\"int\",\"row\":1,\"col\":4,\"title\":\"Integration Suite identity\",\"sub\":\"Service identity toward SAP\",\"kind\":\"integration\"},{\"id\":\"sap\",\"row\":1,\"col\":5,\"title\":\"SAP backend identity\",\"sub\":\"Mapped user or technical user executes\",\"kind\":\"backend\"},{\"id\":\"notenough\",\"row\":2,\"col\":0,\"title\":\"Not sufficient on its own\",\"sub\":\"A Global User ID or an ordinary HTTP header is not principal propagation\",\"kind\":\"decision\",\"span\":2,\"h\":80},{\"id\":\"tx\",\"row\":2,\"col\":2,\"title\":\"Token exchange / user mapping\",\"sub\":\"Subject to validation at every boundary: PENDING, not proven\",\"kind\":\"decision\",\"span\":2,\"h\":80,\"dashed\":true},{\"id\":\"neg\",\"row\":2,\"col\":4,\"title\":\"Negative case\",\"sub\":\"Agent may discover and call the tool; SAP rejects an operation the mapped user lacks authority for\",\"kind\":\"decision\",\"span\":2,\"h\":80},{\"id\":\"auth\",\"row\":3,\"col\":0,\"title\":\"SAP backend is the business authority\",\"sub\":\"Registry visibility, gateway access and tool discovery never grant business authorization. Business approval is a separate step.\",\"kind\":\"backend\",\"span\":3,\"h\":84},{\"id\":\"byscen\",\"row\":3,\"col\":3,\"title\":\"What differs by scenario\",\"sub\":\"S1: agent to Apigee, one hop. S2: agent to AgentCore Gateway to Apigee, two hops. S3: as S1, plus a separate registry identity.\",\"kind\":\"decision\",\"span\":3,\"h\":84}],\"edges\":[[\"user\",\"agent\",\"identity\",\"delegated user token\"],[\"agent\",\"mcp\",\"identity\",\"client credential\"],[\"mcp\",\"gw\",\"identity\",\"bearer · validated\"],[\"gw\",\"int\",\"identity\",\"OAuth / cert · mapping\"],[\"int\",\"sap\",\"identity\",\"principal propagation\"],[\"idp\",\"agent\",\"identity\",\"issues tokens\",{\"off\":-20}],[\"idp\",\"gw\",\"identity\",\"validates\",{\"off\":-10}]],\"bounds\":[],\"lanes\":[[1,\"IDENTITIES\"],[2,\"VALIDATION\"]],\"legend\":[\"identity\"],\"footer\":\"Authentication and authorization are separate at each boundary. Token exchange and user mapping are design assumptions until validated.\"},\"D7\":{\"id\":\"D7\",\"scenario\":null,\"title\":\"LLM execution architecture\",\"chain\":\"Agent runtime → Portkey → approved LLM provider (common to S1, S2, S3)\",\"banner\":\"PROPOSED DESIGN FOR EVALUATION · NOT TENANT-VERIFIED · NOT AN APPROVED ARCHITECTURE\",\"cols\":5,\"nh\":100,\"ys\":[118,258,398,528,668],\"height\":840,\"nodes\":[{\"id\":\"agent\",\"row\":1,\"col\":0,\"title\":\"Agent runtime\",\"sub\":\"S1, S3: SAP BTP Cloud Foundry. S2: AgentCore Runtime\",\"kind\":\"agent\"},{\"id\":\"portkey\",\"row\":1,\"col\":1,\"title\":\"Portkey LLM gateway\",\"sub\":\"Single route to models in all scenarios\",\"kind\":\"llm\"},{\"id\":\"llm\",\"row\":1,\"col\":2,\"title\":\"Approved LLM provider\",\"sub\":\"Selected model\",\"kind\":\"llm\"},{\"id\":\"sep\",\"row\":1,\"col\":4,\"title\":\"MCP gateway and registries\",\"sub\":\"Separate planes: no path to Portkey\",\"kind\":\"gateway\",\"dashed\":true},{\"id\":\"m1\",\"row\":2,\"col\":0,\"title\":\"Model selection\",\"sub\":\"Which approved model serves the request\",\"kind\":\"control\"},{\"id\":\"m2\",\"row\":2,\"col\":1,\"title\":\"Credential management\",\"sub\":\"Provider keys held in Portkey, not in the agent\",\"kind\":\"control\"},{\"id\":\"m3\",\"row\":2,\"col\":2,\"title\":\"Timeout and fallback\",\"sub\":\"Policy for slow or failed calls\",\"kind\":\"control\"},{\"id\":\"m4\",\"row\":2,\"col\":3,\"title\":\"Monitoring\",\"sub\":\"Usage, latency and cost per request\",\"kind\":\"control\"},{\"id\":\"nobypass\",\"row\":3,\"col\":0,\"title\":\"No direct provider route\",\"sub\":\"A call that bypasses Portkey is not permitted in any scenario\",\"kind\":\"decision\",\"span\":5,\"h\":70}],\"edges\":[[\"agent\",\"portkey\",\"llm\",\"LLM request\"],[\"portkey\",\"llm\",\"llm\",\"model call\"]],\"bounds\":[],\"lanes\":[[1,\"LLM PATH\"],[2,\"AT PORTKEY\"]],\"legend\":[\"llm\"],\"footer\":\"Portkey is independent of the MCP gateway and the registry. Model-provider routes that skip Portkey are not drawn because they are not allowed.\"},\"D8\":{\"id\":\"D8\",\"scenario\":null,\"title\":\"Registry lifecycle and synchronization\",\"chain\":\"Developed → artifact → validation → approval → publication → discovery → invocation → monitoring → update or retirement\",\"banner\":\"PROPOSED DESIGN FOR EVALUATION · NOT TENANT-VERIFIED · NOT AN APPROVED ARCHITECTURE\",\"cols\":5,\"nh\":100,\"ys\":[118,258,398,528,668],\"height\":840,\"nodes\":[{\"id\":\"t0\",\"row\":1,\"col\":0,\"title\":\"Capability developed\",\"sub\":\"Agent or MCP code and descriptor\",\"kind\":\"artifact\"},{\"id\":\"t1\",\"row\":1,\"col\":1,\"title\":\"Versioned artifact\",\"sub\":\"Git tag, image or spec version\",\"kind\":\"artifact\"},{\"id\":\"t2\",\"row\":1,\"col\":2,\"title\":\"Domain validation\",\"sub\":\"Domain owner checks scope\",\"kind\":\"artifact\"},{\"id\":\"t3\",\"row\":1,\"col\":3,\"title\":\"Approval\",\"sub\":\"AI Foundry or domain owner\",\"kind\":\"registry\"},{\"id\":\"t4\",\"row\":1,\"col\":4,\"title\":\"Registry publication\",\"sub\":\"Registry record created\",\"kind\":\"registry\"},{\"id\":\"b0\",\"row\":2,\"col\":4,\"title\":\"Discovery\",\"sub\":\"Approved records only\",\"kind\":\"registry\"},{\"id\":\"b1\",\"row\":2,\"col\":3,\"title\":\"Invocation under runtime authorization\",\"sub\":\"Not proven by registration alone\",\"kind\":\"agent\"},{\"id\":\"b2\",\"row\":2,\"col\":2,\"title\":\"Monitoring\",\"sub\":\"Runtime and registry telemetry\",\"kind\":\"registry\"},{\"id\":\"b3\",\"row\":2,\"col\":1,\"title\":\"Version update or retirement\",\"sub\":\"New version or retire record\",\"kind\":\"registry\"},{\"id\":\"b4\",\"row\":2,\"col\":0,\"title\":\"Revocation and stale-metadata handling\",\"sub\":\"Expired or revoked records must disappear\",\"kind\":\"registry\"},{\"id\":\"ext\",\"row\":3,\"col\":0,\"title\":\"External sources (S3)\",\"sub\":\"SAP-hosted agent and Apigee MCP endpoint metadata\",\"kind\":\"domain\",\"span\":1},{\"id\":\"areg\",\"row\":3,\"col\":2,\"title\":\"AWS Agent Registry\",\"sub\":\"Synchronizes approved metadata from external sources where supported\",\"kind\":\"registry\",\"span\":1},{\"id\":\"warn\",\"row\":4,\"col\":0,\"title\":\"Publication is not proof\",\"sub\":\"Not proof of endpoint reachability, runtime authorization or SAP execution. Stale or revoked metadata is detected by periodic re-validation.\",\"kind\":\"decision\",\"span\":5,\"h\":70}],\"edges\":[[\"t0\",\"t1\",\"invoke\",\"\"],[\"t1\",\"t2\",\"invoke\",\"\"],[\"t2\",\"t3\",\"invoke\",\"\"],[\"t3\",\"t4\",\"invoke\",\"\"],[\"t4\",\"b0\",\"registry\",\"publish → discover\"],[\"b0\",\"b1\",\"invoke\",\"\"],[\"b1\",\"b2\",\"invoke\",\"\"],[\"b2\",\"b3\",\"invoke\",\"\"],[\"b3\",\"b4\",\"invoke\",\"\"],[\"ext\",\"areg\",\"registry\",\"sync approved metadata\"]],\"bounds\":[],\"lanes\":[[1,\"PUBLISH\"],[2,\"USE · RETIRE\"],[3,\"\"]],\"legend\":[\"invoke\",\"registry\"],\"footer\":\"Lifecycle arrows show order of steps, not runtime traffic. Discovery returns metadata; invocation is a separate authorized call.\"},\"D9\":{\"id\":\"D9\",\"scenario\":null,\"title\":\"Observability and audit\",\"chain\":\"Agent request → LLM → MCP tool → gateway → Integration Suite → SAP backend, joined by a correlation id\",\"banner\":\"PROPOSED DESIGN FOR EVALUATION · NOT TENANT-VERIFIED · NOT AN APPROVED ARCHITECTURE\",\"cols\":6,\"nh\":100,\"ys\":[118,258,398,528,668],\"height\":840,\"nodes\":[{\"id\":\"s0\",\"row\":1,\"col\":0,\"title\":\"Agent request\",\"sub\":\"Session and business correlation id created\",\"kind\":\"agent\"},{\"id\":\"s1\",\"row\":1,\"col\":1,\"title\":\"LLM request\",\"sub\":\"Portkey log with request id\",\"kind\":\"llm\"},{\"id\":\"s2\",\"row\":1,\"col\":2,\"title\":\"MCP tool invocation\",\"sub\":\"Client call and tool name\",\"kind\":\"agent\"},{\"id\":\"s3\",\"row\":1,\"col\":3,\"title\":\"Gateway decision\",\"sub\":\"Apigee (and AgentCore Gateway in S2) allow or deny\",\"kind\":\"gateway\"},{\"id\":\"s4\",\"row\":1,\"col\":4,\"title\":\"Integration Suite execution\",\"sub\":\"Message processing log\",\"kind\":\"integration\"},{\"id\":\"s5\",\"row\":1,\"col\":5,\"title\":\"SAP backend operation\",\"sub\":\"Application log and change documents\",\"kind\":\"backend\"},{\"id\":\"err\",\"row\":2,\"col\":0,\"title\":\"Error / exception outcome\",\"sub\":\"Recorded with the same business correlation id\",\"kind\":\"decision\",\"span\":2,\"h\":80},{\"id\":\"model\",\"row\":2,\"col\":2,\"title\":\"Common correlation model\",\"sub\":\"Business id + session id + per-system request ids. Products do not share one trace id automatically\",\"kind\":\"store\",\"span\":4,\"h\":80},{\"id\":\"join\",\"row\":3,\"col\":0,\"title\":\"Evidence join\",\"sub\":\"Records are joined across systems by the business correlation id in an evidence store\",\"kind\":\"store\",\"span\":3,\"h\":70},{\"id\":\"resp\",\"row\":3,\"col\":3,\"title\":\"Audit responsibility\",\"sub\":\"Agent platform: agent and LLM. Gateway team: gateway. Integration team: Suite. SAP: backend\",\"kind\":\"control\",\"span\":3,\"h\":70}],\"edges\":[[\"s0\",\"s1\",\"audit\",\"correlate\"],[\"s1\",\"s2\",\"audit\",\"correlate\"],[\"s2\",\"s3\",\"audit\",\"correlate\"],[\"s3\",\"s4\",\"audit\",\"correlate\"],[\"s4\",\"s5\",\"audit\",\"correlate\"]],\"bounds\":[],\"lanes\":[[1,\"EVIDENCE\"],[2,\"OUTCOME\"],[3,\"JOIN\"]],\"legend\":[\"audit\"],\"footer\":\"The correlation id must be propagated by design and tested; it is not assumed to be carried by every product.\"},\"D10\":{\"id\":\"D10\",\"scenario\":null,\"title\":\"Three-scenario comparison\",\"chain\":\"Same labels and ownership boundaries in every scenario; Portkey is common and the registry is never in the path\",\"banner\":\"PROPOSED DESIGN FOR EVALUATION · NOT TENANT-VERIFIED · NOT AN APPROVED ARCHITECTURE\",\"cols\":6,\"nh\":62,\"ys\":[104,176,304,376,504,576],\"height\":840,\"nodes\":[{\"id\":\"S1_ui\",\"row\":0,\"col\":0,\"title\":\"SAP Fiori / UI\",\"sub\":\"SAP-centric\",\"kind\":\"ui\"},{\"id\":\"S1_agent\",\"row\":0,\"col\":1,\"title\":\"Cloud Foundry agent\",\"sub\":\"SAP BTP\",\"kind\":\"agent\"},{\"id\":\"S1_apigee\",\"row\":0,\"col\":3,\"title\":\"Apigee MCP/API\",\"sub\":\"SAP-facing gateway\",\"kind\":\"gateway\"},{\"id\":\"S1_int\",\"row\":0,\"col\":4,\"title\":\"Integration Suite\",\"sub\":\"SAP integration\",\"kind\":\"integration\"},{\"id\":\"S1_sap\",\"row\":0,\"col\":5,\"title\":\"SAP backend\",\"sub\":\"Authorizes\",\"kind\":\"backend\"},{\"id\":\"S1_portkey\",\"row\":1,\"col\":1,\"title\":\"Portkey\",\"sub\":\"LLM gateway\",\"kind\":\"llm\",\"h\":56},{\"id\":\"S1_reg\",\"row\":1,\"col\":2,\"title\":\"Registry\",\"sub\":\"Domain-managed catalog · product selection pending\",\"kind\":\"registry\",\"h\":56,\"dashed\":true,\"status\":\"PENDING\",\"statusColor\":\"#B3261E\"},{\"id\":\"S2_ui\",\"row\":2,\"col\":0,\"title\":\"SAP Fiori / UI\",\"sub\":\"AWS AgentCore-centric\",\"kind\":\"ui\"},{\"id\":\"S2_agent\",\"row\":2,\"col\":1,\"title\":\"AgentCore Runtime agent\",\"sub\":\"AWS\",\"kind\":\"agent\"},{\"id\":\"S2_gw\",\"row\":2,\"col\":2,\"title\":\"AgentCore Gateway\",\"sub\":\"Enterprise gateway\",\"kind\":\"gateway\"},{\"id\":\"S2_apigee\",\"row\":2,\"col\":3,\"title\":\"Apigee MCP/API\",\"sub\":\"SAP-facing gateway\",\"kind\":\"gateway\"},{\"id\":\"S2_int\",\"row\":2,\"col\":4,\"title\":\"Integration Suite\",\"sub\":\"SAP integration\",\"kind\":\"integration\"},{\"id\":\"S2_sap\",\"row\":2,\"col\":5,\"title\":\"SAP backend\",\"sub\":\"Authorizes\",\"kind\":\"backend\"},{\"id\":\"S2_portkey\",\"row\":3,\"col\":1,\"title\":\"Portkey\",\"sub\":\"LLM gateway\",\"kind\":\"llm\",\"h\":56},{\"id\":\"S2_reg\",\"row\":3,\"col\":2,\"title\":\"AWS Agent Registry\",\"sub\":\"Agent and MCP records\",\"kind\":\"registry\",\"h\":56},{\"id\":\"S3_ui\",\"row\":4,\"col\":0,\"title\":\"SAP Fiori / UI\",\"sub\":\"SAP-hosted hybrid · preferred candidate\",\"kind\":\"ui\"},{\"id\":\"S3_agent\",\"row\":4,\"col\":1,\"title\":\"Cloud Foundry agent\",\"sub\":\"SAP BTP\",\"kind\":\"agent\"},{\"id\":\"S3_apigee\",\"row\":4,\"col\":3,\"title\":\"Apigee MCP/API\",\"sub\":\"SAP-facing gateway\",\"kind\":\"gateway\"},{\"id\":\"S3_int\",\"row\":4,\"col\":4,\"title\":\"Integration Suite\",\"sub\":\"SAP integration\",\"kind\":\"integration\"},{\"id\":\"S3_sap\",\"row\":4,\"col\":5,\"title\":\"SAP backend\",\"sub\":\"Authorizes\",\"kind\":\"backend\"},{\"id\":\"S3_portkey\",\"row\":5,\"col\":1,\"title\":\"Portkey\",\"sub\":\"LLM gateway\",\"kind\":\"llm\",\"h\":56},{\"id\":\"S3_reg\",\"row\":5,\"col\":2,\"title\":\"AWS Agent Registry\",\"sub\":\"Metadata only, not a hop\",\"kind\":\"registry\",\"h\":56}],\"edges\":[[\"S1_ui\",\"S1_agent\",\"invoke\",\"\"],[\"S1_agent\",\"S1_apigee\",\"invoke\",\"\"],[\"S1_apigee\",\"S1_int\",\"invoke\",\"\"],[\"S1_int\",\"S1_sap\",\"invoke\",\"\"],[\"S1_agent\",\"S1_portkey\",\"llm\",\"\"],[\"S1_agent\",\"S1_reg\",\"registry\",\"\",{\"off\":22}],[\"S2_ui\",\"S2_agent\",\"invoke\",\"\"],[\"S2_agent\",\"S2_gw\",\"invoke\",\"\"],[\"S2_gw\",\"S2_apigee\",\"invoke\",\"\"],[\"S2_apigee\",\"S2_int\",\"invoke\",\"\"],[\"S2_int\",\"S2_sap\",\"invoke\",\"\"],[\"S2_agent\",\"S2_portkey\",\"llm\",\"\"],[\"S2_agent\",\"S2_reg\",\"registry\",\"\",{\"off\":22}],[\"S3_ui\",\"S3_agent\",\"invoke\",\"\"],[\"S3_agent\",\"S3_apigee\",\"invoke\",\"\"],[\"S3_apigee\",\"S3_int\",\"invoke\",\"\"],[\"S3_int\",\"S3_sap\",\"invoke\",\"\"],[\"S3_agent\",\"S3_portkey\",\"llm\",\"\"],[\"S3_agent\",\"S3_reg\",\"registry\",\"\",{\"off\":22}]],\"bounds\":[],\"lanes\":[[0,\"S1\"],[2,\"S2\"],[4,\"S3 · PREFERRED CANDIDATE\"]],\"legend\":[\"invoke\",\"llm\",\"registry\"],\"footer\":\"Portkey is the LLM gateway in all three. The SAP backend decides authorization in all three. S3-B (AgentCore Gateway mandated) is a separate option, not drawn.\"}}"),
	diagramNames: {
		D1: "Enterprise overview",
		D2: "S1 SAP-centric",
		D3: "S2 AWS AgentCore-centric",
		D4: "S3 SAP-hosted hybrid",
		D5: "MCP hosting versus registration",
		D6: "Identity and authorization",
		D7: "LLM execution",
		D8: "Registry lifecycle",
		D9: "Observability and audit",
		D10: "Three-scenario comparison"
	},
	recommendation: {
		headline: "S3 is the preferred candidate for POC validation, subject to AI Foundry policy. It is not approved and not production-ready.",
		why: [
			"SAP keeps execution ownership: the agent and any custom MCP code run on SAP BTP Cloud Foundry, and Apigee stays the SAP-facing gateway.",
			"AI Foundry still gets central discovery and registration through AWS Agent Registry, which is control plane only and adds no execution hop.",
			"It needs one gateway hop and one identity mapping to prove, not two as in S2."
		],
		depends: [
			"AI Foundry policy on whether AgentCore Gateway is mandatory for all tool invocations (S3-B)",
			"AWS Agent Registry accepts records for agents and MCP servers hosted outside AWS",
			"Approved synchronization method for registry records"
		],
		open: [
			"Registry product for S1 (unresolved)",
			"Delegated user versus service identity",
			"Principal propagation through Integration Suite and Cloud Connector",
			"Whether HANA Cloud is needed at all: persistence is conditional"
		],
		changes: [
			"If AI Foundry mandates AgentCore Gateway for every tool call, evaluate S3-B or S2.",
			"If the enterprise requires AWS hosting for all agents, choose S2.",
			"If no central registry is required, S1 is simplest but its registry stays unresolved."
		],
		poc: [
			"Run one read tool through the S3 path with a service identity and record the call, token and SAP user.",
			"Repeat with user delegation and mark each result PASS, HOLD or NOT_VERIFIED.",
			"Register the SAP-hosted agent and the Apigee endpoint in AWS Agent Registry and confirm discovery without any AWS execution hop."
		]
	},
	evidence: [
		[
			"Google Apigee",
			"Apigee MCP overview",
			"https://docs.cloud.google.com/apigee/docs/api-platform/apigee-mcp/apigee-mcp-overview",
			"Existing Apigee APIs can be exposed as MCP tools through MCP endpoints with no local or remote MCP server to install or manage. OpenAPI 3.0.x only; a limit of 1000 MCP tools per organization; capacity limits in some regions; stateless protocol 2026-07-28 and stateful versions 2025-11-25 down to 2024-11-05.",
			"Pattern A needs no custom MCP server, within the tool and region limits.",
			"Tenant enablement, region capacity and hybrid version"
		],
		[
			"Google Apigee",
			"Manage MCP tool access",
			"https://docs.cloud.google.com/apigee/docs/api-platform/apigee-mcp/manage-mcp-tool-access",
			"Access is controlled with API products and developer apps; ParsePayload (JSON-RPC 2.0) plus API-key or OAuth verification; tools outside the client's product are removed from tools/list. The page also says traffic can be proxied to your own MCP server.",
			"Apigee is the policy layer for tool access, and Pattern B (custom server behind Apigee) is documented.",
			"API product design and the custom-server proxy pattern in this tenant"
		],
		[
			"AWS AgentCore",
			"Gateway core concepts",
			"https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-core-concepts.html",
			"Gateway is a secure entry point for agentic traffic with MCP, HTTP and inference target categories and inbound OAuth (JWT), IAM, authenticate-only or none. The page lists MCP servers under MCP targets and external MCP servers under HTTP targets, so target classification needs confirming.",
			"Makes the S2 gateway hop plausible; Apigee as a gateway target is unproven.",
			"Which target type fits the Apigee MCP endpoint; token exchange"
		],
		[
			"AWS AgentCore",
			"Agent Registry",
			"https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/registry.html",
			"A managed discovery service: a catalog for organizing, curating and discovering resources. Record types AGENT, MCP, SKILL, CUSTOM and WEB_BOT; publishers submit, curators approve. Runtime and Gateway are listed as related services, so it is separate from both. The older bedrock-agentcore preview namespace was announced for discontinuation on 2026-10-30.",
			"Registry is a separate capability from Runtime and Gateway and does not require AWS hosting. Use the agent-registry namespace.",
			"Availability and region in the tenant; curator and approval roles"
		],
		[
			"AWS AgentCore",
			"Registry: synchronize external records",
			"https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/registry-sync-records.html",
			"The registry can synchronize record metadata from external sources by connecting to the provided URL with outbound credentials: MCP servers and A2A agent cards (credentials: none, OAuth through an AgentCore Identity provider, or IAM SigV4). The credential provider must be in the same account.",
			"Supports S3 registration of SAP-hosted metadata, but AWS must be able to reach the endpoint URL: that is a network and credential dependency, not an execution hop.",
			"Reachability of Apigee or Cloud Foundry URLs from AWS; credential provider"
		],
		[
			"AWS AgentCore",
			"Registry: supported record types",
			"https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/registry-supported-record-types.html",
			"AGENT records use a2aAgentCard, mcpServer or custom descriptors; MCP records use mcpServer or custom; exactly one primary descriptor per record. Agents that do not follow A2A can use mcpServer or custom.",
			"A SAP-hosted agent can be registered with a custom or mcpServer descriptor.",
			"Descriptor fit for our agents"
		],
		[
			"SAP",
			"SAP BTP Cloud Foundry runtime",
			"https://help.sap.com/docs/cf-runtime/cloud-foundry-runtime/what-is-sap-btp-cloud-foundry-runtime",
			"NOT_VERIFIED: the page returned no readable body when fetched (script-rendered), so no capability statement is recorded here.",
			"Cloud Foundry as the S1 and S3 agent host rests on the owner's brief and general knowledge, not on this page.",
			"Read the page in a browser; confirm entitlement and quota"
		]
	],
	evidenceStatus: "Pages read through a web fetch on 2026-11-25: six of seven returned content, summarized above; the SAP Cloud Foundry page returned no body and is NOT_VERIFIED. Vendor documentation describes product capability only. It does not show that a feature is configured, licensed or available in this organization's tenant or region.",
	domains: [
		{
			name: "Finance Read MCP",
			mode: "READ",
			tools: "Reconciliation balances, ledger and period data, journal and document status, reconciliation exceptions",
			control: "Read-only backend operations. No write tool is registered. This is the only capability the application uses."
		},
		{
			name: "Finance Posting MCP",
			mode: "WRITE · APPROVAL-GATED · NOT ACTIVE",
			tools: "Future: propose and post a reconciliation adjustment through a governed approval",
			control: "A separately governed capability. It is not active in this application and posting is never automatic."
		},
		{
			name: "Analytical / Data MCP",
			mode: "READ · FUTURE",
			tools: "Authorized Databricks or BDC-backed context",
			control: "Entitlement and scope: TBD · REQUIRES VALIDATION"
		}
	],
	unresolvedRegistry: "Domain-managed catalog · product selection pending"
}, et = "2026-11-25", tt = "TBD · REQUIRES VALIDATION", R = L.ids, nt = L.banner, z = Object.fromEntries(L.ids.map((e) => {
	let t = L.scenarios[e], n = L.diagrams[{
		S1: "D2",
		S2: "D3",
		S3: "D4"
	}[e]];
	return [e, {
		...t,
		label: t.name,
		chain: n.chain,
		summary: t.objective,
		baseline: t.hosting_note
	}];
}));
L.version, L.diagramNames;
var rt = Object.keys(L.diagrams), it = [
	["MCP client", "Agent-side component that discovers and invokes MCP tools."],
	["MCP server", "Protocol endpoint exposing tools and resources over MCP."],
	["Managed MCP endpoint (Pattern A)", "An approved API exposed as an MCP tool by Apigee. No separate custom MCP application server is required."],
	["Custom MCP server (Pattern B)", "Independently deployed MCP business logic on the hosting platform of the scenario, exposed or proxied by Apigee."],
	["MCP gateway", "Governed entry point that routes, authorizes and applies policy. It is not necessarily where tool logic runs."],
	["Registry", "Catalog and discovery of agents and MCP servers. Control plane only; never an invocation hop and not proof of reachability or authorization."],
	["AgentCore Runtime / Gateway / Registry", "Three distinct AWS capabilities: where an agent runs, the gateway that routes tool calls, and the catalog."],
	["Portkey", "LLM gateway for every scenario. Independent of the MCP gateway and the registry."],
	["Integration Suite", "SAP integration boundary between the gateway and the SAP backend."],
	["Cloud Connector", "Private connectivity to the SAP landscape; applies only where the connectivity model needs it."]
], at = L.comparison, ot = L.connCols, st = L.connections, ct = L.domains, lt = {
	headline: L.recommendation.headline,
	why: L.recommendation.why,
	standards: L.recommendation.depends,
	open: L.recommendation.open,
	changes: L.recommendation.changes,
	poc: L.recommendation.poc
}, ut = L.evidence, dt = L.evidenceStatus, ft = L.unresolvedRegistry, pt = {
	invoke: "Runtime invocation",
	registry: "Registration / discovery",
	llm: "LLM invocation",
	identity: "Identity / token",
	audit: "Audit / correlation",
	approval: "Approval",
	deploy: "Deployment"
}, mt = [
	"invoke",
	"registry",
	"llm",
	"identity",
	"audit"
].map((e) => [e, pt[e]]);
function ht(e) {
	return L.diagrams[e];
}
function gt(e) {
	let t = L.diagrams[e];
	return St({
		...t,
		title: t.title,
		captions: (t.lanes || []).map(([e, n]) => [(t.ys || [
			118,
			258,
			398,
			528,
			668
		])[e] - (e >= 2 ? 18 : 26), n]),
		legend: t.legend.map((e) => [e, pt[e]]),
		height: t.height
	});
}
function _t(e) {
	return gt({
		S1: "D2",
		S2: "D3",
		S3: "D4"
	}[e]);
}
var vt = {
	control: "#FFFFFF",
	decision: "#FFF8EE",
	agent: "#E8F1FB",
	gateway: "#FFF1E0",
	domain: "#EAF6EC",
	integration: "#F0EAF8",
	backend: "#E3E9EF",
	data: "#EEF2F5",
	registry: "#E5F5F2",
	artifact: "#F3F3F3",
	identity: "#FFF7DA",
	ui: "#EEF4FA",
	llm: "#F4EAFA",
	store: "#EEF2F5"
}, yt = {
	invoke: {
		c: "#0A4F9E",
		w: 2.6,
		d: ""
	},
	registry: {
		c: "#0C8F76",
		w: 2,
		d: "7 4"
	},
	deploy: {
		c: "#6B6B6B",
		w: 2,
		d: "2 4"
	},
	identity: {
		c: "#C26A00",
		w: 2,
		d: "8 3 2 3"
	},
	approval: {
		c: "#B3261E",
		w: 2.4,
		d: "10 3"
	},
	return: {
		c: "#0C8F76",
		w: 2.2,
		d: "7 4"
	},
	llm: {
		c: "#7B3FA0",
		w: 2.6,
		d: ""
	},
	audit: {
		c: "#5A6B7B",
		w: 1.8,
		d: "1.5 4"
	}
}, bt = {
	google: "#C26A00",
	aws: "#0A4F9E",
	sap: "#5B3F8C"
}, B = (e) => String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
function xt(e, t) {
	let n = [], r = "";
	for (let i of String(e).split(" ")) (r + " " + i).trim().length > t && r ? (n.push(r), r = i) : r = (r + " " + i).trim();
	return r && n.push(r), n;
}
function St(e) {
	let t = e.height || 840, n = e.nh || 92, r = (1140 - (e.cols - 1) * 30) / e.cols, i = e.ys || [
		118,
		258,
		398,
		528,
		668
	], a = {}, o = (e, t) => 20 + xt(e.title, Math.floor(t / 7.1)).length * 15 + xt(e.sub, Math.floor((t - 8) / 5.7)).length * 12.5 + 8 + (e.status ? 14 : 0);
	for (let t of e.nodes) {
		let e = t.span || 1, s = e * r + (e - 1) * 30, c = t.h || n, l = Math.ceil(o(t, s));
		a[t.id] = {
			x: 30 + t.col * (r + 30),
			y: i[t.row],
			w: s,
			h: l > c ? Math.min(l, 136) : c,
			clipped: l > 136,
			n: t
		};
	}
	let s = [];
	for (let [t, n, r] of e.bounds) {
		let e = n.map((e) => a[e]), i = Math.min(...e.map((e) => e.x)) - 10, o = Math.min(...e.map((e) => e.y)) - 24, c = Math.max(...e.map((e) => e.x + e.w)) + 10, l = Math.max(...e.map((e) => e.y + e.h)) + 5;
		s.push(`<rect x="${i}" y="${o}" width="${c - i}" height="${l - o}" rx="8" fill="none" stroke="${bt[r]}" stroke-width="2" stroke-dasharray="14 5"/>`), s.push(`<text x="${i + 8}" y="${o + 15}" font-size="12" font-weight="700" fill="${bt[r]}">${B(t)}</text>`);
	}
	let c = (e, t, n = "end") => s.push(`<text x="${n === "end" ? 1170 : 30}" y="${e}" font-size="11.5" font-weight="700" fill="#506778" text-anchor="${n}">${t}</text>`);
	for (let [t, n, r] of e.captions) c(t, n, r);
	let l = [], u = [], d = {};
	for (let [t, n, r, i, o = {}] of e.edges) {
		let e = r === "identity" ? d[t] = (d[t] ?? -1) + 1 : 0, c = a[t], f = a[n], p = o.active ? {
			...yt[r],
			c: "#E9730C",
			w: yt[r].w + 1
		} : yt[r], m = {
			x: c.x + c.w / 2,
			y: c.y + c.h / 2
		}, h = {
			x: f.x + f.w / 2,
			y: f.y + f.h / 2
		}, g, _, v, y, b, x, S;
		if (r === "return" && c.n.row === f.n.row && !o.straight) {
			let e = c.x + c.w / 2, t = f.x + f.w / 2, n = c.y + c.h, r = n + 56;
			g = `M${e},${n} L${e},${r} L${t},${r} L${t},${n}`, _ = (e + t) / 2, v = r - 7, y = t, b = n, x = 0, S = -1;
		} else if (c.n.row === f.n.row) {
			let e = c.x < f.x, t = e ? c.x + c.w : c.x, n = e ? f.x : f.x + f.w, i = m.y + (r === "identity" ? 14 : 0);
			g = `M${t},${i} L${n},${i}`, _ = (t + n) / 2, v = c.y + c.h + (c.n.row === 1 ? 26 : 14), y = n, b = i, x = e ? 1 : -1, S = 0;
		} else {
			let t = c.y < f.y, n = t ? c.y + c.h : c.y, i = t ? f.y : f.y + f.h, a = r === "identity" ? 14 + e * 40 : r === "approval" ? -12 : o.off || 0, s = m.x + a, l = h.x + a, u = o.my ?? (n + i) / 2;
			g = `M${s},${n} L${s},${u} L${l},${u} L${l},${i}`, r === "identity" ? (_ = s, v = n + (t ? 18 + e * 14 : -8)) : o.labelAt === "mid" ? (_ = (s + l) / 2, v = u - 6) : (_ = l, v = t ? i - 8 : i + 20), y = l, b = i, x = 0, S = t ? 1 : -1;
		}
		s.push(`<path d="${g}" fill="none" stroke="${p.c}" stroke-width="${p.w}"${p.d ? ` stroke-dasharray="${p.d}"` : ""}${o.active ? " class=\"live-flow\"" : ""} data-edge="${t}-${n}"/>`), u.push(x === 0 ? `<polygon points="${y},${b} ${y - 7 * .7},${b - S * 7 * 1.6} ${y + 7 * .7},${b - S * 7 * 1.6}" fill="${p.c}"/>` : `<polygon points="${y},${b} ${y - x * 7 * 1.6},${b - 7 * .7} ${y - x * 7 * 1.6},${b + 7 * .7}" fill="${p.c}"/>`), i && l.push([
			_,
			v,
			i,
			p.c
		]);
	}
	s.push(...u);
	for (let t of e.nodes) {
		let e = a[t.id], n = `${t.stage ? " data-stage=\"1\"" : ""}${t.kind === "control" ? " data-control=\"1\"" : ""}`;
		s.push(`<rect data-node="${t.id}"${e.clipped ? " data-clipped=\"1\"" : ""}${n} x="${e.x}" y="${e.y}" width="${e.w}" height="${e.h}" rx="7" fill="${vt[t.kind]}" stroke="${t.stroke || "#506778"}" stroke-width="${t.strokeWidth || 1.4}"${t.dashed ? " stroke-dasharray=\"7 4\"" : ""}${t.cls ? ` class="${t.cls}"` : ""}/>`);
		let r = xt(t.title, Math.floor(e.w / 7.1));
		r.forEach((t, n) => s.push(`<text x="${e.x + 8}" y="${e.y + 20 + n * 15}" font-size="12.5" font-weight="700" fill="#1D2D3E">${B(t)}</text>`)), xt(t.sub, Math.floor((e.w - 8) / 5.7)).forEach((t, n) => s.push(`<text x="${e.x + 8}" y="${e.y + 20 + r.length * 15 + n * 12.5}" font-size="10.5" fill="#34495C">${B(t)}</text>`)), t.status && s.push(`<text x="${e.x + 8}" y="${e.y + e.h - 9}" font-size="10.5" font-weight="700" fill="${t.statusColor || "#34495C"}">${B(t.status)}</text>`), t.zone && s.push(`<rect data-zone="${B(t.zone)}" x="${e.x}" y="${e.y}" width="${e.w}" height="${e.h}" rx="7" fill="transparent"/>`);
	}
	for (let [e, t, n, r] of l) {
		let i = n.length * 5.6 + 10;
		s.push(`<rect x="${e - i / 2}" y="${t - 11}" width="${i}" height="15" rx="3" fill="#F1F4F7" opacity="0.94"/><text x="${e}" y="${t}" font-size="10.5" font-weight="600" fill="${r}" text-anchor="middle">${B(n)}</text>`);
	}
	let f = 30;
	s.push(`<rect x="22" y="${t - 54}" width="1156" height="40" rx="6" fill="#FFFFFF" stroke="#D9E1E7"/>`), s.push(`<text x="30" y="${t - 36}" font-size="11" font-weight="700" fill="#506778">LEGEND</text>`);
	for (let [n, r] of e.legend) {
		let e = yt[n];
		s.push(`<line x1="${f + 60}" y1="${t - 40}" x2="${f + 90}" y2="${t - 40}" stroke="${e.c}" stroke-width="${e.w}"${e.d ? ` stroke-dasharray="${e.d}"` : ""}/><text x="${f + 96}" y="${t - 36}" font-size="11" fill="#1D2D3E">${B(r)}</text>`), f += 96 + r.length * 5.4 + 8;
	}
	s.push(`<text x="30" y="${t - 20}" font-size="10.5" fill="#506778">${B(e.footer)}</text>`);
	let p = e.title;
	return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 ${t}" role="img" aria-labelledby="t d" font-family="'Segoe UI','Segoe UI Variable','Helvetica Neue',Arial,sans-serif" text-rendering="geometricPrecision"><title id="t">${B(p)}</title><desc id="d">${B(e.chain)}</desc><rect width="1200" height="${t}" fill="#F1F4F7"/><text x="30" y="40" font-size="20" font-weight="700" fill="#1D2D3E">${B(p)}</text><text x="30" y="62" font-size="12" fill="#34495C">${B(e.chain.length > 150 ? e.chain.slice(0, 147) + "…" : e.chain)}</text><text x="30" y="82" font-size="11" fill="#B3261E" font-weight="700">${B(e.banner)}</text>${s.join("")}</svg>\n`;
}
// src/DetailedDiagrams.jsx
var Ct = 1200, wt = 840, Tt = 12, Et = [2, 4], Dt = (e, t, n) => Math.min(n, Math.max(t, e)), Ot = {
	D1: "Overview",
	D2: "S1",
	D3: "S2",
	D4: "S3",
	D5: "Hosting vs registry",
	D6: "Identity",
	D7: "LLM",
	D8: "Lifecycle",
	D9: "Audit",
	D10: "Comparison"
}, kt = Object.fromEntries(rt.map((e) => {
	let t = ht(e);
	return [e, {
		id: e,
		tab: `${e} · ${Ot[e]}`,
		title: `${e} · ${t.title}`,
		svg: gt(e),
		file: `architecture-${e.toLowerCase()}`,
		png: !0,
		summary: t.chain,
		footer: t.footer
	}];
})), At = ["D2", "D4"], jt = [
	"Registry product for S1 is unresolved: a plain API catalog is not a complete agent registry",
	"AgentCore Gateway to Apigee protocol and token exchange (S2): unproven",
	"Whether AI Foundry mandates AgentCore Gateway for every tool call (S3-B): policy-dependent",
	"Principal propagation through Integration Suite and Cloud Connector: to validate",
	"Persistence is conditional: HANA Cloud only if durable SAP-side state is required"
];
function Mt(e, t) {
	return e.replace("aria-labelledby=\"t d\"", `aria-labelledby="${t}-t ${t}-d"`).replace("id=\"t\"", `id="${t}-t"`).replace("id=\"d\"", `id="${t}-d"`);
}
function Nt(e) {
	return new Blob([`<?xml version="1.0" encoding="UTF-8"?>\n${e}`], { type: "image/svg+xml" });
}
function V({ diagram: e, uid: t, view: n, onView: r, onFit: i, expanded: a, onExpand: o, compact: s, onPick: c }) {
	let l = e.w || Ct, u = e.h || wt, d = (0, _.useRef)(null), f = (0, _.useRef)(null), p = (0, _.useRef)(null), m = (0, _.useRef)(n), h = (0, _.useRef)({
		s: .5,
		x: 0,
		y: 0
	}), g = (0, _.useRef)(!0), v = (0, _.useRef)(/* @__PURE__ */ new Map()), y = (0, _.useRef)(null);
	m.current = n;
	let b = (0, _.useRef)(r), x = (0, _.useRef)(i);
	b.current = r, x.current = i;
	let S = (0, _.useMemo)(() => Mt(e.svg, t), [e, t]), C = (0, _.useCallback)(() => {
		let e = f.current?.getBoundingClientRect();
		if (!e || !e.width || !e.height) return null;
		let t = Math.min((e.width - 16) / l, (e.height - 16) / u);
		return {
			s: t,
			x: (e.width - l * t) / 2,
			y: (e.height - u * t) / 2
		};
	}, [l, u]), w = (0, _.useCallback)(() => {
		let e = C();
		e && (h.current = e, g.current = !0, x.current(e));
	}, [C]);
	(0, _.useLayoutEffect)(() => {
		w();
	}, [
		w,
		a,
		e.id
	]), (0, _.useEffect)(() => {
		let e = f.current;
		if (!e || typeof ResizeObserver > "u") return;
		let t = new ResizeObserver(() => {
			if (g.current) w();
			else {
				let e = C();
				e && (h.current = e);
			}
		});
		return t.observe(e), () => t.disconnect();
	}, [w, C]);
	let T = (0, _.useCallback)((e, t, n) => {
		let r = m.current;
		if (!r) return;
		let i = Math.max(.05, h.current.s * .5), a = Dt(r.s * e, i, Tt), o = a / r.s;
		g.current = !1, b.current({
			s: a,
			x: t - (t - r.x) * o,
			y: n - (n - r.y) * o
		});
	}, []), E = (e) => {
		let t = f.current.getBoundingClientRect();
		T(e, t.width / 2, t.height / 2);
	}, D = (e, t) => {
		let n = m.current;
		n && (g.current = !1, b.current({
			...n,
			x: n.x + e,
			y: n.y + t
		}));
	}, O = () => {
		let e = f.current.getBoundingClientRect(), t = m.current, n = 1 / t.s;
		g.current = !1;
		let r = e.width / 2, i = e.height / 2;
		b.current({
			s: 1,
			x: r - (r - t.x) * n,
			y: i - (i - t.y) * n
		});
	};
	(0, _.useEffect)(() => {
		let e = f.current;
		if (!e) return;
		let t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = t.deltaMode === 1 ? 32 : t.deltaMode === 2 ? 400 : 1;
			T(Math.exp(-t.deltaY * r * (t.ctrlKey ? .01 : .0016)), t.clientX - n.left, t.clientY - n.top);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [T]);
	let k = (e) => {
		if (!e.target.closest("button") && (f.current.setPointerCapture?.(e.pointerId), v.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), d.current = {
			x: e.clientX,
			y: e.clientY
		}, v.current.size === 2)) {
			let [e, t] = [...v.current.values()];
			y.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, ee = (e) => {
		let t = v.current.get(e.pointerId);
		if (!t) return;
		let n = {
			x: e.clientX,
			y: e.clientY
		};
		if (v.current.size === 1) D(n.x - t.x, n.y - t.y);
		else if (v.current.size === 2 && y.current) {
			v.current.set(e.pointerId, n);
			let [t, r] = [...v.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y), a = f.current.getBoundingClientRect();
			T(i / y.current, (t.x + r.x) / 2 - a.left, (t.y + r.y) / 2 - a.top), y.current = i;
			return;
		}
		v.current.set(e.pointerId, n);
	}, te = (e) => {
		let t = d.current;
		if (v.current.delete(e.pointerId), v.current.size < 2 && (y.current = null), c && t && e.type === "pointerup" && v.current.size === 0 && Math.hypot(e.clientX - t.x, e.clientY - t.y) < 5) {
			let t = f.current?.getRootNode?.(), n = (t?.elementFromPoint ? t : document).elementFromPoint(e.clientX, e.clientY)?.closest?.("[data-zone]");
			n && c(n.getAttribute("data-zone"));
		}
		d.current = null;
	}, ne = (e) => {
		if (e.key === "+" || e.key === "=") E(1.25);
		else if (e.key === "-" || e.key === "_") E(.8);
		else if (e.key === "0") w();
		else if (e.key === "1") O();
		else if (e.key === "ArrowLeft") D(60, 0);
		else if (e.key === "ArrowRight") D(-60, 0);
		else if (e.key === "ArrowUp") D(0, 60);
		else if (e.key === "ArrowDown") D(0, -60);
		else if (e.key === "Escape" && a) o(!1);
		else return;
		e.preventDefault(), e.stopPropagation();
	};
	(0, _.useEffect)(() => {
		if (!a) return;
		let e = (e) => {
			e.key === "Escape" && o(!1);
		};
		document.addEventListener("keydown", e);
		let t = () => {
			!document.fullscreenElement && a && o(!1);
		};
		return document.addEventListener("fullscreenchange", t), () => {
			document.removeEventListener("keydown", e), document.removeEventListener("fullscreenchange", t);
		};
	}, [a, o]);
	let re = () => {
		if (a) document.fullscreenElement && document.exitFullscreen?.().catch(() => {}), o(!1);
		else {
			o(!0);
			try {
				p.current?.requestFullscreen?.().catch(() => {});
			} catch {}
		}
	}, ie = () => {
		let t = URL.createObjectURL(Nt(e.svg));
		window.open(t, "_blank", "noopener"), setTimeout(() => URL.revokeObjectURL(t), 6e4);
	}, ae = () => {
		let t = URL.createObjectURL(Nt(e.svg)), n = document.createElement("a");
		n.href = t, n.download = `${e.file || `finance-architecture-${e.id.toLowerCase()}`}.svg`, document.body.appendChild(n), n.click(), n.remove(), setTimeout(() => URL.revokeObjectURL(t), 1e3);
	}, oe = (t) => {
		let n = URL.createObjectURL(Nt(e.svg)), r = new Image();
		r.onload = () => {
			let i = document.createElement("canvas");
			i.width = l * t, i.height = u * t, i.getContext("2d").drawImage(r, 0, 0, i.width, i.height), URL.revokeObjectURL(n), i.toBlob((n) => {
				if (!n) return;
				let r = URL.createObjectURL(n), i = document.createElement("a");
				i.href = r, i.download = `${e.file || `finance-architecture-${e.id.toLowerCase()}`}-${t}x.png`, document.body.appendChild(i), i.click(), i.remove(), setTimeout(() => URL.revokeObjectURL(r), 1e3);
			}, "image/png");
		}, r.onerror = () => URL.revokeObjectURL(n), r.src = n;
	}, se = Math.round((n?.s || 0) * 100), ce = n ? `translate(${n.x}px,${n.y}px) scale(${n.s})` : "none";
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		ref: p,
		className: `dd-viewer ${a ? "expanded" : ""} ${s ? "compact" : ""}`,
		children: [/* @__PURE__ */ (0, A.jsxs)("div", {
			className: "dd-toolbar",
			role: "toolbar",
			"aria-label": `${e.title} viewer controls`,
			children: [/* @__PURE__ */ (0, A.jsxs)("strong", {
				className: "dd-viewer-title",
				children: [/* @__PURE__ */ (0, A.jsx)("span", {
					className: `dd-dot ${e.id.toLowerCase()}`,
					"aria-hidden": "true"
				}), e.title]
			}), /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "dd-tools",
				children: [
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: () => E(.8),
						"aria-label": `Zoom out ${e.id}`,
						title: "Zoom out (−)",
						children: "−"
					}),
					/* @__PURE__ */ (0, A.jsxs)("output", {
						className: "dd-zoom",
						"aria-live": "polite",
						"aria-label": `${e.id} zoom level`,
						children: [se, "%"]
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: () => E(1.25),
						"aria-label": `Zoom in ${e.id}`,
						title: "Zoom in (+)",
						children: "+"
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: w,
						"aria-label": `Reset ${e.id} view to fit`,
						title: "Reset to fit (0)",
						children: "Reset"
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: O,
						"aria-label": `${e.id} actual size`,
						title: "Actual size, 100% (1)",
						children: "100%"
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: re,
						"aria-label": a ? `Exit expanded ${e.id} view` : `Expand ${e.id} to full screen`,
						"aria-pressed": a,
						children: a ? "Close ✕" : "Expand ⤢"
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: ie,
						title: "Open the vector SVG in a new browser tab",
						children: "Open full-size ↗"
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: ae,
						title: "Download the vector SVG",
						children: "SVG ⤓"
					}),
					e.png && Et.map((t) => /* @__PURE__ */ (0, A.jsxs)("button", {
						type: "button",
						onClick: () => oe(t),
						"aria-label": `Download ${e.id} as ${t}x PNG`,
						title: `Download a ${l * t} x ${u * t} px PNG`,
						children: [
							"PNG ",
							t,
							"× ⤓"
						]
					}, t))
				]
			})]
		}), /* @__PURE__ */ (0, A.jsxs)("div", {
			ref: f,
			className: "dd-viewport",
			tabIndex: 0,
			role: "group",
			"aria-label": `${e.title} diagram. Scroll or pinch to zoom, drag to pan. Keys: plus and minus zoom, arrow keys pan, 0 resets, 1 actual size.`,
			onPointerDown: k,
			onPointerMove: ee,
			onPointerUp: te,
			onPointerCancel: te,
			onKeyDown: ne,
			onDoubleClick: (e) => {
				if (e.target.closest("button")) return;
				let t = f.current.getBoundingClientRect();
				T(1.8, e.clientX - t.left, e.clientY - t.top);
			},
			children: [/* @__PURE__ */ (0, A.jsx)("div", {
				className: "dd-stage",
				"data-testid": `diagram-${e.id}`,
				style: {
					width: l,
					height: u,
					transform: ce
				},
				dangerouslySetInnerHTML: { __html: S }
			}), /* @__PURE__ */ (0, A.jsx)("span", {
				className: "dd-hint",
				"aria-hidden": "true",
				children: "Scroll to zoom · drag to pan · double-click to zoom in"
			})]
		})]
	});
}
function Pt({ view: e = "D1", onView: t, onBack: n }) {
	let [r, i] = (0, _.useState)(null), [a, o] = (0, _.useState)(null), [s, c] = (0, _.useState)(!0), [l, u] = (0, _.useState)(null), [d, f] = (0, _.useState)(At), p = e === "compare", m = kt[e] ? e : "D1", h = (e) => {
		u(null), t(e);
	}, g = kt[m], v = (0, _.useCallback)((e) => {
		i(e), o(e);
	}, []), y = [
		"D2",
		"D3",
		"D4"
	];
	return /* @__PURE__ */ (0, A.jsxs)("main", {
		className: "detailed-diagrams",
		"aria-label": "Architecture diagrams",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("header", {
				className: "surface dd-header",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "dd-title",
						children: [/* @__PURE__ */ (0, A.jsx)("span", {
							className: "eyebrow",
							children: "ARCHITECTURE DIAGRAMS · V5.1 · GENERATED FROM ONE MODEL (VECTOR)"
						}), /* @__PURE__ */ (0, A.jsx)("h2", { children: p ? "Scenario topologies side by side" : g.title })]
					}),
					/* @__PURE__ */ (0, A.jsx)("nav", {
						className: "dd-selector",
						role: "tablist",
						"aria-label": "Detailed diagram selection",
						children: [...rt, "compare"].map((t) => /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": e === t,
							className: e === t ? "active" : "",
							onClick: () => h(t),
							children: t === "compare" ? "Compare side-by-side" : kt[t].tab
						}, t))
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "dd-header-actions",
						children: [/* @__PURE__ */ (0, A.jsx)("span", {
							className: "pill warn",
							children: "PROPOSED DESIGN · NOT APPROVED · NOT TENANT-VERIFIED"
						}), /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							onClick: n,
							children: "← Complete architecture"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface dd-summary",
				"aria-label": "Diagram summary",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
					className: "eyebrow",
					children: p ? "WHAT THIS VIEW SHOWS" : g.id
				}), /* @__PURE__ */ (0, A.jsx)("p", { children: p ? "Two scenario topologies from the same model. Pick the scenarios below; zoom and pan can be synchronized." : g.summary })] }), /* @__PURE__ */ (0, A.jsxs)("div", {
					className: "dd-invariant",
					children: [/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "COMMON TO S1, S2 AND S3"
					}), /* @__PURE__ */ (0, A.jsx)("p", { children: "Portkey is the LLM gateway. Google Apigee is the SAP-facing MCP/API gateway. SAP Integration Suite is the SAP integration boundary. The SAP backend decides business authorization. A registry is a catalog, never an invocation hop." })]
				})]
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: `dd-body ${p ? "is-compare" : ""}`,
				children: [p ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "dd-compare-bar surface",
					children: [/* @__PURE__ */ (0, A.jsxs)("label", { children: [/* @__PURE__ */ (0, A.jsx)("input", {
						type: "checkbox",
						checked: s,
						onChange: (e) => c(e.target.checked)
					}), " Synchronize zoom and pan"] }), d.map((e, t) => /* @__PURE__ */ (0, A.jsxs)("label", { children: [
						t ? "with" : "Compare",
						" ",
						/* @__PURE__ */ (0, A.jsx)("select", {
							value: e,
							onChange: (e) => f((n) => n.map((n, r) => r === t ? e.target.value : n)),
							children: y.map((e) => /* @__PURE__ */ (0, A.jsx)("option", {
								value: e,
								children: kt[e].tab
							}, e))
						})
					] }, t))]
				}), /* @__PURE__ */ (0, A.jsx)("div", {
					className: "dd-compare-grid",
					children: d.map((e, t) => /* @__PURE__ */ (0, A.jsx)(V, {
						diagram: kt[e],
						uid: `dd-${e}-cmp-${t}`,
						compact: !0,
						view: t === 0 ? r : a,
						onView: (e) => {
							s ? v(e) : (t === 0 ? i : o)(e);
						},
						onFit: (e) => {
							s ? v(e) : (t === 0 ? i : o)(e);
						},
						expanded: l === t,
						onExpand: (e) => u(e ? t : null)
					}, `${e}-${t}`))
				})] }) : /* @__PURE__ */ (0, A.jsx)(V, {
					diagram: g,
					uid: `dd-${g.id}`,
					view: r,
					onView: i,
					onFit: i,
					expanded: l === g.id,
					onExpand: (e) => u(e ? g.id : null)
				}, g.id), /* @__PURE__ */ (0, A.jsxs)("aside", {
					className: "surface dd-side",
					"aria-label": "Open validations",
					children: [
						/* @__PURE__ */ (0, A.jsx)("h3", { children: "Scenarios in this model" }),
						/* @__PURE__ */ (0, A.jsx)("ul", { children: [
							"S1",
							"S2",
							"S3"
						].map((e) => /* @__PURE__ */ (0, A.jsxs)("li", { children: [
							/* @__PURE__ */ (0, A.jsx)("strong", { children: e }),
							" ",
							z[e].agent_runtime,
							" · registry: ",
							z[e].agent_registry
						] }, e)) }),
						/* @__PURE__ */ (0, A.jsx)("h3", { children: "Open validations" }),
						/* @__PURE__ */ (0, A.jsx)("ul", { children: jt.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) }),
						/* @__PURE__ */ (0, A.jsxs)("p", {
							className: "micro",
							children: [nt, ". Vendor-named components are design projections, not connected services."]
						}),
						/* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							className: "text-link",
							onClick: n,
							children: "Back to complete architecture →"
						})
					]
				})]
			})
		]
	});
}
// src/ArchitectureDiagram.jsx
function Ft({ diagramKey: e, onClose: t, onDetails: n }) {
	let r = ht(e), [i, a] = (0, _.useState)(null), [o, s] = (0, _.useState)(!1), c = (0, _.useMemo)(() => r ? {
		id: `modal-${e}`,
		title: r.title,
		svg: gt(e),
		file: `architecture-${e.toLowerCase()}`,
		png: !0
	} : null, [r, e]);
	return (0, _.useEffect)(() => {
		let e = (e) => {
			e.key === "Escape" && t();
		};
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}, [t]), r ? /* @__PURE__ */ (0, A.jsx)("div", {
		className: "arch-diagram-backdrop",
		onMouseDown: (e) => {
			e.target === e.currentTarget && t();
		},
		children: /* @__PURE__ */ (0, A.jsxs)("section", {
			className: "surface arch-diagram-modal",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": `${r.title} architecture diagram`,
			children: [
				/* @__PURE__ */ (0, A.jsxs)("header", {
					className: "arch-diagram-header",
					children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsxs)("span", {
						className: "eyebrow",
						children: ["ARCHITECTURE DIAGRAM · ", e]
					}), /* @__PURE__ */ (0, A.jsx)("h2", { children: r.title })] }), /* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
						className: "pill warn",
						children: "PROPOSED · NOT APPROVED"
					}), /* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: t,
						autoFocus: !0,
						children: "Close"
					})] })]
				}),
				/* @__PURE__ */ (0, A.jsx)("div", {
					className: "arch-diagram-viewer",
					children: /* @__PURE__ */ (0, A.jsx)(V, {
						diagram: c,
						uid: `arch-${e}`,
						view: i,
						onView: a,
						onFit: a,
						expanded: o,
						onExpand: s
					})
				}),
				/* @__PURE__ */ (0, A.jsxs)("footer", {
					className: "arch-diagram-footer",
					children: [/* @__PURE__ */ (0, A.jsxs)("p", { children: [
						/* @__PURE__ */ (0, A.jsx)("strong", { children: "Note:" }),
						" ",
						r.footer,
						" ",
						nt,
						"."
					] }), /* @__PURE__ */ (0, A.jsx)("div", { children: n && /* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: n,
						children: "View details →"
					}) })]
				})
			]
		})
	}) : null;
}
// src/McpApproaches.jsx
var It = {
	S1: "D2",
	S2: "D3",
	S3: "D4"
}, Lt = [
	["Agent hosting and execution", "agent_runtime"],
	["MCP gateway", "mcp_gateway"],
	["Custom MCP runtime (if required)", "custom_mcp_runtime"],
	["Agent registry", "agent_registry"],
	["MCP registry", "mcp_registry"],
	["LLM gateway", "llm_gateway"],
	["SAP integration", "integration_suite"],
	["Business authorization", "backend_authorization"],
	["Persistence", "persistence"]
];
function Rt({ playbooks: e = {}, onQuestion: t, onDetailedDiagram: n, onGovernance: r, onAgentHosting: i }) {
	let [a, o] = (0, _.useState)("S3"), [s, c] = (0, _.useState)(null), l = a === "compare" ? null : a, u = l ? z[l] : null, d = l ? e[l] : null;
	return /* @__PURE__ */ (0, A.jsxs)("main", {
		className: "mcp-comparison mcp-bird arch-page hosting-page",
		"aria-label": "Complete architecture",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("header", {
				className: "surface mcp-bird-header",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("h2", { children: "Complete architecture" }), /* @__PURE__ */ (0, A.jsx)("span", {
					className: "eyebrow",
					children: "AGENT → MCP → SAP, END TO END · THREE SCENARIOS UNDER EVALUATION"
				})] }), /* @__PURE__ */ (0, A.jsx)("span", {
					className: "pill warn",
					children: nt.split(" · ")[0]
				})]
			}),
			/* @__PURE__ */ (0, A.jsx)("nav", {
				className: "surface mcp-route-tabs mcp-bird-tabs",
				role: "tablist",
				"aria-label": "Architecture approach details",
				children: [...R, "compare"].map((e) => /* @__PURE__ */ (0, A.jsxs)("button", {
					type: "button",
					role: "tab",
					"aria-selected": a === e,
					className: a === e ? "active" : "",
					onClick: () => o(e),
					children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: e === "compare" ? "Compare all" : e }), /* @__PURE__ */ (0, A.jsx)("span", { children: e === "compare" ? "Three scenarios side by side" : z[e].short })]
				}, e))
			}),
			l ? /* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface mcp-bird-panel arch-panel",
				role: "tabpanel",
				"aria-label": `${l} architecture overview`,
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "mcp-bird-panel-title",
						children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsxs)("span", {
							className: "eyebrow",
							children: [
								l,
								" · ",
								u.status.toUpperCase()
							]
						}), /* @__PURE__ */ (0, A.jsx)("h3", { children: u.name })] }), /* @__PURE__ */ (0, A.jsx)("div", {
							className: "mcp-bird-title-actions",
							children: /* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								className: "diagram-action",
								onClick: () => c(It[l]),
								children: "Architecture diagram ↗"
							})
						})]
					}),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "mcp-bird-path arch-path",
						"aria-label": "Selected request path",
						children: u.chain.split(" → ").map((e, t) => /* @__PURE__ */ (0, A.jsxs)(_.Fragment, { children: [t > 0 && /* @__PURE__ */ (0, A.jsx)("span", {
							"aria-hidden": "true",
							children: "→"
						}), /* @__PURE__ */ (0, A.jsx)("b", { children: e })] }, e + t))
					}),
					/* @__PURE__ */ (0, A.jsx)("p", { children: u.objective }),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "arch-grid",
						children: [
							/* @__PURE__ */ (0, A.jsxs)("section", {
								"aria-label": "Route facts",
								children: [/* @__PURE__ */ (0, A.jsx)("h4", { children: "Who owns what" }), /* @__PURE__ */ (0, A.jsx)("div", {
									className: "arch-cards",
									children: Lt.map(([e, t]) => /* @__PURE__ */ (0, A.jsxs)("div", {
										className: /pending|TBD/i.test(u[t]) ? "warn" : "",
										children: [/* @__PURE__ */ (0, A.jsx)("span", { children: e }), /* @__PURE__ */ (0, A.jsx)("b", { children: u[t] })]
									}, t))
								})]
							}),
							/* @__PURE__ */ (0, A.jsxs)("section", {
								"aria-label": "Open dependencies",
								children: [
									/* @__PURE__ */ (0, A.jsx)("h4", { children: "Not yet verified" }),
									/* @__PURE__ */ (0, A.jsx)("ul", { children: u.unverified.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) }),
									/* @__PURE__ */ (0, A.jsx)("h4", { children: "Enterprise-policy dependencies" }),
									/* @__PURE__ */ (0, A.jsx)("ul", { children: u.policy_dependencies.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })
								]
							}),
							/* @__PURE__ */ (0, A.jsxs)("section", {
								"aria-label": "Assumptions",
								className: "arch-judgment",
								children: [
									/* @__PURE__ */ (0, A.jsx)("h4", { children: "Assumptions" }),
									/* @__PURE__ */ (0, A.jsx)("ul", { children: u.assumptions.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) }),
									u.variant_b && /* @__PURE__ */ (0, A.jsxs)("p", {
										className: "bad",
										children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "S3-B" }), u.variant_b]
									}),
									d?.decisions?.length > 0 && /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [/* @__PURE__ */ (0, A.jsx)("h4", { children: "Open decisions" }), /* @__PURE__ */ (0, A.jsx)("ul", { children: d.decisions.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })] })
								]
							})
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "arch-links",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Related, separate views:" }),
							r && /* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								className: "text-link",
								onClick: () => r(l),
								children: "MCP hosting →"
							}),
							i && /* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								className: "text-link",
								onClick: i,
								children: "Agent hosting →"
							}),
							n && /* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								className: "text-link",
								onClick: () => n(l),
								children: "All diagrams →"
							}),
							t && /* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								className: "text-link",
								onClick: t,
								children: "Architecture questions →"
							})
						]
					})
				]
			}) : /* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface mcp-bird-panel mcp-bird-compare arch-panel",
				role: "tabpanel",
				"aria-label": "Route comparison overview",
				children: [/* @__PURE__ */ (0, A.jsx)("div", {
					className: "mcp-bird-panel-title",
					children: /* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "COMPLETE ARCHITECTURE · SIDE BY SIDE"
					}), /* @__PURE__ */ (0, A.jsx)("h3", { children: "Three scenarios, one decision view" })] })
				}), /* @__PURE__ */ (0, A.jsx)("div", {
					className: "mg-scroll",
					children: /* @__PURE__ */ (0, A.jsxs)("table", {
						className: "mg-table",
						"data-testid": "arch-compare",
						children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsx)("th", {
							scope: "col",
							children: "Dimension"
						}), R.map((e) => /* @__PURE__ */ (0, A.jsx)("th", {
							scope: "col",
							children: z[e].name
						}, e))] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: at.map(([e, ...t]) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsx)("th", {
							scope: "row",
							children: e
						}), t.map((e, t) => /* @__PURE__ */ (0, A.jsx)("td", { children: e }, R[t]))] }, e)) })]
					})
				})]
			}),
			s && /* @__PURE__ */ (0, A.jsx)(Ft, {
				diagramKey: s,
				onClose: () => c(null),
				onDetails: () => {
					let e = Object.keys(It).find((e) => It[e] === s);
					c(null), e && n && n(e);
				}
			})
		]
	});
}
// src/ScenarioDecisions.jsx
var zt = [
	[
		"Agent hosting and execution",
		"agent_runtime",
		"Where the agent runs"
	],
	[
		"Agent registration and discovery",
		"agent_registry",
		"Where the agent is catalogued"
	],
	[
		"MCP implementation hosting",
		"custom_mcp_runtime",
		"Only where custom MCP code is needed"
	],
	[
		"MCP registration and discovery",
		"mcp_registry",
		"Where the MCP server is catalogued"
	],
	[
		"MCP gateway / exposure",
		"mcp_gateway",
		"Who exposes and governs the tools"
	],
	[
		"LLM gateway",
		"llm_gateway",
		"Model access, independent of the rest"
	]
], Bt = (e) => /pending|TBD|unresolved/i.test(e);
function Vt({ focus: e = R, title: t = "The independent decisions in each scenario", rows: n = zt }) {
	return /* @__PURE__ */ (0, A.jsxs)("section", {
		className: "surface sd-strip",
		"data-testid": "decision-strip",
		"aria-label": t,
		children: [/* @__PURE__ */ (0, A.jsxs)("div", {
			className: "sd-head",
			children: [/* @__PURE__ */ (0, A.jsx)("span", {
				className: "eyebrow",
				children: t.toUpperCase()
			}), /* @__PURE__ */ (0, A.jsx)("span", {
				className: "micro",
				children: "Registration never decides hosting: AWS Agent Registry (S3) does not move the agent to AWS."
			})]
		}), /* @__PURE__ */ (0, A.jsx)("div", {
			className: "mg-scroll",
			children: /* @__PURE__ */ (0, A.jsxs)("table", {
				className: "mg-table sd-table",
				children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsx)("th", {
					scope: "col",
					children: "Decision"
				}), R.map((t) => /* @__PURE__ */ (0, A.jsx)("th", {
					scope: "col",
					className: e.includes(t) ? "sel" : "",
					children: z[t].name
				}, t))] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: n.map(([t, n, r]) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsxs)("th", {
					scope: "row",
					children: [t, /* @__PURE__ */ (0, A.jsx)("small", { children: r })]
				}), R.map((t) => /* @__PURE__ */ (0, A.jsx)("td", {
					"data-label": z[t].name,
					className: `${e.includes(t) ? "sel" : ""} ${Bt(z[t][n]) ? "mg-open" : ""}`,
					children: z[t][n]
				}, t))] }, n)) })]
			})
		})]
	});
}
// src/McpGovernance.jsx
var Ht = [
	["mg-responsibility", "Comparison matrix"],
	["mg-connections", "Endpoint connectivity"],
	["mg-patterns", "Exposure patterns"],
	["mg-domain", "Finance domain design"],
	["mg-recommendation", "Recommendation"],
	["mg-evidence", "Source evidence"]
], H = {
	"mg-responsibility": "Hosting, registration, gateway, identity, cost and governance side by side",
	"mg-patterns": "Managed endpoint (Pattern A) versus custom server (Pattern B)",
	"mg-domain": "Read, posting and analytical tools with separate authorizations",
	"mg-recommendation": "Preferred candidate and proof plan",
	"mg-evidence": "Official sources and what they do not prove",
	"mg-connections": "Every connection, with its plane and verification status"
};
function Ut(e) {
	return {
		id: e,
		title: z[e].label,
		svg: _t(e),
		file: `mcp-topology-${e.toLowerCase()}`,
		png: !0
	};
}
var Wt = (e) => /TBD|TO VALIDATE|unproven|NOT_VERIFIED|REQUIRES VALIDATION|needs proof|must be proven|unmeasured|pending|unresolved/i.test(e), Gt = ({ text: e }) => /* @__PURE__ */ (0, A.jsx)("td", {
	className: Wt(e) ? "mg-open" : "",
	children: e
});
function Kt({ id: e, testid: t, title: n, hint: r, open: i, onToggle: a, children: o }) {
	return /* @__PURE__ */ (0, A.jsxs)("details", {
		id: e,
		className: "surface mg-section mg-fold",
		"data-testid": t,
		open: i,
		onToggle: (t) => a(e, t.currentTarget.open),
		children: [/* @__PURE__ */ (0, A.jsxs)("summary", { children: [/* @__PURE__ */ (0, A.jsx)("h3", { children: n }), /* @__PURE__ */ (0, A.jsx)("span", {
			className: "mg-hint",
			children: r
		})] }), o]
	});
}
function qt({ view: e = "S3", onView: t, onApproaches: n, onAgentHosting: r, onDetailed: i, onRegistry: a }) {
	let o = (0, _.useRef)(null), [s, c] = (0, _.useState)({ "mg-recommendation": !0 }), l = (e, t) => c((n) => n[e] === t ? n : {
		...n,
		[e]: t
	}), [u, d] = (0, _.useState)(null), [f, p] = (0, _.useState)(null), [m, h] = (0, _.useState)(!0), [g, v] = (0, _.useState)(null), [y, b] = (0, _.useState)("S3"), x = e === "compare", S = x ? "S1" : e, C = z[S] || z.S3, w = (0, _.useMemo)(() => Object.fromEntries(R.map((e) => [e, Ut(e)])), []), T = (0, _.useCallback)((e) => {
		d(e), p(e);
	}, []), E = y === S ? R.find((e) => e !== S) : y, D = (n) => {
		n !== e && (v(null), t(n));
	}, O = (e) => {
		c((t) => ({
			...t,
			[e]: !0
		})), requestAnimationFrame(() => o.current?.querySelector(`#${e}`)?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		}));
	}, k = x ? ["S1", E] : [S];
	return /* @__PURE__ */ (0, A.jsxs)("main", {
		ref: o,
		className: "detailed-diagrams mcp-governance",
		"aria-label": "MCP hosting",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("header", {
				className: "surface dd-header",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "dd-title",
						children: [/* @__PURE__ */ (0, A.jsx)("span", {
							className: "eyebrow",
							children: "MCP HOSTING AND EXPOSURE · WHO EXPOSES, GOVERNS, HOSTS AND EXECUTES THE FINANCE MCP"
						}), /* @__PURE__ */ (0, A.jsx)("h2", { children: x ? "Compare MCP topologies" : C.label })]
					}),
					/* @__PURE__ */ (0, A.jsx)("nav", {
						className: "dd-selector",
						role: "tablist",
						"aria-label": "MCP scenario selection",
						children: [...R, "compare"].map((t) => /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": e === t,
							className: e === t ? "active" : "",
							onClick: () => D(t),
							children: t === "compare" ? "Compare side-by-side" : z[t].label
						}, t))
					}),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "dd-header-actions",
						children: /* @__PURE__ */ (0, A.jsx)("span", {
							className: "pill warn",
							children: nt.split(" · ").slice(0, 2).join(" · ")
						})
					})
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface dd-summary",
				"aria-label": "Scenario summary",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
					/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: x ? "WHAT THIS VIEW SHOWS" : `${S} · ${C.short.toUpperCase()} · ${C.status.toUpperCase()}`
					}),
					/* @__PURE__ */ (0, A.jsx)("p", { children: x ? "Two scenarios side by side. Pick the second one below. The matrices further down always show all three." : C.summary }),
					!x && /* @__PURE__ */ (0, A.jsx)("p", {
						className: "micro",
						children: C.baseline
					})
				] }), /* @__PURE__ */ (0, A.jsxs)("div", {
					className: "dd-invariant",
					children: [/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "THIS PAGE: EXPOSURE AND HOSTING"
					}), /* @__PURE__ */ (0, A.jsx)("p", { children: "Apigee is the SAP-facing MCP/API gateway in every scenario. An approved API is exposed as an MCP tool (Pattern A, no custom server) or a custom MCP server runs on the scenario host behind Apigee (Pattern B). Registration of the agent and the MCP server is a separate decision: see Registry." })]
				})]
			}),
			/* @__PURE__ */ (0, A.jsx)(Vt, {
				focus: x ? ["S1", E] : [S],
				title: "MCP hosting next to the other decisions",
				rows: [
					[
						"MCP gateway / exposure",
						"mcp_gateway",
						"Who exposes and governs the tools"
					],
					[
						"MCP endpoint type",
						"mcp_endpoint_type",
						"Pattern A or B"
					],
					[
						"MCP implementation hosting",
						"custom_mcp_runtime",
						"Only where custom code is needed"
					],
					[
						"MCP tool execution",
						"mcp_tool_execution_location",
						"Where the tool actually runs"
					]
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("nav", {
				className: "mg-anchors",
				"aria-label": "Sections on this page",
				children: [
					Ht.map(([e, t]) => /* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: () => O(e),
						children: t
					}, e)),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: n,
						children: "Complete architecture →"
					}),
					r && /* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: r,
						children: "Agent hosting →"
					}),
					a && /* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: a,
						children: "Registry →"
					}),
					i && /* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: () => i("D5"),
						children: "Hosting versus registration diagram →"
					})
				]
			}),
			x && /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "surface dd-compare-bar",
				children: [/* @__PURE__ */ (0, A.jsxs)("label", { children: [/* @__PURE__ */ (0, A.jsx)("input", {
					type: "checkbox",
					checked: m,
					onChange: (e) => h(e.target.checked)
				}), " Synchronize zoom and pan"] }), /* @__PURE__ */ (0, A.jsxs)("label", { children: ["Compare S1 with ", /* @__PURE__ */ (0, A.jsx)("select", {
					value: E,
					onChange: (e) => b(e.target.value),
					children: R.filter((e) => e !== "S1").map((e) => /* @__PURE__ */ (0, A.jsx)("option", {
						value: e,
						children: z[e].label
					}, e))
				})] })]
			}),
			/* @__PURE__ */ (0, A.jsx)("div", {
				className: `mg-viewers ${x ? "two" : ""}`,
				children: k.map((e, t) => /* @__PURE__ */ (0, A.jsx)("div", {
					className: "mg-viewer",
					"data-scenario": e,
					children: /* @__PURE__ */ (0, A.jsx)(V, {
						diagram: w[e],
						uid: `mg-${e}-${x ? "c" : "s"}`,
						compact: x,
						view: t === 0 ? u : f,
						onView: (e) => {
							x && m ? T(e) : (t === 0 ? d : p)(e);
						},
						onFit: (e) => {
							x && m ? T(e) : (t === 0 ? d : p)(e);
						},
						expanded: g === e,
						onExpand: (t) => v(t ? e : null)
					})
				}, e))
			}),
			/* @__PURE__ */ (0, A.jsxs)(Kt, {
				id: "mg-responsibility",
				testid: "mg-matrix",
				title: /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
					"Comparison matrix · ",
					at.length,
					" rows"
				] }),
				hint: H["mg-responsibility"],
				open: !!s["mg-responsibility"],
				onToggle: l,
				children: [/* @__PURE__ */ (0, A.jsxs)("p", {
					className: "micro",
					children: [
						"Selected scenario highlighted. “",
						tt,
						"” marks proof that does not exist yet."
					]
				}), /* @__PURE__ */ (0, A.jsx)("div", {
					className: "mg-scroll",
					children: /* @__PURE__ */ (0, A.jsxs)("table", {
						className: "mg-table",
						children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsx)("th", {
							scope: "col",
							children: "Dimension"
						}), R.map((e) => /* @__PURE__ */ (0, A.jsx)("th", {
							scope: "col",
							className: k.includes(e) ? "sel" : "",
							children: z[e].label
						}, e))] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: at.map(([e, ...t], n) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsxs)("th", {
							scope: "row",
							children: [
								n + 1,
								". ",
								e
							]
						}), t.map((e, t) => /* @__PURE__ */ (0, A.jsx)("td", {
							className: `${k.includes(R[t]) ? "sel" : ""} ${Wt(e) ? "mg-open" : ""}`,
							children: e
						}, R[t]))] }, e)) })]
					})
				})]
			}),
			k.map((e) => /* @__PURE__ */ (0, A.jsx)(Kt, {
				id: e === k[0] ? "mg-connections" : `mg-connections-${e}`,
				testid: `mg-connections-${e}`,
				title: /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: ["Endpoint connectivity · ", z[e].label] }),
				hint: H["mg-connections"],
				open: !!s[e === k[0] ? "mg-connections" : `mg-connections-${e}`],
				onToggle: l,
				children: /* @__PURE__ */ (0, A.jsx)("div", {
					className: "mg-scroll",
					children: /* @__PURE__ */ (0, A.jsxs)("table", {
						className: "mg-table wide",
						children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsx)("tr", { children: ot.map((e) => /* @__PURE__ */ (0, A.jsx)("th", {
							scope: "col",
							children: e
						}, e)) }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: st[e].map((e, t) => /* @__PURE__ */ (0, A.jsx)("tr", {
							className: /not invocation/i.test(e[2]) ? "mg-aside" : "",
							children: e.map((e, t) => t === 0 ? /* @__PURE__ */ (0, A.jsx)("th", {
								scope: "row",
								children: e
							}, t) : /* @__PURE__ */ (0, A.jsx)(Gt, { text: e }, t))
						}, t)) })]
					})
				})
			}, e)),
			/* @__PURE__ */ (0, A.jsxs)(Kt, {
				id: "mg-patterns",
				testid: "mg-patterns",
				title: /* @__PURE__ */ (0, A.jsx)(A.Fragment, { children: "Exposure patterns · managed endpoint versus custom server" }),
				hint: H["mg-patterns"],
				open: !!s["mg-patterns"],
				onToggle: l,
				children: [
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "micro",
						children: "Do not assume every API-backed MCP capability needs its own MCP server. A managed endpoint is not application-code hosting."
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "mg-cards",
						children: [/* @__PURE__ */ (0, A.jsxs)("article", { children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "pill quiet",
								children: "PATTERN A · DEFAULT"
							}),
							/* @__PURE__ */ (0, A.jsx)("h4", { children: "Apigee-managed MCP endpoint" }),
							/* @__PURE__ */ (0, A.jsx)("p", { children: "An existing approved API is exposed as an MCP tool by Apigee. Path: agent, applicable gateway, Apigee endpoint, SAP Integration Suite, SAP backend. No separate MCP application server." })
						] }), /* @__PURE__ */ (0, A.jsxs)("article", { children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "pill warn",
								children: "PATTERN B · ONLY IF LOGIC NEEDS CODE"
							}),
							/* @__PURE__ */ (0, A.jsx)("h4", { children: "Custom MCP server behind Apigee" }),
							/* @__PURE__ */ (0, A.jsx)("p", { children: "Independently deployed business logic on the scenario host, exposed or proxied by Apigee. The diagram shows both the Apigee endpoint and the separate code runtime." })
						] })]
					}),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "mg-scroll",
						children: /* @__PURE__ */ (0, A.jsxs)("table", {
							className: "mg-table",
							children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsx)("th", {
								scope: "col",
								children: "Item"
							}), R.map((e) => /* @__PURE__ */ (0, A.jsx)("th", {
								scope: "col",
								className: k.includes(e) ? "sel" : "",
								children: z[e].label
							}, e))] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: [
								["Endpoint type", "mcp_endpoint_type"],
								["Gateway", "mcp_gateway"],
								["Custom MCP code runs on", "custom_mcp_runtime"],
								["Hosting owner", "custom_mcp_hosting_owner"],
								["Tool executes", "mcp_tool_execution_location"],
								["Tool discovery", "mcp_tool_discovery"]
							].map(([e, t]) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsx)("th", {
								scope: "row",
								children: e
							}), R.map((e) => /* @__PURE__ */ (0, A.jsx)("td", {
								className: `${k.includes(e) ? "sel" : ""} ${Wt(z[e][t]) ? "mg-open" : ""}`,
								children: z[e][t]
							}, e))] }, t)) })]
						})
					}),
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "micro",
						children: "In S2 a custom MCP on AgentCore Runtime that Apigee proxies is a conditional cross-cloud path; the extra network hop is drawn, not hidden. Registration of the endpoint is on the Registry page."
					})
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)(Kt, {
				id: "mg-domain",
				testid: "mg-domain",
				title: /* @__PURE__ */ (0, A.jsx)(A.Fragment, { children: "Finance domain MCP design" }),
				hint: H["mg-domain"],
				open: !!s["mg-domain"],
				onToggle: l,
				children: [
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "micro",
						children: "Read and write use separate authorizations. This application is read and tally only; no posting capability is active."
					}),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "mg-cards",
						children: ct.map((e) => /* @__PURE__ */ (0, A.jsxs)("article", { children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: `pill ${e.mode.startsWith("WRITE") ? "warn" : "quiet"}`,
								children: e.mode
							}),
							/* @__PURE__ */ (0, A.jsx)("h4", { children: e.name }),
							/* @__PURE__ */ (0, A.jsx)("p", { children: e.tools }),
							/* @__PURE__ */ (0, A.jsxs)("p", { children: [
								/* @__PURE__ */ (0, A.jsx)("strong", { children: "Control" }),
								" ",
								e.control
							] })
						] }, e.name))
					}),
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "micro",
						children: "Five authorizations stay distinct: business approval, agent authorization, gateway authorization, SAP backend user authorization and the actual SAP result. The SAP backend remains the business authority."
					})
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)(Kt, {
				id: "mg-recommendation",
				testid: "mg-recommendation",
				title: /* @__PURE__ */ (0, A.jsx)(A.Fragment, { children: "Recommendation and proof plan" }),
				hint: H["mg-recommendation"],
				open: !!s["mg-recommendation"],
				onToggle: l,
				children: [
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "mg-reco",
						children: /* @__PURE__ */ (0, A.jsx)("strong", { children: lt.headline })
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "mg-cards",
						children: [
							/* @__PURE__ */ (0, A.jsxs)("article", { children: [/* @__PURE__ */ (0, A.jsx)("h4", { children: "Why" }), /* @__PURE__ */ (0, A.jsx)("ul", { children: lt.why.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })] }),
							/* @__PURE__ */ (0, A.jsxs)("article", { children: [/* @__PURE__ */ (0, A.jsx)("h4", { children: "Depends on" }), /* @__PURE__ */ (0, A.jsx)("ul", { children: lt.standards.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })] }),
							/* @__PURE__ */ (0, A.jsxs)("article", { children: [/* @__PURE__ */ (0, A.jsx)("h4", { children: "Open decisions" }), /* @__PURE__ */ (0, A.jsx)("ul", { children: lt.open.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })] }),
							/* @__PURE__ */ (0, A.jsxs)("article", { children: [/* @__PURE__ */ (0, A.jsx)("h4", { children: "What would change it" }), /* @__PURE__ */ (0, A.jsx)("ul", { children: lt.changes.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })] }),
							/* @__PURE__ */ (0, A.jsxs)("article", { children: [/* @__PURE__ */ (0, A.jsx)("h4", { children: "Proof of concept" }), /* @__PURE__ */ (0, A.jsx)("ul", { children: lt.poc.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })] })
						]
					}),
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "micro",
						children: "A recommendation is not production authorization."
					})
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)(Kt, {
				id: "mg-evidence",
				testid: "mg-evidence",
				title: /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: ["Source evidence · listed ", et] }),
				hint: H["mg-evidence"],
				open: !!s["mg-evidence"],
				onToggle: l,
				children: [/* @__PURE__ */ (0, A.jsx)("p", {
					className: "micro",
					children: dt
				}), /* @__PURE__ */ (0, A.jsx)("div", {
					className: "mg-scroll",
					children: /* @__PURE__ */ (0, A.jsxs)("table", {
						className: "mg-table wide",
						children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsx)("tr", { children: [
							"Platform",
							"Source",
							"Documented capability",
							"Architecture consequence",
							"Validation still required"
						].map((e) => /* @__PURE__ */ (0, A.jsx)("th", {
							scope: "col",
							children: e
						}, e)) }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: ut.map(([e, t, n, r, i, a]) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, A.jsx)("th", {
								scope: "row",
								children: e
							}),
							/* @__PURE__ */ (0, A.jsx)("td", { children: /* @__PURE__ */ (0, A.jsxs)("a", {
								href: n,
								target: "_blank",
								rel: "noreferrer",
								children: [t, " ↗"]
							}) }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: r }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: i }),
							/* @__PURE__ */ (0, A.jsx)(Gt, { text: a })
						] }, n)) })]
					})
				})]
			}),
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface mg-section",
				"aria-label": "Glossary",
				children: [/* @__PURE__ */ (0, A.jsxs)("details", { children: [/* @__PURE__ */ (0, A.jsx)("summary", { children: /* @__PURE__ */ (0, A.jsx)("strong", { children: "Glossary · terms used on this page" }) }), /* @__PURE__ */ (0, A.jsx)("dl", {
					className: "mg-glossary",
					children: it.map(([e, t]) => /* @__PURE__ */ (0, A.jsxs)(_.Fragment, { children: [/* @__PURE__ */ (0, A.jsx)("dt", { children: e }), /* @__PURE__ */ (0, A.jsx)("dd", { children: t })] }, e))
				})] }), /* @__PURE__ */ (0, A.jsxs)("p", {
					className: "micro",
					children: [
						"Legend: ",
						mt.map(([, e]) => e).join(" · "),
						"."
					]
				})]
			})
		]
	});
}
// src/HostingPriority.jsx
var Jt = [{
	id: "cf",
	name: "SAP BTP Cloud Foundry",
	scenarios: ["S1", "S3"],
	diagrams: {
		S1: "D2",
		S3: "D4"
	},
	priority: "S1 and S3 · SAP owns execution",
	why: [
		"The agent, its MCP client and any custom MCP code run in the SAP BTP landscape, next to Integration Suite and the SAP backend.",
		"The agent calls Apigee directly: one gateway hop and one identity mapping to prove.",
		"Registration is independent: S1 has no registry product yet, S3 registers metadata in AWS Agent Registry without moving anything to AWS."
	],
	prove: [
		"Cloud Foundry space, entitlement and quota (the SAP documentation page could not be read, so this is NOT_VERIFIED)",
		"Workload identity for the agent and its token to Apigee",
		"Outbound path from Cloud Foundry to Apigee and to Portkey"
	]
}, {
	id: "agentcore",
	name: "AWS AgentCore Runtime",
	scenarios: ["S2"],
	diagrams: { S2: "D3" },
	priority: "S2 · AWS owns execution",
	why: [
		"The agent and any custom MCP code run on AgentCore Runtime; AgentCore Gateway is the enterprise entry for tool calls and Apigee stays the SAP-facing gateway behind it.",
		"AgentCore Runtime, Gateway and Agent Registry are three separate capabilities, each with its own configuration and owner.",
		"A custom MCP on AgentCore Runtime that Apigee proxies is a cross-cloud path and is conditional."
	],
	prove: [
		"AgentCore availability and region in the tenant",
		"Gateway to Apigee protocol, token exchange and target type",
		"Duplicated policy at two gateways and who owns it"
	]
}], Yt = [
	["Agent hosting and execution", "agent_runtime"],
	["Operated by", "agent_hosting_owner"],
	["Execution endpoint", "agent_execution_endpoint"],
	["UI hosting", "ui_hosting"],
	["MCP client", "mcp_client"],
	["Custom MCP code (if required)", "custom_mcp_runtime"],
	["LLM path", "llm_boundary"],
	["Identity", "identity_boundary"],
	["Persistence", "persistence"],
	["Monitoring and audit", "monitoring_audit"]
];
function Xt({ onMcp: e, onComplete: t, onRegistry: n }) {
	let [r, i] = (0, _.useState)("cf"), [a, o] = (0, _.useState)(null), [s, c] = (0, _.useState)("S3"), l = Jt.find((e) => e.id === r), u = l.scenarios.includes(s) ? s : l.scenarios[0], d = z[u];
	return /* @__PURE__ */ (0, A.jsxs)("main", {
		className: "mcp-comparison mcp-bird arch-page hosting-page",
		"aria-label": "Agent hosting",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("header", {
				className: "surface mcp-bird-header",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("h2", { children: "Agent hosting" }), /* @__PURE__ */ (0, A.jsx)("span", {
					className: "eyebrow",
					children: "WHERE THE FINANCE AGENT RUNS AND EXECUTES · REGISTRATION IS A SEPARATE DECISION"
				})] }), /* @__PURE__ */ (0, A.jsx)("span", {
					className: "pill warn",
					children: nt.split(" · ")[0]
				})]
			}),
			/* @__PURE__ */ (0, A.jsx)("nav", {
				className: "surface mcp-route-tabs mcp-bird-tabs",
				role: "tablist",
				"aria-label": "Agent hosting options",
				children: Jt.map((e) => /* @__PURE__ */ (0, A.jsxs)("button", {
					type: "button",
					role: "tab",
					"aria-selected": r === e.id,
					className: r === e.id ? "active" : "",
					onClick: () => {
						i(e.id), c(e.scenarios[e.scenarios.length - 1]);
					},
					children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: e.name }), /* @__PURE__ */ (0, A.jsx)("span", { children: e.priority })]
				}, e.id))
			}),
			/* @__PURE__ */ (0, A.jsx)(Vt, {
				focus: l.scenarios,
				title: "Hosting next to the other decisions",
				rows: [
					[
						"Agent hosting and execution",
						"agent_runtime",
						"Where it runs"
					],
					[
						"Agent registration and discovery",
						"agent_registry",
						"Not decided by hosting"
					],
					[
						"MCP implementation hosting",
						"custom_mcp_runtime",
						"Where custom code runs"
					],
					[
						"LLM gateway",
						"llm_gateway",
						"Same everywhere"
					]
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface mcp-bird-panel arch-panel",
				role: "tabpanel",
				"aria-label": `${l.name} overview`,
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "mcp-bird-panel-title",
						children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
							className: "eyebrow",
							children: l.priority
						}), /* @__PURE__ */ (0, A.jsx)("h3", { children: l.name })] }), /* @__PURE__ */ (0, A.jsx)("div", {
							className: "mcp-bird-title-actions",
							children: l.scenarios.map((e) => /* @__PURE__ */ (0, A.jsxs)("button", {
								type: "button",
								className: "diagram-action",
								onClick: () => o(l.diagrams[e]),
								children: [e, " diagram ↗"]
							}, e))
						})]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "mcp-bird-path arch-path",
						"aria-label": "Where the agent sits",
						children: [
							/* @__PURE__ */ (0, A.jsx)("b", { children: "SAP Fiori / existing UI" }),
							/* @__PURE__ */ (0, A.jsx)("span", {
								"aria-hidden": "true",
								children: "→"
							}),
							/* @__PURE__ */ (0, A.jsxs)("b", { children: ["Agent · ", l.name] }),
							/* @__PURE__ */ (0, A.jsx)("span", {
								"aria-hidden": "true",
								children: "→"
							}),
							/* @__PURE__ */ (0, A.jsx)("b", { children: "Portkey → approved LLM" }),
							/* @__PURE__ */ (0, A.jsx)("span", {
								"aria-hidden": "true",
								children: "→"
							}),
							/* @__PURE__ */ (0, A.jsx)("b", { children: u === "S2" ? "AgentCore Gateway → Apigee" : "Apigee MCP/API" })
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "arch-grid",
						children: [
							/* @__PURE__ */ (0, A.jsxs)("section", {
								"aria-label": "Scenario details",
								children: [
									/* @__PURE__ */ (0, A.jsx)("h4", { children: "Scenario" }),
									l.scenarios.length > 1 && /* @__PURE__ */ (0, A.jsx)("div", {
										className: "dd-selector",
										role: "tablist",
										"aria-label": "Scenario using this host",
										children: l.scenarios.map((e) => /* @__PURE__ */ (0, A.jsx)("button", {
											type: "button",
											role: "tab",
											"aria-selected": u === e,
											className: u === e ? "active" : "",
											onClick: () => c(e),
											children: e
										}, e))
									}),
									/* @__PURE__ */ (0, A.jsxs)("p", { children: [
										/* @__PURE__ */ (0, A.jsxs)("strong", { children: [d.name, "."] }),
										" ",
										d.objective
									] }),
									/* @__PURE__ */ (0, A.jsx)("h4", { children: "Why this host" }),
									/* @__PURE__ */ (0, A.jsx)("ul", { children: l.why.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })
								]
							}),
							/* @__PURE__ */ (0, A.jsxs)("section", {
								"aria-label": "What runs where",
								children: [/* @__PURE__ */ (0, A.jsxs)("h4", { children: ["What runs where in ", u] }), /* @__PURE__ */ (0, A.jsx)("div", {
									className: "arch-cards one",
									children: Yt.map(([e, t]) => /* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: e }), /* @__PURE__ */ (0, A.jsx)("b", { children: d[t] })] }, t))
								})]
							}),
							/* @__PURE__ */ (0, A.jsxs)("section", {
								"aria-label": "To prove",
								className: "arch-judgment",
								children: [
									/* @__PURE__ */ (0, A.jsx)("h4", { children: "Still to prove" }),
									/* @__PURE__ */ (0, A.jsx)("ul", { children: l.prove.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) }),
									/* @__PURE__ */ (0, A.jsx)("h4", { children: "Not verified" }),
									/* @__PURE__ */ (0, A.jsx)("ul", { children: d.unverified.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })
								]
							})
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "arch-links",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Also:" }),
							n && /* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								className: "text-link",
								onClick: n,
								children: "Registry →"
							}),
							e && /* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								className: "text-link",
								onClick: e,
								children: "MCP hosting →"
							}),
							t && /* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								className: "text-link",
								onClick: t,
								children: "Complete architecture →"
							})
						]
					})
				]
			}),
			a && /* @__PURE__ */ (0, A.jsx)(Ft, {
				diagramKey: a,
				onClose: () => o(null)
			})
		]
	});
}
// src/RegistryView.jsx
var Zt = [
	["Agent registry", "agent_registry"],
	["MCP registry", "mcp_registry"],
	["Publisher and approval owner", "registry_publisher_approver"],
	["Synchronization", "registry_sync"],
	["Agent discovery", "agent_discovery"],
	["MCP tool discovery", "mcp_tool_discovery"],
	["Identity of the registry caller", "identity_boundary"],
	["Audit of publication", "monitoring_audit"]
], Qt = {
	S1: [
		"No registry product is selected. The application shows this as a gap and does not substitute one.",
		"An ordinary API catalog is not a complete agent registry: agents, MCP servers, versions, approval and revocation all need an owner.",
		"Until a product is chosen, discovery of the agent and its MCP endpoint is a manual or domain-run process."
	],
	S2: [
		"AWS Agent Registry is a separate service from AgentCore Runtime and AgentCore Gateway. It catalogues what they host but is not on the call path.",
		"Agent and MCP descriptors are submitted, approved by a curator, then discoverable. Use the agent-registry namespace.",
		"Gateway tool discovery (tools/list) is separate from registry discovery of the MCP server record."
	],
	S3: [
		"The agent runs on SAP BTP Cloud Foundry and the MCP endpoint is Apigee; only their metadata lives in AWS Agent Registry.",
		"Synchronization connects from AWS to the endpoint URL with an outbound credential from a provider in the same account. That is control-plane traffic, never an execution hop.",
		"If AI Foundry mandates AgentCore Gateway for every tool call, that is variant S3-B, not this baseline."
	]
}, $t = ["D5", "D8"], en = (e) => /pending|TBD|unresolved|not defined/i.test(e);
function tn({ onMcp: e, onAgentHosting: t, onDiagrams: n }) {
	let [r, i] = (0, _.useState)("S3"), [a, o] = (0, _.useState)("D5"), [s, c] = (0, _.useState)(null), [l, u] = (0, _.useState)(!1), d = r === "compare", f = d ? null : r, p = (0, _.useMemo)(() => {
		let e = ht(a);
		return {
			id: a,
			title: e.title,
			svg: gt(a),
			file: `architecture-${a.toLowerCase()}`,
			png: !0
		};
	}, [a]), m = at.filter((e) => [
		"Agent registry",
		"MCP registry",
		"Enterprise governance alignment"
	].includes(e[0]));
	return /* @__PURE__ */ (0, A.jsxs)("main", {
		className: "detailed-diagrams mcp-governance arch-page registry-page",
		"aria-label": "Registry",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("header", {
				className: "surface dd-header",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "dd-title",
						children: [/* @__PURE__ */ (0, A.jsx)("span", {
							className: "eyebrow",
							children: "AGENT AND MCP REGISTRATION · CONTROL PLANE, NEVER AN EXECUTION HOP"
						}), /* @__PURE__ */ (0, A.jsx)("h2", { children: d ? "Registry compared" : z[f].name })]
					}),
					/* @__PURE__ */ (0, A.jsx)("nav", {
						className: "dd-selector",
						role: "tablist",
						"aria-label": "Registry scenario selection",
						children: [...R, "compare"].map((e) => /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": r === e,
							className: r === e ? "active" : "",
							onClick: () => i(e),
							children: e === "compare" ? "Compare all" : z[e].name
						}, e))
					}),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "dd-header-actions",
						children: /* @__PURE__ */ (0, A.jsx)("span", {
							className: "pill warn",
							children: nt.split(" · ").slice(0, 2).join(" · ")
						})
					})
				]
			}),
			/* @__PURE__ */ (0, A.jsx)(Vt, {
				focus: d ? R : [f],
				title: "Registration next to hosting",
				rows: [
					[
						"Agent hosting and execution",
						"agent_runtime",
						"Where it runs"
					],
					[
						"Agent registration and discovery",
						"agent_registry",
						"Where it is catalogued"
					],
					[
						"MCP implementation hosting",
						"custom_mcp_runtime",
						"Where custom code runs"
					],
					[
						"MCP registration and discovery",
						"mcp_registry",
						"Where it is catalogued"
					]
				]
			}),
			d ? /* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface mg-section",
				"data-testid": "registry-compare",
				children: [/* @__PURE__ */ (0, A.jsx)("h3", { children: "Registry comparison" }), /* @__PURE__ */ (0, A.jsx)("div", {
					className: "mg-scroll",
					children: /* @__PURE__ */ (0, A.jsxs)("table", {
						className: "mg-table",
						children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsx)("th", {
							scope: "col",
							children: "Item"
						}), R.map((e) => /* @__PURE__ */ (0, A.jsx)("th", {
							scope: "col",
							children: z[e].name
						}, e))] }) }), /* @__PURE__ */ (0, A.jsxs)("tbody", { children: [Zt.slice(0, 6).map(([e, t]) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsx)("th", {
							scope: "row",
							children: e
						}), R.map((e) => /* @__PURE__ */ (0, A.jsx)("td", {
							className: en(z[e][t]) ? "mg-open" : "",
							children: z[e][t]
						}, e))] }, t)), m.map(([e, ...t]) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsx)("th", {
							scope: "row",
							children: e
						}), t.map((e, t) => /* @__PURE__ */ (0, A.jsx)("td", {
							className: en(e) ? "mg-open" : "",
							children: e
						}, R[t]))] }, e))] })]
					})
				})]
			}) : /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "mg-cards registry-cards",
				children: [/* @__PURE__ */ (0, A.jsxs)("section", {
					className: "surface mg-section",
					"data-testid": "registry-facts",
					children: [/* @__PURE__ */ (0, A.jsxs)("h3", { children: ["How registration works in ", f] }), /* @__PURE__ */ (0, A.jsx)("table", {
						className: "mg-table",
						children: /* @__PURE__ */ (0, A.jsx)("tbody", { children: Zt.map(([e, t]) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [/* @__PURE__ */ (0, A.jsx)("th", {
							scope: "row",
							children: e
						}), /* @__PURE__ */ (0, A.jsx)("td", {
							className: en(z[f][t]) ? "mg-open" : "",
							children: z[f][t]
						})] }, t)) })
					})]
				}), /* @__PURE__ */ (0, A.jsxs)("section", {
					className: "surface mg-section",
					"data-testid": "registry-notes",
					children: [
						/* @__PURE__ */ (0, A.jsx)("h3", { children: "What to know" }),
						/* @__PURE__ */ (0, A.jsx)("ul", { children: Qt[f].map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) }),
						/* @__PURE__ */ (0, A.jsx)("h3", { children: "Not yet verified" }),
						/* @__PURE__ */ (0, A.jsx)("ul", { children: z[f].unverified.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) }),
						f === "S1" && /* @__PURE__ */ (0, A.jsxs)("p", {
							className: "micro",
							children: [/* @__PURE__ */ (0, A.jsxs)("strong", { children: [ft, "."] }), " Select a product before this scenario can be compared fairly."]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface mg-section",
				"aria-label": "Registry diagrams",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "dd-compare-bar",
						children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "Diagram" }), $t.map((e) => /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							className: a === e ? "active" : "",
							"aria-pressed": a === e,
							onClick: () => {
								o(e), c(null);
							},
							children: e === "D5" ? "D5 · Hosting versus registration" : "D8 · Registry lifecycle"
						}, e))]
					}),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "mg-viewers",
						children: /* @__PURE__ */ (0, A.jsx)("div", {
							className: "mg-viewer",
							children: /* @__PURE__ */ (0, A.jsx)(V, {
								diagram: p,
								uid: `reg-${a}`,
								view: s,
								onView: c,
								onFit: c,
								expanded: l,
								onExpand: u
							})
						})
					}),
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "micro",
						children: "Publication is not proof of reachability, runtime authorization or SAP execution. Revoked or stale records must disappear from discovery."
					})
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("nav", {
				className: "mg-anchors",
				"aria-label": "Related views",
				children: [
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: e,
						children: "MCP hosting →"
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: t,
						children: "Agent hosting →"
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: () => n && n("D8"),
						children: "All diagrams →"
					})
				]
			})
		]
	});
}
// src/roleData.js
var nn = [
	{
		id: "ea",
		name: "Enterprise architect",
		ask: "Is the target coherent, governable and decision-ready?",
		links: [
			["brief", "Decision brief"],
			["ontology", "Ontology"],
			["approaches", "Complete architecture"]
		]
	},
	{
		id: "ia",
		name: "Integration architect",
		ask: "Which interfaces, identities and hops does each route need?",
		links: [
			["mcp", "MCP hosting"],
			["ontology", "Ontology"],
			["diagrams", "Detailed diagrams"]
		]
	},
	{
		id: "fin",
		name: "Finance",
		ask: "Can I trust the close result, and who approves what?",
		links: [
			["business", "Close & reconcile"],
			["treasury", "Cash & treasury"],
			["agents", "Ask the agents"]
		]
	},
	{
		id: "ba",
		name: "Business architect",
		ask: "What changes in the process, and where are the controls?",
		links: [
			["business", "Who does what"],
			["agents", "Agent roles"],
			["brief", "Decision brief"]
		]
	}
], rn = [
	[
		"Collect source balances",
		"System",
		"Simulated S/4HANA, Central Finance and BW snapshots"
	],
	[
		"Compare and compute variance",
		"Agent · read only",
		"Reconciliation agent, deterministic rules"
	],
	[
		"Explain the variance",
		"Agent · read only",
		"Investigator agent; advisory, never a posting"
	],
	[
		"Draft an adjustment proposal",
		"Agent · local draft",
		"Proposal agent writes a draft only, never to SAP"
	],
	[
		"Approve",
		"Person",
		"Finance approver, a different role from the maker"
	],
	[
		"Post to SAP",
		"Outside this demo",
		"Human-approved path; only a nonproduction marker is simulated"
	]
], an = [
	"Maker and approver are separate roles",
	"Approval is bound to the proposal hash and case version",
	"Every step is stored as an event you can inspect",
	"No agent tool can post to SAP"
], on = [
	[
		"Scenario to validate first",
		"S3 (SAP-hosted hybrid) as the preferred candidate for the POC, subject to AI Foundry policy",
		"Enterprise architecture + AI Foundry + SAP integration"
	],
	[
		"Agent runtime host",
		"SAP BTP Cloud Foundry in S1 and S3; AWS AgentCore Runtime in S2. Registration is decided separately",
		"Enterprise AI + platform team"
	],
	[
		"Identity: user delegation or service identity",
		"Prove service identity first, then delegation",
		"Security + SAP Basis"
	],
	[
		"Registry",
		"AWS Agent Registry in S2 and S3; S1 registry product is unresolved (domain-managed catalog)",
		"Enterprise AI Foundry"
	],
	[
		"Is AgentCore Gateway mandatory for every tool call?",
		"Not in the S3 baseline; if mandated, evaluate S3-B or S2",
		"AI Foundry + Security"
	],
	[
		"Is persistence needed?",
		"Conditional: HANA Cloud only if durable SAP-side state is required",
		"SAP BTP + finance engineering"
	],
	[
		"Model access (Portkey)",
		"Portkey is the LLM gateway in every scenario; model and credential approval is separate and does not decide the host",
		"Enterprise AI"
	],
	[
		"Posting to SAP",
		"Out of scope. Human approval and nonproduction evidence first",
		"Finance + SAP"
	],
	[
		"12-month total cost",
		"Unmeasured; needs an estimate per route",
		"Finance + procurement"
	]
], sn = [
	[
		"G1",
		"Scenario, owners, licensing, cost and network topology",
		"OPEN"
	],
	[
		"G2",
		"Gateway inbound authorization, target type and outbound credential proof",
		"OPEN"
	],
	[
		"G3",
		"Integration Suite identity mapping and SAP authorization at all backends",
		"OPEN · P0"
	],
	[
		"G4",
		"Finance rules, source contracts, freshness and reconciliation vectors",
		"OPEN"
	],
	[
		"G5",
		"Human approval tests and nonproduction SAP document evidence",
		"OPEN · P0"
	],
	[
		"G6",
		"Privacy, Unity Catalog grants, BDC sharing and Portkey retention",
		"OPEN"
	],
	[
		"G7",
		"Cross-system trace correlation, retention and incident ownership",
		"OPEN"
	]
], cn = [
	"The workflow shape: ask, plan, specialist calls, evidence, proposal, approval",
	"What each agent may and may not do, shown as read-only tools and refusals",
	"Where each route puts the gateway, the identity hop and the owner"
], ln = [
	"Any live SAP, AWS, Apigee, Portkey or Databricks connection",
	"A real MCP transport (calls are in-process and MCP-shaped)",
	"Identity propagation, performance, availability or cost"
], un = {
	change: ["What would change the recommendation", lt.changes],
	poc: ["How a proof of concept settles it", lt.poc],
	depends: ["What the recommendation depends on", lt.standards],
	limits: ["What this demo proves, and what it does not", null]
};
function dn({ onComplete: e, onMcp: t, onAgentHosting: n }) {
	let [r, i] = (0, _.useState)(null);
	(0, _.useEffect)(() => {
		if (!r) return;
		let e = (e) => {
			e.key === "Escape" && i(null);
		};
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}, [r]);
	let a = lt.headline.replace(/^ARCHITECTURE_RECOMMENDED \(proposal for owner decision, not approval\): /, "");
	return /* @__PURE__ */ (0, A.jsxs)("main", {
		className: "mcp-comparison mcp-bird arch-page brief-page",
		"aria-label": "Decision brief",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("header", {
				className: "surface mcp-bird-header",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("h2", { children: "Decision brief" }), /* @__PURE__ */ (0, A.jsx)("span", {
					className: "eyebrow",
					children: "WHAT NEEDS DECIDING, WHO OWNS IT, WHAT IS STILL OPEN"
				})] }), /* @__PURE__ */ (0, A.jsx)("span", {
					className: "pill warn",
					children: "PROPOSAL FOR OWNER DECISION · NOT AN APPROVAL"
				})]
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "brief-grid",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("section", {
						className: "surface brief-card",
						"aria-label": "Recommendation",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "eyebrow",
								children: "PROPOSED BASELINE"
							}),
							/* @__PURE__ */ (0, A.jsx)("h3", { children: a.charAt(0).toUpperCase() + a.slice(1) }),
							/* @__PURE__ */ (0, A.jsx)("ul", { children: lt.why.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) }),
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: "brief-links",
								children: [
									/* @__PURE__ */ (0, A.jsx)("button", {
										type: "button",
										onClick: () => i("change"),
										children: "What would change it"
									}),
									/* @__PURE__ */ (0, A.jsx)("button", {
										type: "button",
										onClick: () => i("poc"),
										children: "Proof plan"
									}),
									/* @__PURE__ */ (0, A.jsx)("button", {
										type: "button",
										onClick: () => i("depends"),
										children: "Depends on"
									}),
									/* @__PURE__ */ (0, A.jsx)("button", {
										type: "button",
										onClick: () => i("limits"),
										children: "Proves / does not prove"
									})
								]
							}),
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: "brief-links alt",
								children: [
									/* @__PURE__ */ (0, A.jsx)("button", {
										type: "button",
										onClick: e,
										children: "Complete architecture →"
									}),
									/* @__PURE__ */ (0, A.jsx)("button", {
										type: "button",
										onClick: t,
										children: "MCP hosting →"
									}),
									/* @__PURE__ */ (0, A.jsx)("button", {
										type: "button",
										onClick: n,
										children: "Agent hosting →"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("section", {
						className: "surface brief-card",
						"aria-label": "Decisions needed",
						children: [/* @__PURE__ */ (0, A.jsxs)("span", {
							className: "eyebrow",
							children: ["DECISIONS NEEDED · ", on.length]
						}), /* @__PURE__ */ (0, A.jsxs)("table", {
							className: "brief-table",
							children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, A.jsx)("th", {
									scope: "col",
									children: "Decision"
								}),
								/* @__PURE__ */ (0, A.jsx)("th", {
									scope: "col",
									children: "Proposal"
								}),
								/* @__PURE__ */ (0, A.jsx)("th", {
									scope: "col",
									children: "Owner"
								}),
								/* @__PURE__ */ (0, A.jsx)("th", {
									scope: "col",
									children: "Status"
								})
							] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: on.map(([e, t, n]) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, A.jsx)("th", {
									scope: "row",
									children: e
								}),
								/* @__PURE__ */ (0, A.jsx)("td", { children: t }),
								/* @__PURE__ */ (0, A.jsx)("td", { children: n }),
								/* @__PURE__ */ (0, A.jsx)("td", { children: /* @__PURE__ */ (0, A.jsx)("span", {
									className: "brief-open",
									children: "OPEN"
								}) })
							] }, e)) })]
						})]
					}),
					/* @__PURE__ */ (0, A.jsxs)("section", {
						className: "surface brief-card",
						"aria-label": "Proof gates",
						children: [/* @__PURE__ */ (0, A.jsx)("span", {
							className: "eyebrow",
							children: "PROOF GATES · NONE PASSED"
						}), /* @__PURE__ */ (0, A.jsx)("ul", {
							className: "brief-gates",
							children: sn.map(([e, t, n]) => /* @__PURE__ */ (0, A.jsxs)("li", { children: [
								/* @__PURE__ */ (0, A.jsx)("b", { children: e }),
								/* @__PURE__ */ (0, A.jsx)("span", { children: t }),
								/* @__PURE__ */ (0, A.jsx)("em", {
									className: n.includes("P0") ? "p0" : "",
									children: n
								})
							] }, e))
						})]
					})
				]
			}),
			r && /* @__PURE__ */ (0, A.jsx)("div", {
				className: "mcp-bird-modal-backdrop",
				onMouseDown: (e) => {
					e.target === e.currentTarget && i(null);
				},
				children: /* @__PURE__ */ (0, A.jsxs)("section", {
					className: "surface mcp-bird-modal",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": un[r][0],
					children: [/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "mcp-bird-modal-header",
						children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
							className: "eyebrow",
							children: "DECISION BRIEF · DESIGN REVIEW ONLY"
						}), /* @__PURE__ */ (0, A.jsx)("h3", { children: un[r][0] })] }), /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							onClick: () => i(null),
							autoFocus: !0,
							children: "Close"
						})]
					}), /* @__PURE__ */ (0, A.jsx)("div", {
						className: "mcp-bird-modal-body",
						children: r === "limits" ? /* @__PURE__ */ (0, A.jsxs)("div", {
							className: "mcp-bird-modal-owners",
							children: [/* @__PURE__ */ (0, A.jsxs)("article", { children: [/* @__PURE__ */ (0, A.jsx)("h4", { children: "This demo shows" }), /* @__PURE__ */ (0, A.jsx)("ul", { children: cn.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })] }), /* @__PURE__ */ (0, A.jsxs)("article", { children: [/* @__PURE__ */ (0, A.jsx)("h4", { children: "This demo does not prove" }), /* @__PURE__ */ (0, A.jsx)("ul", { children: ln.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })] })]
						}) : /* @__PURE__ */ (0, A.jsx)("ul", { children: un[r][1].map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })
					})]
				})
			})
		]
	});
}
// src/ReconciliationReport.jsx
var fn = (e) => new Intl.NumberFormat("en-US", {
	style: "currency",
	currency: "USD",
	maximumFractionDigits: 0
}).format(Number(e || 0)), pn = (e) => `${Number(e) > 0 ? "+" : Number(e) < 0 ? "−" : ""}${fn(Math.abs(Number(e || 0)))}`, mn = [
	["summary", "Summary"],
	["accounts", "Accounts"],
	["matching", "Matching details"],
	["items", "Reconciling items"],
	["aging", "Aging"],
	["controls", "Controls"],
	["posting", "SAP posting guide"],
	["ai", "AI review"],
	["audit", "Audit trail"]
], hn = {
	BALANCED: "Balanced",
	WITHIN_TOLERANCE: "Within tolerance",
	EXPLAINED: "Explained · approval needed",
	EXCEPTION: "Exception · investigate",
	HOLD: "On hold · sources stale"
}, gn = {
	BALANCED: "ok",
	WITHIN_TOLERANCE: "ok",
	EXPLAINED: "info",
	EXCEPTION: "bad",
	HOLD: "warn"
};
function _n(e, t, n) {
	let r = URL.createObjectURL(new Blob([n], { type: t })), i = document.createElement("a");
	i.href = r, i.download = e, document.body.appendChild(i), i.click(), i.remove(), setTimeout(() => URL.revokeObjectURL(r), 1e3);
}
var vn = (e) => `"${String(e ?? "").replace(/"/g, "\"\"")}"`;
function yn(e) {
	let t = [
		"item_id",
		"document_id",
		"document_type",
		"account",
		"account_name",
		"posting_date",
		"age_days",
		"s4_amount",
		"cfin_amount",
		"difference",
		"materiality",
		"category",
		"reason_code",
		"status",
		"owner",
		"recommended_action",
		"ai_confidence"
	];
	return [t.join(","), ...e.items.map((e) => t.map((t) => vn(t === "ai_confidence" ? e.ai.confidence : e[t])).join(","))].join("\r\n");
}
function bn({ bridge: e }) {
	let t = e[0].value, n = e[e.length - 1].value, r = Math.min(t, n) * .985, i = Math.max(t, n) * 1.005, a = 640 / e.length, o = (e) => 24 + 142 * (1 - (e - r) / Math.max(1, i - r)), s = t;
	return /* @__PURE__ */ (0, A.jsx)("svg", {
		className: "rr-bridge",
		viewBox: "0 0 640 210",
		role: "img",
		"aria-label": "Variance bridge from the S/4HANA balance to the Central Finance balance",
		children: e.map((e, t) => {
			let n = t * a + a * .2, i = a * .6, c, l, u;
			e.kind === "total" ? (c = r, l = e.value, u = "#0a6ed1") : (c = s, l = s + e.value, s = l, u = e.value < 0 ? "#bb0000" : "#107e3e");
			let d = o(Math.max(c, l)), f = Math.max(3, Math.abs(o(c) - o(l)));
			return /* @__PURE__ */ (0, A.jsxs)("g", { children: [
				/* @__PURE__ */ (0, A.jsx)("rect", {
					x: n,
					y: d,
					width: i,
					height: f,
					fill: u,
					rx: "2"
				}),
				/* @__PURE__ */ (0, A.jsx)("text", {
					x: n + i / 2,
					y: d - 6,
					textAnchor: "middle",
					fontSize: "11",
					fontWeight: "700",
					fill: "#1d2d3e",
					children: e.kind === "total" ? fn(e.value) : pn(e.value)
				}),
				/* @__PURE__ */ (0, A.jsx)("text", {
					x: n + i / 2,
					y: 188,
					textAnchor: "middle",
					fontSize: "10.5",
					fill: "#34495c",
					children: e.label.length > 20 ? e.label.slice(0, 19) + "…" : e.label
				})
			] }, e.label);
		})
	});
}
function xn({ status: e }) {
	return /* @__PURE__ */ (0, A.jsx)("span", {
		className: `rr-chip ${String(e).toLowerCase().replace("_", "-")}`,
		children: String(e).replace("_", " ")
	});
}
function Sn({ report: e }) {
	let t = e.summary;
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: `rr-banner ${gn[t.status]}`,
				children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: hn[t.status] }), /* @__PURE__ */ (0, A.jsx)("span", { children: t.status_text })]
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "rr-kpis",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "S/4HANA balance" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: fn(t.s4_total) })] }),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Central Finance balance" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: fn(t.cfin_total) })] }),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: t.variance ? "attn" : "",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Variance" }),
							/* @__PURE__ */ (0, A.jsx)("strong", { children: pn(t.variance) }),
							/* @__PURE__ */ (0, A.jsxs)("small", { children: ["Tolerance ", fn(t.tolerance)] })
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [
						/* @__PURE__ */ (0, A.jsx)("span", { children: "Explained" }),
						/* @__PURE__ */ (0, A.jsxs)("strong", { children: [t.explained_pct, "%"] }),
						/* @__PURE__ */ (0, A.jsxs)("small", { children: [
							fn(t.explained),
							" of ",
							fn(t.variance)
						] })
					] }),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: t.unexplained ? "attn" : "",
						children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Unexplained" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: fn(t.unexplained) })]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [
						/* @__PURE__ */ (0, A.jsx)("span", { children: "Open items" }),
						/* @__PURE__ */ (0, A.jsx)("strong", { children: t.open_items }),
						/* @__PURE__ */ (0, A.jsxs)("small", { children: [
							t.high_items,
							" high · ",
							t.matched_movements,
							" matched movements"
						] })
					] })
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "rr-grid2",
				children: [/* @__PURE__ */ (0, A.jsxs)("section", { children: [
					/* @__PURE__ */ (0, A.jsx)("h3", { children: "Variance bridge" }),
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "rr-note",
						children: "From the S/4HANA balance to the Central Finance balance, by reason."
					}),
					e.bridge.length > 2 ? /* @__PURE__ */ (0, A.jsx)(bn, { bridge: e.bridge }) : /* @__PURE__ */ (0, A.jsx)("p", {
						className: "rr-empty",
						children: "No reconciling items. The two balances agree."
					})
				] }), /* @__PURE__ */ (0, A.jsxs)("section", { children: [/* @__PURE__ */ (0, A.jsx)("h3", { children: "Close timeline · source checks" }), /* @__PURE__ */ (0, A.jsx)("ol", {
					className: "rr-timeline",
					children: e.timeline.map((e) => /* @__PURE__ */ (0, A.jsxs)("li", {
						className: e.freshness === "current" ? "ok" : "warn",
						children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: e.step }), /* @__PURE__ */ (0, A.jsxs)("span", { children: [
							fn(e.balance),
							" · ",
							e.freshness,
							" · ",
							e.timestamp_utc?.slice(11, 16),
							" UTC"
						] })]
					}, e.source))
				})] })]
			}),
			/* @__PURE__ */ (0, A.jsxs)("section", { children: [/* @__PURE__ */ (0, A.jsx)("h3", { children: "Next actions" }), e.actions.length ? /* @__PURE__ */ (0, A.jsxs)("table", {
				className: "rr-table",
				children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "#" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Item" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Owner" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Action" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Due" }),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Amount"
					})
				] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: e.actions.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.priority }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.item_id }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.owner }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.action }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.due }),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: pn(e.amount)
					})
				] }, e.item_id)) })]
			}) : /* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-empty",
				children: "No action needed for this period."
			})] }),
			/* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-note",
				children: e.sign_convention
			}),
			/* @__PURE__ */ (0, A.jsxs)("p", {
				className: "rr-note",
				children: [
					"Approval readiness: ",
					t.ready_for_approval ? "ready for a separate finance approval." : "not ready. Resolve the items above first.",
					" This report never posts to SAP."
				]
			})
		]
	});
}
function Cn({ report: e }) {
	let t = Math.max(1, ...e.accounts.map((e) => Math.abs(e.difference)));
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		children: [/* @__PURE__ */ (0, A.jsxs)("table", {
			className: "rr-table",
			children: [
				/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Account" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Name" }),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "S/4HANA"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Central Finance"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Difference"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Open items" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Status" })
				] }) }),
				/* @__PURE__ */ (0, A.jsx)("tbody", { children: e.accounts.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", {
					className: e.status === "variance" ? "hl" : "",
					children: [
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.account }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.name }),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: fn(e.s4_balance)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: fn(e.cfin_balance)
						}),
						/* @__PURE__ */ (0, A.jsxs)("td", {
							className: "num",
							children: [/* @__PURE__ */ (0, A.jsx)("span", {
								className: "rr-bar",
								style: { width: `${Math.abs(e.difference) / t * 60}px` },
								"aria-hidden": "true"
							}), pn(e.difference)]
						}),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.open_items }),
						/* @__PURE__ */ (0, A.jsxs)("td", { children: [
							/* @__PURE__ */ (0, A.jsx)(xn, { status: e.status === "variance" ? "EXCEPTION" : (e.status, "PASS") }),
							" ",
							e.status.replace("_", " ")
						] })
					]
				}, e.account)) }),
				/* @__PURE__ */ (0, A.jsx)("tfoot", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", {
						colSpan: "2",
						children: "Total"
					}),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: fn(e.summary.s4_total)
					}),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: fn(e.summary.cfin_total)
					}),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: pn(e.summary.variance)
					}),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.summary.open_items }),
					/* @__PURE__ */ (0, A.jsx)("td", {})
				] }) })
			]
		}), /* @__PURE__ */ (0, A.jsx)("p", {
			className: "rr-note",
			children: "S/4HANA lines come from the synthetic history. Central Finance lines are derived from the document-level differences so that every column adds up."
		})]
	});
}
var wn = [
	["all", "All rows"],
	["exceptions", "Exceptions only"],
	["MATCHED", "Matched"],
	["UNMATCHED_SOURCE", "Unmatched source"],
	["UNMATCHED_TARGET", "Unmatched target"],
	["AMOUNT_MISMATCH", "Amount mismatch"],
	["TIMING_DIFFERENCE", "Timing difference"],
	["DUPLICATE", "Duplicate"],
	["REQUIRES_REVIEW", "Requires review"]
];
function Tn({ report: e }) {
	let [t, n] = (0, _.useState)("all"), r = e.matching, i = r.totals, a = r.rows.filter((e) => t === "all" || (t === "exceptions" ? e.status !== "MATCHED" : e.status === t));
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "rr-match-totals",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Matched" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: i.matched_count })] }),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Exceptions" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: i.exception_count })] }),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Sum of row differences" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: pn(i.difference_total) })] }),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Summary variance" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: pn(i.summary_variance) })] }),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Check" }), /* @__PURE__ */ (0, A.jsx)("strong", {
						className: i.reconciles ? "rr-match-ok" : "rr-match-bad",
						"data-testid": "match-check",
						children: i.reconciles ? "Rows explain the variance" : "Rows do not explain the variance"
					})] })
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("label", {
				className: "rr-filter",
				children: ["Show ", /* @__PURE__ */ (0, A.jsx)("select", {
					value: t,
					onChange: (e) => n(e.target.value),
					"aria-label": "Matching status filter",
					children: wn.map(([e, t]) => /* @__PURE__ */ (0, A.jsx)("option", {
						value: e,
						children: t
					}, e))
				})]
			}),
			/* @__PURE__ */ (0, A.jsxs)("table", {
				className: "rr-table",
				"data-testid": "matching-table",
				children: [
					/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Matching key" }),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Source ref" }),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Target ref" }),
						/* @__PURE__ */ (0, A.jsx)("th", {
							className: "num",
							children: "Amount"
						}),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Cur." }),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Posting date" }),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Rule" }),
						/* @__PURE__ */ (0, A.jsx)("th", {
							className: "num",
							children: "Difference"
						}),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Status" }),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Exception reason" })
					] }) }),
					/* @__PURE__ */ (0, A.jsxs)("tbody", { children: [a.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", {
						className: e.status === "MATCHED" ? "" : "hl",
						children: [
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.matching_key }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.source_ref }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.target_ref || "none" }),
							/* @__PURE__ */ (0, A.jsx)("td", {
								className: "num",
								children: fn(e.amount)
							}),
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.currency }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.posting_date || "n/a" }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.rule }),
							/* @__PURE__ */ (0, A.jsx)("td", {
								className: "num",
								children: pn(e.difference)
							}),
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.status }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.reason || "none" })
						]
					}, e.matching_key)), !a.length && /* @__PURE__ */ (0, A.jsx)("tr", { children: /* @__PURE__ */ (0, A.jsx)("td", {
						colSpan: "10",
						children: "No rows with this status in this period."
					}) })] }),
					/* @__PURE__ */ (0, A.jsx)("tfoot", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, A.jsx)("th", {
							colSpan: "7",
							children: "Total of all rows"
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: pn(i.difference_total)
						}),
						/* @__PURE__ */ (0, A.jsxs)("td", {
							colSpan: "2",
							children: ["Summary variance ", pn(i.summary_variance)]
						})
					] }) })
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("p", {
				className: "rr-note",
				children: [
					i.scope_note,
					" ",
					e.sign_convention
				]
			})
		]
	});
}
var En = [
	["Post General Journal Entries (F0718), SAP Help", "https://help.sap.com/docs/SAP_S4HANA_ON-PREMISE/7340a09096454b7abf4379f926a21567/950f8054747b053de10000000a441470.html?version=2023.latest"],
	["Manage Journal Entries, SAP Help", "https://help.sap.com/docs/SAP_S4HANA_ON-PREMISE/3cb1182b4a184bdd93f8d62e3f1f0741/d2d78154f9a7033de10000000a441470.html?version=2023.latest"],
	["Verify General Journal Entries – For Requester, SAP Help", "https://help.sap.com/docs/SAP_S4HANA_ON-PREMISE/651d8af3ea974ad1a4d74449122c620e/6b33e9e760b840098d4c66f49121dc98.html"],
	["SAP Fiori Apps Reference Library", "https://fioriappslibrary.hana.ondemand.com/"]
], Dn = {
	no: "No journal entry",
	conditional: "Conditional",
	after_investigation: "Only after investigation"
};
function On({ report: e }) {
	let t = e.manual_posting;
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane rr-guide",
		"data-testid": "posting-guide",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "rr-banner warn",
				children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "Manual posting only" }), /* @__PURE__ */ (0, A.jsx)("span", { children: "This app never posts to SAP and shows no SAP document number. A person with SAP authorization posts, after approval." })]
			}),
			/* @__PURE__ */ (0, A.jsx)("h3", { children: "Which items need a journal entry?" }),
			e.items.length ? /* @__PURE__ */ (0, A.jsxs)("table", {
				className: "rr-table",
				children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Item" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Cause" }),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Difference"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Manual G/L entry" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Recommended route" })
				] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: e.items.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.item_id }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.category_label }),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: pn(e.difference)
					}),
					/* @__PURE__ */ (0, A.jsx)("td", { children: Dn[e.treatment.manual_journal_entry] }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.treatment.route })
				] }, e.item_id)) })]
			}) : /* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-empty",
				children: "No reconciling items for this period, so there is nothing to correct."
			}),
			/* @__PURE__ */ (0, A.jsx)("h3", { children: "SAP Fiori apps" }),
			/* @__PURE__ */ (0, A.jsx)("div", {
				className: "rr-apps",
				children: t.apps.map((e) => /* @__PURE__ */ (0, A.jsxs)("article", { children: [
					/* @__PURE__ */ (0, A.jsxs)("b", { children: [
						e.id,
						" · ",
						e.name
					] }),
					/* @__PURE__ */ (0, A.jsx)("p", { children: e.use }),
					/* @__PURE__ */ (0, A.jsx)("p", { children: /* @__PURE__ */ (0, A.jsx)("em", { children: e.note }) })
				] }, e.id))
			}),
			/* @__PURE__ */ (0, A.jsx)("h3", { children: "Manual workflow" }),
			/* @__PURE__ */ (0, A.jsx)("ol", { children: t.steps.map((e) => /* @__PURE__ */ (0, A.jsxs)("li", { children: [
				/* @__PURE__ */ (0, A.jsxs)("strong", { children: [e.title, "."] }),
				" ",
				e.text
			] }, e.title)) }),
			/* @__PURE__ */ (0, A.jsxs)("details", { children: [
				/* @__PURE__ */ (0, A.jsx)("summary", { children: "Fields the accountant reviews before posting" }),
				/* @__PURE__ */ (0, A.jsx)("ul", { children: t.fields.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) }),
				/* @__PURE__ */ (0, A.jsx)("p", {
					className: "rr-note",
					children: "No account, amount or posting rule is proposed here. Any example would be synthetic and is intentionally not shown."
				})
			] }),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "rr-not-done",
				children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "What this app did not do" }), /* @__PURE__ */ (0, A.jsx)("ul", { children: t.not_done.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })]
			}),
			/* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-note",
				children: t.verification
			}),
			/* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-note",
				children: En.map(([e, t], n) => /* @__PURE__ */ (0, A.jsxs)(_.Fragment, { children: [n > 0 && " · ", /* @__PURE__ */ (0, A.jsxs)("a", {
					href: t,
					target: "_blank",
					rel: "noreferrer",
					children: [e, " ↗"]
				})] }, t))
			})
		]
	});
}
function kn({ report: e }) {
	let [t, n] = (0, _.useState)("all"), [r, i] = (0, _.useState)("all"), [a, o] = (0, _.useState)(null), s = e.items.filter((e) => (t === "all" || e.status === t) && (r === "all" || e.materiality === r));
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "rr-filters",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("label", { children: ["Status", /* @__PURE__ */ (0, A.jsxs)("select", {
						value: t,
						onChange: (e) => n(e.target.value),
						children: [
							/* @__PURE__ */ (0, A.jsx)("option", {
								value: "all",
								children: "All"
							}),
							/* @__PURE__ */ (0, A.jsx)("option", {
								value: "needs_review",
								children: "Needs review"
							}),
							/* @__PURE__ */ (0, A.jsx)("option", {
								value: "explained",
								children: "Explained"
							})
						]
					})] }),
					/* @__PURE__ */ (0, A.jsxs)("label", { children: ["Materiality", /* @__PURE__ */ (0, A.jsxs)("select", {
						value: r,
						onChange: (e) => i(e.target.value),
						children: [
							/* @__PURE__ */ (0, A.jsx)("option", {
								value: "all",
								children: "All"
							}),
							/* @__PURE__ */ (0, A.jsx)("option", {
								value: "high",
								children: "High"
							}),
							/* @__PURE__ */ (0, A.jsx)("option", {
								value: "medium",
								children: "Medium"
							}),
							/* @__PURE__ */ (0, A.jsx)("option", {
								value: "low",
								children: "Low"
							})
						]
					})] }),
					/* @__PURE__ */ (0, A.jsxs)("span", { children: [
						s.length,
						" of ",
						e.items.length,
						" items"
					] })
				]
			}),
			e.items.length === 0 ? /* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-empty",
				children: "No reconciling items for this period."
			}) : /* @__PURE__ */ (0, A.jsxs)("table", {
				className: "rr-table",
				children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", {}),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Document" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Type" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Account" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Posted" }),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "S/4HANA"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Central Finance"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Difference"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Reason" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Status" })
				] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: s.map((e) => /* @__PURE__ */ (0, A.jsxs)(_.Fragment, { children: [/* @__PURE__ */ (0, A.jsxs)("tr", {
					className: a === e.item_id ? "hl" : "",
					children: [
						/* @__PURE__ */ (0, A.jsx)("td", { children: /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							className: "rr-expand",
							"aria-expanded": a === e.item_id,
							"aria-label": `Details for ${e.document_id}`,
							onClick: () => o(a === e.item_id ? null : e.item_id),
							children: a === e.item_id ? "▾" : "▸"
						}) }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.document_id }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.document_type }),
						/* @__PURE__ */ (0, A.jsxs)("td", { children: [
							e.account,
							" ",
							e.account_name
						] }),
						/* @__PURE__ */ (0, A.jsxs)("td", { children: [
							e.posting_date,
							" · ",
							e.age_days,
							"d"
						] }),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: fn(e.s4_amount)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: fn(e.cfin_amount)
						}),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: /* @__PURE__ */ (0, A.jsx)("strong", { children: pn(e.difference) })
						}),
						/* @__PURE__ */ (0, A.jsxs)("td", { children: [
							e.reason_code,
							" · ",
							e.category_label
						] }),
						/* @__PURE__ */ (0, A.jsxs)("td", { children: [
							/* @__PURE__ */ (0, A.jsx)(xn, { status: e.status === "explained" ? "PASS" : "HOLD" }),
							" ",
							e.status.replace("_", " "),
							" · ",
							e.materiality
						] })
					]
				}), a === e.item_id && /* @__PURE__ */ (0, A.jsxs)("tr", {
					className: "rr-detail",
					children: [/* @__PURE__ */ (0, A.jsx)("td", {}), /* @__PURE__ */ (0, A.jsx)("td", {
						colSpan: "9",
						children: /* @__PURE__ */ (0, A.jsxs)("div", {
							className: "rr-detail-grid",
							children: [
								/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "AIF / mapping" }), /* @__PURE__ */ (0, A.jsxs)("strong", { children: [
									e.aif_status,
									" · ",
									e.mapping_status
								] })] }),
								/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Owner" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: e.owner })] }),
								/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "SAP reference" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: e.sap_reference })] }),
								/* @__PURE__ */ (0, A.jsxs)("div", {
									className: "wide",
									children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Recommended action" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: e.recommended_action })]
								}),
								/* @__PURE__ */ (0, A.jsxs)("div", {
									className: "wide",
									children: [
										/* @__PURE__ */ (0, A.jsxs)("span", { children: [
											"AI assessment · ",
											Math.round(e.ai.confidence * 100),
											"% confidence"
										] }),
										/* @__PURE__ */ (0, A.jsx)("strong", { children: e.ai.rationale }),
										/* @__PURE__ */ (0, A.jsx)("small", { children: e.ai.basis })
									]
								})
							]
						})
					})]
				})] }, e.item_id)) })]
			}),
			/* @__PURE__ */ (0, A.jsxs)("details", {
				className: "rr-matched",
				children: [/* @__PURE__ */ (0, A.jsxs)("summary", { children: [/* @__PURE__ */ (0, A.jsxs)("strong", { children: [
					"Matched movements (",
					e.matched.length,
					")"
				] }), " · agree in S/4HANA and Central Finance"] }), /* @__PURE__ */ (0, A.jsxs)("table", {
					className: "rr-table",
					children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Journal" }),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Account" }),
						/* @__PURE__ */ (0, A.jsx)("th", { children: "Description" }),
						/* @__PURE__ */ (0, A.jsx)("th", {
							className: "num",
							children: "Amount"
						})
					] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: e.matched.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.journal_id }),
						/* @__PURE__ */ (0, A.jsxs)("td", { children: [
							e.account,
							" ",
							e.account_name
						] }),
						/* @__PURE__ */ (0, A.jsx)("td", { children: e.description }),
						/* @__PURE__ */ (0, A.jsx)("td", {
							className: "num",
							children: fn(e.amount)
						})
					] }, e.journal_id)) })]
				})]
			})
		]
	});
}
function An({ report: e }) {
	let t = Math.max(1, ...e.aging.map((e) => Math.abs(e.amount)));
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		children: [
			/* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-note",
				children: "Age of open reconciling items at the period end."
			}),
			/* @__PURE__ */ (0, A.jsx)("div", {
				className: "rr-aging",
				children: e.aging.map((e) => /* @__PURE__ */ (0, A.jsxs)("div", { children: [
					/* @__PURE__ */ (0, A.jsx)("span", { children: e.bucket }),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "rr-meter",
						children: /* @__PURE__ */ (0, A.jsx)("i", { style: { width: `${Math.abs(e.amount) / t * 100}%` } })
					}),
					/* @__PURE__ */ (0, A.jsxs)("strong", { children: [
						e.count,
						" item",
						e.count === 1 ? "" : "s",
						" · ",
						pn(e.amount)
					] })
				] }, e.bucket))
			}),
			e.aging[3].count + e.aging[2].count > 0 && /* @__PURE__ */ (0, A.jsxs)("p", {
				className: "rr-banner warn",
				children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "Older items" }), /* @__PURE__ */ (0, A.jsx)("span", { children: "Items older than 30 days need an owner and a clearing date before sign-off." })]
			})
		]
	});
}
function jn({ report: e }) {
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		children: [/* @__PURE__ */ (0, A.jsx)("p", {
			className: "rr-note",
			children: "PASS, HOLD and NOT_VERIFIED are reported separately. NOT_VERIFIED means the demo cannot prove it without a real tenant."
		}), /* @__PURE__ */ (0, A.jsxs)("table", {
			className: "rr-table",
			children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
				/* @__PURE__ */ (0, A.jsx)("th", { children: "ID" }),
				/* @__PURE__ */ (0, A.jsx)("th", { children: "Control" }),
				/* @__PURE__ */ (0, A.jsx)("th", { children: "Status" }),
				/* @__PURE__ */ (0, A.jsx)("th", { children: "Detail" })
			] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: e.controls.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
				/* @__PURE__ */ (0, A.jsx)("td", { children: e.id }),
				/* @__PURE__ */ (0, A.jsx)("td", { children: e.name }),
				/* @__PURE__ */ (0, A.jsx)("td", { children: /* @__PURE__ */ (0, A.jsx)(xn, { status: e.status }) }),
				/* @__PURE__ */ (0, A.jsx)("td", { children: e.detail })
			] }, e.id)) })]
		})]
	});
}
function Mn({ report: e }) {
	let t = e.ai_review;
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("p", {
				className: "rr-banner info",
				children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "Advisory only" }), /* @__PURE__ */ (0, A.jsxs)("span", { children: [
					"The assistant explains and ranks. A person decides. Model: ",
					t.model,
					"."
				] })]
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "rr-grid2",
				children: [/* @__PURE__ */ (0, A.jsxs)("section", { children: [/* @__PURE__ */ (0, A.jsx)("h3", { children: "What the AI did" }), /* @__PURE__ */ (0, A.jsx)("ul", { children: t.did.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })] }), /* @__PURE__ */ (0, A.jsxs)("section", { children: [/* @__PURE__ */ (0, A.jsx)("h3", { children: "What it did not do" }), /* @__PURE__ */ (0, A.jsx)("ul", { children: t.did_not.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: e }, e)) })] })]
			}),
			/* @__PURE__ */ (0, A.jsxs)("section", { children: [
				/* @__PURE__ */ (0, A.jsx)("h3", { children: "Confidence by item" }),
				e.items.length ? /* @__PURE__ */ (0, A.jsx)("div", {
					className: "rr-aging",
					children: e.items.map((e) => /* @__PURE__ */ (0, A.jsxs)("div", { children: [
						/* @__PURE__ */ (0, A.jsx)("span", { children: e.document_id }),
						/* @__PURE__ */ (0, A.jsx)("div", {
							className: "rr-meter",
							children: /* @__PURE__ */ (0, A.jsx)("i", {
								style: { width: `${e.ai.confidence * 100}%` },
								className: e.ai.confidence < .7 ? "low" : ""
							})
						}),
						/* @__PURE__ */ (0, A.jsxs)("strong", { children: [
							Math.round(e.ai.confidence * 100),
							"% · ",
							e.ai.classification
						] })
					] }, e.item_id))
				}) : /* @__PURE__ */ (0, A.jsx)("p", {
					className: "rr-empty",
					children: "Nothing to classify."
				}),
				/* @__PURE__ */ (0, A.jsx)("p", {
					className: "rr-note",
					children: "Items below 70% confidence are flagged for human review."
				})
			] })
		]
	});
}
function Nn({ report: e }) {
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "rr-pane",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "rr-detail-grid",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Report" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: e.report_id })] }),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Case / route" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: e.case_id ? `${e.case_id} · ${e.scenario}` : "Not attached" })] }),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Trace" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: e.trace_id || "Run the period to attach a trace" })] }),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "As of" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: e.as_of })] })
				]
			}),
			/* @__PURE__ */ (0, A.jsx)("h3", { children: "Source evidence" }),
			/* @__PURE__ */ (0, A.jsxs)("table", {
				className: "rr-table",
				children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Source" }),
					/* @__PURE__ */ (0, A.jsx)("th", {
						className: "num",
						children: "Balance"
					}),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Freshness" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Timestamp" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Evidence id" })
				] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: e.sources.map((t) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("td", { children: t.source }),
					/* @__PURE__ */ (0, A.jsx)("td", {
						className: "num",
						children: fn(t.balance)
					}),
					/* @__PURE__ */ (0, A.jsxs)("td", { children: [
						/* @__PURE__ */ (0, A.jsx)(xn, { status: t.freshness === "current" ? "PASS" : "HOLD" }),
						" ",
						t.freshness
					] }),
					/* @__PURE__ */ (0, A.jsxs)("td", { children: [t.timestamp_utc?.replace("T", " ").slice(0, 16), " UTC"] }),
					/* @__PURE__ */ (0, A.jsxs)("td", { children: [
						"SYN-",
						t.source.toUpperCase(),
						"-",
						e.period,
						"-AGG"
					] })
				] }, t.source)) })]
			}),
			/* @__PURE__ */ (0, A.jsxs)("h3", { children: [
				"Stored events (",
				e.events.length,
				")"
			] }),
			e.events.length ? /* @__PURE__ */ (0, A.jsxs)("table", {
				className: "rr-table",
				children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("th", { children: "#" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "From" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "To" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Operation" }),
					/* @__PURE__ */ (0, A.jsx)("th", { children: "Status" })
				] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: e.events.map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.seq }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.source }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.target }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.operation }),
					/* @__PURE__ */ (0, A.jsx)("td", { children: e.status })
				] }, e.seq)) })]
			}) : /* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-empty",
				children: "No run is attached to this report. Run the period to record events."
			}),
			/* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-note",
				children: e.disclaimer
			})
		]
	});
}
function Pn({ report: e, period: t, periods: n, onPeriod: r, onClose: i }) {
	let a = (0, _.useRef)(null), [o, s] = (0, _.useState)("summary"), [c, l] = (0, _.useState)(!1);
	(0, _.useEffect)(() => {
		let e = a.current;
		return e && !e.open && e.showModal(), () => {
			e?.open && e.close();
		};
	}, []), (0, _.useEffect)(() => {
		if (!c) return;
		let e = () => l(!1);
		window.addEventListener("afterprint", e);
		let t = setTimeout(() => {
			try {
				window.print();
			} catch {
				e();
			}
		}, 60);
		return () => {
			clearTimeout(t), window.removeEventListener("afterprint", e);
		};
	}, [c]);
	let u = (0, _.useMemo)(() => e ? {
		summary: /* @__PURE__ */ (0, A.jsx)(Sn, { report: e }),
		accounts: /* @__PURE__ */ (0, A.jsx)(Cn, { report: e }),
		matching: /* @__PURE__ */ (0, A.jsx)(Tn, { report: e }),
		posting: /* @__PURE__ */ (0, A.jsx)(On, { report: e }),
		items: /* @__PURE__ */ (0, A.jsx)(kn, { report: e }),
		aging: /* @__PURE__ */ (0, A.jsx)(An, { report: e }),
		controls: /* @__PURE__ */ (0, A.jsx)(jn, { report: e }),
		ai: /* @__PURE__ */ (0, A.jsx)(Mn, { report: e }),
		audit: /* @__PURE__ */ (0, A.jsx)(Nn, { report: e })
	}[o] : null, [e, o]);
	return /* @__PURE__ */ (0, A.jsxs)("dialog", {
		ref: a,
		className: "rr-dialog",
		"aria-labelledby": "rr-title",
		onClose: i,
		children: [/* @__PURE__ */ (0, A.jsxs)("header", {
			className: "rr-header",
			children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
				/* @__PURE__ */ (0, A.jsxs)("span", {
					className: "eyebrow",
					children: ["SYNTHETIC RECONCILIATION REPORT · ", e?.report_id || `RPT-${t}`]
				}),
				/* @__PURE__ */ (0, A.jsx)("h2", {
					id: "rr-title",
					children: e ? `Company code ${e.company_code} · ledger ${e.ledger} · ${e.period_label} (FY${e.fiscal.year} P${String(e.fiscal.period).padStart(2, "0")}) · ${e.currency}` : `Loading report for ${t}…`
				}),
				e && /* @__PURE__ */ (0, A.jsx)(xe, {
					provenance: e.provenance,
					compact: !0
				})
			] }), /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "rr-actions",
				children: [
					r && /* @__PURE__ */ (0, A.jsx)(N, {
						period: t,
						periods: n,
						onPeriod: r,
						id: "rr-period"
					}),
					e && /* @__PURE__ */ (0, A.jsx)("span", {
						className: `rr-chip ${gn[e.summary.status]}`,
						children: hn[e.summary.status]
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						disabled: !e,
						onClick: () => _n(`${e.report_id}-items.csv`, "text/csv", yn(e)),
						children: "Items CSV ⤓"
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						disabled: !e,
						onClick: () => _n(`${e.report_id}.json`, "application/json", JSON.stringify(e, null, 2)),
						children: "Report JSON ⤓"
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						disabled: !e,
						onClick: () => l(!0),
						children: "Print full report"
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: i,
						"aria-label": "Close reconciliation report",
						children: "×"
					})
				]
			})]
		}), e && c ? /* @__PURE__ */ (0, A.jsx)("div", {
			className: "rr-body rr-print-all",
			children: mn.map(([t, n]) => /* @__PURE__ */ (0, A.jsxs)("section", { children: [/* @__PURE__ */ (0, A.jsx)("h2", { children: n }), {
				summary: /* @__PURE__ */ (0, A.jsx)(Sn, { report: e }),
				accounts: /* @__PURE__ */ (0, A.jsx)(Cn, { report: e }),
				matching: /* @__PURE__ */ (0, A.jsx)(Tn, { report: e }),
				posting: /* @__PURE__ */ (0, A.jsx)(On, { report: e }),
				items: /* @__PURE__ */ (0, A.jsx)(kn, { report: e }),
				aging: /* @__PURE__ */ (0, A.jsx)(An, { report: e }),
				controls: /* @__PURE__ */ (0, A.jsx)(jn, { report: e }),
				ai: /* @__PURE__ */ (0, A.jsx)(Mn, { report: e }),
				audit: /* @__PURE__ */ (0, A.jsx)(Nn, { report: e })
			}[t]] }, t))
		}) : e ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [/* @__PURE__ */ (0, A.jsx)("div", {
			className: "rr-tabs",
			role: "tablist",
			"aria-label": "Report sections",
			onKeyDown: (e) => {
				let t = mn.findIndex(([e]) => e === o);
				e.key === "ArrowRight" && (s(mn[(t + 1) % mn.length][0]), e.preventDefault()), e.key === "ArrowLeft" && (s(mn[(t + mn.length - 1) % mn.length][0]), e.preventDefault());
			},
			children: mn.map(([t, n]) => /* @__PURE__ */ (0, A.jsxs)("button", {
				type: "button",
				role: "tab",
				"aria-selected": o === t,
				tabIndex: o === t ? 0 : -1,
				className: o === t ? "active" : "",
				onClick: () => s(t),
				children: [n, t === "items" && e.items.length ? /* @__PURE__ */ (0, A.jsx)("em", { children: e.items.length }) : null]
			}, t))
		}), /* @__PURE__ */ (0, A.jsx)("div", {
			className: "rr-body",
			role: "tabpanel",
			children: u
		})] }) : /* @__PURE__ */ (0, A.jsx)("div", {
			className: "rr-body",
			children: /* @__PURE__ */ (0, A.jsx)("p", {
				className: "rr-empty",
				role: "status",
				children: "Loading the synthetic report…"
			})
		})]
	});
}
// src/orchestrationSvg.js
var Fn = {
	w: 1200,
	h: 660
}, In = (e, t, n, r, i, a, o = {}) => ({
	id: e,
	row: t,
	col: n,
	title: r,
	sub: i,
	kind: a,
	...o
}), Ln = [
	["invoke", "MCP-style tools/call (in-process)"],
	["registry", "Reaches application layer"],
	["identity", "Needs input"],
	["approval", "Blocked by a control"]
], Rn = {
	"Selected gateway": [
		"Selected MCP gateway",
		"gateway",
		"Apigee, or AgentCore Gateway in S2"
	],
	"Domain MCP": [
		"Domain MCP tools",
		"domain",
		"Finance read tools"
	],
	"SAP BAIP": [
		"SAP integration",
		"integration",
		"API Management and iFlow"
	],
	"SAP backends": [
		"SAP backends",
		"backend",
		"S/4HANA, Central Finance, BW"
	],
	"Enterprise Databricks": [
		"Databricks",
		"data",
		"Data evidence"
	],
	"Agent runtime": [
		"Agent runtime",
		"domain",
		"Runs the finance agent"
	],
	"Business entry": [
		"Business request",
		"agent",
		"Intent and scope"
	],
	"Agent controls": [
		"Agent identity",
		"identity",
		"Workload identity"
	],
	"Model branch": [
		"AI advisory",
		"agent",
		"Explanation only"
	],
	"Write approval": [
		"Write approval",
		"decision",
		"Separate branch"
	],
	"Future BDC": [
		"BDC (future)",
		"data",
		"Reference only"
	],
	"Design time and registration": [
		"Agent registration",
		"registry",
		"Design time"
	]
}, zn = {
	done: "#107E3E",
	running: "#E9730C",
	held: "#E9730C",
	blocked: "#BB0000",
	pending: void 0
};
function Bn(e, t, n) {
	return t < n ? e.status : t === n ? "running" : "pending";
}
function Vn({ plan: e, catalog: t, shown: n, selectedAgent: r }) {
	let i = (t?.agents || []).filter((e) => e.kind !== "orchestrator"), a = e?.steps || [], o = Math.min(n, a.length), s = (t, r) => e ? Bn(t, r, n) : "pending", c = {};
	a.forEach((e, t) => {
		(c[e.agent] ||= []).push({
			step: e,
			index: t
		});
	});
	let l = [], u = e ? o >= a.length ? "All steps dispatched" : `Dispatching step ${o + 1} of ${a.length}` : "Waiting for a request";
	l.push(In("orch", 0, 1.5, "Orchestrator · tool client", e ? `${e.orchestrator?.rule || ""}. ${u}. It plans and calls tools; it never touches SAP.` : "Ask a question to start. It plans and calls tools; it never touches SAP.", "agent", {
		span: 3,
		h: 84,
		zone: "agent:orchestrator",
		status: e ? u : "Idle",
		statusColor: e ? "#0A4F9E" : "#506778",
		stroke: r === "orchestrator" ? "#0A6ED1" : "#0A4F9E",
		strokeWidth: 2.4
	})), i.forEach((e, t) => {
		let n = c[e.id] || [], a = n.map(({ step: e, index: t }) => s(e, t)), o = n.length > 0 && a.some((e) => e !== "pending"), u = a.includes("blocked") ? "blocked" : a.includes("held") ? "held" : a.includes("running") ? "running" : o ? "done" : "pending", d = a.filter((e) => e === "done").length;
		l.push(In(`agent:${e.id}`, 1, t + (6 - i.length) / 2, e.name, `${e.mcp_server} · ${e.tools.join(", ")}`, "domain", {
			h: 84,
			zone: `agent:${e.id}`,
			status: n.length ? o ? `${d}/${n.length} calls done${n.every(({ step: e }) => !e.trace?.layers?.length) ? " · computed locally" : ""}` : "Queued" : "Not called",
			statusColor: o ? zn[u] : "#506778",
			stroke: r === e.id ? "#0A6ED1" : o ? zn[u] : "#B8C7D3",
			strokeWidth: r === e.id ? 3.2 : o ? 2.2 : 1.2,
			dashed: !o && n.length === 0
		}));
	});
	let d = [], f = [];
	a.forEach((e, t) => {
		let n = s(e, t);
		n !== "pending" && n !== "running" && (e.trace?.layers || []).forEach((t, n) => {
			d.includes(t) || d.push(t), f.push([
				`agent:${e.agent}`,
				`layer:${t}`,
				"registry",
				n === 0 && e.trace?.count ? `${e.trace.count} events` : ""
			]);
		});
	}), d.forEach((e, t) => {
		let n = Rn[e] || [
			e,
			"control",
			""
		];
		l.push(In(`layer:${e}`, t < 6 ? 2 : 3, t % 6, n[0], n[2], n[1], {
			h: 84,
			status: "Reached",
			statusColor: "#0D6A33",
			stroke: "#107E3E",
			strokeWidth: 1.8
		}));
	});
	let p = /* @__PURE__ */ new Set(), m = f.filter(([e, t]) => !p.has(`${e}>${t}`) && p.add(`${e}>${t}`)), h = [];
	return Object.entries(c).forEach(([e, t]) => {
		let n = t.map(({ step: e, index: t }) => s(e, t));
		if (n.every((e) => e === "pending")) return;
		let r = n.includes("blocked") ? "blocked" : n.includes("held") ? "held" : "ok", i = `#${t.map(({ index: e }) => e + 1).join(" #")} ${t[0].step.tool}${t.length > 1 ? ` +${t.length - 1}` : ""}`;
		h.push([
			"orch",
			`agent:${e}`,
			r === "blocked" ? "approval" : r === "held" ? "identity" : "invoke",
			i,
			{ active: n.includes("running") }
		]);
	}), h.push(...m), St({
		cols: 6,
		ys: [
			96,
			224,
			392,
			508
		],
		nh: 84,
		height: Fn.h,
		nodes: l,
		edges: h,
		bounds: [],
		legend: Ln,
		captions: [[
			88,
			"ORCHESTRATOR · TOOL CLIENT",
			"end"
		], [
			382,
			"APPLICATION LAYERS THE EVENTS TOUCHED",
			"end"
		]],
		title: e ? `Orchestration · ${String(e.intent).replace("_", " ")}` : "Orchestration · waiting for a request",
		chain: a.length ? a.map((e, t) => `#${t + 1} ${e.agent}.${e.tool}`).join(" → ") : "Orchestrator → specialist agents (tool providers) → application layers",
		banner: "SIMULATED AGENTS · DETERMINISTIC RULES · NO LLM · NO SAP WRITES",
		footer: "Each arrow from the orchestrator is an in-process, MCP-style tool call (no MCP transport). Layers are drawn only from the stored events each step produced; steps with none were computed locally."
	});
}
// src/AgentWorkbench.jsx
var Hn = {
	done: "✓",
	running: "…",
	pending: "·",
	held: "?",
	blocked: "✕",
	skipped: "–"
}, Un = {
	treasury: "Open Cash & treasury",
	"treasury-forecast": "Open the cash forecast",
	"treasury-banks": "Open bank relationships",
	run: "Open the live architecture",
	report: "Open the detailed report",
	"evidence-proof": "Open the proof dossier",
	"decision-responsibilities": "Open responsibilities & governance",
	close: "Open Close & reconcile",
	plan: "Stay here"
}, Wn = /* @__PURE__ */ new Set(), Gn = () => {
	try {
		return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	} catch {
		return !1;
	}
};
function Kn({ onAsk: e, busy: t, label: n = "Ask the agents", period: r = y, periods: i, domain: a = "reconciliation" }) {
	let [o, s] = be(r, a);
	return /* @__PURE__ */ (0, A.jsxs)("form", {
		className: "surface agent-ask-bar",
		onSubmit: (n) => {
			n.preventDefault(), o.trim() && !t && e(o.trim());
		},
		children: [
			/* @__PURE__ */ (0, A.jsxs)("label", {
				htmlFor: "ask-bar-input",
				children: [/* @__PURE__ */ (0, A.jsx)("span", {
					className: "eyebrow",
					children: "AGENTS · SIMULATED"
				}), /* @__PURE__ */ (0, A.jsx)("strong", { children: n })]
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "ask-main",
				children: [/* @__PURE__ */ (0, A.jsx)("input", {
					id: "ask-bar-input",
					value: o,
					onChange: (e) => s(e.target.value),
					"aria-label": n
				}), /* @__PURE__ */ (0, A.jsxs)("span", {
					className: "ask-meta",
					children: [/* @__PURE__ */ (0, A.jsx)(ye, {
						text: o,
						period: r,
						periods: i
					}), /* @__PURE__ */ (0, A.jsx)(P, { text: o })]
				})]
			}),
			/* @__PURE__ */ (0, A.jsx)("button", {
				type: "submit",
				className: "primary",
				disabled: t,
				children: t ? "Running…" : "Ask →"
			})
		]
	});
}
function qn({ plan: e }) {
	return /* @__PURE__ */ (0, A.jsxs)("section", {
		className: "surface aw-result tr-result",
		"aria-label": "Result",
		"data-testid": "module-result",
		"data-module": e.domain,
		children: [
			/* @__PURE__ */ (0, A.jsxs)("span", {
				className: "eyebrow",
				children: [
					"RESULT · ",
					e.effective_period,
					" · SYNTHETIC DATA · NOT AN SAP BALANCE"
				]
			}),
			/* @__PURE__ */ (0, A.jsx)(M, { blocks: e.result_blocks }),
			e.references?.length > 0 && /* @__PURE__ */ (0, A.jsxs)("details", {
				open: !0,
				className: "tr-sources",
				"data-testid": "module-sources",
				children: [/* @__PURE__ */ (0, A.jsx)("summary", { children: /* @__PURE__ */ (0, A.jsx)("b", { children: "SAP sources behind this answer" }) }), /* @__PURE__ */ (0, A.jsx)("ul", {
					className: "tr-refs",
					children: e.references.map((e) => /* @__PURE__ */ (0, A.jsxs)("li", { children: [
						/* @__PURE__ */ (0, A.jsxs)("a", {
							href: e.url,
							target: "_blank",
							rel: "noreferrer",
							children: [
								e.id,
								" · ",
								e.title,
								" ↗"
							]
						}),
						" ",
						/* @__PURE__ */ (0, A.jsxs)("small", { children: [
							e.supports,
							" [",
							e.status,
							"]"
						] })
					] }, e.id))
				})]
			})
		]
	});
}
function Jn({ catalog: e, plan: t, busy: n, onAsk: r, onOpenLayer: i, onOpenConcept: a, onOpenOutput: o, period: s = y, periods: c, ontology: l }) {
	let u = re(), d = e?.order || ["reconciliation"], [f, p] = (0, _.useState)(null), m = f || e?.default || d[0], h = p;
	(0, _.useEffect)(() => {
		t?.domain && p(t.domain);
	}, [t?.plan_id]);
	let g = e?.domains?.[m] || e, v = t && (t.domain || e?.default) === m ? t : null, b = g?.agents || [], x = (e) => b.find((t) => t.id === e)?.kind === "orchestrator", S = (b.find((e) => e.kind === "orchestrator") || {}).id || "orchestrator", [w, E] = be(s, m), D = u.examples(m, s), O = (e) => ((l?.classes || []).find((t) => t.id === e) || {}).label || String(e).split(".").pop(), [k, ee] = (0, _.useState)(0), [te, ne] = (0, _.useState)(null), [ie, ae] = (0, _.useState)(null), [oe, se] = (0, _.useState)(!1), ce = (0, _.useRef)(null), j = v?.steps || [];
	(0, _.useEffect)(() => {
		if (!v || ce.current === v.plan_id) return;
		if (ce.current = v.plan_id, ne(null), Gn() || !j.length || Wn.has(v.plan_id)) {
			Wn.add(v.plan_id), ee(j.length);
			return;
		}
		Wn.add(v.plan_id), ee(0);
		let e = 0, t = setInterval(() => {
			e += 1, ee(e), e >= j.length && clearInterval(t);
		}, 650);
		return () => clearInterval(t);
	}, [v?.plan_id]);
	let le = te?.agent || null, ue = (0, _.useMemo)(() => Vn({
		plan: v,
		catalog: g,
		shown: k,
		selectedAgent: x(le) ? "orchestrator" : le
	}), [
		v,
		g,
		k,
		le
	]), de = (0, _.useMemo)(() => ({
		id: "orchestration",
		title: "Orchestration",
		svg: ue,
		w: Fn.w,
		h: Fn.h,
		file: "orchestration",
		png: !0
	}), [ue]), fe = Object.fromEntries(b.map((e) => [e.id, e])), pe = (e) => {
		e.preventDefault(), w.trim() && !n && r(w.trim());
	}, me = (e) => {
		if (!e?.startsWith("agent:")) return;
		let t = e.slice(6);
		if (t === "orchestrator") {
			ne({ agent: S });
			return;
		}
		let n = j.find((e) => e.agent === t);
		ne({
			agent: t,
			step_id: n?.step_id
		});
	}, he = j.find((e) => e.step_id === te?.step_id) || null, ge = te ? fe[te.agent] : null, _e = v && k >= j.length;
	return /* @__PURE__ */ (0, A.jsxs)("main", {
		className: "agent-workbench",
		"aria-label": "Agents",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("header", {
				className: "surface aw-header",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "aw-title",
					children: [
						/* @__PURE__ */ (0, A.jsx)("div", {
							className: "domain-switch",
							role: "tablist",
							"aria-label": "Agent family",
							children: d.map((t) => /* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								role: "tab",
								"aria-selected": m === t,
								className: m === t ? "active" : "",
								onClick: () => h(t),
								children: e?.domains?.[t]?.name || t
							}, t))
						}),
						/* @__PURE__ */ (0, A.jsxs)("span", {
							className: "eyebrow",
							children: ["AGENTS · ORCHESTRATED WITH MCP-STYLE TOOL CALLS · ", (g?.name || m).toUpperCase()]
						}),
						/* @__PURE__ */ (0, A.jsx)("h2", { children: "Watch the orchestrator call its agents" }),
						/* @__PURE__ */ (0, A.jsx)("p", { children: "The orchestrator plans and calls specialist agents, each a tool provider with a few typed tools. The calls are MCP-shaped but in-process (no MCP transport yet). Select an agent or a step to see what it did and which application layers its events actually touched." })
					]
				}), /* @__PURE__ */ (0, A.jsxs)("form", {
					className: "aw-ask",
					onSubmit: pe,
					children: [
						/* @__PURE__ */ (0, A.jsx)("label", {
							htmlFor: "aw-ask-input",
							className: "sr-only",
							children: "Ask the orchestrator"
						}),
						/* @__PURE__ */ (0, A.jsx)("input", {
							id: "aw-ask-input",
							value: w,
							onChange: (e) => E(e.target.value),
							"aria-label": "Ask the orchestrator"
						}),
						/* @__PURE__ */ (0, A.jsx)("button", {
							type: "submit",
							className: "primary",
							disabled: n,
							children: n ? "Running…" : "Run plan"
						}),
						/* @__PURE__ */ (0, A.jsxs)("span", {
							className: "ask-meta",
							children: [/* @__PURE__ */ (0, A.jsx)(ye, {
								text: w,
								period: s,
								periods: c
							}), /* @__PURE__ */ (0, A.jsx)(P, { text: w })]
						}),
						/* @__PURE__ */ (0, A.jsx)("div", {
							className: "aw-examples",
							role: "group",
							"aria-label": "Example requests",
							children: D.map((e) => /* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								onClick: () => E(e),
								children: e.length > 34 ? e.slice(0, 32) + "…" : e
							}, e))
						})
					]
				})]
			}),
			v && /* @__PURE__ */ (0, A.jsx)("p", {
				className: "aw-period",
				children: /* @__PURE__ */ (0, A.jsxs)("span", {
					className: `domain-badge ${v.domain}`,
					"data-testid": "plan-domain",
					children: ["Handled by ", /* @__PURE__ */ (0, A.jsx)("b", { children: u.label(v.domain) })]
				})
			}),
			v?.message && /* @__PURE__ */ (0, A.jsxs)("p", {
				className: "aw-period",
				"data-testid": "plan-request",
				children: ["Your request: ", /* @__PURE__ */ (0, A.jsxs)("b", { children: [
					"“",
					v.message,
					"”"
				] })]
			}),
			v?.effective_period && /* @__PURE__ */ (0, A.jsxs)("p", {
				className: "aw-period",
				"data-testid": "plan-period",
				children: [
					"Plan period: ",
					/* @__PURE__ */ (0, A.jsx)("b", { children: C(v.effective_period) }),
					" · ",
					T(v.effective_period),
					" · taken from ",
					v.period_source === "request" ? "the request" : v.period_source === "selector" ? "the period selector" : "the open case"
				]
			}),
			v?.effective_period && v.effective_period !== s && /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "period-stale",
				role: "alert",
				"data-testid": "plan-stale",
				children: [
					"This plan is for ",
					C(v.effective_period),
					". The selected period is ",
					C(s),
					". ",
					/* @__PURE__ */ (0, A.jsxs)("button", {
						type: "button",
						onClick: () => r(u.ask(v.domain, s)),
						children: ["Run for ", C(s)]
					})
				]
			}),
			v && (_e || j.length === 0) && /* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface aw-answer",
				"aria-label": "What the agents found",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
					className: "eyebrow",
					children: "WHAT THE AGENTS FOUND"
				}), /* @__PURE__ */ (0, A.jsx)("p", { children: v.answer || v.blocked_reason || v.note })] }), v.adaptations?.length > 0 && /* @__PURE__ */ (0, A.jsxs)("p", {
					className: "aw-adapt",
					children: [
						/* @__PURE__ */ (0, A.jsx)("b", { children: "The orchestrator adapted the plan:" }),
						" ",
						v.adaptations.map((e) => e.added ? `added ${e.added} because ${e.because}` : e.because).join("; "),
						"."
					]
				})]
			}),
			v && v.status === "done" && (_e || j.length === 0) && (() => {
				let e = u.byId[v.domain]?.output;
				return e?.open_label && /* @__PURE__ */ (0, A.jsxs)("section", {
					className: "surface aw-output",
					"data-testid": "plan-output",
					"aria-label": "Open the full output of this run",
					children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "FULL OUTPUT OF THIS RUN"
					}), /* @__PURE__ */ (0, A.jsxs)("p", { children: [
						"The answer above is a summary. The complete output for ",
						C(v.effective_period),
						" is on the ",
						e.screen_name,
						" screen."
					] })] }), /* @__PURE__ */ (0, A.jsxs)("div", {
						className: "aw-output-actions",
						children: [/* @__PURE__ */ (0, A.jsxs)("button", {
							type: "button",
							className: "primary",
							"data-testid": "plan-output-screen",
							onClick: () => o?.(v, "screen"),
							children: [e.open_label, " →"]
						}), e.detail_label && /* @__PURE__ */ (0, A.jsxs)("button", {
							type: "button",
							"data-testid": "plan-output-detail",
							onClick: () => o?.(v, "detail"),
							children: [e.detail_label, " →"]
						})]
					})]
				});
			})(),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "aw-body",
				children: [/* @__PURE__ */ (0, A.jsx)("section", {
					className: "aw-graph",
					"aria-label": "Orchestration graph",
					children: /* @__PURE__ */ (0, A.jsx)("div", {
						className: "aw-viewer",
						children: /* @__PURE__ */ (0, A.jsx)(V, {
							diagram: de,
							uid: "orch",
							view: ie,
							onView: ae,
							onFit: ae,
							expanded: oe,
							onExpand: se,
							onPick: me
						})
					})
				}), /* @__PURE__ */ (0, A.jsxs)("aside", {
					className: "surface aw-side",
					"aria-label": "Orchestration log and step detail",
					children: [
						/* @__PURE__ */ (0, A.jsx)("h3", { children: "Orchestration log" }),
						v ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: `aw-plan-state ${v.status}`,
								role: "status",
								children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: String(v.intent).replace("_", " ") }), /* @__PURE__ */ (0, A.jsx)("span", { children: v.blocked_reason || (_e || j.length === 0 ? {
									done: "Plan complete.",
									needs_input: "Stopped: it needs one more detail.",
									blocked: "Stopped at a control. Nothing was changed."
								}[v.status] || "" : `Dispatching step ${Math.min(k + 1, j.length)} of ${j.length}…`) })]
							}),
							/* @__PURE__ */ (0, A.jsxs)("ol", {
								className: "aw-log",
								children: [/* @__PURE__ */ (0, A.jsx)("li", {
									className: "orch",
									children: /* @__PURE__ */ (0, A.jsxs)("button", {
										type: "button",
										onClick: () => ne({ agent: S }),
										children: [
											/* @__PURE__ */ (0, A.jsx)("span", {
												className: "aw-mark",
												children: "◆"
											}),
											/* @__PURE__ */ (0, A.jsx)("b", { children: "Orchestrator" }),
											/* @__PURE__ */ (0, A.jsxs)("small", { children: [
												"Planned ",
												j.length,
												" step",
												j.length === 1 ? "" : "s",
												" (",
												v.orchestrator?.rule,
												"). Calls each agent with an MCP-style tool call (in-process)."
											] })
										]
									})
								}), j.map((e, t) => {
									let n = Bn(e, t, k);
									return n === "pending" && t > k ? null : /* @__PURE__ */ (0, A.jsx)("li", {
										className: `${n} ${te?.step_id === e.step_id ? "sel" : ""}`,
										children: /* @__PURE__ */ (0, A.jsxs)("button", {
											type: "button",
											onClick: () => ne({
												agent: e.agent,
												step_id: e.step_id
											}),
											children: [
												/* @__PURE__ */ (0, A.jsx)("span", {
													className: "aw-mark",
													"aria-hidden": "true",
													children: Hn[n]
												}),
												/* @__PURE__ */ (0, A.jsxs)("b", { children: [
													"#",
													t + 1,
													" ",
													fe[e.agent]?.name || e.agent
												] }),
												/* @__PURE__ */ (0, A.jsx)("small", { children: n === "running" ? e.purpose : e.summary || e.purpose }),
												e.added_by && /* @__PURE__ */ (0, A.jsxs)("small", {
													className: "aw-added",
													children: ["Added by the orchestrator: ", e.added_by]
												}),
												/* @__PURE__ */ (0, A.jsxs)("code", {
													className: "tech",
													children: [
														e.mcp?.server,
														" · ",
														e.tool,
														" · ",
														e.duration_ms ?? 0,
														" ms"
													]
												})
											]
										})
									}, e.step_id);
								})]
							}),
							j.length === 0 && /* @__PURE__ */ (0, A.jsx)("p", {
								className: `aw-note ${v.status === "blocked" ? "bad" : ""}`,
								children: v.blocked_reason || v.note
							})
						] }) : /* @__PURE__ */ (0, A.jsx)("p", {
							className: "aw-empty",
							children: "No plan yet. Run a request to see the orchestrator dispatch its calls."
						}),
						ge && /* @__PURE__ */ (0, A.jsxs)("div", {
							className: "aw-detail",
							"aria-live": "polite",
							children: [
								/* @__PURE__ */ (0, A.jsxs)("h3", { children: [ge.name, he ? ` · step #${j.indexOf(he) + 1}` : ""] }),
								/* @__PURE__ */ (0, A.jsx)("p", { children: ge.role }),
								he ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
									/* @__PURE__ */ (0, A.jsxs)("dl", { children: [
										/* @__PURE__ */ (0, A.jsx)("dt", { children: "Tool provider" }),
										/* @__PURE__ */ (0, A.jsx)("dd", { children: he.mcp?.server }),
										/* @__PURE__ */ (0, A.jsx)("dt", { children: "Call" }),
										/* @__PURE__ */ (0, A.jsxs)("dd", { children: [
											/* @__PURE__ */ (0, A.jsx)("code", { children: "tools/call" }),
											" (MCP-style) · ",
											he.tool,
											" (",
											he.rw,
											")"
										] }),
										/* @__PURE__ */ (0, A.jsx)("dt", { children: "Result" }),
										/* @__PURE__ */ (0, A.jsx)("dd", { children: he.summary || "Pending" }),
										/* @__PURE__ */ (0, A.jsx)("dt", { children: "Layers reached" }),
										/* @__PURE__ */ (0, A.jsx)("dd", { children: he.trace?.layers?.length ? he.trace.layers.join(" → ") : "None. Computed locally, no application layer called." }),
										/* @__PURE__ */ (0, A.jsx)("dt", { children: "Events" }),
										/* @__PURE__ */ (0, A.jsxs)("dd", { children: [
											he.trace?.count ?? 0,
											" stored",
											he.trace?.first_seq ? ` · #${he.trace.first_seq}–#${he.trace.last_seq}` : ""
										] })
									] }),
									(() => {
										let e = (g?.tools || []).find((e) => e.name === he.tool), t = [...(e?.reads || []).map((e) => ["reads", e]), ...(e?.produces || []).map((e) => ["produces", e])];
										return t.length > 0 && /* @__PURE__ */ (0, A.jsxs)("div", {
											className: "concept-chips",
											"data-testid": "concept-chips",
											children: [/* @__PURE__ */ (0, A.jsx)("span", {
												className: "micro",
												children: "Concepts:"
											}), t.map(([e, t]) => /* @__PURE__ */ (0, A.jsxs)("button", {
												type: "button",
												className: `concept-chip ${e}`,
												"data-testid": "concept-chip",
												onClick: () => a?.(t),
												children: [
													e,
													" · ",
													O(t)
												]
											}, e + t))]
										});
									})(),
									he.trace?.hops?.length > 0 && /* @__PURE__ */ (0, A.jsxs)("details", {
										className: "aw-hops",
										children: [/* @__PURE__ */ (0, A.jsxs)("summary", { children: [
											"Calls made (",
											he.trace.hops.length,
											" distinct hops)"
										] }), /* @__PURE__ */ (0, A.jsx)("ul", { children: he.trace.hops.map((e, t) => /* @__PURE__ */ (0, A.jsxs)("li", { children: [
											/* @__PURE__ */ (0, A.jsxs)("code", { children: [
												e.from,
												" → ",
												e.to
											] }),
											" · ",
											e.operation
										] }, t)) })]
									}),
									/* @__PURE__ */ (0, A.jsxs)("details", {
										className: "tech aw-json",
										children: [/* @__PURE__ */ (0, A.jsx)("summary", { children: "MCP-shaped request (illustrative, never sent)" }), /* @__PURE__ */ (0, A.jsx)("pre", { children: JSON.stringify({
											note: "in-process call; no MCP transport",
											jsonrpc: "2.0",
											method: "tools/call",
											params: {
												name: he.tool,
												arguments: he.mcp?.arguments || {}
											}
										}, null, 2) })]
									}),
									/* @__PURE__ */ (0, A.jsxs)("button", {
										type: "button",
										className: "aw-open",
										onClick: () => i(ge, he),
										children: [ge.view_label || Un[he.view || ge.view] || "Open layer", " →"]
									})
								] }) : /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
									/* @__PURE__ */ (0, A.jsxs)("dl", { children: [
										/* @__PURE__ */ (0, A.jsx)("dt", { children: "Tool provider" }),
										/* @__PURE__ */ (0, A.jsx)("dd", { children: ge.mcp_server }),
										/* @__PURE__ */ (0, A.jsx)("dt", { children: "Tools" }),
										/* @__PURE__ */ (0, A.jsx)("dd", { children: ge.tools.join(", ") }),
										/* @__PURE__ */ (0, A.jsx)("dt", { children: "Layers it can reach" }),
										/* @__PURE__ */ (0, A.jsx)("dd", { children: ge.layers.join(" → ") || "None; it only plans and calls" })
									] }),
									/* @__PURE__ */ (0, A.jsx)("p", {
										className: "aw-note",
										children: x(ge.id) ? "It chose this plan with a fixed rule table, then called each agent in order. No model is involved." : "Not called in this plan."
									}),
									!x(ge.id) && /* @__PURE__ */ (0, A.jsxs)("button", {
										type: "button",
										className: "aw-open",
										onClick: () => i(ge),
										children: [ge.view_label || Un[ge.view] || "Open layer", " →"]
									})
								] })
							]
						})
					]
				})]
			}),
			v?.result_blocks?.length > 0 && (_e || j.length === 0) && /* @__PURE__ */ (0, A.jsx)(qn, { plan: v }),
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "surface aw-roster",
				"aria-label": "Agent roster",
				children: [/* @__PURE__ */ (0, A.jsx)("div", {
					className: "aw-roster-head",
					children: /* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "AGENT ROSTER"
					}), /* @__PURE__ */ (0, A.jsx)("strong", { children: "Who does what" })] })
				}), /* @__PURE__ */ (0, A.jsx)("ul", { children: b.map((e) => {
					let t = j.filter((t) => t.agent === e.id);
					return /* @__PURE__ */ (0, A.jsx)("li", { children: /* @__PURE__ */ (0, A.jsxs)("button", {
						type: "button",
						className: `agent-card ${te?.agent === e.id ? "active" : ""}`,
						onClick: () => ne({
							agent: e.id,
							step_id: t[0]?.step_id
						}),
						"aria-label": `Select ${e.name} agent`,
						children: [
							/* @__PURE__ */ (0, A.jsx)("strong", { children: e.name }),
							/* @__PURE__ */ (0, A.jsx)("span", { children: e.role }),
							/* @__PURE__ */ (0, A.jsx)("small", {
								className: "aw-chips",
								children: e.tools.map((e) => /* @__PURE__ */ (0, A.jsx)("i", { children: e }, e))
							}),
							/* @__PURE__ */ (0, A.jsx)("em", { children: e.mcp_server }),
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "aw-last",
								children: t.length ? t.map((e) => e.summary || e.purpose).join(" · ") : "Not called in this plan"
							})
						]
					}) }, e.id);
				}) })]
			}),
			/* @__PURE__ */ (0, A.jsxs)("details", {
				className: "surface aw-catalog",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("summary", { children: [
						/* @__PURE__ */ (0, A.jsx)("strong", { children: "Tool catalog" }),
						" ",
						/* @__PURE__ */ (0, A.jsxs)("span", { children: [
							"tools/list-shaped · ",
							g?.tools?.length || 0,
							" tools · writes are not tools"
						] })
					] }),
					/* @__PURE__ */ (0, A.jsxs)("table", {
						className: "rr-table",
						children: [/* @__PURE__ */ (0, A.jsx)("thead", { children: /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, A.jsx)("th", { children: "Tool" }),
							/* @__PURE__ */ (0, A.jsx)("th", { children: "Agent" }),
							/* @__PURE__ */ (0, A.jsx)("th", { children: "Class" }),
							/* @__PURE__ */ (0, A.jsx)("th", { children: "Input" }),
							/* @__PURE__ */ (0, A.jsx)("th", { children: "Output" })
						] }) }), /* @__PURE__ */ (0, A.jsx)("tbody", { children: (g?.tools || []).map((e) => /* @__PURE__ */ (0, A.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, A.jsx)("td", { children: /* @__PURE__ */ (0, A.jsx)("code", { children: e.name }) }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: fe[e.agent]?.name }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.rw }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: /* @__PURE__ */ (0, A.jsx)("code", { children: JSON.stringify(e.input) }) }),
							/* @__PURE__ */ (0, A.jsx)("td", { children: e.output })
						] }, e.name)) })]
					}),
					/* @__PURE__ */ (0, A.jsxs)("p", {
						className: "micro",
						children: [
							"Not registered as tools, by design: ",
							(g?.not_tools || []).join(", "),
							". ",
							g?.note
						]
					})
				]
			})
		]
	});
}
// src/Entry.jsx
function Yn({ periodCount: e, localBundle: t, onOpenApp: n, onOpenAgents: r, onOpenArchitecture: i, onOpenTreasury: a, onAsk: o, onGo: s, period: c = y, periods: l, onPeriod: u }) {
	let d = re(), [f, p] = be(c, d.def?.id), m = d.modules.flatMap((e) => d.examples(e.id, c).slice(0, 2));
	return /* @__PURE__ */ (0, A.jsxs)("main", {
		className: "entry",
		"aria-label": "Finance agents home",
		children: [
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "entry-hero",
				children: [
					/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "FINANCE / AGENTS"
					}),
					/* @__PURE__ */ (0, A.jsx)("h2", { children: "Ask the finance agents" }),
					/* @__PURE__ */ (0, A.jsx)("p", { children: "An orchestrator plans your request, routes it to the right agent module, and calls its specialist agents with MCP-style tool calls. They read the simulated SAP finance layers; people approve and nothing is posted." }),
					/* @__PURE__ */ (0, A.jsxs)("form", {
						className: "entry-ask",
						onSubmit: (e) => {
							e.preventDefault(), f.trim() && o(f.trim());
						},
						children: [
							u && /* @__PURE__ */ (0, A.jsx)(N, {
								period: c,
								periods: l,
								onPeriod: u,
								id: "entry-period"
							}),
							/* @__PURE__ */ (0, A.jsx)("label", {
								htmlFor: "entry-ask-input",
								className: "sr-only",
								children: "What should the agents do?"
							}),
							/* @__PURE__ */ (0, A.jsx)("input", {
								id: "entry-ask-input",
								value: f,
								onChange: (e) => p(e.target.value),
								"aria-label": "What should the agents do?"
							}),
							/* @__PURE__ */ (0, A.jsx)("button", {
								type: "submit",
								className: "primary",
								children: "Run plan →"
							})
						]
					}),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "entry-examples",
						role: "group",
						"aria-label": "Example requests",
						children: m.map((e) => /* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							onClick: () => p(e),
							children: e
						}, e))
					}),
					/* @__PURE__ */ (0, A.jsxs)("span", {
						className: "ask-meta",
						children: [/* @__PURE__ */ (0, A.jsx)(ye, {
							text: f,
							period: c,
							periods: l
						}), /* @__PURE__ */ (0, A.jsx)(P, { text: f })]
					})
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("section", {
				className: "entry-how",
				"aria-label": "How it works",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "You ask" }), /* @__PURE__ */ (0, A.jsx)("span", { children: "Plain request" })] }),
					/* @__PURE__ */ (0, A.jsx)("b", {
						"aria-hidden": "true",
						children: "→"
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "hot",
						children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "Orchestrator" }), /* @__PURE__ */ (0, A.jsx)("span", { children: "Tool client · plans and calls" })]
					}),
					/* @__PURE__ */ (0, A.jsx)("b", {
						"aria-hidden": "true",
						children: "→"
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "Specialist agents" }), /* @__PURE__ */ (0, A.jsx)("span", { children: "Tool providers · typed tools" })] }),
					/* @__PURE__ */ (0, A.jsx)("b", {
						"aria-hidden": "true",
						children: "→"
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "Application layers" }), /* @__PURE__ */ (0, A.jsx)("span", { children: "Gateway · SAP integration · SAP · Databricks" })] })
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("ul", {
				className: "entry-cards",
				children: [
					d.tabs.map((e) => /* @__PURE__ */ (0, A.jsx)("li", { children: /* @__PURE__ */ (0, A.jsxs)("button", {
						type: "button",
						className: "entry-card",
						onClick: () => s?.(e.tab.id),
						"aria-label": `Open ${e.short_name}`,
						"data-module": e.id,
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								"aria-hidden": "true",
								children: e.icon
							}),
							/* @__PURE__ */ (0, A.jsx)("strong", { children: e.short_name }),
							/* @__PURE__ */ (0, A.jsx)("small", { children: e.blurb }),
							/* @__PURE__ */ (0, A.jsxs)("em", { children: [
								"Open ",
								e.short_name,
								" →"
							] })
						]
					}) }, e.id)),
					/* @__PURE__ */ (0, A.jsx)("li", { children: /* @__PURE__ */ (0, A.jsxs)("button", {
						type: "button",
						className: "entry-card",
						onClick: r,
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								"aria-hidden": "true",
								children: "◆"
							}),
							/* @__PURE__ */ (0, A.jsx)("strong", { children: "Watch the agents work" }),
							/* @__PURE__ */ (0, A.jsx)("small", { children: "See the orchestrator call each agent and which layers it reached." }),
							/* @__PURE__ */ (0, A.jsx)("em", { children: "Open Agents →" })
						]
					}) }),
					/* @__PURE__ */ (0, A.jsx)("li", { children: /* @__PURE__ */ (0, A.jsxs)("button", {
						type: "button",
						className: "entry-card",
						onClick: i,
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								"aria-hidden": "true",
								children: "⬡"
							}),
							/* @__PURE__ */ (0, A.jsx)("strong", { children: "Review the architecture" }),
							/* @__PURE__ */ (0, A.jsx)("small", { children: "Live run, the three scenarios (SAP-centric, AgentCore-centric, SAP-hosted hybrid), MCP hosting and diagrams." }),
							/* @__PURE__ */ (0, A.jsx)("em", { children: "Open Architecture →" })
						]
					}) })
				]
			}),
			s && /* @__PURE__ */ (0, A.jsxs)("section", {
				className: "entry-roles",
				"aria-label": "Start from your audience",
				children: [/* @__PURE__ */ (0, A.jsx)("h3", { children: "Presenting this? Start from your audience" }), /* @__PURE__ */ (0, A.jsx)("ul", { children: nn.map((e) => /* @__PURE__ */ (0, A.jsxs)("li", { children: [
					/* @__PURE__ */ (0, A.jsx)("strong", { children: e.name }),
					/* @__PURE__ */ (0, A.jsx)("small", { children: e.ask }),
					/* @__PURE__ */ (0, A.jsx)("div", {
						className: "role-links",
						children: e.links.map(([e, t]) => /* @__PURE__ */ (0, A.jsxs)("button", {
							type: "button",
							onClick: () => s(e),
							children: [t, " →"]
						}, e + t))
					})
				] }, e.id)) })]
			}),
			"    ",
			t && /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "entry-download",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "Run it on your laptop" }), /* @__PURE__ */ (0, A.jsxs)("span", { children: [
					"Windows bundle. Python is needed on first launch. ",
					Math.round(t.bytes / 1024),
					" KB · SHA-256 ",
					t.sha256.slice(0, 12),
					"…"
				] })] }), /* @__PURE__ */ (0, A.jsx)("a", {
					href: t.url,
					download: "finance_reconciliation_local_windows.zip",
					"aria-label": "Download local Windows demo bundle",
					children: "Download Windows bundle ↓"
				})]
			})
		]
	});
}
// src/liveArchitecture.js
var Xn = {
	w: 1200,
	h: 520
}, Zn = (e, t, n, r, i, a, o = {}) => ({
	id: e,
	row: t,
	col: n,
	title: r,
	sub: i,
	kind: a,
	...o
}), Qn = [
	["invoke", "Tool call"],
	["return", "Evidence"],
	["registry", "Reference"],
	["deploy", "Registration"],
	["identity", "Identity"],
	["approval", "Approval"]
], $n = [[
	92,
	"DESIGN TIME AND IDENTITY",
	"end"
], [
	322,
	"RESULT, EVIDENCE AND APPROVAL",
	"start"
]], er = {
	"Business entry": "agent",
	"Agent runtime": "domain",
	"Selected gateway": "gateway",
	"Domain MCP": "domain",
	"SAP BAIP": "integration",
	"SAP backends": "backend",
	"Enterprise Databricks": "data",
	"Future BDC": "data",
	"Model branch": "agent",
	"Design time and registration": "registry",
	"Agent controls": "identity",
	"Write approval": "decision"
}, tr = {
	"Design time and registration": [0, 0],
	"Agent controls": [0, 1],
	"Business entry": [1, 0],
	"Agent runtime": [1, 1],
	"Selected gateway": [1, 2],
	"Domain MCP": [1, 3],
	"SAP BAIP": [1, 4],
	"SAP backends": [1, 5],
	"Enterprise Databricks": [2, 3],
	"Future BDC": [2, 4],
	"Write approval": [2, 0],
	"Model branch": [2, 2]
};
function nr({ registry: e, events: t, scenario: n, selectedZone: r, liveRunning: i, reportReady: a, zoneShort: o }) {
	let s = e?.components || [], c = Object.fromEntries(s.map((e) => [e.component_id, e.zone])), l = (e) => s.filter((t) => t.zone === e).length, u = {};
	for (let e of t) {
		let t = c[e.direction === "response" ? e.source_component_id : e.target_component_id];
		t && (u[t] = (u[t] || 0) + 1);
	}
	let d = t.at(-1), f = d ? c[d.direction === "response" ? d.source_component_id : d.target_component_id] : null, p = i && f, m = Object.keys(tr).map((e) => {
		let [t, i] = tr[e], a = p && f === e, s = !!u[e], c = a ? "Processing now" : s ? `${u[e]} events` : e === "Future BDC" ? "Future / simulated" : e === "Write approval" ? "Separate branch" : "Waiting", d = e === "Selected gateway" ? `${n} · ${n === "S2" ? "AgentCore Gateway, then Apigee" : "Apigee"}` : `${e} · ${l(e)} components`;
		return Zn(e, t, i, o[e] || e, d, er[e], {
			zone: e,
			status: c,
			statusColor: a ? "#B45309" : s ? "#0D6A33" : "#506778",
			stroke: e === r ? "#0A6ED1" : a ? "#E9730C" : s ? "#107E3E" : void 0,
			strokeWidth: e === r ? 3.2 : a ? 3.4 : s ? 2 : void 0,
			dashed: e === "Future BDC",
			cls: a ? "node-current" : ""
		});
	});
	m.push(Zn("__report", 2, 1, "Business report", a ? "Analysis and evidence are ready" : "Run the architecture to generate the result", "control", {
		zone: "__report",
		status: a ? "Complete · open report" : "Awaiting run",
		statusColor: a ? "#0D6A33" : "#506778",
		stroke: a ? "#107E3E" : void 0,
		strokeWidth: a ? 2 : void 0
	}));
	let h = (e) => !!(p && f === e), g = [
		[
			"Business entry",
			"Agent runtime",
			"invoke",
			"business intent",
			{ active: h("Business entry") }
		],
		[
			"Agent runtime",
			"Selected gateway",
			"invoke",
			"MCP tool call",
			{ active: h("Agent runtime") }
		],
		[
			"Selected gateway",
			"Domain MCP",
			"invoke",
			"authorized call",
			{ active: h("Selected gateway") }
		],
		[
			"Domain MCP",
			"SAP BAIP",
			"invoke",
			"typed SAP request",
			{ active: h("Domain MCP") }
		],
		[
			"SAP BAIP",
			"SAP backends",
			"invoke",
			"backend read",
			{ active: h("SAP BAIP") }
		],
		[
			"Domain MCP",
			"Enterprise Databricks",
			"invoke",
			"data evidence",
			{ active: h("Enterprise Databricks") }
		],
		[
			"Enterprise Databricks",
			"Future BDC",
			"registry",
			"future reference"
		],
		[
			"Design time and registration",
			"Agent runtime",
			"deploy",
			"agent registration",
			{ off: -34 }
		],
		[
			"Agent controls",
			"Agent runtime",
			"identity",
			"agent identity"
		],
		[
			"SAP backends",
			"Model branch",
			"return",
			"SAP evidence",
			{ labelAt: "mid" }
		],
		[
			"Enterprise Databricks",
			"Model branch",
			"return",
			"data evidence",
			{ straight: !0 }
		],
		[
			"Model branch",
			"__report",
			"return",
			"deterministic result",
			{ straight: !0 }
		],
		[
			"__report",
			"Write approval",
			"approval",
			"separate write branch"
		]
	];
	return St({
		cols: 6,
		ys: [
			100,
			214,
			334
		],
		nh: 80,
		height: Xn.h,
		nodes: m,
		edges: g,
		bounds: [[
			"SAP landscape",
			["SAP BAIP", "SAP backends"],
			"sap"
		]],
		captions: $n,
		legend: Qn,
		title: `Live run (simulator) · ${(z[n] || z.S1).name}`,
		chain: "Finance request → external agent → selected gateway → domain tools → SAP integration → SAP backend",
		banner: p ? "RUN IN PROGRESS · SIMULATED" : "SIMULATED · NO TENANT CONNECTED",
		footer: "Simulator scope: the agent runtime zone stands for Cloud Foundry (S1, S3) or AgentCore Runtime (S2). S2 passes AgentCore Gateway and then Apigee; S1 and S3 call Apigee directly (S3 registration is not on the call path). The full topology is in Diagrams D2 to D4. Orange: processing now. Green: visited. Blue: selected zone."
	});
}
// src/AgentJourney.jsx
var rr = [
	{
		label: "Finance intent",
		operation: "submit_request",
		doneDirection: "request",
		success: "Accepted",
		description: "Request accepted"
	},
	{
		label: "External agent",
		operation: "invoke_agent",
		doneDirection: "request",
		success: "Invoked",
		description: "Bounded plan invoked"
	},
	{
		label: "SAP tool call",
		operation: "read_sap",
		doneDirection: "request",
		success: "Called",
		description: "Read requested through gateway"
	},
	{
		label: "SAP evidence",
		operation: "sap_read",
		doneDirection: "response",
		success: "Returned",
		description: "Source response returned"
	},
	{
		label: "Reconciliation",
		operation: "calculate_variance",
		doneDirection: "response",
		success: "Verified",
		description: "Deterministic check completed"
	}
];
function ir({ events: e = [], running: t = !1, selectedZone: n, onOpenEvidence: r }) {
	let i = rr.map((t) => {
		let n = e.filter((e) => e.operation === t.operation), r = n.findLast((e) => e.direction === t.doneDirection && e.status !== "denied"), i = n.findLast((e) => e.status === "denied");
		return {
			...t,
			event: r || i || n.at(-1),
			state: i && !r ? "held" : r ? "complete" : n.length ? "working" : "waiting"
		};
	});
	return /* @__PURE__ */ (0, A.jsxs)("section", {
		className: "surface agent-journey",
		"aria-label": "External agent and SAP journey",
		children: [/* @__PURE__ */ (0, A.jsxs)("div", {
			className: "agent-journey-heading",
			children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
				className: "eyebrow",
				children: "EXTERNAL AGENT → SAP · SYNTHETIC FLOW"
			}), /* @__PURE__ */ (0, A.jsx)("strong", { children: n })] }), /* @__PURE__ */ (0, A.jsx)("button", {
				type: "button",
				onClick: r,
				children: "Inspect event proof in Evidence →"
			})]
		}), /* @__PURE__ */ (0, A.jsx)("div", {
			className: "agent-journey-stages",
			children: i.map((e, n) => /* @__PURE__ */ (0, A.jsxs)("div", {
				className: `agent-journey-stage ${e.state}`,
				children: [
					/* @__PURE__ */ (0, A.jsxs)("span", { children: [
						String(n + 1).padStart(2, "0"),
						" · ",
						e.label
					] }),
					/* @__PURE__ */ (0, A.jsx)("strong", { children: e.state === "complete" ? e.success : e.state === "held" ? "Held" : e.state === "working" ? "Processing" : e.description }),
					/* @__PURE__ */ (0, A.jsx)("small", { children: e.event ? `Recorded event #${e.event.seq}` : t ? "Awaiting handoff" : "No event yet" })
				]
			}, e.operation))
		})]
	});
}
// src/App.jsx
var ar = {
	"Business entry": "Finance request",
	"Design time and registration": "Agent registration",
	"Agent runtime": "External finance agent",
	"Agent controls": "Agent identity",
	"Selected gateway": "Agent gateway",
	"Domain MCP": "Domain tools",
	"SAP BAIP": "SAP integration",
	"SAP backends": "SAP finance",
	"Enterprise Databricks": "Data evidence",
	"Future BDC": "BDC reference",
	"Model branch": "AI advisory",
	"Write approval": "Approval"
}, or = [
	["FI", "Variance operands, freshness, posting controls"],
	["SAP", "Backend roles and approved APIs"],
	["Central Finance", "Replication mapping and cutoff"],
	["BW/4HANA", "Aggregate context and load state"],
	["Integration", "BAIP, destinations and identity"],
	["Apigee", "SAP-facing MCP/API policy, routing and audit (S1, S2, S3)"],
	["AWS", "AgentCore Gateway and runtime identity (S2); Agent Registry (S2, S3)"],
	["Databricks", "Unity Catalog and Delta evidence"],
	["BDC", "Future sharing boundary"],
	["Portkey / AI", "Redaction, guardrails and advisory text"],
	["Node.js / Python", "Typed UI contracts and deterministic engine"],
	["UX", "Task clarity, accessibility and trace readability"]
], sr = (e) => {
	if (!e) return "Select month";
	let [t, n] = e.split("-").map(Number);
	return new Date(Date.UTC(t, n - 1, 1)).toLocaleString("en-US", {
		month: "short",
		year: "numeric",
		timeZone: "UTC"
	});
}, cr = (e) => e == null ? "—" : new Intl.NumberFormat("en-US", {
	style: "currency",
	currency: "USD",
	maximumFractionDigits: 0
}).format(Number(e));
async function U(e, t = "GET", n) {
	let r = await fetch(e, {
		method: t,
		headers: { "Content-Type": "application/json" },
		body: n ? JSON.stringify(n) : void 0
	}), i;
	try {
		i = await r.json();
	} catch {
		i = { detail: r.statusText };
	}
	if (!r.ok) throw Error(i.detail || r.statusText);
	return i;
}
function lr(e, t) {
	if (e.error) return [];
	let n = e.case_id || t?.case_id || null, r = e.trace_case_id || n, i = !!(e.result || t?.result), a = [];
	return i && (a.push({
		label: "View reconciliation report",
		target: "report",
		caseId: n
	}), a.push({
		label: "Inspect source evidence",
		target: "finance",
		caseId: n
	})), r && a.push({
		label: "Follow component flow",
		target: "architecture",
		caseId: n,
		traceId: r
	}), (e.status === "limited" || e.status === "needs_scope") && a.push({
		label: "Open architecture questions",
		target: "questions"
	}), a.length || a.push({
		label: "Open close worklist",
		target: "business"
	}), a;
}
function ur({ menuModules: e = [], open: t, onToggle: n, onNavigate: r }) {
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "shell-menu-wrap",
		children: [/* @__PURE__ */ (0, A.jsxs)("button", {
			type: "button",
			className: "shell-menu-trigger",
			onClick: n,
			"aria-label": "Open application menu",
			"aria-expanded": t,
			"aria-controls": "finance-app-menu",
			children: [/* @__PURE__ */ (0, A.jsx)("span", {
				"aria-hidden": "true",
				children: "▦"
			}), /* @__PURE__ */ (0, A.jsx)("span", { children: "Menu" })]
		}), t && /* @__PURE__ */ (0, A.jsxs)("div", {
			id: "finance-app-menu",
			className: "shell-menu-popover",
			role: "menu",
			"aria-label": "Finance application menu",
			children: [
				/* @__PURE__ */ (0, A.jsx)("strong", { children: "Finance workspace" }),
				/* @__PURE__ */ (0, A.jsxs)("button", {
					type: "button",
					role: "menuitem",
					onClick: () => r("launchpad"),
					children: ["⌂ ", /* @__PURE__ */ (0, A.jsx)("span", { children: "My Home" })]
				}),
				/* @__PURE__ */ (0, A.jsxs)("button", {
					type: "button",
					role: "menuitem",
					onClick: () => r("business"),
					children: ["▤ ", /* @__PURE__ */ (0, A.jsx)("span", { children: "Close worklist" })]
				}),
				e.filter((e) => e.tab && e.tab.id !== "business").map((e) => /* @__PURE__ */ (0, A.jsxs)("button", {
					type: "button",
					role: "menuitem",
					onClick: () => r(e.tab.id),
					children: [
						e.icon,
						" ",
						/* @__PURE__ */ (0, A.jsx)("span", { children: e.short_name })
					]
				}, e.id)),
				/* @__PURE__ */ (0, A.jsxs)("button", {
					type: "button",
					role: "menuitem",
					onClick: () => r("architecture"),
					children: ["⇄ ", /* @__PURE__ */ (0, A.jsx)("span", { children: "Live architecture" })]
				}),
				/* @__PURE__ */ (0, A.jsxs)("button", {
					type: "button",
					role: "menuitem",
					onClick: () => r("approaches"),
					children: ["⇌ ", /* @__PURE__ */ (0, A.jsx)("span", { children: "Complete architecture" })]
				}),
				/* @__PURE__ */ (0, A.jsxs)("button", {
					type: "button",
					role: "menuitem",
					onClick: () => r("agent"),
					children: ["✦ ", /* @__PURE__ */ (0, A.jsx)("span", { children: "Ask Finance Agent" })]
				})
			]
		})]
	});
}
var dr = (e) => `${Number(e) > 0 ? "+" : Number(e) < 0 ? "−" : ""}${cr(Math.abs(Number(e || 0)))}`;
function fr({ summary: e, state: t, period: n, onOpenDetail: r, onAsk: i, onRun: a }) {
	if (t === "none") return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "period-nodata",
		role: "alert",
		"data-testid": "level1-nodata",
		children: ["NO DATA AVAILABLE FOR ", C(n).toUpperCase()]
	});
	if (!e) return /* @__PURE__ */ (0, A.jsx)("div", {
		className: "empty-state",
		role: "status",
		children: /* @__PURE__ */ (0, A.jsxs)("strong", { children: [
			"Loading ",
			C(n),
			"…"
		] })
	});
	let o = e.summary, s = e.matching.totals, c = e.matching.rows.filter((e) => e.status.startsWith("UNMATCHED")).length, l = o.status === "BALANCED" || o.status === "WITHIN_TOLERANCE" ? "ok" : o.status === "EXCEPTION" ? "bad" : o.status === "HOLD" ? "warn" : "";
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "period-panel",
		"data-testid": "period-panel",
		"data-period": e.period,
		children: [
			/* @__PURE__ */ (0, A.jsx)(xe, {
				provenance: e.provenance,
				compact: !0
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: `pp-status ${l}`,
				children: [
					/* @__PURE__ */ (0, A.jsx)("strong", { children: o.status.replace("_", " ") }),
					" · ",
					o.status_text
				]
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "pp-kpis",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [
						/* @__PURE__ */ (0, A.jsx)("span", { children: "Company · ledger" }),
						/* @__PURE__ */ (0, A.jsxs)("strong", { children: [
							e.company_code,
							" · ",
							e.ledger
						] }),
						/* @__PURE__ */ (0, A.jsxs)("small", { children: [
							e.currency,
							" · FY",
							e.fiscal.year,
							" P",
							String(e.fiscal.period).padStart(2, "0")
						] })
					] }),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: o.variance ? "attn" : "",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Variance" }),
							/* @__PURE__ */ (0, A.jsx)("strong", {
								"data-testid": "level1-variance",
								children: dr(o.variance)
							}),
							/* @__PURE__ */ (0, A.jsx)("small", { children: "S/4HANA − Central Finance · positive means S/4HANA is higher" })
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Source balance (S/4HANA)" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: cr(o.s4_total) })] }),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Target balance (Central Finance)" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: cr(o.cfin_total) })] }),
					/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Matched items" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: s.matched_count })] }),
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: s.exception_count ? "attn" : "",
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", { children: "Unmatched · exceptions" }),
							/* @__PURE__ */ (0, A.jsxs)("strong", { children: [
								c,
								" · ",
								s.exception_count
							] }),
							/* @__PURE__ */ (0, A.jsxs)("small", { children: ["Unexplained ", cr(o.unexplained)] })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, A.jsx)("div", {
				className: "pp-actions",
				children: /* @__PURE__ */ (0, A.jsx)("button", {
					type: "button",
					className: "primary",
					onClick: r,
					children: "Open detailed reconciliation →"
				})
			}),
			/* @__PURE__ */ (0, A.jsxs)("details", {
				className: "close-process",
				children: [
					/* @__PURE__ */ (0, A.jsx)("summary", { children: "Who does what in the close" }),
					/* @__PURE__ */ (0, A.jsx)("ol", { children: rn.map(([e, t, n]) => /* @__PURE__ */ (0, A.jsxs)("li", { children: [
						/* @__PURE__ */ (0, A.jsx)("b", { children: e }),
						/* @__PURE__ */ (0, A.jsx)("em", { children: t }),
						/* @__PURE__ */ (0, A.jsx)("small", { children: n })
					] }, e)) }),
					/* @__PURE__ */ (0, A.jsxs)("p", { children: [
						/* @__PURE__ */ (0, A.jsx)("strong", { children: "Controls:" }),
						" ",
						an.join(" · "),
						"."
					] })
				]
			})
		]
	});
}
var pr = [
	"architecture",
	"approaches",
	"mcp",
	"agenthost",
	"registry",
	"brief",
	"ontology",
	"diagrams"
];
function mr({ result: e, onOpenEvidence: t, onRunCurrent: n, onOpenDetail: r, period: i, summary: a, summaryState: o, onAskPeriod: s }) {
	return e?.scope?.period === i && e?.variance, /* @__PURE__ */ (0, A.jsxs)("section", {
		className: "surface business-result",
		children: [/* @__PURE__ */ (0, A.jsxs)("div", {
			className: "section-heading",
			children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
				className: "eyebrow",
				children: "MONTH-END RECONCILIATION"
			}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "Selected period" })] }), /* @__PURE__ */ (0, A.jsxs)("span", {
				className: "pill quiet",
				"data-testid": "level1-period",
				children: [
					sr(i),
					" · ",
					T(i)
				]
			})]
		}), /* @__PURE__ */ (0, A.jsx)(fr, {
			summary: a,
			state: o,
			period: i,
			onOpenDetail: r,
			onAsk: s,
			onRun: n
		})]
	});
}
function hr({ caseRecord: e, onClose: t, onOpenEvidence: n }) {
	let r = (0, _.useRef)(null), i = e?.result, a = i?.variance;
	return (0, _.useEffect)(() => {
		let e = r.current;
		return e?.showModal(), () => {
			e?.open && e.close();
		};
	}, []), /* @__PURE__ */ (0, A.jsxs)("dialog", {
		ref: r,
		className: "business-report-dialog",
		"aria-labelledby": "business-report-title",
		onClose: t,
		children: [
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "business-report-header",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
					/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "SYNTHETIC MONTH-END RECONCILIATION"
					}),
					/* @__PURE__ */ (0, A.jsx)("h2", {
						id: "business-report-title",
						children: "Business analysis report"
					}),
					/* @__PURE__ */ (0, A.jsx)("p", { children: i ? `${sr(i.scope?.period)} · ${i.scenario} · ${i.case_id}` : "No completed case selected" })
				] }), /* @__PURE__ */ (0, A.jsx)("button", {
					type: "button",
					onClick: t,
					"aria-label": "Close business report",
					children: "×"
				})]
			}),
			a ? /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "business-report-body",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("div", {
						className: "business-report-summary",
						children: [
							/* @__PURE__ */ (0, A.jsxs)("div", { children: [
								/* @__PURE__ */ (0, A.jsx)("span", { children: "Variance" }),
								/* @__PURE__ */ (0, A.jsx)("strong", { children: a.amount === null ? "Not comparable" : cr(a.amount) }),
								/* @__PURE__ */ (0, A.jsx)("small", { children: "S/4HANA − Central Finance" })
							] }),
							/* @__PURE__ */ (0, A.jsxs)("div", { children: [
								/* @__PURE__ */ (0, A.jsx)("span", { children: "Result state" }),
								/* @__PURE__ */ (0, A.jsx)("strong", { children: a.state.toUpperCase() }),
								/* @__PURE__ */ (0, A.jsx)("small", { children: a.state === "comparable" ? "Sources are comparable" : "Source review required" })
							] }),
							/* @__PURE__ */ (0, A.jsxs)("div", { children: [
								/* @__PURE__ */ (0, A.jsx)("span", { children: "Period" }),
								/* @__PURE__ */ (0, A.jsx)("strong", { children: sr(i.scope?.period) }),
								/* @__PURE__ */ (0, A.jsxs)("small", { children: [i.scenario, " synthetic route"] })
							] })
						]
					}),
					/* @__PURE__ */ (0, A.jsxs)("section", { children: [
						/* @__PURE__ */ (0, A.jsx)("h3", { children: "Business conclusion" }),
						/* @__PURE__ */ (0, A.jsx)("p", { children: i.advisory_explanation }),
						/* @__PURE__ */ (0, A.jsx)("p", { children: "The calculation is deterministic. Review the supporting records before proposing any variance marker." })
					] }),
					/* @__PURE__ */ (0, A.jsx)("p", {
						className: "business-report-note",
						children: "Synthetic local data only. This report does not post to SAP or prove live system authorization."
					})
				]
			}) : /* @__PURE__ */ (0, A.jsx)("div", {
				className: "business-report-body",
				children: /* @__PURE__ */ (0, A.jsxs)("div", {
					className: "empty-state",
					children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "No completed report yet" }), /* @__PURE__ */ (0, A.jsx)("p", { children: "Run the architecture for a synthetic month-end period, then open Business report again to inspect the calculated result and evidence." })]
				})
			}),
			/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "business-report-actions",
				children: [i && /* @__PURE__ */ (0, A.jsx)("button", {
					type: "button",
					onClick: () => {
						t(), n();
					},
					children: "Inspect source records in Evidence →"
				}), /* @__PURE__ */ (0, A.jsx)("button", {
					type: "button",
					className: "primary",
					onClick: t,
					children: "Close"
				})]
			})
		]
	});
}
function gr({ registry: e, events: t, scenario: n, selectedZone: r, onZone: i, liveRunning: a, reportReady: o, onOpenReport: s }) {
	let [c, l] = (0, _.useState)(null), [u, d] = (0, _.useState)(!1), f = (0, _.useMemo)(() => nr({
		registry: e,
		events: t,
		scenario: n,
		selectedZone: r,
		liveRunning: a,
		reportReady: o,
		zoneShort: ar
	}), [
		e,
		t,
		n,
		r,
		a,
		o
	]), p = (0, _.useMemo)(() => ({
		id: "live",
		title: `Live run (simulator) · ${n}`,
		svg: f,
		w: Xn.w,
		h: Xn.h,
		file: "live-architecture",
		png: !0
	}), [f, n]);
	return /* @__PURE__ */ (0, A.jsx)("div", {
		className: "route-viewer",
		"aria-label": "Live architecture topology",
		children: /* @__PURE__ */ (0, A.jsx)(V, {
			diagram: p,
			uid: "live-arch",
			view: c,
			onView: l,
			onFit: l,
			expanded: u,
			onExpand: d,
			onPick: (e) => e === "__report" ? s() : i(e)
		})
	});
}
function _r({ registry: e, zone: t, events: n, selectedComponent: r, onComponent: i, scenario: a }) {
	let o = (e?.components || []).filter((e) => e.zone === t), s = (0, _.useMemo)(() => {
		let e = {};
		for (let t of n) {
			let n = t.direction === "response" ? t.source_component_id : t.target_component_id;
			e[n] = t;
		}
		return e;
	}, [n]), c = o.find((e) => e.component_id === r) || o[0], l = c && s[c.component_id];
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "detail-layout",
		children: [/* @__PURE__ */ (0, A.jsxs)("section", {
			className: "surface component-panel",
			children: [/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "section-heading",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
					className: "eyebrow",
					children: "COMPONENT LAYER"
				}), /* @__PURE__ */ (0, A.jsx)("h2", { children: t })] }), /* @__PURE__ */ (0, A.jsxs)("span", {
					className: "pill quiet",
					children: [o.length, " nodes"]
				})]
			}), /* @__PURE__ */ (0, A.jsx)("div", {
				className: "component-grid",
				children: o.map((e) => {
					let t = s[e.component_id], n = e.runtime_state === "scenario_s1" && a === "S2" || e.runtime_state === "scenario_s2" && a === "S1", r = n ? `INACTIVE IN ${a}` : e.runtime_state === "future" ? "FUTURE" : e.runtime_state === "inactive" ? "INACTIVE" : t?.direction === "request" ? "PROCESSING" : t ? "RETURNED" : "READY";
					return /* @__PURE__ */ (0, A.jsxs)("button", {
						type: "button",
						onClick: () => i(e.component_id),
						className: `component-tile ${c?.component_id === e.component_id ? "selected" : ""} ${r === "PROCESSING" ? "working" : ""} ${n ? "skipped" : ""}`,
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "component-type",
								children: e.classification
							}),
							/* @__PURE__ */ (0, A.jsx)("strong", { children: e.display_name }),
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: `component-state ${r === "RETURNED" ? "ok" : r === "PROCESSING" ? "busy" : ""}`,
								children: r
							}),
							t && /* @__PURE__ */ (0, A.jsxs)("small", { children: [
								t.operation.replaceAll("_", " "),
								" · ",
								t.direction
							] })
						]
					}, e.component_id);
				})
			})]
		}), /* @__PURE__ */ (0, A.jsxs)("aside", {
			className: "surface inspector",
			children: [/* @__PURE__ */ (0, A.jsx)("span", {
				className: "eyebrow",
				children: "ARCHITECT INSPECTOR"
			}), c ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
				/* @__PURE__ */ (0, A.jsx)("h2", { children: c.display_name }),
				/* @__PURE__ */ (0, A.jsx)("p", { children: c.purpose }),
				/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "inspector-row",
					children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Owner" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: c.owner })]
				}),
				/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "inspector-row",
					children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Boundary" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: c.trust_boundary })]
				}),
				/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "inspector-row",
					children: [/* @__PURE__ */ (0, A.jsx)("span", { children: "Contract" }), /* @__PURE__ */ (0, A.jsx)("strong", { children: c.request_schema })]
				}),
				/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "inspector-block",
					children: [/* @__PURE__ */ (0, A.jsx)("span", {
						className: "eyebrow",
						children: "LATEST COMPONENT MESSAGE"
					}), l ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [/* @__PURE__ */ (0, A.jsxs)("p", {
						className: "message-operation",
						children: [
							l.operation.replaceAll("_", " "),
							" · ",
							l.direction,
							" · ",
							l.status
						]
					}), /* @__PURE__ */ (0, A.jsx)("pre", { children: JSON.stringify(l.payload_summary || {}, null, 2) })] }) : /* @__PURE__ */ (0, A.jsx)("p", {
						className: "micro",
						children: "Run a question to see this component's bounded input and output."
					})]
				}),
				/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "validation-note",
					children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "Live validation still required" }), /* @__PURE__ */ (0, A.jsx)("p", { children: c.remaining_live_vendor_validation })]
				})
			] }) : /* @__PURE__ */ (0, A.jsx)("p", { children: "Select a component." })]
		})]
	});
}
function vr({ bridge: e }) {
	let t = !!e, [n, r] = (0, _.useState)(e?.data || null), i = (0, _.useMemo)(() => ee((t ? e?.data?.modules : n?.modules) || []), [
		t,
		e?.data?.modules,
		n?.modules
	]), [a, o] = (0, _.useState)("business"), [s, c] = (0, _.useState)("D1"), [l, u] = (0, _.useState)("S1"), [d, f] = (0, _.useState)(e?.data?.conditions || []), [p, m] = (0, _.useState)(e?.data?.agents || null), [h, g] = (0, _.useState)(e?.data?.agent_plan || null), [v, y] = (0, _.useState)(!1), [b, x] = (0, _.useState)(null), [w, T] = (0, _.useState)(() => {
		try {
			return localStorage.getItem("finance.showTech") === "1";
		} catch {
			return !1;
		}
	}), E = (0, _.useRef)("approaches"), [D, te] = (0, _.useState)(null), [re, ie] = (0, _.useState)(null), [ae, oe] = (0, _.useState)("launchpad"), se = (0, _.useRef)("business"), [ce, j] = (0, _.useState)(!1), [le, ue] = (0, _.useState)(!1), [de, fe] = (0, _.useState)(null), [pe, he] = (0, _.useState)(null), [ge, _e] = (0, _.useState)({
		section: "proof",
		nonce: 0
	}), [ve, M] = (0, _.useState)(!1), [ye, be] = (0, _.useState)("S1"), [P, xe] = (0, _.useState)(O), F = (0, _.useRef)(0), Ce = (0, _.useRef)(0), we = (0, _.useCallback)((e) => {
		S(e) && (F.current += 1, xe(e), k(e));
	}, []), [Te, Ee] = (0, _.useState)(60), [De, ke] = (0, _.useState)(""), [Ae, je] = (0, _.useState)("Reconcile the selected synthetic period"), [Me, Ne] = (0, _.useState)([{
		role: "assistant",
		text: "Ask about a reconciliation, the source evidence, an architecture component, or a control. Each answer has an inspectable synthetic flow."
	}]), [I, Pe] = (0, _.useState)(null), [Fe, Le] = (0, _.useState)(null), [Re, Ve] = (0, _.useState)([]), [He, Ue] = (0, _.useState)(!1), [We, Ge] = (0, _.useState)("Business entry"), [Ke, qe] = (0, _.useState)(null), [Je, Xe] = (0, _.useState)(null), [Ze, Qe] = (0, _.useState)(null), [L, et] = (0, _.useState)(!1), [tt, R] = (0, _.useState)(""), [nt, z] = (0, _.useState)([]), [rt, it] = (0, _.useState)([]), [at, ot] = (0, _.useState)(null), [st, ct] = (0, _.useState)(e?.data?.investigation || null), [lt, ut] = (0, _.useState)([]), [dt, ft] = (0, _.useState)(!1), [pt, mt] = (0, _.useState)("maker"), [ht, gt] = (0, _.useState)(!1), [_t, vt] = (0, _.useState)(e?.data?.decision_run || null), [yt, bt] = (0, _.useState)(!1), B = (0, _.useRef)(!1), xt = (0, _.useRef)(null), St = (0, _.useRef)(null), Ct = (0, _.useRef)(null), wt = (0, _.useRef)(null), Tt = n?.architecture, Et = n?.history, [Dt, Ot] = (0, _.useState)(null);
	(0, _.useEffect)(() => {
		if (t) return;
		let e = !1;
		return Ot(null), U(`/api/reports/${P}`).then((t) => {
			e || Ot({
				period: P,
				report: t
			});
		}).catch((t) => {
			e || Ot({
				period: P,
				error: t.message
			});
		}), () => {
			e = !0;
		};
	}, [
		t,
		P,
		Et,
		I?.case_id,
		I?.status
	]), (0, _.useEffect)(() => {
		t && e.action({
			type: "select_period",
			period: P
		});
	}, [t, P]);
	let kt = t ? e?.data?.period_report?.period === P ? e.data.period_report : null : Dt?.period === P && Dt.report || null, [At, jt] = (0, _.useState)(null), [Mt, Nt] = (0, _.useState)(0), [V, Ft] = (0, _.useState)({}), It = i.tabs.find((e) => e.tab.id === a && e.renderer !== "builtin:reconciliation") || null, Lt = It?.has_view ? It.id : At ? "treasury" : null;
	(0, _.useEffect)(() => {
		if (t || !Lt) return;
		let e = !1;
		return U(`/api/cockpit/${Lt}/view/${P}`).then((t) => {
			e || Ft((e) => ({
				...e,
				[Lt]: {
					period: P,
					view: t
				}
			}));
		}).catch((t) => {
			e || Ft((e) => ({
				...e,
				[Lt]: {
					period: P,
					error: t.message
				}
			}));
		}), () => {
			e = !0;
		};
	}, [
		t,
		P,
		Lt,
		Mt
	]);
	let zt = (n) => t ? e?.data?.module_views?.[n]?.period === P ? e.data.module_views[n] : null : V[n]?.period === P && V[n].view || null, Bt = (e) => zt(e) ? "ok" : Et?.available_periods && !Et.available_periods.includes(P) || !t && V[e]?.period === P && V[e].error ? "none" : "loading", Vt = zt("treasury");
	async function Ht(n, r) {
		if (pt !== "approver") {
			R("Switch to the finance approver role first.");
			return;
		}
		R("");
		let i = {
			proposal_id: n.proposal_id,
			approved: r,
			payload_hash: n.payload_hash
		};
		if (t) e.action({
			type: "module_action",
			module: "treasury",
			name: "decide",
			payload: i,
			role: pt
		});
		else try {
			await U("/api/cockpit/treasury/action/decide", "POST", {
				...i,
				approver_id: "finance.approver"
			}), Nt((e) => e + 1);
		} catch (e) {
			R(e.message);
		}
	}
	let [H, Ut] = (0, _.useState)(e?.data?.ontology || null), [Wt, Gt] = (0, _.useState)(null);
	(0, _.useEffect)(() => {
		t ? e?.data?.ontology && Ut(e.data.ontology) : H || U("/api/cockpit/ontology").then(Ut).catch(() => {});
	}, [t, e?.data?.ontology]);
	let Kt = Object.values(p?.domains || {}).flatMap((e) => e.references || []);
	function Jt(e) {
		Gt(e), o("ontology");
	}
	let Yt = (e) => {
		let t = h;
		if (!t || t.domain !== e || t.status !== "done" || !t.effective_period || t.effective_period !== P) return null;
		let n = String(t.answer || "");
		return /* @__PURE__ */ (0, A.jsxs)("div", {
			className: "surface agent-run-banner",
			"data-testid": "agent-run-banner",
			children: [
				/* @__PURE__ */ (0, A.jsxs)("span", {
					className: "eyebrow",
					children: ["LATEST AGENT RUN · ", C(t.effective_period).toUpperCase()]
				}),
				/* @__PURE__ */ (0, A.jsxs)("span", {
					className: "arb-text",
					children: [n.slice(0, 180), n.length > 180 ? "…" : ""]
				}),
				/* @__PURE__ */ (0, A.jsx)("button", {
					type: "button",
					onClick: () => o("agents"),
					children: "View agent run →"
				})
			]
		});
	};
	function Zt(e, t) {
		let n = i.byId[e.domain];
		if (!n) return;
		let r = e.effective_period;
		r && r !== P && we(r), t === "detail" && n.renderer === "builtin:reconciliation" ? (o("business"), un(r || P)) : t === "detail" && n.renderer === "treasury" ? (o("treasury"), jt("position")) : n.tab && o(n.tab.id);
	}
	let Qt = Et?.available_periods, $t = kt ? "ok" : Qt && !Qt.includes(P) || !t && Dt?.period === P && Dt.error ? "none" : "loading", en = rt.find((e) => e.case_id === I?.case_id);
	(0, _.useEffect)(() => {
		(a === "business" || a === "agents" || pr.includes(a) || i.tabs.some((e) => e.tab.id === a)) && (se.current = a);
	}, [a]), (0, _.useEffect)(() => {
		let e = I?.scope?.period;
		!t && e && U(`/api/history/${e}`).then(ot).catch(() => ot(null));
	}, [t, I?.scope?.period]);
	let nn = Ze === null ? Re : Re.slice(0, Ze + 1), rn = Je || nn.at(-1), an = rn ? rn.direction === "response" ? rn.source_component_id : rn.target_component_id : null, on = Tt?.components?.find((e) => e.component_id === an)?.zone;
	(0, _.useEffect)(() => {
		if (!t) return Promise.all([U("/api/bootstrap"), U("/api/proposals")]).then(([e, t]) => {
			r(e), z(e.cases || []), it(t);
		}).catch((e) => R(e.message)), () => {
			xt.current?.close();
		};
	}, [t]), (0, _.useEffect)(() => {
		if (!t) return;
		let n = e.data || {};
		r((e) => ({
			...e,
			...n
		})), z(n.cases || []), it(n.proposals || []), ot(n.history_detail || null), ct(n.investigation || null), ut(n.investigation_events || []), vt(n.decision_run || null), n.decision_run?.status === "complete" && bt(!1), n.active_case && (Pe(n.active_case), Le(n.active_case.case_id), be(n.active_case.scenario)), n.events && Ve(n.events), Ue(n.active_case?.status === "queued" || n.active_case?.status === "running"), n.response && n.response_nonce !== wt.current && (wt.current = n.response_nonce, B.current = !1, gt(!1), ft(!1), Ne((e) => [...e, {
			role: "assistant",
			text: n.response.answer || n.response.error || "The synthetic operation completed.",
			limited: n.response.status === "limited",
			actions: lr(n.response, n.active_case || I)
		}]), n.response.error && R(n.response.error));
	}, [t, e?.data]), (0, _.useEffect)(() => {
		if (t || !st?.investigation_id || !["running", "reconciling"].includes(st.status)) return;
		let e = !1, n = setInterval(async () => {
			try {
				let [t, n] = await Promise.all([U(`/api/investigations/${st.investigation_id}`), U(`/api/architecture/events?case_id=${encodeURIComponent(st.case_id)}`)]);
				e || (ct(t), ut(n), Le(t.case_id), Ve(n));
			} catch (t) {
				e || R(t.message);
			}
		}, 350);
		return () => {
			e = !0, clearInterval(n);
		};
	}, [
		t,
		st?.investigation_id,
		st?.status
	]), (0, _.useEffect)(() => {
		!t && a === "evidence" && st?.case_id && U(`/api/architecture/events?case_id=${encodeURIComponent(st.case_id)}`).then(ut).catch((e) => R(e.message));
	}, [
		t,
		a,
		st?.case_id,
		st?.status
	]), (0, _.useEffect)(() => {
		if (t || !_t?.run_id || _t.status === "complete") return;
		let e = !1, n = setInterval(async () => {
			try {
				let t = await U(`/api/architecture/questions/runs/${encodeURIComponent(_t.run_id)}`);
				e || (vt(t), t.status === "complete" && bt(!1));
			} catch (t) {
				e || (R(t.message), bt(!1));
			}
		}, 350);
		return () => {
			e = !0, clearInterval(n);
		};
	}, [
		t,
		_t?.run_id,
		_t?.status
	]), (0, _.useEffect)(() => {
		if (!L || !Re.length) return;
		let e = setInterval(() => Qe((e) => {
			let t = (e ?? -1) + 1;
			return t >= Re.length ? (et(!1), Re.length - 1) : t;
		}), 140);
		return () => clearInterval(e);
	}, [L, Re.length]), (0, _.useEffect)(() => {
		Ct.current && (Ct.current.scrollTop = Ct.current.scrollHeight);
	}, [Me]), (0, _.useEffect)(() => {
		if (!ce) return;
		let e = (e) => {
			e.key === "Escape" && j(!1);
		};
		return window.addEventListener("keydown", e), document.getElementById("chat-question")?.focus(), () => window.removeEventListener("keydown", e);
	}, [ce]), (0, _.useEffect)(() => {
		if (!le) return;
		let e = (e) => {
			e.target.closest(".shell-menu-wrap") || ue(!1);
		}, t = (e) => {
			e.key === "Escape" && ue(!1);
		};
		return document.addEventListener("pointerdown", e), window.addEventListener("keydown", t), () => {
			document.removeEventListener("pointerdown", e), window.removeEventListener("keydown", t);
		};
	}, [le]), (0, _.useEffect)(() => {
		on && Ze === null && Ge(on);
	}, [on, Ze]), (0, _.useEffect)(() => {
		de && I?.case_id === de && (fe(null), M(!0));
	}, [de, I?.case_id]);
	async function sn(n) {
		if (t) {
			e.action({
				type: "load_case",
				case_id: n
			});
			return;
		}
		let r = F.current, [i, a, o] = await Promise.all([
			U(`/api/cases/${encodeURIComponent(n)}`),
			U(`/api/architecture/events?case_id=${encodeURIComponent(n)}`),
			U(`/api/investigations?case_id=${encodeURIComponent(n)}`)
		]);
		Pe(i), ct(o[0] || null), Le(n), be(i.scenario), r === F.current && i.scope?.period && i.scope.period !== P && we(i.scope.period), Ve(a), Qe(null), Xe(null);
	}
	function cn(e) {
		xt.current?.close();
		let t = new EventSource(`/api/architecture/runs/${encodeURIComponent(e)}/stream`);
		xt.current = t, t.addEventListener("flow", (e) => {
			let t = JSON.parse(e.data);
			Ve((e) => e.some((e) => e.seq === t.seq) ? e : [...e, t]);
		}), t.addEventListener("complete", async () => {
			t.close(), xt.current = null, Ue(!1);
			try {
				await sn(e);
				let t = await U("/api/cases");
				z(t.slice(0, 20));
			} catch (e) {
				R(e.message);
			}
		}), t.onerror = () => {
			R("Live connection interrupted. Stored events can be reloaded from the case list.");
		};
	}
	async function ln() {
		R(""), ct(null), o("architecture"), Ve([]), Qe(null), Xe(null), Ue(!0);
		let n = Ae.trim() === "Reconcile the selected synthetic period" || !Ae.trim() ? `Reconcile ${sr(P)}` : Ae.trim();
		if (t) e.action({
			type: "run",
			message: n,
			scenario: ye,
			period: P,
			pace: Te
		});
		else try {
			let e = await U("/api/runs", "POST", {
				message: n,
				scenario: ye,
				user_id: "finance.user",
				demo_pace_ms: Te
			});
			if (e.follow_up) {
				Ue(!1), R(e.follow_up);
				return;
			}
			Le(e.case_id), Pe({
				case_id: e.case_id,
				scenario: e.scenario,
				scope: e.scope,
				status: "running"
			}), cn(e.case_id);
		} catch (e) {
			Ue(!1), R(e.message);
		}
	}
	async function un(n) {
		if (we(n), te(n), ie(null), t) e.action({
			type: "report",
			period: n
		});
		else try {
			let e = I?.scope?.period === n ? `?case_id=${encodeURIComponent(I.case_id)}` : "";
			ie(await U(`/api/reports/${n}${e}`));
		} catch (e) {
			R(e.message), te(null);
		}
	}
	(0, _.useEffect)(() => {
		t ? f(e.data?.conditions || []) : U("/api/conditions").then(f).catch(() => {});
	}, [t, e?.data?.conditions]);
	async function fn(n, i) {
		if (R(""), t) e.action({
			type: "condition",
			period: n,
			condition: i
		});
		else try {
			await U("/api/conditions", "POST", {
				period: n,
				condition: i
			});
			let e = await U("/api/history");
			r((t) => ({
				...t,
				history: e
			})), D && un(D);
		} catch (e) {
			R(e.message);
		}
	}
	function pn() {
		te(null), ie(null), t && e.action({
			type: "report",
			period: null
		});
	}
	(0, _.useEffect)(() => {
		t && D && e.data?.report?.period === D && ie(e.data.report);
	}, [
		t,
		D,
		e?.data?.report
	]), (0, _.useEffect)(() => {
		try {
			localStorage.setItem("finance.showTech", w ? "1" : "0");
		} catch {}
	}, [w]), (0, _.useEffect)(() => {
		pr.includes(a) && (E.current = a);
	}, [a]), (0, _.useEffect)(() => {
		if (t) {
			let t = e.data || {};
			t.agents && m(t.agents), t.agent_plan && t.agent_plan.plan_id !== h?.plan_id && (g(t.agent_plan), y(!1), t.agent_plan.period_source === "request" && t.agent_plan.effective_period && we(t.agent_plan.effective_period));
		} else U("/api/agent/catalog").then(m).catch(() => {});
	}, [
		t,
		e?.data?.agents,
		e?.data?.agent_plan
	]);
	async function mn(n) {
		R(""), oe("app"), o("agents"), y(!0);
		let i = ++Ce.current;
		if (t) e.action({
			type: "agent_plan",
			message: n,
			scenario: ye,
			case_id: I?.case_id || null,
			period: P
		});
		else try {
			let e = await U("/api/agent/plan", "POST", {
				message: n,
				scenario: ye,
				user_id: "finance.user",
				case_id: I?.case_id || null,
				period: P,
				demo_pace_ms: 0
			});
			if (i !== Ce.current) return;
			if (e.period_source === "request" && e.effective_period && e.effective_period !== P && we(e.effective_period), g(e), Nt((e) => e + 1), e.trace_case_id && !e.case_id && (Le(e.trace_case_id), Ve(await U(`/api/architecture/events?case_id=${encodeURIComponent(e.trace_case_id)}`)), Qe(null)), e.case_id) {
				await sn(e.case_id);
				let t = await U("/api/history");
				r((e) => ({
					...e,
					history: t
				})), z((await U("/api/cases")).slice(0, 20));
			}
		} catch (e) {
			R(e.message);
		} finally {
			y(!1);
		}
	}
	function hn(e, t) {
		if (!e?.id) return;
		x({
			id: e.id,
			name: e.name,
			role: e.role,
			tools: e.tools || []
		});
		let n = t?.view || e.view, r = t?.ref?.period || I?.scope?.period || Et?.available_periods?.at(-1);
		if (n === "run") o("architecture");
		else if (n === "report") un(r);
		else if (n === "evidence-proof") Sn("proof");
		else if (n === "decision-responsibilities") o("mcp");
		else if (typeof n == "string" && n.startsWith("module:")) {
			let [, e, t] = n.split(":"), r = i.byId[e];
			r?.tab && o(r.tab.id), e === "treasury" && t && jt(t);
		} else o("business");
	}
	function gn(e) {
		let t = [
			...i.tabs.map((e) => e.tab.id),
			"agents",
			"architecture"
		], n = t.findIndex((e) => e === "architecture" ? pr.includes(a) : a === e), r = null;
		if (e.key === "ArrowRight" && (r = (n + 1) % t.length), e.key === "ArrowLeft" && (r = (n + t.length - 1) % t.length), r === null) return;
		e.preventDefault();
		let s = t[r], c = e.currentTarget;
		o(s === "architecture" ? E.current : s), requestAnimationFrame(() => c.querySelectorAll("[role=tab]")[r]?.focus());
	}
	async function _n() {
		if (pt !== "approver") R("Switch to the synthetic finance approver lane first.");
		else if (t) e.action({
			type: "approve",
			case_id: I?.case_id,
			role: pt
		});
		else try {
			let e = (await U("/api/proposals")).find((e) => e.case_id === I?.case_id && e.status === "awaiting_approval");
			if (!e) {
				R("No pending synthetic proposal for this case.");
				return;
			}
			let t = await U("/api/decisions", "POST", {
				proposal_id: e.proposal_id,
				approver_id: "finance.approver",
				approved: !0,
				payload_hash: e.payload_hash,
				case_version: e.case_version
			});
			Ne((e) => [...e, {
				role: "assistant",
				text: `Approval result: ${t.status}. Synthetic variance marker ${t.document_number || "not created"}.`
			}]), Ve(await U(`/api/architecture/events?case_id=${encodeURIComponent(I.case_id)}`)), it(await U("/api/proposals"));
		} catch (e) {
			R(e.message);
		}
	}
	async function vn(n) {
		if (I?.case_id) {
			if (R(""), ft(!0), t) e.action({
				type: "investigate",
				case_id: I.case_id,
				fault_profile: n
			});
			else try {
				let e = await U("/api/investigations", "POST", {
					case_id: I.case_id,
					fault_profile: n
				});
				ct(e), Le(e.case_id), Qe(null), Ve(await U(`/api/architecture/events?case_id=${encodeURIComponent(e.case_id)}`));
			} catch (e) {
				R(e.message);
			} finally {
				ft(!1);
			}
		}
	}
	async function yn(n) {
		if (R(""), ft(!0), t) e.action({
			type: "reprocess",
			investigation_id: n,
			operator_id: "finance.operator"
		});
		else try {
			let e = await U(`/api/investigations/${n}/reprocess`, "POST", { operator_id: "finance.operator" });
			e.after?.case_id && await sn(e.after.case_id), ct(e);
			let t = await U("/api/history");
			r((e) => ({
				...e,
				history: t
			})), z((await U("/api/cases")).slice(0, 20)), Ne((t) => [...t, {
				role: "assistant",
				text: e.reason
			}]);
		} catch (e) {
			R(e.message);
		} finally {
			ft(!1);
		}
	}
	async function bn(n) {
		t ? (e.action({
			type: "load_case",
			case_id: n
		}), o("architecture")) : (Le(n), Ve(await U(`/api/architecture/events?case_id=${encodeURIComponent(n)}`)), Qe(null), o("architecture"));
	}
	async function xn(n, r, i) {
		if (o("questions"), R(""), bt(!0), vt(null), t) e.action({
			type: "decision_run",
			question_id: n,
			route: r,
			probe: i
		});
		else try {
			let e = await U("/api/architecture/questions/runs", "POST", {
				question_id: n,
				route: r,
				probe: i
			});
			vt(e);
		} catch (e) {
			R(e.message), bt(!1);
		}
	}
	function Sn(e = "proof", t = {}) {
		_e((n) => ({
			section: e,
			...t,
			nonce: n.nonce + 1
		})), o("evidence");
	}
	function Cn(e) {
		ue(!1), j(!1), e === "launchpad" ? oe("launchpad") : (oe("app"), o(e === "agent" ? "agents" : e));
	}
	let wn = /* @__PURE__ */ (0, A.jsx)("footer", {
		className: "app-footer",
		children: /* @__PURE__ */ (0, A.jsxs)("span", { children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: "Demo and learning purposes only." }), " Synthetic finance data; no live SAP or cloud system is connected."] })
	});
	return ((e) => /* @__PURE__ */ (0, A.jsx)(ne, {
		value: i,
		children: e
	}))(ae === "launchpad" ? /* @__PURE__ */ (0, A.jsxs)("div", {
		className: `app-shell launchpad-shell ${t ? "embedded" : ""}`,
		children: [
			/* @__PURE__ */ (0, A.jsxs)("header", {
				className: "shell-header launchpad-header",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "brand",
					children: [/* @__PURE__ */ (0, A.jsx)(ur, {
						menuModules: i.modules,
						open: le,
						onToggle: () => ue((e) => !e),
						onNavigate: Cn
					}), /* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
						className: "brand-overline",
						children: "SAP FINANCE AGENT COCKPIT / LOCAL DEMO"
					}), /* @__PURE__ */ (0, A.jsx)("h1", { children: "My Home" })] })]
				}), /* @__PURE__ */ (0, A.jsx)("div", {
					className: "header-meta",
					children: /* @__PURE__ */ (0, A.jsx)("span", {
						className: "pill simulated",
						children: "LOCAL SIMULATION"
					})
				})]
			}),
			/* @__PURE__ */ (0, A.jsx)(Yn, {
				period: P,
				periods: Et?.available_periods,
				onPeriod: we,
				periodCount: Et?.available_periods?.length || 12,
				localBundle: n?.local_bundle,
				onOpenApp: () => {
					o("business"), oe("app");
				},
				onOpenAgents: () => {
					o("agents"), oe("app");
				},
				onOpenArchitecture: () => {
					o(E.current), oe("app");
				},
				onOpenTreasury: () => {
					o("treasury"), oe("app");
				},
				onAsk: mn,
				onGo: (e) => {
					o(e === "live" ? "architecture" : e), oe("app");
				}
			}),
			wn
		]
	}) : /* @__PURE__ */ (0, A.jsxs)("div", {
		className: `app-shell ${t ? "embedded" : ""} ${w ? "" : "tech-off"}`,
		children: [
			/* @__PURE__ */ (0, A.jsxs)("header", {
				className: "shell-header",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "brand",
					children: [
						/* @__PURE__ */ (0, A.jsx)("button", {
							type: "button",
							className: "shell-home",
							onClick: () => Cn("launchpad"),
							"aria-label": "Back to Finance Launchpad",
							children: "⌂"
						}),
						/* @__PURE__ */ (0, A.jsx)(ur, {
							menuModules: i.modules,
							open: le,
							onToggle: () => ue((e) => !e),
							onNavigate: Cn
						}),
						/* @__PURE__ */ (0, A.jsx)("span", {
							className: "brand-mark",
							"aria-hidden": "true",
							children: "F"
						}),
						/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
							className: "brand-overline",
							children: "HOME / FINANCE / AGENT COCKPIT"
						}), /* @__PURE__ */ (0, A.jsx)("h1", { children: "SAP Finance Agent Cockpit" })] })
					]
				}), /* @__PURE__ */ (0, A.jsxs)("div", {
					className: "header-meta",
					children: [
						/* @__PURE__ */ (0, A.jsx)("span", {
							className: "pill simulated",
							children: "LOCAL SIMULATION"
						}),
						/* @__PURE__ */ (0, A.jsx)("span", { className: "header-separator" }),
						/* @__PURE__ */ (0, A.jsx)(N, {
							period: P,
							periods: Et?.available_periods,
							onPeriod: we,
							id: "global-period"
						}),
						/* @__PURE__ */ (0, A.jsx)("span", { className: "header-separator" }),
						/* @__PURE__ */ (0, A.jsxs)("label", {
							className: "tech-toggle",
							children: [/* @__PURE__ */ (0, A.jsx)("input", {
								type: "checkbox",
								checked: w,
								onChange: (e) => T(e.target.checked)
							}), " Technical details"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, A.jsx)("div", {
				className: "tab-nav four",
				style: { gridTemplateColumns: `repeat(${i.tabs.length + 2},minmax(0,1fr))` },
				role: "tablist",
				"aria-label": "Application sections",
				onKeyDown: gn,
				children: [
					...i.tabs.map((e) => [
						e.tab.id,
						e.tab.icon,
						e.tab.label,
						e.tab.short
					]),
					[
						"agents",
						"◆",
						"Agents",
						"Agents"
					],
					[
						"architecture",
						"⬡",
						"Architecture",
						"Design"
					]
				].map(([e, t, n, r]) => {
					let i = e === "architecture" ? pr.includes(a) : a === e;
					return /* @__PURE__ */ (0, A.jsxs)("button", {
						type: "button",
						role: "tab",
						tabIndex: i ? 0 : -1,
						"aria-selected": i,
						className: i ? "active" : "",
						onClick: () => o(e === "architecture" ? E.current : e),
						children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "tab-icon",
								"aria-hidden": "true",
								children: t
							}),
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "tab-label-full",
								children: n
							}),
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "tab-label-mobile",
								children: r
							})
						]
					}, e);
				})
			}),
			(a === "evidence" || a === "questions") && /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "detail-return-bar",
				children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
					className: "eyebrow",
					children: "ON-DEMAND DETAIL"
				}), /* @__PURE__ */ (0, A.jsx)("strong", { children: a === "evidence" ? "Evidence & correlation" : "Architecture questions" })] }), /* @__PURE__ */ (0, A.jsxs)("button", {
					type: "button",
					onClick: () => o(se.current),
					children: ["← Back to ", {
						business: "Execution simulator",
						treasury: "Cash & treasury",
						ontology: "Ontology",
						architecture: "Live architecture",
						approaches: "Complete architecture",
						agenthost: "Agent hosting",
						brief: "Decision brief",
						diagrams: "Architecture diagrams",
						mcp: "MCP hosting",
						agents: "Agents"
					}[se.current]]
				})]
			}),
			tt && /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "error-banner",
				role: "alert",
				children: [
					/* @__PURE__ */ (0, A.jsx)("strong", { children: "Needs attention" }),
					/* @__PURE__ */ (0, A.jsx)("span", { children: tt }),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: () => R(""),
						"aria-label": "Dismiss error",
						children: "×"
					})
				]
			}),
			pr.includes(a) && /* @__PURE__ */ (0, A.jsx)("div", {
				className: "surface decision-nav",
				role: "tablist",
				"aria-label": "Architecture views",
				children: [
					[
						"architecture",
						"Live run",
						"Replay a run through the architecture"
					],
					[
						"approaches",
						"Complete architecture",
						"Three scenarios end to end"
					],
					[
						"mcp",
						"MCP hosting",
						"How the MCP is exposed, hosted and run"
					],
					[
						"agenthost",
						"Agent hosting",
						"Where the finance agent runs"
					],
					[
						"registry",
						"Registry",
						"Where agents and MCP servers are catalogued"
					],
					[
						"brief",
						"Decision brief",
						"What is open, who owns it"
					],
					[
						"ontology",
						"Ontology",
						"Concepts and how the agents use them"
					],
					[
						"diagrams",
						"Diagrams",
						"Ten generated diagrams, zoom and export"
					]
				].map(([e, t, n]) => /* @__PURE__ */ (0, A.jsxs)("button", {
					type: "button",
					role: "tab",
					"aria-selected": a === e,
					className: a === e ? "active" : "",
					onClick: () => o(e),
					children: [t, /* @__PURE__ */ (0, A.jsx)("small", { children: n })]
				}, e))
			}),
			b && /* @__PURE__ */ (0, A.jsxs)("div", {
				className: "agent-ribbon",
				role: "status",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("strong", { children: [
						"Opened by the ",
						b.name,
						" agent"
					] }),
					/* @__PURE__ */ (0, A.jsx)("span", { children: b.role }),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: () => {
							o("agents"), x(null);
						},
						children: "Back to Agents"
					}),
					/* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: () => x(null),
						"aria-label": "Dismiss agent banner",
						children: "Dismiss"
					})
				]
			}),
			At && /* @__PURE__ */ (0, A.jsx)(Ie, {
				data: Vt,
				period: P,
				periods: Et?.available_periods,
				onPeriod: we,
				role: pt,
				onDecision: Ht,
				onAsk: mn,
				refs: p?.domains?.treasury?.references,
				initial: At,
				onClose: () => jt(null)
			}),
			D && /* @__PURE__ */ (0, A.jsx)(Pn, {
				report: re,
				period: D,
				periods: Et?.available_periods,
				onPeriod: un,
				onClose: pn
			}),
			It ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [
				/* @__PURE__ */ (0, A.jsx)(Kn, {
					onAsk: mn,
					busy: v,
					period: P,
					periods: Et?.available_periods,
					domain: It.id,
					label: `Ask the ${It.short_name} agents`
				}),
				Yt(It.id),
				It.renderer === "treasury" ? /* @__PURE__ */ (0, A.jsx)(Oe, {
					period: P,
					periods: Et?.available_periods,
					data: Vt,
					state: Bt("treasury"),
					role: pt,
					onRole: mt,
					onOpenDetail: jt,
					onDecision: Ht,
					onAsk: mn
				}) : /* @__PURE__ */ (0, A.jsx)(Se, {
					module: It,
					period: P,
					view: zt(It.id),
					state: Bt(It.id),
					onAsk: mn
				})
			] }) : a === "business" ? /* @__PURE__ */ (0, A.jsxs)(A.Fragment, { children: [/* @__PURE__ */ (0, A.jsx)(Kn, {
				onAsk: mn,
				busy: v,
				period: P,
				periods: Et?.available_periods,
				domain: "reconciliation"
			}), /* @__PURE__ */ (0, A.jsx)(ze, {
				period: P,
				onPeriod: we,
				onOpenReport: un,
				onAsk: () => mn(i.ask("reconciliation", P)),
				banner: Yt("reconciliation"),
				conditions: d,
				onCondition: fn,
				history: Et,
				cases: nt,
				currentCase: I,
				proposal: en,
				role: pt,
				onRole: mt,
				approve: _n,
				onOpenEvidence: () => Sn("finance"),
				summary: kt,
				periodPanel: /* @__PURE__ */ (0, A.jsx)(mr, {
					result: I?.result,
					period: P,
					summary: kt,
					summaryState: $t,
					onAskPeriod: () => mn(i.ask("reconciliation", P)),
					onOpenDetail: () => un(P),
					onOpenEvidence: () => Sn("finance"),
					onRunCurrent: () => mn(i.ask("reconciliation", P))
				}),
				extrasRight: st ? /* @__PURE__ */ (0, A.jsx)(Be, {
					investigation: st,
					onOpen: () => Sn("proof")
				}) : null,
				extrasLeft: /* @__PURE__ */ (0, A.jsx)(A.Fragment, { children: I?.result?.variance?.amount !== null && I?.result?.variance?.amount !== void 0 && Number(I.result.variance.amount) !== 0 && st?.case_id !== I.case_id && /* @__PURE__ */ (0, A.jsxs)("section", {
					className: "surface action-strip",
					children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
						/* @__PURE__ */ (0, A.jsx)("span", {
							className: "eyebrow",
							children: "CONTROLLED WRITE BRANCH"
						}),
						/* @__PURE__ */ (0, A.jsx)("strong", { children: "Signed variance marker requires separate approval" }),
						/* @__PURE__ */ (0, A.jsx)("p", { children: "A comparable nonzero variance may create a local marker proposal." })
					] }), /* @__PURE__ */ (0, A.jsx)("button", {
						type: "button",
						onClick: () => mn("Propose an adjustment"),
						children: "Ask the agents to propose a variance marker"
					})]
				}) })
			})] }) : a === "agents" ? /* @__PURE__ */ (0, A.jsx)(Jn, {
				catalog: p,
				plan: h,
				busy: v,
				onAsk: mn,
				onOpenLayer: hn,
				onOpenConcept: Jt,
				onOpenOutput: Zt,
				ontology: H,
				period: P,
				periods: Et?.available_periods
			}) : a === "architecture" ? /* @__PURE__ */ (0, A.jsxs)("main", {
				className: "architecture-layout",
				children: [
					/* @__PURE__ */ (0, A.jsxs)("section", {
						className: "surface command-bar",
						children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [
							/* @__PURE__ */ (0, A.jsx)("span", {
								className: "eyebrow",
								children: "EXTERNAL AGENT → SAP FINANCE"
							}),
							/* @__PURE__ */ (0, A.jsx)("h2", { children: "Follow an external agent into SAP" }),
							/* @__PURE__ */ (0, A.jsx)("p", { children: "This simulator replays one synthetic reconciliation through the selected scenario: S1 and S3 call Apigee directly, S2 passes AgentCore Gateway and then Apigee. The full topology is in the Diagrams tab (D2 to D4)." }),
							/* @__PURE__ */ (0, A.jsx)("button", {
								type: "button",
								className: "text-link architecture-question-link",
								onClick: () => o("questions"),
								children: "Review open architecture questions →"
							})
						] }), /* @__PURE__ */ (0, A.jsxs)("div", {
							className: "command-controls",
							children: [
								/* @__PURE__ */ (0, A.jsxs)("label", { children: ["Business intent", /* @__PURE__ */ (0, A.jsx)("input", {
									value: Ae,
									onChange: (e) => je(e.target.value),
									"aria-label": "Business intent"
								})] }),
								/* @__PURE__ */ (0, A.jsxs)("label", { children: ["Period", /* @__PURE__ */ (0, A.jsx)("select", {
									value: P,
									onChange: (e) => we(e.target.value),
									children: (Et?.available_periods || ["2026-11"]).map((e) => /* @__PURE__ */ (0, A.jsx)("option", {
										value: e,
										children: sr(e)
									}, e))
								})] }),
								/* @__PURE__ */ (0, A.jsxs)("label", { children: ["Route", /* @__PURE__ */ (0, A.jsxs)("select", {
									value: ye,
									onChange: (e) => be(e.target.value),
									disabled: He,
									children: [
										/* @__PURE__ */ (0, A.jsx)("option", {
											value: "S1",
											children: "S1 · SAP-centric"
										}),
										/* @__PURE__ */ (0, A.jsx)("option", {
											value: "S2",
											children: "S2 · AWS AgentCore-centric"
										}),
										/* @__PURE__ */ (0, A.jsx)("option", {
											value: "S3",
											children: "S3 · SAP-hosted hybrid"
										})
									]
								})] }),
								/* @__PURE__ */ (0, A.jsxs)("label", { children: ["Pace", /* @__PURE__ */ (0, A.jsxs)("select", {
									value: Te,
									onChange: (e) => Ee(Number(e.target.value)),
									children: [
										/* @__PURE__ */ (0, A.jsx)("option", {
											value: 30,
											children: "Fast"
										}),
										/* @__PURE__ */ (0, A.jsx)("option", {
											value: 60,
											children: "Normal"
										}),
										/* @__PURE__ */ (0, A.jsx)("option", {
											value: 120,
											children: "Slow"
										})
									]
								})] }),
								/* @__PURE__ */ (0, A.jsx)("button", {
									type: "button",
									className: "primary",
									onClick: ln,
									disabled: He,
									children: He ? "Running…" : "Run architecture"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, A.jsxs)("section", {
						className: "surface route-panel",
						children: [
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: "section-heading",
								children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
									className: "eyebrow",
									children: "COMPONENT COMMUNICATION"
								}), /* @__PURE__ */ (0, A.jsx)("h2", { children: He ? "Processing live" : I?.status === "complete" ? "Case complete" : "Architecture ready" })] }), /* @__PURE__ */ (0, A.jsxs)("div", {
									className: "route-actions",
									children: [
										/* @__PURE__ */ (0, A.jsx)("span", {
											className: "pill quiet tech",
											children: Fe || "No trace selected"
										}),
										/* @__PURE__ */ (0, A.jsx)("button", {
											type: "button",
											onClick: () => {
												Qe(-1), Xe(null), et(!0);
											},
											disabled: !Re.length,
											children: "Replay"
										}),
										/* @__PURE__ */ (0, A.jsx)("button", {
											type: "button",
											onClick: () => et(!1),
											disabled: !L,
											children: "Pause"
										}),
										/* @__PURE__ */ (0, A.jsx)("button", {
											type: "button",
											onClick: () => {
												et(!1), Qe(null), Xe(null);
											},
											disabled: Ze === null,
											children: "Live"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, A.jsx)(gr, {
								registry: Tt,
								events: nn,
								scenario: ye,
								selectedZone: We,
								onZone: (e) => {
									Ge(e), qe(null);
								},
								viewportRef: St,
								liveRunning: He,
								reportReady: !!I?.result?.variance,
								onOpenReport: () => M(!0)
							}),
							/* @__PURE__ */ (0, A.jsxs)("div", {
								className: "flow-caption",
								children: [
									/* @__PURE__ */ (0, A.jsx)("span", { className: `status-dot ${He ? "pulsing" : ""}` }),
									" ",
									/* @__PURE__ */ (0, A.jsx)("strong", { children: rn ? `${rn.status === "denied" ? "Control denied" : "Handoff recorded"} · ${ar[on || We] || on || We}` : "Awaiting a business question" }),
									/* @__PURE__ */ (0, A.jsx)("span", { children: ar[on] || "Select a route zone" }),
									/* @__PURE__ */ (0, A.jsxs)("span", {
										className: "tech",
										children: [Re.length, " stored events"]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, A.jsx)(ir, {
						events: nn,
						running: He,
						selectedZone: ar[We] || We,
						onOpenEvidence: () => Sn("components")
					}),
					/* @__PURE__ */ (0, A.jsxs)("section", {
						className: "surface case-strip",
						children: [/* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
							className: "eyebrow",
							children: "STORED CASES"
						}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "Replay an earlier run" })] }), /* @__PURE__ */ (0, A.jsxs)("div", {
							className: "case-buttons",
							children: [nt.slice(0, 8).map((e) => /* @__PURE__ */ (0, A.jsxs)("button", {
								type: "button",
								onClick: () => sn(e.case_id),
								children: [
									sr(e.scope?.period),
									" · ",
									e.scenario,
									" · ",
									e.status
								]
							}, e.case_id)), !nt.length && /* @__PURE__ */ (0, A.jsx)("span", {
								className: "micro",
								children: "No completed case yet."
							})]
						})]
					})
				]
			}) : a === "questions" ? /* @__PURE__ */ (0, A.jsx)($e, {
				questions: n?.decision_questions || [],
				routePlaybooks: n?.route_playbooks || {},
				focus: pe,
				run: _t,
				onRun: xn,
				busy: yt,
				onOpenEvidence: (e) => Sn("questions", { stepSeq: e })
			}) : a === "ontology" ? /* @__PURE__ */ (0, A.jsx)(me, {
				ontology: H,
				references: Kt,
				focus: Wt,
				onOpenTab: (e) => o(e)
			}) : a === "brief" ? /* @__PURE__ */ (0, A.jsx)(dn, {
				onComplete: () => o("approaches"),
				onMcp: () => o("mcp"),
				onAgentHosting: () => o("agenthost")
			}) : a === "registry" ? /* @__PURE__ */ (0, A.jsx)(tn, {
				onMcp: () => o("mcp"),
				onAgentHosting: () => o("agenthost"),
				onDiagrams: (e) => {
					c(e), o("diagrams");
				}
			}) : a === "agenthost" ? /* @__PURE__ */ (0, A.jsx)(Xt, {
				onMcp: () => o("mcp"),
				onComplete: () => o("approaches"),
				onRegistry: () => o("registry")
			}) : a === "mcp" ? /* @__PURE__ */ (0, A.jsx)(qt, {
				view: l,
				onView: u,
				onApproaches: () => o("approaches"),
				onAgentHosting: () => o("agenthost"),
				onRegistry: () => o("registry"),
				onDetailed: (e) => {
					c({
						S1: "D2",
						S2: "D3",
						S3: "D4"
					}[e] || e), o("diagrams");
				}
			}) : a === "diagrams" ? /* @__PURE__ */ (0, A.jsx)(Pt, {
				view: s,
				onView: c,
				onBack: () => o("approaches")
			}) : a === "approaches" ? /* @__PURE__ */ (0, A.jsx)(Rt, {
				playbooks: n?.route_playbooks || {},
				onQuestion: () => o("questions"),
				onDetailedDiagram: (e) => {
					c({
						S1: "D2",
						S2: "D3",
						S3: "D4"
					}[e] || e), o("diagrams");
				},
				onGovernance: (e) => {
					u(e), o("mcp");
				},
				onAgentHosting: () => o("agenthost")
			}) : /* @__PURE__ */ (0, A.jsx)(Ye, {
				investigation: st,
				currentCase: I,
				history: Et,
				busy: dt,
				onStart: vn,
				onResolve: yn,
				onTrace: bn,
				historyDetail: at,
				events: st?.case_id === I?.case_id && lt.length ? lt : Re,
				caseEvents: Re,
				decisionRun: _t,
				decisionQuestions: n?.decision_questions || [],
				focus: ge,
				componentDetails: /* @__PURE__ */ (0, A.jsx)(_r, {
					registry: Tt,
					zone: We,
					events: nn,
					selectedComponent: Ke,
					onComponent: qe,
					scenario: ye
				}),
				reviewPanel: /* @__PURE__ */ (0, A.jsxs)("section", {
					className: "surface architect-review",
					children: [
						/* @__PURE__ */ (0, A.jsx)("div", {
							className: "section-heading",
							children: /* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("span", {
								className: "eyebrow",
								children: "CROSS-DISCIPLINE REVIEW"
							}), /* @__PURE__ */ (0, A.jsx)("h2", { children: "Architect questions to test" })] })
						}),
						/* @__PURE__ */ (0, A.jsx)("div", {
							className: "review-list",
							children: or.map(([e, t]) => /* @__PURE__ */ (0, A.jsxs)("div", { children: [/* @__PURE__ */ (0, A.jsx)("strong", { children: e }), /* @__PURE__ */ (0, A.jsx)("span", { children: t })] }, e))
						}),
						/* @__PURE__ */ (0, A.jsx)("p", {
							className: "micro",
							children: "Vendor-named stages are simulations. G1–G7 remain open pending tenant evidence."
						})
					]
				})
			}),
			wn,
			ve && /* @__PURE__ */ (0, A.jsx)(hr, {
				caseRecord: I,
				onClose: () => M(!1),
				onOpenEvidence: () => Sn("finance")
			})
		]
	}));
}
// src/streamlit.jsx
var yr = /* @__PURE__ */ new WeakMap(), br = [], xr = null, Sr = null, Cr = 0;
function wr() {
	if (xr || !br.length || !Sr) return;
	xr = br.shift();
	let e = xr;
	Sr("action", {
		...e.payload,
		_seq: e.seq
	}), e.timer = setTimeout(() => {
		xr === e && (xr = null, wr());
	}, 12e3);
}
function Tr(e) {
	e?.type === "select_period" && (br = br.filter((e) => e.payload.type !== "select_period")), br.push({
		payload: e,
		seq: ++Cr
	}), wr();
}
function Er(e) {
	xr && typeof e == "number" && e >= xr.seq && (clearTimeout(xr.timer), xr = null, wr());
}
function Dr(e) {
	let { parentElement: t, data: n, setTriggerValue: r } = e, i = t.querySelector(".finance-root");
	if (!i) throw Error("Missing finance component mount");
	let a = yr.get(t);
	return a || (a = (0, v.createRoot)(i), yr.set(t, a)), Sr = r, Er(n?.action_seq), a.render(/* @__PURE__ */ (0, A.jsx)(vr, { bridge: {
		data: n || {},
		action: Tr
	} })), () => {
		let e = yr.get(t);
		e && (e.unmount(), yr.delete(t));
	};
}
export { Dr as default };
